#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    int n,arr[1000],i;
    scanf("%d",&n);
    if(n<=1000 && n>=1){
        for(i=0;i<n;i++){
            scanf("%d",&arr[i]);
            if(arr[i]>10000 || arr[i]<1)
                return -1;
        }
        
        for(i=n-1;i>=0;i--)
            printf("%d ",arr[i]);
    }
    return 0;
}

