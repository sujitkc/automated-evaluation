//3/5
#include<stdio.h>
#include<stdlib.h>
int *a;
int main(void) {
	int n,i,j;
	printf("enter the no of element:");
	scanf("%d",&n);
	a=(int *)malloc(n*sizeof(int));
	for(i=0;i<n;i++){
		printf("enter the value:");
		scanf("%d",&a[i]);
	}
	printf("reverse will  be:");
	for(j=n-1;j<0;j--){
		printf("%d",a[j]);
	}
	return 0;
}

