//2/5
#include<stdio.h>
main()
    {
    int n;
  
    printf("enter n value\n");
    scanf("%d",&n);
    int arr[n],i;
    
    for(i=n;i<1;i--)
       printf("%d ",arr[i]);
    return 0;
}

