//3/5
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main()
{
   int n, c, d, a[100], b[100];
 
   printf(" ");
   scanf("%d",&n);
 
   for (c = 0; c < n ; c++)
      scanf("%d",&a[c]);
 
  
 
   
}
