//3/5
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
int main(){
    int n,temp; 
    scanf("%d",&n);
    int arr_i;
    int *arr = malloc(sizeof(int) * n);
    for(arr_i = 0; arr_i < n; arr_i++){
       scanf("%d",&arr[arr_i]);
    }
    for(arr_i = 0; arr_i < n; arr_i++){
        temp=arr_i;
        arr_i=arr_i+1;
        arr_i =temp - 1;
}
    return 0;
}

