//3/5
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n,v[n]; 
    scanf("%d",&n);
    int arr[n] ;
    for(int arr_i = 0; arr_i < n; arr_i++){
       scanf("%d",&arr[arr_i]);
    }
    for(int i=n-1;i>=0;i--)
        {
         v[n-1-i]=arr[i];
        }
    
    printf("%d %d %d %d",v[0],v[1],v[2],v[3]);
    return 0;
}

