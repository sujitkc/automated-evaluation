//4/5
#include <stdio.h>
int main()
{
    int A[10000];
    int N,i;
    printf("\n Enter the no. of elements: ");
    scanf("%d",&N);
    if((N>=1)&&(N<=1000))
    {
        for(i=0;i<N;i++)
        {
            scanf(" %d",&A[i]);
        }
        for(i=(N-1);i>=0;i++)
        {
            printf(" %d",A[i]);
        }
    }
    else
    {
        printf("\n Limit exceeded");
    }
    return 0;
}
