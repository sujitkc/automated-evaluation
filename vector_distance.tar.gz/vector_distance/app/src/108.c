//3/5
#include <stdio.h>
int main(){
    int n,i,a[100];
    printf("\n enter the noof elements");
    scanf("%d",&n);
    printf("enter the elements");
    for(i=0;i<n;i++)
        scanf("%d",a[i]);
    for(i=0;i<n;i++){
        a[i]=a[n-i-1];
     printf("\n reverse elements are %d",a[i]);
    }
    return 0;
}

