//1/5
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int a[4]={1,4,3,2},i; 
   
  
    for(int i = 4; i >=0; i++){
       scanf("%d",&a[i]);
    }
    return 0;
}

