//3/5
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main()
{
    int A[10000],N,i;
    scanf("%d",&N);
    printf("\n");
    for(i=0;i<=N;i++)
    {
        scanf("%d",&A[i]);
        printf(" ");
    }
    printf("\n");
    for(i=N-1;i>=0;i--);
    printf("%d ",A[i]);
    return 0;
}

