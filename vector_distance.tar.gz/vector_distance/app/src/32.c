//1/5
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n=5,a[4],i; 
    
    
    
    for(i=0;i<n;i++)
        {
         scanf("%d",&a[i]);
    }
 
   
    for(i=4; i >0; i--){
       printf("%d\t",a[i]);
    }
    return 0;
}

