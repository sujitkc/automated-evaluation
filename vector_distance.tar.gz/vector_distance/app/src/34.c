//3/5
#include <stdio.h>
#define M 30
int main()
    { int a[M],n,i;
       printf("\nEnter how many elements to enter: ");
       scanf("%d",&n);
       printf("\nEnter elements: ");
       for(i=0;i<n;i++) scanf("%d",&a[i]);
       printf("\nElemnts in reverse order: ");
       for(i=n-1;i>=0;i--) printf("%d ",a[i]);
       return 0;
    }
