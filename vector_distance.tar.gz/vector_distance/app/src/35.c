//3/5
#include<stdio.h>

int main()
{
   int N,A[N],i,j,t;
    printf("enter length of array\n");
    scanf("%d",&N);

    for(i=0;i<N;i++)
        scanf("%d",&A[i]);
   for(i=0,j=N-1;i<=j;i++,j--)
       {
     t=A[i];
     A[i]=A[j];
     A[j]=t;
 }
   
    printf("after reverse:\n");
    for(i=0;i<N;i++)
        printf("%4d",A[i]);
        
}

