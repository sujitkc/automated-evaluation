//1/5
#include<stdio.h>
main()
    {
    int a[4];
    int i;
    for(i=0;i<4;i++)
        {scanf("%d",&a[i]);}
    for(i=0;i<4;i++)
        {printf("%d",a[i]);}
}
