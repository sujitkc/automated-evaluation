//1/5
#include <stdio.h>

static const int array[] = {4,6,43,3,5,7,6,43,3,5,778};
static const unsigned int ARRAYSIZE = sizeof(array) / sizeof(int);

int main ()
{
    puts("Graham's simple attempt");
    
    for (int count = ARRAYSIZE; count >= 0; count--)
        printf ("%d ", array[count]);
        
    puts("");
    
    return 0;
}


