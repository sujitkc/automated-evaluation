//2/5
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n,i,arr_i,temp; 
    scanf("%d",&n);
    int *arr = malloc(sizeof(int) * n);
    for(arr_i = 0; arr_i < n; arr_i++){
       scanf("%d",&arr[arr_i]);
    }
    for(i=0;i<=n/2;i++)
        {
        temp=arr_i;
         }
    for(i=0;i<n;i++)
        printf("%d",arr_i);
    return 0;
}

