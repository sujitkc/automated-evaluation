//2/5
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>
#include<stdio.h>
 
int main() {
   int arr[30], i, j, num, temp;
 
   printf("\nEnter no of elements : ");
   scanf("%d", &num);
 
   
   for (i = 0; i < num; i++) {
      scanf("%d", &arr[i]);
   }
   
 
   
   printf("\nResult after reversal : ");
   for (i = num; i >=0; i--) {
      printf("%d \t", arr[i]);
   }

   return (0);
}
