//0/5

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
    int n,a[10]; 
    printf("enter n");
    scanf("%d",&n);
    printf("%d",n);
}

