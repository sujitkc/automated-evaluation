////3/5
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int ar[4];
    int n; 
    scanf("%d",&n);
    
    for(int i= 0; i < n;i++){
       scanf("%d",&ar[i]);
    }
    for(int i=3; i>=0 ;i--){
        printf("%d ",ar[i]);
    }
    return 0;
}

