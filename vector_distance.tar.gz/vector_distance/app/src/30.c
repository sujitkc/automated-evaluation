//2/5
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n; 
    scanf("%d",&n);
    int arr_j;
    int *arr = malloc(sizeof(int) * n);
    for(int arr_i = 0; arr_i < n; arr_i++){
       scanf("%d",&arr[arr_i]);
        {for(int arr_j=n; arr_j>=0; arr_j--)
            scanf("%d",&arr[arr_j]);
         arr[arr_j]=arr[arr_i];
        }
        printf("%d",arr[arr_j]);
        
        
            
    }
   
    return 0;
}

