//2/5
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>


int main(){
    int n,i;
    char a[100];
    scanf("%d",&n);
    for(i=0;i<n;i++)
        {
        gets(a);
    
       strrev(a);
       puts(a);
    }
        
    
    
  

    return 0;
}

