//3/5
#include <math.h>
#include <stdio.h>
#include <string.h>


int main(){
    int n,i,j,temp,a[40];
    printf("enter the number of variables to be used");
    scanf("%d",&n);
    for(i=0;i<n;i++)
        {
        printf("enter the value of a[%d]",i);
        scanf("%d",&a[i]);
    }
    printf("the normal array is \n");
    for(i=0;i<n;i++)
      {
        printf("a[%d]=%d\n",i,a[i]);
    }
    for(i=0,j=n-1;i<=j;i++,j--)
        {
        temp=a[i];
        a[i]=a[j];
    a[i]=temp;
    }
    printf("the array in reverse order is \n");
    for(i=0;i<n;i++)
        {
        printf("a[%d]= %d\n",i,a[i]);
    }
    }
    

