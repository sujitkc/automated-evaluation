//3/5
#include<stdio.h>
int main()
{
    int n,a[50],i;
    scanf("%d",&n);
    printf("\n");
        for(i=0;i<n;i++)
            {
                scanf("%d\t",&a[i]);
            }
        for(i=n-1;i>=0;i--)
        {
            printf("%d",a[i]);       
        }
return 0;
}
