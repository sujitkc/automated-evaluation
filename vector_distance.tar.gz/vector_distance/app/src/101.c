//3/5
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
   long int n; 
    scanf("%ld",&n);
   long int *arr = malloc(sizeof(long int) * n);
    for(long int arr_i = 0; arr_i < n; arr_i++){
       scanf("%ld",&arr[arr_i]);
    }
    for(long int arr_i = n-1; arr_i >=0; arr_i++){
       printf("%ld",&arr[arr_i]);
    }
    return 0;
}

