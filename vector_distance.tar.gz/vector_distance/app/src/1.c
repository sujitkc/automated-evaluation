//marks = 3/5
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n,j,temp,arr_i; 
    scanf("%d",&n);
    int *arr = malloc(sizeof(int) * n);
    for(int arr_i = 0; arr_i < n; arr_i++){
       scanf("%d\t",&arr[arr_i]);
    }
    j=arr_i-1;
    arr_i=0;
   while(arr_i< j){
       temp=arr[arr_i];
       arr[arr_i]=arr[j];
       arr[j]=temp;
      arr_i++;
       j--;
   }
    for(arr_i=0;arr_i<n;arr_i++){
        printf("%d\t",arr[arr_i]);
        }
    
    return 0;
}

