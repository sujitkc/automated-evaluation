//2/5
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n,i,a[i];
    for(i=0;i<n;i++)
        {
        scanf("%d",&a[i]);
        }
    for(i=0;i<n;i++)
        {
        printf("%d",a[i]);
       }
    for(i=n;i>0;i--)
        {
        printf("%d",a[i]);
    }
   return 0;
    }
    


