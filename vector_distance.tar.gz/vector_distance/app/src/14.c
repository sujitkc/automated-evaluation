//2/5
#include <stdio.h>
int main()
{
    int n,arr[4],i;
    //printf("enter no of integers\n");
    scanf("%d",&n);
    //printf("enter the integers\n");
    for(i=0;i<4;i++)
    scanf("%d",&arr[i]);
    for(i=3;i>=0;i--)    
    printf("%d ",arr[i]);
    return 0;   
    
}

