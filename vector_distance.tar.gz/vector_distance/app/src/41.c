//3/5
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
 int main()
{
     
     int n,i,j,a[100];
     scanf("%d/t",&n);
      for(i=0;i<n;i++)
            scanf("%d",&a[i]);
for(j=n-1;j>=n;j--)
    scanf("%d",&a[j]);
         return 0;
 }

