//4/5
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n,ar[100],i; 
    scanf("%d",&n);
    for(i=0;i<n;i++)
        scanf("%d",&ar[i]);
    for(i=n-1;i>=0;i--)
        printf(" %d",ar[i]);
    
    return 0;
}

