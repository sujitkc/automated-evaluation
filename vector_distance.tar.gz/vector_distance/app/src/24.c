//3/5
#include<stdio.h>
int main()
    {
    int a[10],b[10],i,j,n;
    printf("\n enter the size of array");
    scanf("%d",&n);
    if(n>10)
        printf("\n array out of bounds");
    else
        for(i=0;i<10;i++)
        {
        scanf("%d",&a[i]);
    }
    for(j=n-1;j>i;j--)
        {
        b[j]=a[i];
    }
    printf("\n reverse array is %d",b[j]);
}
