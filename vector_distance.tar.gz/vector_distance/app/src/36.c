//3/5
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
     int a[1000],n;
    int N,i;
    printf("ENTER NO OF INTEGERS");
    
    scanf("%d",&N);
    printf("%d",N);
        n=N;
    for(i=0;i<n;i++)
        {
        scanf("%d",&a[i]);
        
    }
    for(i=n-1;i>=0;i--)
        {
        printf("%d",&a[i]);
        printf(' ');
    }
    return 0;
}

