//4/5
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main() {
   int arr[100], i, j, num, temp;
 
   printf("\nhow many numbers to be printed ");
   scanf("%d", &num);
 
   for (i = 0; i < num; i++) {
      scanf("%d", &arr[i]);
   }
 
   j = i - 1;   //last element
   i = 0;       //first element
 
   while (i < j) {
      temp = arr[i];
      arr[i] = arr[j];
      arr[j] = temp;
      i++;            
      j--;             
   }
 
   printf("\nResult after reversal : ");
   for (i = 0; i < num; i++) {
      printf("%d \t", arr[i]);
   }
 
   return (0);
}

