//3/5
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main()
{
    int n; 
    scanf("%d",&n);
    int a[10],i;
    for( i = 0; i < n;i++)
    {
       scanf("%d",&a[i]);
    }
    return 0;
}

