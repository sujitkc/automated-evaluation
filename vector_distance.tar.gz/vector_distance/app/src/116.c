//0/5
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n=4,i;
    int arr[4]={1,4,3,2};
    for( i = n-1; i >=0 ; i--){
       printf("%d ",arr[i]);
    }
    return 0;
}

