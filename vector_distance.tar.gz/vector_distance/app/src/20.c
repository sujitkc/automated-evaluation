//3/5
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n; 
    scanf("%d",&n);
    int *arr = malloc(sizeof(int) * n);
    for(int i = 0; i < n; i++){
       scanf("%d",&arr[i]);
        
    }
    for(int i=n;i>=0;i--)
    {
        printf("%d\n",&arr[i]);
    }
    return 0;
}

