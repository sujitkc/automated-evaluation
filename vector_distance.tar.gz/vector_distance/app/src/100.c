////4/5
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>
int main(){
    int n,j,k,i;
    scanf("%d",&n);
    int *arr = malloc(sizeof(int) * n);
    for(int arr_i = 0; arr_i < n; arr_i++){
        scanf("%d",&arr[i]);
            
        }
    for(int arr_i=0;arr_i<n;i++)
        {
         k=j-i-1;
    }printf("reverse array\n");
    for(i=0;i<n;i++)
        {
        printf("%d",j);            
    }
   return 0;
}

