#/bin/bash

sed -i "s/^\(MIN_TOKENS=\).*/\1'30 20'/" config 
sed -i "s/^\(STRIDE=\).*/\1'3 2'/" config 
sed -i "s/^\(SIMILARITY=\).*/\1'0.9 0.8'/" config 


