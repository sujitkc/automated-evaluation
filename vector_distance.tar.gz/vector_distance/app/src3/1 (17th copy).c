#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n,i,temp,numberOfSwaps=0; 
    scanf("%d",&n);
    int a[n];
    for(int i = 0;i < n;i++){
       scanf("%d",&a[i]);
    }
    // Track number of elements swapped during a single array traversal
     
    for(i=0;i<n-1;i++){
       
    for (int j = 0; j < n-i-1 ; j++) {
        // Swap adjacent elements if they are in decreasing order
        if (a[j] > a[j+1]) {
            temp=a[j];
            a[j]=a[j+1];
            a[j+1]=temp;
            numberOfSwaps++;
        }
    }
    }
    // If no elements were swapped during a traversal, array is sorted


        printf("Array is sorted in %d swaps.\n",numberOfSwaps);
  //  for(i = 0;i < n;i++)
      //  printf("%d",a[i]);
 printf("First Element: %d\nLast Element: %d",a[0],a[n-1]);

    return 0;
}

