#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n,temp,i,j,swaps=0; 
    scanf("%d",&n);
    int *a = malloc(sizeof(int) * n);
    for(i = 0;i < n;i++)
    {
       scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++)
        {
        for(j=i+1;j<n;j++)
            {
            if(a[i]>a[j])
                {
                temp=a[i];
                a[i]=a[j];
                a[j]=temp;
                swaps++;
                }
            }
        }
    /*for(i=0;i<n;i++)
        printf("%d ",a[i]);*/
    printf("Array is sorted in %d swaps.\n",swaps);
    printf("First Element: %d\n",a[0]);
    printf("Last Element: %d",a[n-1]);
    return 0;
}

