#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main()
{
    int n,i,temp,nos,j;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
        scanf("%d",&a[i]);
    for(i=0;i<n;i++)
        {for(j=i+1;j<n;j++)
         {if(a[i]>a[j])
           { nos++;
             temp=a[i];
             a[i]=a[j];
             a[j]=temp;
           }
         }   
        }
    printf("Array is sorted in %d swaps.",nos); printf("\n");
    printf("First Element: %d",a[0]); printf("\n");
     printf("Last Element: %d",a[n-1]); printf("\n");
            
         
   return 0;
         
     }
    



