#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n,i,j,t,c=0; 
    scanf("%d",&n);
    int *A = malloc(sizeof(int) * n);
    for(i = 0; i < n; i++)
    {
       scanf("%d",&A[i]);
    }
    for(i=0;i<n;i++)
    for(j=1;j<n-i;j++)
    {
        if(A[j-1]>A[j])
        {
            t = A[j-1];
            A[j-1] = A[j];
            A[j] = t;
            c++;
        }    
    }
    /*for(i=0;i<n;i++)
        printf("%d ",A[i]);*/
    printf("Array is sorted in %d swaps.\n",c);
    printf("First Element: %d\n",A[0]);
    printf("Last Element: %d\n",A[n-1]);
    return 0;
}

