#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main()
{
    int n,i,c=0,temp,j;
    scanf("%d",&n);
    int A[n];
    for(i=0;i<n;i++)
        scanf("%d",&A[i]);
    for(i=0;i<n-1;i++)
    {
        for(j=0;j<n-1-i;j++)
        {
            if(A[j]>A[j+1])
            {
                temp=A[j];
                A[j]=A[j+1];
                A[j+1]=temp;
                c++;
            }
        }
        
    }
    printf("Array is sorted in %d swaps.",c);
    printf("\nFirst Element: %d",A[0]);
    printf("\nLast Element: %d",A[n-1]);
    
    return 0;
}

