#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n; 
    int i, j, swap = 0;
    scanf("%d",&n);
    int *a = malloc(sizeof(int) * n);
    for(int a_i = 0; a_i < n; a_i++){
       scanf("%d",&a[a_i]);
    }
    
    for (i = 0; i < n; i++) {
        for (j = 0; j < n - i - 1; j++) {
            if (a[j] > a[j+1]) {
                int tmp;
                tmp = a[j+1];
                a[j+1] = a[j];
                a[j] = tmp;
                swap++;
            }
        }
    }
    printf("Array is sorted in %d swaps.\n", swap);
    printf("First Element: %d\n", a[0]);
    printf("Last Element: %d", a[n-1]);
    return 0;
}

