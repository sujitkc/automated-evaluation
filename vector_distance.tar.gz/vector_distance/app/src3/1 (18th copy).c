#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    long int n,i,j,temp,swap=0; 
    scanf("%ld",&n);
    long int a[n];
    
    for(i = 0; i < n; i++)
    {
       scanf("%ld",&a[i]);
    }
    
    for(i=0;i<n;i++)
        {
        for(j=0;j<n-1;j++)
            {
            if(a[j]>a[j+1])
                {
                
                temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
                swap++;
                }
            }
       // printf("%ld %d\n",swap,a[n-1-i]);
        if(swap==0)
            break;
        }
    printf("Array is sorted in %ld swaps.\nFirst Element: %ld\nLast Element: %ld",swap,a[0],a[n-1]);
    return 0;
}

