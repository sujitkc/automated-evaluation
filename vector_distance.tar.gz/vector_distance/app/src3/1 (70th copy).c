#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n,i,j,p=0,q=0,t; 
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
        {
            scanf("%d",&a[i]);
    }
    for(i=0;i<n-1;i++)
        {
            for(j=0;j<n-i-1;j++)
                {
                    if(a[j]>a[j+1])
                        {
                            p++;
                            t=a[j];
                            a[j]=a[j+1];
                            a[j+1]=t;
                        }
               }
              if(p==0)
                  {
                   
                    break;
              }
                else
                    {
                        q++;
                }
        }
    
        printf("Array is sorted in %d swaps.\n",p);
        printf("First Element: %d\n",a[0]);
        printf("Last Element: %d\n",a[n-1]);
    return 0;
}

