#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>
int main()
    {
    int a[1000],n,j,i,numberOfSwaps=0,temp=0;
        scanf("%d",&n);
        for(i=0;i<n;i++)
        scanf("%d",&a[i]);
for (int i = 0; i < n; i++) {
    // Track number of elements swapped during a single array traversal
    
    
    for (int j = 0; j < n - 1; j++) {
        // Swap adjacent elements if they are in decreasing order
        if (a[j] > a[j + 1]) {
            temp=a[j];
            a[j]=a[j+1];
            a[j+1]=temp;
            numberOfSwaps++;
        }
    }
    
    // If no elements were swapped during a traversal, array is sorted
    if (numberOfSwaps == 0) {
        break;
    }
}
printf("Array is sorted in %d swaps. \n",numberOfSwaps);
printf("First Element: ");
printf("%d \n",a[0]);
printf("Last Element: ");
printf("%d \n",a[n-1]);
}
