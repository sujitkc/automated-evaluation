#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n; 
    scanf("%d",&n);
    int a[n],i;
    for(i=0;i<n;i++)
        scanf("%d",&a[i]);
    int j,count=0;
    int k;
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)    
        {
            if(a[j]<a[i])
            {
                count++;
                k=a[j];
                a[j]=a[i];
                a[i]=k;
            }
        }
        
        
    }
    printf("Array is sorted in %d swaps.\n", count);
        printf("First Element: %d\n",a[0]);
        printf("Last Element: %d\n",a[n-1]);
    return 0;
}

