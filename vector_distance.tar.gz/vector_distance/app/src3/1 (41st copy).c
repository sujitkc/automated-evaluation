#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n,i,j,temp;
    int A[600];
    int no_swaps=0;
    scanf("%d",&n);
    //int *a = malloc(sizeof(int) * n);
    for(int i = 0; i < n;i++){
        scanf("%d",&A[i]);
    }
    for(i = 0; i<n;i++)
      {
           // no_swaps = 0;
            for(j= 0 ; j<n-i-1;j++)
                   {
                    if(A[j]>A[j+1])
                        {
                        temp = A[j+1];
                        A[j+1] = A[j];
                           A[j] = temp;
                        no_swaps++;
                        }
                   }
    }
    printf("Array is sorted in %d swaps.\nFirst Element: %d\nLast Element: %d\n",no_swaps,A[0],A[n-1]);
    return 0;
}

