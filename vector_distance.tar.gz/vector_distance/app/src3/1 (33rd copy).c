#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n,count=0,i,t,j; 
    scanf("%d",&n);
    int *a = malloc(sizeof(int) * n);
    int *temp=malloc(sizeof(int) * n);
    for(int a_i = 0; a_i < n; a_i++){
       scanf("%d",&a[a_i]);
    }
    temp=a;
    for(i=0;i<n;i++)
        {
        for(j=0;j<n-1;j++)
            {
        if(temp[j]>temp[j+1])
            {
            count++;
        t=temp[j];
        temp[j]=temp[j+1];
        temp[j+1]=t;
        }
        }
    }
    /*if(temp==a)
        count=0;*/
    printf("Array is sorted in %d swaps.",count);
    printf("\nFirst Element: %d",a[0]);
    printf("\nLast Element: %d",a[n-1]);
    return 0;
}

