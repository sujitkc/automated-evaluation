#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n,i,j,total,no,temp; 
    scanf("%d",&n);
    int *a = malloc(sizeof(int) * n);
    for( i = 0; i < n; i++){
       scanf("%d",&a[i]);
    }
    total=0;
    for(i=0;i<n;i++)
        {
        no=0;
        for(j=0;j<n-1;j++)
            {
            if(a[j]>a[j+1])
                {
                temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
                total++;
                no++;
            }
        }
    }
    printf("Array is sorted in %d swaps.",total);
    printf("\nFirst Element: %d",a[0]);
     printf("\nLast Element: %d",a[n-1]);
    return 0;
}

