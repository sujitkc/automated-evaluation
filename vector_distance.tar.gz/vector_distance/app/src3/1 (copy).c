#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n; 
   scanf("%d",&n);
    int a[n],i,j,temp=0;
    int count=0;
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++){
        for(j=0;j<n-1;j++){
            if(a[j]>a[j+1]){
                temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
                count++;
            }
        }
    }
    printf("Array is sorted in %d swaps.",count);
    printf("\nFirst Element: %d",a[0]);
    printf("\nLast Element: %d",a[n-1]);

}

