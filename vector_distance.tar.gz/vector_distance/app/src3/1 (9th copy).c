#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n; 
    int t;
     int numberOfSwaps = 0;
    int ty=0;
    scanf("%d",&n);
    int *a = malloc(sizeof(int) * n);
    for(int a_i = 0; a_i < n; a_i++){
       scanf("%d",&a[a_i]);
    }
    

    for (int i = 0; i < n; i++) {
    // Track number of elements swapped during a single array traversal
 int numberOfSwaps = 0;
    
    
    for (int j = 0; j < n - 1; j++) {
        // Swap adjacent elements if they are in decreasing order
        if (a[j] > a[j + 1]) {
            t=a[j+1];
            a[j+1]=a[j];
            a[j]=t;
             ty=ty+1;
        }
    }
    
    // If no elements were swapped during a traversal, array is sorted
    
    }
 printf("Array is sorted in %d swaps.\nFirst Element: %d\nLast Element: %d",ty,a[0],a[n-1]);
 
    return 0;
}

