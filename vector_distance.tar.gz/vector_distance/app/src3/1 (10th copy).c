#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>
int main(){
    int n,i; 
    int swapCount=0;
    scanf("%d",&n);
    int *a = malloc(sizeof(int) * n);
    for(int a_i = 0; a_i < n; a_i++){
       scanf("%d",&a[a_i]);
    }
    for(int j=0;j<n-1;j++)
        {
    for( i=1;i<n;i++)
        {
        if(a[i-1]>a[i])
            {
            int temp;
            temp=a[i-1];
            a[i-1]=a[i];
            a[i]=temp;
            swapCount++;
        }
    }
    }
    printf("Array is sorted in %d swaps.\n",swapCount);
    printf("First Element: %d\n",a[0]);
     printf("Last Element: %d\n",a[n-1]);
    return 0;
}

