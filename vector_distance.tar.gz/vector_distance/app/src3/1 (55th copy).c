#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n; 
    scanf("%d",&n);
    int *a = malloc(sizeof(int) * n);
    for(int a_i = 0; a_i < n; a_i++){
       scanf("%d",&a[a_i]);
    }
    int no_of_swap=0;
    for(int i=0;i<n-1;++i)
        {
        int status=0;
        for(int j=0;j<n-i-1;++j)
            {
            if(a[j]>a[j+1])
                {
                int temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
                status=1;
                no_of_swap++;
            }
        }
        if(status==0)
            break;
    }
    printf("Array is sorted in %d swaps.\n",no_of_swap);
    printf("First Element: %d\n",a[0]);
    printf("Last Element: %d",a[n-1]);
    return 0;
}

