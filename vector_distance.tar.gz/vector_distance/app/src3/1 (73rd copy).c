#include<stdio.h>

int main()
{
    int n,i,j,t=0,c=0;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
    {
        scanf(" %d",&a[i]);
    }
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(a[j]<a[i])
            {
                t=a[i];
                a[i]=a[j];
                a[j]=t;
                c++;
            }
        }
    }
    printf("Array is sorted in %d swaps.\n",c);
    printf("First Element: %d\n",a[0]);
    printf("Last Element: %d\n",a[n-1]);
}

