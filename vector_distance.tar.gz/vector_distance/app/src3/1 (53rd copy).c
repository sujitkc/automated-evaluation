#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n,i,j,count=0,temp; 
    scanf("%d",&n);
    int *a = malloc(sizeof(int) * n);
    for( i = 0; i < n; i++){
       scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++)
        {
        for(j=i;j<n;j++)
            {
            if(a[i]>a[j])
                {
                temp=a[i];
                a[i]=a[j];
                a[j]=temp;
                count++;
            }
        }
            
    }
    printf("Array is sorted in %d swaps.\n",count);
    printf("First Element: %d\n",a[0]);
    printf("Last Element: %d\n",a[n-1]);
    
    return 0;
}

