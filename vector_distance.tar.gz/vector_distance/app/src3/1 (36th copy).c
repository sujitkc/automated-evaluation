#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n; 
    scanf("%d",&n);
    int i,k,j,count=0,a[n];
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }    
    for(j=1;j<=n-1;j++)
    {
        for(i=0,k=i+1;i<n-1,k<n;i++,k++)
        {
            int temp;
            if(a[k]<a[i])
            {
                temp=a[i];
                a[i]=a[k];
                a[k]=temp;
                count++;
            }        
        }    
    }    
    printf("Array is sorted in %d swaps.\n",count);
    printf("First Element: %d\n",a[0]);
    printf("Last Element: %d",a[n-1]);
    return 0;
}

