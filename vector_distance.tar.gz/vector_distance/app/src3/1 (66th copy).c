#include<stdio.h>
int main ()
    {
    int n;
    scanf("%d",&n);
    int a[n];
    int i;
    for(i=0;i<n;i++)
        {
        scanf("%d",&a[i]);
    }
    int s=0;
    int j;
    int k;
    for(i=0;i<n;i++)
        {
        for(j=0;j<n-1-i;j++)
            {
            if(a[j]>a[j+1])
                {
                s++;
                k=a[j];
                a[j]=a[j+1];
                a[j+1]=k;
            }
        }
    }
    printf("Array is sorted in %d swaps.\nFirst Element: %d\nLast Element: %d\n",s,a[0],a[n-1]);
    return 0;
}

