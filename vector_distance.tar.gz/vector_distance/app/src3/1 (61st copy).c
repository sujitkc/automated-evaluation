#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n,ttl=0,p,q; 
    scanf("%d",&n);
    int *a = malloc(sizeof(int) * n);
    for(int a_i = 0; a_i < n; a_i++){
       scanf("%d",&a[a_i]);
        ttl+=1;
    }
    //p=ttl;
    q=ttl-1;
    int cnt=0,temp;
    for(int j=0;j<ttl;j++)
        {
        for(int i=0;i<q;i++)
            {
            if(a[i]>a[i+1])
                {
                cnt+=1;
                temp=a[i];
                a[i]=a[i+1];
                a[i+1]=temp;
            }
        }
        q--;
    }
    printf("Array is sorted in %d swaps.\n",cnt);
    printf("First Element: %d\n",a[0]);
    printf("Last Element: %d\n",a[ttl-1]);
    return 0;
}

