#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main(){
    int n; int k=0,i,j;
    int t;
    scanf("%d",&n);
    int *a = malloc(sizeof(int) * n);
    for(int a_i = 0; a_i < n; a_i++){
       scanf("%d",&a[a_i]);
    }
    for(i=0;i<n;i++)
        {
        for(j=0;j<(n-1);j++)
            {
            if(a[j]>a[j+1])
                {k++;
                t=a[j];
                a[j]=a[j+1];
                a[j+1]=t;
                
            }
        }
    }
    printf("Array is sorted in %d swaps.\n",k);
    printf("First Element: %d\n",a[0]);
    printf("Last Element: %d\n",a[n-1]);
    return 0;
}

