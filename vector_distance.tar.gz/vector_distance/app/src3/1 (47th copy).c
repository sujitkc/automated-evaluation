#include <stdio.h>

int main(){
    int n;
    scanf("%d",&n);
    int a[n];
    for(int i=0;i<n;i++)
        scanf("%d",&a[i]);
    int swaps=0;
    for(int i=0;i<n;i++)
        {
        for(int j=0;j<n-1;j++)
            {
            if(a[j]>a[j+1])
                {
                int temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
                swaps++;
            }
        }
    }
    printf("Array is sorted in %d swaps.\n",swaps);
    printf("First Element: %d\n",a[0]);
    printf("Last Element: %d\n",a[n-1]);
}

