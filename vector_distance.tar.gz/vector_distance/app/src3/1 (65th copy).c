#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

int main()
{
    int n,arr[1000],numswaps=0,firstelement,lastelement;
    scanf("%d",&n);
    for(int i=0;i<n;i++)
      {
        scanf("%d",&arr[i]);
      }
      for(int i=0;i<n;i++)
      {
        for(int j=0;j<n-1;j++)
        {
            if(arr[j]>arr[j+1])
            {
                numswaps++;                
                int temp=arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;
               
             }
           
        }
      }
    firstelement=arr[0];
    lastelement=arr[n-1];
    printf("Array is sorted in %d swaps.\n",numswaps);
      printf("First Element: %d\n",firstelement);
      printf("Last Element: %d\n",lastelement);

}

