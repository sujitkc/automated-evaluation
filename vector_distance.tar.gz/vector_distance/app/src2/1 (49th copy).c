#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {

      long int i,j,n ,a[1000];
        scanf("%ld",&n);
        for(i=0;i<n;i++)
             scanf("%ld",&a[i]);
        for(i=n-1;i>=0;i--)
               printf("%ld\t",a[i]);
    return 0;
}

