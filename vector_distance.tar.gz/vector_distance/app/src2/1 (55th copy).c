#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    int i,num,array[1000];
    scanf("%d",&num);
    
    for(i=0;i<num;i++)
    {
        scanf("%d",&array[i]);   
    }
    
    for(i=num-1;i>0;i--)
    {
        printf("%d ",array[i]);        
    }
    printf("%d\n",array[0]);
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */    
    return 0;
}

