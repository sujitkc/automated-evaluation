#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {

    /* Enter your code here. Read input from STDIN. Print output to STDOUT */
    int N;
    int i;
    int *a;
    
    scanf("%d", &N);
    if((a = calloc(N, sizeof(int))) == NULL) {
        printf("out of memory\n");
        return 1;
    }
    for (i = 0; i < N; i++) {
        scanf("%d", &a[i]);
    }
    for (i = N - 1; i >= 0; i--) {
        printf("%d ", a[i]);
    }
    free(a);
    return 0;
}

