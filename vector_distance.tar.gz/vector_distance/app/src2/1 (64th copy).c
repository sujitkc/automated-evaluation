#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {

    /* Enter your code here. Read input from STDIN. Print output to STDOUT */    
    int n , A[10000], i;
    scanf("%d",&n);
    for(i = 0 ; i < n ; i++)
        {
        scanf("%d",&A[i]);
    }
    
    for(i = n-1 ; i >= 0 ; i--)
        printf("%d ",A[i]);
    printf("\n");
    return 0;
}

