#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    int a[1000],i,j,k;
    scanf("%d",&i);
    if(i>0 && i<=1000)
        {
        for(j=0;j<i;j++)
            {
            scanf("%d",&k);
            if(k>=1 && k<=10000)
                a[j] = k;
        }
        while(j>0)
            {
            printf("%d ",a[--j]);
        }
    }

    /* Enter your code here. Read input from STDIN. Print output to STDOUT */    
    return 0;
}

