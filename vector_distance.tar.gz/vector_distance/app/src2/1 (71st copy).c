#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {

    /* Enter your code here. Read input from STDIN. Print output to STDOUT */    
    
    int N,*arr,i;
    scanf("%d",&N);
    arr=(int *)malloc(N*sizeof(int));
    if(arr==NULL)
        exit(0);
    for (i=0;i<N;i++)
        scanf("%d",arr+i);
    for (i=N-1;i>=0;i--)
        printf("%d ",*(arr+i));
    return 0;
}

