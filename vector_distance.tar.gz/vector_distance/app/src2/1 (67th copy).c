#include<stdio.h>
#include<stdlib.h>
int main()
{
  int i,n,*a;
  scanf("%d",&n);
  a=(int *)malloc(n*sizeof(int));
  for(i=0;i<n;i++)
    {
      scanf("%d",&a[i]);
    }
  for(i=n-1;i>=0;i--)
    {
      printf("%d\t",a[i]);
    }
  free(a);
}

