#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() 
{
    int n, i, temp, arr[10000];
    scanf("%d", &n);
    for(i=0; i<n; i++)
        scanf("%d", &arr[i]);
    for(i=0; i<n/2; i++)
        {
        temp = arr[i];
        arr[i] = arr[n-1-i];
        arr[n-1-i] = temp;
    }    
    for(i=0; i<n; i++)
        printf("%d ", arr[i]);
    
    return 0;
}

