#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#define MAX 66000

int main() {

    /* Enter your code; here. Read input from STDIN. Print output to STDOUT */    
    int N,i,j,temp,mid;
    int *p1,*p2;
    int array[MAX];
    scanf("%d",&N);
    for(i=0;i<N;i++)
        scanf("%d",&array[i]);
    mid=floor(N/2);
    for(i=0,j=N-1;i<=mid,j>=mid;i++,j--)
        {
         temp=array[i];
         array[i]=array[j];
         array[j]=temp;
        }
    
   for(i=0;i<N;i++)
        printf("%d ",array[i]);
}


