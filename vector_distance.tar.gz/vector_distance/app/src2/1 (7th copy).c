#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    int i,*a,j,n;
    scanf("%d",&i);
    a=(int *)malloc(sizeof(int)*i);
    for(j=0;j<i;j++)
        {
        scanf("%d",&n);
        a[j]=n;
    }
    for(j=i-1;j>=0;j--)
        printf("%d ",a[j]);

    /* Enter your code here. Read input from STDIN. Print output to STDOUT */    
    return 0;
}

