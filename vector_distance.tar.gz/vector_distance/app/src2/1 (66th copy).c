#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>


int main()
    {
    
int i,N,a[1000];
    scanf("%d",&N);
    for(i=0;i<=N-1;i++)
        {
        scanf("%d",&a[i]);
        }
    for(i=N-1;i>=0;i--)
     printf("%d ",a[i]);
    
    return 0;
}

