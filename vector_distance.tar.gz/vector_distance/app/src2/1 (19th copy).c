#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {

    /* Enter your code here. Read input from STDIN. Print output to STDOUT */   
    int a,b,c;
    int n[100000];
    scanf("%d",&a);
    for(b=0;b<a;b++)
        {
        scanf("%d",&n[b]);
        
    }
    for(b=a-1;b>=0;b--)
        printf("%d\t",n[b]);
    return 0;
}

