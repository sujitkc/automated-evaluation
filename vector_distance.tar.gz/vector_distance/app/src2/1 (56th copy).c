#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#define MAX_N 1000
int main() {
    int i,N;
    int arr[MAX_N];
    scanf("%d",&N);
    for(i =0; i<N;i++){
        scanf("%d",arr+i);
    }
    for(i=N-1;i>=0;i--){
        printf("%d ",arr[i]);
    }
    return 0;
}

