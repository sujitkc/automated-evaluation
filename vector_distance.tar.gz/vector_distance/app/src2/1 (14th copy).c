#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {

    /* Enter your code here. Read input from STDIN. Print output to STDOUT */ 
    
    int count,i,array[1000];
    scanf("%d",&count);

    for(i=0;i<count;i++)
    {
        scanf("%d",&array[i]);
    }
    for(i=count-1;i>=0;i--)
    {
        printf("%d ",array[i]);
    }
    
    return 0;
}

