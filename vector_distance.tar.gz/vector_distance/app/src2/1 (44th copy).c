#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {

    int size;
    scanf("%d", &size);
    
    int i, array[size];
    for(i = 0; i < size; i++)
        scanf("%d", &array[i]);
    
    for(i = size - 1; i > -1; i--)
        printf("%d ", array[i]);
    return 0;
}

