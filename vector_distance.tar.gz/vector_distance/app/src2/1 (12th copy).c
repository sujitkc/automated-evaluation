#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
  int n,b[1000],a[1000];
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */    
//printf("enter the value of n, size of array\n");
    scanf("%d",&n);
    //printf("enter the input array\n");
    for(int i=0;i<n;i++)
        {
        scanf("%d",&a[i]);
    }
    //printf("the output is=");
    for(int j=1;j<=n;j++)
        {
        b[n-j]=a[j-1];
    }
    for(int j=0;j<n;j++)
        {
        printf("%d",b[j]);
        printf(" ");
    }
    
    return 0;
}

