#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {

    /* Enter your code here. Read input from STDIN. Print output to STDOUT */
    
    int size;
    scanf("%d",&size);
    int arr[size],i=0;
    while(i<size)
        {
        scanf("%d",&arr[i++]);
    }
    size-=1;
    while(size>=0)
        {
        printf("%d ",arr[size--]);
    }
    return 0;
}

