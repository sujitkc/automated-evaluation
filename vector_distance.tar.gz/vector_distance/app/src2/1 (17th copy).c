#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
int x,i;
    scanf("%d",&x);
    int a[x];
    for(i=0;i<x;i++)
        {
        scanf("%d",&a[i]);
    }
    for(i=x-1;i>=0;i--)
        {
        printf("%d ",a[i]);
    }
        
    return 0;
}

