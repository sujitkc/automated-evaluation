#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
int a[1000];
int main() {
int N,i;
    scanf("%d",&N);
    for(i=0;i<N;i++)
        scanf("%d",a+i);
    for(i=0;i<N;i++)
        printf("%d ",a[N-1-i]);
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */    
    return 0;
}

