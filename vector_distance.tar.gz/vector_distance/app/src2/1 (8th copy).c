#include <stdio.h>
#include <stdlib.h>
 
int main(){
  int *arr, m, i;
  scanf("%d", &m);
  arr = (int *) malloc( m * sizeof(int) );
  for (i = 0; i < m; i++)
    scanf("%d",&arr[i]);
  for(i = m-1; i>0; i--)  
    printf("%d ",arr[i]);
  printf("%d",arr[0]);
  return 0;
}
