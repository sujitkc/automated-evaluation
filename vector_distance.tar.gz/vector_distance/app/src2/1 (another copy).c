#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {

    /* Enter your code here. Read input from STDIN. Print output to STDOUT */   
    int n,i,a[1000];
    scanf("%d",&n);
    for(i=0;i<n;i++)
            scanf("%d\t",&a[i]);
    for(i=0;i<n;i++)
            printf("%d\t",a[n-i-1]);
    
    return 0;
}

