#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    int a[1000];
    int copy[1000];
    int count = 0;
    int i ;
    int temp;
    scanf("%d",&count);
    for(i = 0 ; i < count ; i++)
    {
        scanf("%d",&a[i]);    
    }
   
    temp = count;
    temp--;
    for(i =0 ; i < count; i++)
    {
        copy[i] = a[temp];
        temp--;
    }
    for(i =0 ; i < count; i++)
    {
       printf("%d ",copy[i]);
    }
    
    
    
    
    
    
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */    
    return 0;
}

