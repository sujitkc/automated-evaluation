#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

#define MAXSIZE 1000

int main() {

    /* Enter your code here. Read input from STDIN. Print output to STDOUT */   
    int N;
    int Array[MAXSIZE];
    int i;
    
    scanf("%d",&N);
    for ( i = 0; i < N; i++)
        scanf("%d",&Array[i]);
    
    for ( i = N-1; i >=0; i--)
        printf("%d ",Array[i]);
    
    
    return 0;
}

