#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {

    /* Enter your code here. Read input from STDIN. Print output to STDOUT */   
    int i,s;
    scanf("%d",&s);
    int arr[s];
    for(i=0;i<s;i++)
        {
          scanf("%d",&arr[i]);
        
    }
    for(i=s-1;i>=0;i--)
        {
          printf("%d ",arr[i]);
        
    }
    return 0;
}

