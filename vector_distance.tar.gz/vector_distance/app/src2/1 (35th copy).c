#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {int array[1000];int n;
            int i;
            scanf("%d",&n);
            for(i=0;i<n;i++)
                scanf("%d",&array[i]);
            --i;
            while(i>=0){
                
                printf("%d ",array[i]);
                i--;
            }

    /* Enter your code here. Read input from STDIN. Print output to STDOUT */    
    return 0;
}

