#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    int i,j,a[1000],n;
    scanf("%d",&n);
    for(i=0;i<n;i++)
        {
        scanf("%d",&a[i]);
      
    }
for(j=n-1;j>=0;j--)
    {
    printf("%d ",a[j]);
}

/* Enter your code here. Read input from STDIN. Print output to STDOUT */
    return 0;
}
