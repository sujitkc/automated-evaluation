#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {

    /* Enter your code here. Read input from STDIN. Print output to STDOUT */
    int num,*a,i=0;
    a = (int*)malloc(sizeof(int)*num);
    scanf("%d",&num);
    while(i!=num)
        {
        scanf("%d",(a+i));
        i++;
    }
    for(i=num-1;i>=0;i--)
        printf("%d ",*(a+i));
    free(a);
    return 0;
}

