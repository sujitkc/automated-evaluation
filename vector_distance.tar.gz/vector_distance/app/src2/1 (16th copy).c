#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {

   int a[1000],i,l;
    scanf("%d",&l);
    for(i=0;i<l;i++)
        scanf("%d",&a[i]);
    for(i=l-1;i>=0;i--)
        printf("%d\t",a[i]);
    return 0;
}

