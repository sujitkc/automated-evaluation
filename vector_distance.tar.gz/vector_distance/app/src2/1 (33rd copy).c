#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {

    /* Enter your code here. Read input from STDIN. Print output to STDOUT */
    
    int N,i;
    
    scanf("%d",&N);
 //   printf("\n");
    
    int x[N];
    
    for(i=0;i<N;i++){
        
        scanf("%d",&x[i]);
 //       printf(" ");

        
    }
    
    
    for(i=N-1;i>-1;i--){
        
        printf("%d ",x[i]);
        
    }
    
    
    
    return 0;
}

