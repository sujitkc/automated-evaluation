#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
int i,n,j,temp;
    scanf("%d",&n);
    int *a;
    a=(int *)malloc(sizeof (int) * n);
    for (i=0;i<n;i++)
        scanf("%d",&a[i]);
    for(i=0,j=n-1;i<=n/2,j>=n/2;i++,j--)
    {
    temp=a[j];
    a[j]=a[i];
    a[i]=temp;
    }
    for(i=0;i<n;i++)
        printf("%d ",a[i]);
    
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */    
    return 0;
}

