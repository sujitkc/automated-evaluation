#!/bin/sh
sudo ../scripts/clonedetect/vdbgen overwrite 
sudo awk -F "," '/^#/ {NF=1; p=H[$1]++} !p ' vectors/vdb_20_2 > wrong.txt
#sudo cp output.txt /home/rachana
sudo octave readandcompute.m wrong.txt

