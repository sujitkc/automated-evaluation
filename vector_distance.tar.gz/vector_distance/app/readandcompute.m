arg_list = argv ();
filename = arg_list{1};
A = importdata(filename,'#');

i = 1;
vectors = [];
filenames = [];

while i <= length(A)
    filenames{length(filenames)+1} = char(A{i});
    vectors{length(vectors)+1} = str2num(char(A{i+1}));
    i = i + 2;
end

%disp(vectors{10});
%disp(filenames{10});
%disp(vectors{12});
%disp(filenames{12});
%disp(norm(vectors{10}-vectors{12}));

fileID = fopen('distance_data.txt' , 'w');
formatSpec1 = '%d %d %f\n';
formatSpec2 = '%f\n';
formatSpec3 = '%d\n';
fprintf(fileID,'%d ',3);
nrows = factorial(length(filenames))/(2*factorial(length(filenames) - 2));
fprintf(fileID,formatSpec3, nrows);
for (i = 1:(length(filenames)-1))
	for(j = i+1:length(filenames))	
    		dist = norm(vectors{i} - vectors{j});
		fprintf(fileID,formatSpec1,i,j,dist);
    		%fprintf(fileID,formatSpec1,j);
    		%fprintf(fileID,formatSpec2,dist);	
	end 
end    

	
fileID = fopen('data_filenames.txt' , 'w');
formatSpec4 = '%d ';
formatSpec5 = '%s\n';
formatSpec6 = '%s ';
for (i = 1:length(filenames))
	fprintf(fileID,'%d %s\n',i,filenames{i});   
 	%fprintf(fileID,formatSpec5,filenames{i});		 
end    


fileID = fopen('dot_filenames.txt' , 'w');

for(i = 1:length(filenames))
	filenames{i} = strrep(filenames{i},'# FILE:src/' ,'/home/rachana/correct/');
	fprintf(fileID,formatSpec5,filenames{i});
end
 
  
fileID = fopen('dot_pairs.txt' , 'w');

for(i = 1:length(filenames))
	filenames{i} = strrep(filenames{i},'.c' ,'.main.dot');
end

for (i = 1:(length(filenames)-1))
	for(j = i+1:length(filenames))
		fprintf(fileID,formatSpec6,filenames{i});
    		fprintf(fileID,formatSpec5,filenames{j});		
	end 
end
