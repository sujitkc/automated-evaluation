arg_list = argv ();
filename1 = arg_list{1};
filename2 = arg_list{2};
A = importdata(filename1,'#');
B = importdata(filename2,'#');

i = 1;
vectors1 = [];
filenames1 = [];

while i <= length(A)
    filenames1{length(filenames1)+1} = char(A{i});
    vectors1{length(vectors1)+1} = str2num(char(A{i+1}));
    i = i + 2;
end

%1wrong
%2clusters

i = 1;
vectors2 = [];
filenames2 = [];

while i <= length(B)
    filenames2{length(filenames2)+1} = char(B{i});
    vectors2{length(vectors2)+1} = str2num(char(B{i+1}));
    i = i + 2;
end

t = 1;
fileID = fopen('partial_grades.txt' , 'w');
formatSpec1 = '%s %s %f\n';
final_dist = 100;
for (i = 1:length(vectors2))
	for(j = 1:length(vectors1))	
    		dist = norm(vectors1{j} - vectors2{i});
%		if(dist < final_dist)
%			final_dist = dist;
%			t = j;			
		fprintf(fileID,formatSpec1,filenames1{j},filenames2{i},dist);
%		end	
	end 
%	fprintf(fileID,formatSpec1,filenames1{i},filenames2{t},final_dist);
end    


%fileID = fopen('dot_filenames_wrong.txt' , 'w');

for(i = 1:length(filenames1))
	filenames1{i} = strrep(filenames1{i},'# FILE:src/' ,'/home/rachana/wrong/');
	%fprintf(fileID,'%s\n',filenames1{i});
end

for(i = 1:length(filenames2))
	filenames2{i} = strrep(filenames2{i},'# FILE:src/' ,'/home/rachana/wrong/');
	%fprintf(fileID,'%s\n',filenames2{i});
end 
  
fileID = fopen('dot_pairs_wrong.txt' , 'w');

for(i = 1:length(filenames1))
	filenames1{i} = strrep(filenames1{i},'.c' ,'.main.dot');
end

for(i = 1:length(filenames2))
	filenames2{i} = strrep(filenames2{i},'.c' ,'.main.dot');
end

for (i = 1:length(filenames2))
	for(j = 1:length(filenames1))
		fprintf(fileID,'%s %s\n',filenames1{j},filenames2{i});	
	end 
end
