/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_PT_C_TAB_HH_INCLUDED
# define YY_YY_PT_C_TAB_HH_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    IDENTIFIER = 258,
    TYPENAME = 259,
    SCSPEC = 260,
    STATIC = 261,
    TYPESPEC = 262,
    TYPE_QUAL = 263,
    CONSTANT = 264,
    STRING = 265,
    ELLIPSIS = 266,
    SIZEOF = 267,
    ENUM = 268,
    STRUCT = 269,
    UNION = 270,
    IF = 271,
    ELSE = 272,
    WHILE = 273,
    DO = 274,
    FOR = 275,
    SWITCH = 276,
    CASE = 277,
    DEFAULT = 278,
    BREAK = 279,
    CONTINUE = 280,
    RETURN = 281,
    GOTO = 282,
    ASM_KEYWORD = 283,
    TYPEOF = 284,
    ALIGNOF = 285,
    ATTRIBUTE = 286,
    EXTENSION = 287,
    LABEL = 288,
    REALPART = 289,
    IMAGPART = 290,
    VA_ARG = 291,
    CHOOSE_EXPR = 292,
    TYPES_COMPATIBLE_P = 293,
    PTR_VALUE = 294,
    PTR_BASE = 295,
    PTR_EXTENT = 296,
    FUNC_NAME = 297,
    ASSIGN = 298,
    OROR = 299,
    ANDAND = 300,
    EQCOMPARE = 301,
    ARITHCOMPARE = 302,
    LSHIFT = 303,
    RSHIFT = 304,
    UNARY = 305,
    PLUSPLUS = 306,
    MINUSMINUS = 307,
    HYPERUNARY = 308,
    POINTSAT = 309,
    INTERFACE = 310,
    IMPLEMENTATION = 311,
    END = 312,
    SELECTOR = 313,
    DEFS = 314,
    ENCODE = 315,
    CLASSNAME = 316,
    PUBLIC = 317,
    PRIVATE = 318,
    PROTECTED = 319,
    PROTOCOL = 320,
    OBJECTNAME = 321,
    CLASS = 322,
    ALIAS = 323,
    AT_THROW = 324,
    AT_TRY = 325,
    AT_CATCH = 326,
    AT_FINALLY = 327,
    AT_SYNCHRONIZED = 328,
    OBJC_STRING = 329
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 10 "pt_c.y" /* yacc.c:1909  */

Tree *t;

#line 133 "pt_c.tab.hh" /* yacc.c:1909  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif



int yyparse (void);

#endif /* !YY_YY_PT_C_TAB_HH_INCLUDED  */
