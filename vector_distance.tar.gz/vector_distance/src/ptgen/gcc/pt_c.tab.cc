/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "3.0.4"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 1

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* Copy the first part of user declarations.  */
#line 4 "pt_c.y" /* yacc.c:339  */

#include<ptree.h>

using namespace std;

#line 72 "pt_c.tab.cc" /* yacc.c:339  */

# ifndef YY_NULLPTR
#  if defined __cplusplus && 201103L <= __cplusplus
#   define YY_NULLPTR nullptr
#  else
#   define YY_NULLPTR 0
#  endif
# endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* In a future release of Bison, this section will be replaced
   by #include "pt_c.tab.hh".  */
#ifndef YY_YY_PT_C_TAB_HH_INCLUDED
# define YY_YY_PT_C_TAB_HH_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    IDENTIFIER = 258,
    TYPENAME = 259,
    SCSPEC = 260,
    STATIC = 261,
    TYPESPEC = 262,
    TYPE_QUAL = 263,
    CONSTANT = 264,
    STRING = 265,
    ELLIPSIS = 266,
    SIZEOF = 267,
    ENUM = 268,
    STRUCT = 269,
    UNION = 270,
    IF = 271,
    ELSE = 272,
    WHILE = 273,
    DO = 274,
    FOR = 275,
    SWITCH = 276,
    CASE = 277,
    DEFAULT = 278,
    BREAK = 279,
    CONTINUE = 280,
    RETURN = 281,
    GOTO = 282,
    ASM_KEYWORD = 283,
    TYPEOF = 284,
    ALIGNOF = 285,
    ATTRIBUTE = 286,
    EXTENSION = 287,
    LABEL = 288,
    REALPART = 289,
    IMAGPART = 290,
    VA_ARG = 291,
    CHOOSE_EXPR = 292,
    TYPES_COMPATIBLE_P = 293,
    PTR_VALUE = 294,
    PTR_BASE = 295,
    PTR_EXTENT = 296,
    FUNC_NAME = 297,
    ASSIGN = 298,
    OROR = 299,
    ANDAND = 300,
    EQCOMPARE = 301,
    ARITHCOMPARE = 302,
    LSHIFT = 303,
    RSHIFT = 304,
    UNARY = 305,
    PLUSPLUS = 306,
    MINUSMINUS = 307,
    HYPERUNARY = 308,
    POINTSAT = 309,
    INTERFACE = 310,
    IMPLEMENTATION = 311,
    END = 312,
    SELECTOR = 313,
    DEFS = 314,
    ENCODE = 315,
    CLASSNAME = 316,
    PUBLIC = 317,
    PRIVATE = 318,
    PROTECTED = 319,
    PROTOCOL = 320,
    OBJECTNAME = 321,
    CLASS = 322,
    ALIAS = 323,
    AT_THROW = 324,
    AT_TRY = 325,
    AT_CATCH = 326,
    AT_FINALLY = 327,
    AT_SYNCHRONIZED = 328,
    OBJC_STRING = 329
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 10 "pt_c.y" /* yacc.c:355  */

Tree *t;

#line 191 "pt_c.tab.cc" /* yacc.c:355  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif



int yyparse (void);

#endif /* !YY_YY_PT_C_TAB_HH_INCLUDED  */

/* Copy the second part of user declarations.  */
#line 14 "pt_c.y" /* yacc.c:358  */

void yyerror(char*s);
int yylex(YYSTYPE *yylvalp);

Tree *root;
#line 180 "pt_c.y" /* yacc.c:358  */

/*
#include "config.h"
#include "system.h"
#include "coretypes.h"
#include "tm.h"
#include "tree.h"
#include "input.h"
#include "cpplib.h"
#include "intl.h"
#include "timevar.h"
#include "c-pragma.h"
#include "c-tree.h"
#include "flags.h"
#include "varray.h"
#include "output.h"
#include "toplev.h"
#include "ggc.h"
*/



#line 235 "pt_c.tab.cc" /* yacc.c:358  */

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif

#ifndef YY_ATTRIBUTE
# if (defined __GNUC__                                               \
      && (2 < __GNUC__ || (__GNUC__ == 2 && 96 <= __GNUC_MINOR__)))  \
     || defined __SUNPRO_C && 0x5110 <= __SUNPRO_C
#  define YY_ATTRIBUTE(Spec) __attribute__(Spec)
# else
#  define YY_ATTRIBUTE(Spec) /* empty */
# endif
#endif

#ifndef YY_ATTRIBUTE_PURE
# define YY_ATTRIBUTE_PURE   YY_ATTRIBUTE ((__pure__))
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# define YY_ATTRIBUTE_UNUSED YY_ATTRIBUTE ((__unused__))
#endif

#if !defined _Noreturn \
     && (!defined __STDC_VERSION__ || __STDC_VERSION__ < 201112)
# if defined _MSC_VER && 1200 <= _MSC_VER
#  define _Noreturn __declspec (noreturn)
# else
#  define _Noreturn YY_ATTRIBUTE ((__noreturn__))
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(E) ((void) (E))
#else
# define YYUSE(E) /* empty */
#endif

#if defined __GNUC__ && 407 <= __GNUC__ * 100 + __GNUC_MINOR__
/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN \
    _Pragma ("GCC diagnostic push") \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")\
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# define YY_IGNORE_MAYBE_UNINITIALIZED_END \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif


#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYSIZE_T yynewbytes;                                            \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / sizeof (*yyptr);                          \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, (Count) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYSIZE_T yyi;                         \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  63
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   3590

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  97
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  159
/* YYNRULES -- Number of rules.  */
#define YYNRULES  520
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  846

/* YYTRANSLATE[YYX] -- Symbol number corresponding to YYX as returned
   by yylex, with out-of-bounds checking.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   329

#define YYTRANSLATE(YYX)                                                \
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, without out-of-bounds checking.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    50,     2,     2,     2,    68,    59,     2,
      75,    44,    66,    64,    43,    65,    74,    67,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    54,    46,
       2,    52,     2,    53,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    76,     2,    45,    58,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    48,    57,    47,    49,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    51,    55,
      56,    60,    61,    62,    63,    69,    70,    71,    72,    73,
      77,    78,    79,    80,    81,    82,    83,    84,    85,    86,
      87,    88,    89,    90,    91,    92,    93,    94,    95,    96
};

#if YYDEBUG
  /* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   283,   283,   290,   302,   313,   330,   341,   352,   363,
     398,   415,   438,   467,   496,   513,   524,   535,   546,   587,
     610,   651,   674,   709,   726,   737,   748,   759,   770,   781,
     792,   803,   814,   825,   837,   843,   854,   865,   888,   899,
     916,   933,   950,   967,   984,  1013,  1030,  1059,  1076,  1093,
    1104,  1115,  1126,  1137,  1166,  1177,  1200,  1223,  1246,  1269,
    1292,  1315,  1338,  1361,  1384,  1407,  1430,  1453,  1476,  1499,
    1534,  1563,  1586,  1609,  1620,  1637,  1660,  1677,  1688,  1699,
    1710,  1751,  1774,  1791,  1814,  1831,  1860,  1901,  1954,  1995,
    2024,  2047,  2070,  2087,  2104,  2115,  2132,  2144,  2150,  2161,
    2178,  2189,  2200,  2217,  2234,  2263,  2292,  2309,  2326,  2344,
    2350,  2361,  2390,  2419,  2442,  2465,  2482,  2499,  2510,  2527,
    2544,  2561,  2578,  2595,  2606,  2623,  2634,  2651,  2668,  2685,
    2702,  2719,  2736,  2747,  2764,  2781,  2798,  2815,  2832,  2849,
    2866,  2883,  2900,  2917,  2934,  2951,  2968,  2985,  3002,  3019,
    3030,  3047,  3064,  3081,  3098,  3115,  3132,  3149,  3166,  3183,
    3200,  3217,  3234,  3251,  3268,  3285,  3302,  3319,  3336,  3353,
    3370,  3387,  3404,  3421,  3438,  3455,  3472,  3489,  3506,  3523,
    3540,  3557,  3574,  3591,  3608,  3625,  3642,  3659,  3676,  3693,
    3710,  3727,  3744,  3761,  3778,  3789,  3800,  3811,  3822,  3833,
    3844,  3855,  3866,  3877,  3888,  3899,  3910,  3921,  3932,  3943,
    3954,  3965,  3976,  3987,  3998,  4009,  4020,  4031,  4042,  4053,
    4064,  4075,  4086,  4097,  4108,  4119,  4130,  4141,  4152,  4163,
    4174,  4185,  4196,  4207,  4218,  4229,  4240,  4251,  4262,  4273,
    4284,  4295,  4306,  4317,  4328,  4339,  4350,  4361,  4372,  4383,
    4395,  4401,  4412,  4423,  4434,  4445,  4456,  4467,  4478,  4489,
    4518,  4547,  4558,  4587,  4598,  4628,  4634,  4663,  4698,  4721,
    4756,  4780,  4786,  4797,  4808,  4825,  4866,  4877,  4901,  4907,
    4918,  4947,  4988,  5017,  5028,  5039,  5050,  5061,  5072,  5083,
    5094,  5117,  5125,  5131,  5148,  5159,  5182,  5205,  5222,  5245,
    5256,  5279,  5290,  5297,  5308,  5325,  5342,  5377,  5400,  5429,
    5458,  5469,  5480,  5509,  5532,  5549,  5572,  5583,  5594,  5605,
    5628,  5645,  5656,  5679,  5696,  5719,  5742,  5771,  5794,  5823,
    5846,  5863,  5874,  5885,  5902,  5913,  5930,  5941,  5958,  5999,
    6034,  6075,  6110,  6157,  6198,  6215,  6232,  6250,  6256,  6268,
    6274,  6285,  6296,  6314,  6320,  6343,  6360,  6383,  6400,  6423,
    6434,  6441,  6458,  6469,  6498,  6509,  6538,  6555,  6584,  6607,
    6624,  6653,  6676,  6687,  6710,  6717,  6728,  6751,  6769,  6775,
    6787,  6793,  6804,  6821,  6832,  6843,  6854,  6877,  6894,  6917,
    6946,  6969,  6986,  7003,  7014,  7043,  7066,  7095,  7130,  7165,
    7176,  7187,  7198,  7209,  7220,  7237,  7254,  7271,  7288,  7299,
    7316,  7333,  7350,  7361,  7378,  7395,  7412,  7429,  7440,  7457,
    7468,  7479,  7490,  7501,  7513,  7520,  7527,  7533,  7544,  7555,
    7572,  7595,  7606,  7617,  7628,  7639,  7674,  7685,  7692,  7709,
    7726,  7743,  7754,  7783,  7807,  7813,  7824,  7841,  7852,  7869,
    7886,  7909,  7920,  7937,  7972,  8007,  8018,  8071,  8106,  8123,
    8134,  8145,  8156,  8173,  8190,  8207,  8230,  8271,  8324,  8389,
    8466,  8489,  8518,  8529,  8540,  8557,  8592,  8615,  8650,  8667,
    8697,  8703,  8715,  8721,  8733,  8739,  8750,  8761,  8784,  8813,
    8860,  8871,  8894,  8911,  8928,  8957,  8969,  8975,  8986,  8997,
    9020,  9031,  9054,  9083,  9112,  9135,  9164,  9187,  9216,  9245,
    9268,  9297,  9320,  9331,  9348,  9359,  9376,  9387,  9410,  9421,
    9444
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || 0
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "IDENTIFIER", "TYPENAME", "SCSPEC",
  "STATIC", "TYPESPEC", "TYPE_QUAL", "CONSTANT", "STRING", "ELLIPSIS",
  "SIZEOF", "ENUM", "STRUCT", "UNION", "IF", "ELSE", "WHILE", "DO", "FOR",
  "SWITCH", "CASE", "DEFAULT", "BREAK", "CONTINUE", "RETURN", "GOTO",
  "ASM_KEYWORD", "TYPEOF", "ALIGNOF", "ATTRIBUTE", "EXTENSION", "LABEL",
  "REALPART", "IMAGPART", "VA_ARG", "CHOOSE_EXPR", "TYPES_COMPATIBLE_P",
  "PTR_VALUE", "PTR_BASE", "PTR_EXTENT", "FUNC_NAME", "','", "')'", "']'",
  "';'", "'}'", "'{'", "'~'", "'!'", "ASSIGN", "'='", "'?'", "':'", "OROR",
  "ANDAND", "'|'", "'^'", "'&'", "EQCOMPARE", "ARITHCOMPARE", "LSHIFT",
  "RSHIFT", "'+'", "'-'", "'*'", "'/'", "'%'", "UNARY", "PLUSPLUS",
  "MINUSMINUS", "HYPERUNARY", "POINTSAT", "'.'", "'('", "'['", "INTERFACE",
  "IMPLEMENTATION", "END", "SELECTOR", "DEFS", "ENCODE", "CLASSNAME",
  "PUBLIC", "PRIVATE", "PROTECTED", "PROTOCOL", "OBJECTNAME", "CLASS",
  "ALIAS", "AT_THROW", "AT_TRY", "AT_CATCH", "AT_FINALLY",
  "AT_SYNCHRONIZED", "OBJC_STRING", "$accept", "program", "extdefs",
  "extdef", "extdef_1", "datadef", "fndef", "identifier", "unop", "expr",
  "exprlist", "nonnull_exprlist", "unary_expr", "sizeof", "alignof",
  "typeof", "cast_expr", "expr_no_commas", "primary", "multistrings",
  "old_style_parm_decls", "old_style_parm_decls_1", "lineno_datadecl",
  "datadecls", "datadecl", "lineno_decl", "setspecs", "maybe_resetattrs",
  "decl", "declspecs_nosc_nots_nosa_noea", "declspecs_nosc_nots_nosa_ea",
  "declspecs_nosc_nots_sa_noea", "declspecs_nosc_nots_sa_ea",
  "declspecs_nosc_ts_nosa_noea", "declspecs_nosc_ts_nosa_ea",
  "declspecs_nosc_ts_sa_noea", "declspecs_nosc_ts_sa_ea",
  "declspecs_sc_nots_nosa_noea", "declspecs_sc_nots_nosa_ea",
  "declspecs_sc_nots_sa_noea", "declspecs_sc_nots_sa_ea",
  "declspecs_sc_ts_nosa_noea", "declspecs_sc_ts_nosa_ea",
  "declspecs_sc_ts_sa_noea", "declspecs_sc_ts_sa_ea", "declspecs_ts",
  "declspecs_nots", "declspecs_ts_nosa", "declspecs_nots_nosa",
  "declspecs_nosc_ts", "declspecs_nosc_nots", "declspecs_nosc",
  "declspecs", "maybe_type_quals_attrs", "typespec_nonattr",
  "typespec_attr", "typespec_reserved_nonattr", "typespec_reserved_attr",
  "typespec_nonreserved_nonattr", "initdecls", "notype_initdecls",
  "maybeasm", "initdcl", "notype_initdcl", "maybe_attribute", "attributes",
  "attribute", "attribute_list", "attrib", "any_word", "scspec", "init",
  "initlist_maybe_comma", "initlist1", "initelt", "initval",
  "designator_list", "designator", "nested_function",
  "notype_nested_function", "declarator", "after_type_declarator",
  "parm_declarator", "parm_declarator_starttypename",
  "parm_declarator_nostarttypename", "notype_declarator", "struct_head",
  "union_head", "enum_head", "structsp_attr", "structsp_nonattr",
  "maybecomma", "maybecomma_warn", "component_decl_list",
  "component_decl_list2", "component_decl", "components",
  "components_notype", "component_declarator",
  "component_notype_declarator", "enumlist", "enumerator", "typename",
  "absdcl", "absdcl_maybe_attribute", "absdcl1", "absdcl1_noea",
  "absdcl1_ea", "direct_absdcl1", "array_declarator", "stmts_and_decls",
  "lineno_stmt_decl_or_labels_ending_stmt",
  "lineno_stmt_decl_or_labels_ending_decl",
  "lineno_stmt_decl_or_labels_ending_label",
  "lineno_stmt_decl_or_labels_ending_error", "lineno_stmt_decl_or_labels",
  "errstmt", "pushlevel", "poplevel", "maybe_label_decls", "label_decls",
  "label_decl", "compstmt_or_error", "compstmt_start", "compstmt_nostart",
  "compstmt_contents_nonempty", "compstmt_primary_start", "compstmt",
  "simple_if", "if_prefix", "do_stmt_start", "save_location",
  "lineno_labeled_stmt", "c99_block_lineno_labeled_stmt", "lineno_stmt",
  "lineno_label", "select_or_iter_stmt", "for_init_stmt", "stmt",
  "exprstmt", "label", "maybe_type_qual", "xexpr", "asm_operands",
  "nonnull_asm_operands", "asm_operand", "asm_clobbers", "parmlist",
  "parmlist_1", "parmlist_2", "parms", "parm", "firstparm", "setspecs_fp",
  "parmlist_or_identifiers", "parmlist_or_identifiers_1", "identifiers",
  "identifiers_or_typenames", "extension", YY_NULLPTR
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[NUM] -- (External) token number corresponding to the
   (internal) symbol number NUM (which must be that of a token).  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,    44,    41,    93,    59,   125,   123,   126,
      33,   298,    61,    63,    58,   299,   300,   124,    94,    38,
     301,   302,   303,   304,    43,    45,    42,    47,    37,   305,
     306,   307,   308,   309,    46,    40,    91,   310,   311,   312,
     313,   314,   315,   316,   317,   318,   319,   320,   321,   322,
     323,   324,   325,   326,   327,   328,   329
};
# endif

#define YYPACT_NINF -670

#define yypact_value_is_default(Yystate) \
  (!!((Yystate) == (-670)))

#define YYTABLE_NINF -497

#define yytable_value_is_error(Yytable_value) \
  0

  /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
     STATE-NUM.  */
static const yytype_int16 yypact[] =
{
    1042,   335,  -670,  -670,  -670,  -670,  -670,    48,    48,    48,
     -20,  -670,    -9,  -670,  -670,    70,  1404,  -670,  -670,  -670,
    -670,    22,    41,   863,  1416,  1023,  1705,   403,   562,  1926,
     909,  1090,  1785,  1239,  1915,  1945,  1174,  2240,  1849,  -670,
    -670,    97,  -670,  -670,  -670,  -670,  -670,    48,  -670,  -670,
     164,   179,   241,  -670,  -670,  2423,  -670,  -670,    48,    48,
      48,  2963,    88,  -670,  -670,  2693,  -670,    46,    48,    42,
    -670,  1525,  -670,  -670,  -670,    48,  -670,  -670,  -670,  -670,
    -670,  -670,  -670,  -670,    48,  -670,  -670,  -670,  -670,  -670,
    -670,  -670,  -670,    48,  -670,  -670,  -670,  -670,  -670,  -670,
    -670,  -670,    48,  -670,  -670,  -670,  -670,  -670,  -670,  -670,
    -670,    48,  -670,  -670,  -670,  -670,  -670,  -670,  -670,  -670,
      48,  -670,  -670,  -670,  -670,  -670,  -670,  -670,  -670,    48,
    -670,  -670,  -670,  -670,  -670,  -670,  -670,  -670,    48,  -670,
    -670,  -670,  -670,  -670,   199,    41,  -670,  -670,  -670,  -670,
    -670,   100,  -670,   127,   368,   158,  -670,   221,  -670,  -670,
    -670,  -670,  2963,  2963,   172,   194,   196,  -670,  -670,  -670,
     207,  -670,  -670,  -670,  2963,  -670,  -670,  2266,  2963,   238,
     247,  -670,  3005,  3047,  -670,  3482,   573,   243,  1974,  2963,
    1137,   268,   979,  2320,  1162,  2404,   658,   444,   809,   542,
     269,   279,   209,   317,   212,   330,  -670,    41,    41,    48,
      48,  -670,   309,   352,    48,   187,  -670,  -670,   799,    52,
      48,  -670,  -670,   482,  -670,    46,    48,   350,  -670,  3161,
     220,   311,   354,  1773,   345,   959,  -670,   384,  -670,  -670,
     381,   392,  -670,   368,   306,  -670,  -670,  2963,  2963,  1625,
    -670,  -670,   393,  -670,   395,   402,  -670,   409,  2963,  2266,
    -670,  2266,  -670,  2963,  2963,  2735,  2963,  2963,  2963,  2963,
    2963,  2963,  2963,  2963,  2963,  2963,  2963,  2963,  2963,  2963,
    -670,  -670,   207,   207,  2963,  2963,  -670,  -670,   417,  -670,
     451,   470,  -670,  -670,  -670,  -670,   449,  -670,   426,  -670,
    -670,    46,    48,  -670,  -670,  -670,  -670,   483,  -670,  -670,
     311,   224,    41,  -670,  -670,   221,  1477,  -670,    46,   502,
    2783,    83,   309,  -670,  -670,   467,  -670,  1259,  2435,   874,
     353,  1489,  2664,  1658,   399,   485,   490,   199,   199,    48,
    -670,   309,  -670,    48,    48,  -670,  -670,   309,  -670,    48,
    -670,  -670,   979,  2320,  1162,  2404,   658,   444,   809,   542,
    -670,   515,   493,  2362,   494,    48,   498,  2963,   207,   505,
     392,  -670,  3273,  3299,   529,  -670,  -670,  2831,  -670,  3482,
     530,   538,  3482,  3482,  2963,   531,  3511,  3169,  3522,  1779,
     882,   935,  1159,   771,   771,   512,   512,  -670,  -670,  -670,
    -670,  -670,   572,   247,   574,  -670,   207,  2047,   451,  -670,
    -670,  1137,   578,  3089,   269,  1898,  -670,    48,  -670,  -670,
    -670,    33,    39,   581,  -670,  -670,  -670,  -670,  -670,   586,
     410,  -670,  -670,   522,  2963,  2963,  -670,  2873,  3374,   605,
    -670,  -670,   620,  -670,  2308,  -670,   199,  -670,    41,   220,
     231,   199,    83,   616,  -670,    83,  -670,   188,   210,  -670,
    -670,    48,  -670,    48,  3482,  -670,    48,   623,  1625,  2963,
    1625,  1560,  -670,   626,   626,  3498,  2963,  -670,  -670,  -670,
     419,   309,  -670,  -670,   160,   183,   214,   215,   675,  -670,
     630,  2487,  -670,  -670,  -670,  -670,  -670,   249,   635,  -670,
    -670,   638,  -670,  1124,  -670,  -670,  -670,  -670,   133,   110,
    -670,  2636,    48,   682,  -670,  3398,  3422,  -670,  -670,  -670,
    -670,  -670,  1560,  3482,  -670,   448,   659,   457,  -670,  -670,
    -670,  2308,  -670,  2963,   270,   645,  -670,  2963,   229,   649,
    -670,  -670,  -670,  -670,    48,   650,  3325,   657,  -670,    50,
    1560,   207,  2963,   648,  3482,   660,   661,  -670,  -670,   -11,
    1694,  3498,   207,  -670,  -670,  -670,  -670,  -670,  -670,  -670,
    2551,  -670,  -670,  -670,  -670,  -670,  -670,  -670,   652,   639,
     642,  -670,   643,   646,  2963,   656,   667,   676,  2921,    90,
     718,  -670,  -670,   685,   989,  -670,  -670,  -670,   690,  -670,
     720,  2120,    24,  -670,  -670,  -670,  -670,  2624,  2963,  -670,
    -670,  -670,  -670,    46,    48,    48,   514,   535,   204,  -670,
    -670,    48,    46,    48,   204,  -670,  -670,  1259,  2435,  2705,
    3128,   874,   353,  2094,   921,  1489,  2664,  3292,  3173,  1658,
     399,  2167,   963,  -670,  -670,  -670,  1124,  -670,  -670,  -670,
     692,  -670,  -670,  -670,  2415,  2963,  -670,    48,  2415,  2963,
    -670,    48,  -670,  -670,  2963,  -670,   700,  -670,   415,  2350,
    -670,  1611,  -670,  2350,  -670,  -670,  -670,  -670,  2963,  2963,
    -670,   730,  -670,  -670,  2624,  2963,  1258,  -670,  -670,  -670,
    -670,   703,  2963,   704,  -670,   677,   701,  -670,  2963,   199,
      41,  -670,  2193,  -670,  -670,  -670,  2963,  -670,   569,   133,
    1350,  -670,    48,  -670,    48,  -670,  -670,    48,   110,  1872,
    -670,   133,   110,  -670,  -670,  -670,  2415,   188,  -670,  2415,
     210,  3350,  -670,  2963,  -670,  -670,  -670,  -670,   712,   715,
    -670,  -670,  -670,  -670,  2963,   716,   721,  2963,  -670,  -670,
     724,  -670,  2963,    48,   722,   464,  -670,  3210,   472,  -670,
    1822,  -670,  -670,   727,  -670,   514,   535,   289,  -670,  -670,
      48,   204,  -670,   204,  -670,  -670,  -670,  -670,  -670,  -670,
    3446,  -670,  -670,   726,  -670,  -670,  3464,  -670,   266,  -670,
    3245,  -670,  -670,  -670,  -670,   731,  -670,  -670,  -670,  -670,
    -670,  -670,  2963,  -670,  -670,   733,    30,  -670,   605,   605,
    -670,   729,  -670,   207,    40,   293,   743,  -670,  -670,  -670,
    -670,   745,  2963,   742,    30,    30,  -670,   221,   750,  -670,
     295,  -670,    57,  -670,   753,   221,  2963,  -670,   786,   590,
     757,   221,   762,  -670,   786,  -670
};

  /* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
     Performed when YYTABLE does not specify something else to do.  Zero
     means the default is an error.  */
static const yytype_uint16 yydefact[] =
{
       0,     0,   258,   288,   287,   255,   117,   336,   332,   334,
       0,    51,     0,   520,    17,     0,     0,     4,     6,     8,
       7,     0,     0,   202,   203,   204,   205,   194,   195,   196,
     197,   206,   207,   208,   209,   198,   199,   200,   201,   109,
     109,     0,   125,   132,   252,   254,   253,   123,   273,   149,
       0,     0,     0,   257,   256,     0,    15,    16,   337,   333,
     335,     0,     0,     1,     5,     0,   331,   250,   271,     0,
     263,     0,   118,   130,   136,   120,   152,   119,   131,   137,
     153,   121,   142,   147,   124,   159,   122,   143,   148,   160,
     126,   128,   134,   133,   170,   127,   129,   135,   171,   138,
     140,   145,   144,   185,   139,   141,   146,   186,   150,   168,
     177,   156,   154,   151,   169,   178,   155,   157,   183,   192,
     163,   161,   158,   184,   193,   162,   164,   166,   175,   174,
     172,   165,   167,   176,   173,   179,   181,   190,   189,   187,
     180,   182,   191,   188,     0,     0,    14,   274,    24,    25,
     353,   344,   353,   345,     0,   346,    10,    73,    77,    94,
      49,    50,     0,     0,     0,     0,     0,    79,    31,    32,
       0,    26,    28,    27,     0,    29,    30,     0,     0,     0,
      33,    52,     0,     0,    54,    36,    38,    78,     0,     0,
     278,     0,   230,   231,   232,   233,   226,   227,   228,   229,
     378,     0,   222,   223,   224,   225,   251,     0,     0,   272,
     271,    11,    23,     0,   271,   250,   444,    96,     0,   444,
     271,   330,   101,     0,   316,   250,   271,     0,   261,     0,
     310,   311,     0,     0,     0,     0,   353,     0,   353,   374,
     375,   349,   372,     0,    74,    47,    48,     0,     0,     0,
      42,    39,     0,   438,     0,     0,    41,     0,     0,     0,
      43,     0,    45,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      92,    93,     0,     0,    34,     0,    76,    95,     0,   434,
     426,     0,    40,   285,   286,   283,     0,   276,   279,   284,
     259,   250,   271,   377,   379,   384,   383,   385,   393,   260,
     329,     0,     0,   110,   423,     0,     0,   327,   250,   251,
       0,     0,     0,   103,   102,   270,    99,   214,   215,   210,
     211,   216,   217,   212,   213,   109,   109,     0,     0,   271,
      13,    19,   444,   271,   271,   314,    12,    21,   444,   271,
     360,   355,   222,   223,   224,   225,   218,   219,   220,   221,
     109,   109,   352,     0,     0,   271,     0,     0,   350,     0,
     349,    75,     0,     0,     0,    82,    81,     0,     9,    37,
       0,     0,    72,    71,     0,     0,    68,    67,    65,    66,
      64,    63,    62,    60,    61,    55,    56,    57,    58,    59,
      91,    90,     0,    35,     0,    84,     0,     0,   427,   428,
      83,   278,     0,    34,   387,     0,   392,   271,   391,   328,
     264,   265,     0,     0,   516,   497,   109,   109,   514,     0,
     498,   500,   513,     0,     0,     0,   395,     0,     0,     0,
     433,    22,   424,   431,     0,   106,     0,   107,     0,   315,
       0,     0,     0,   268,   313,     0,   339,   357,     0,   354,
     361,   271,   341,   271,   376,   373,   271,     0,     0,     0,
       0,     0,    53,    44,    46,    70,     0,    85,    89,   518,
       0,   437,   408,   436,   444,   444,   444,   444,     0,   417,
       0,     0,   403,   412,   429,   277,   275,    73,     0,   386,
     388,     0,   492,     0,   390,   266,   495,   512,   380,   380,
     493,     0,   271,     0,   515,     0,     0,   396,   394,   432,
     439,   291,     0,   289,   269,     0,   265,     0,   312,   262,
      18,     0,    20,     0,   271,   356,   362,     0,   271,   358,
     364,   338,   340,   343,   271,     0,     0,     0,   302,    73,
       0,     0,     0,     0,   301,     0,   347,   294,   299,     0,
       0,    69,     0,   430,   409,   404,   413,   410,   405,   414,
       0,   406,   415,   411,   407,   416,   418,   425,   258,     0,
       0,   444,     0,     0,     0,     0,     0,     0,     0,     0,
     480,   472,   444,     0,    38,   108,   109,   109,     0,   460,
     451,     0,     0,   461,   448,   473,   449,     0,     0,   280,
     282,   389,   321,   250,   271,   271,   317,   318,   271,   509,
     381,   384,   250,   271,   271,   511,   499,   202,   203,   204,
     205,   194,   195,   196,   197,   206,   207,   208,   209,   198,
     199,   200,   201,   109,   109,   501,     0,   517,   397,   398,
       0,   104,   105,   267,   271,     0,   366,   271,   271,     0,
     369,   271,   342,    86,     0,    88,     0,   305,     0,     0,
      80,     0,   293,     0,   304,   297,   519,   435,     0,     0,
     447,     0,   445,   444,   482,     0,     0,   478,   462,   463,
     464,     0,     0,     0,   481,     0,     0,   474,    34,     0,
       0,   115,     0,   441,   440,   455,     0,   116,     0,   387,
       0,   507,   271,   320,   271,   323,   508,   382,   387,     0,
     510,   380,   380,   494,   290,   368,   271,     0,   371,   271,
       0,     0,   300,     0,   307,   298,   295,   296,     0,     0,
     443,   446,   483,   459,   482,     0,     0,     0,   476,   465,
       0,   470,     0,   271,     0,     0,   113,     0,     0,   114,
       0,   452,   450,     0,   281,   324,   325,     0,   319,   322,
     271,   271,   504,   271,   506,   367,   363,   370,   365,    87,
       0,   442,   444,     0,   458,   444,     0,   471,     0,   479,
      85,   111,   444,   112,   444,     0,   326,   502,   503,   505,
     306,   453,   482,   457,   477,     0,   484,   475,     0,     0,
     454,     0,   466,     0,     0,     0,   485,   486,   308,   309,
     444,     0,     0,     0,   484,     0,   456,     0,     0,   467,
       0,   487,     0,   488,     0,     0,     0,   468,   490,     0,
       0,     0,     0,   489,   491,   469
};

  /* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -670,  -670,  -670,    36,  -670,  -670,  -670,   -49,  -670,   -61,
    -404,  -266,   458,  -670,  -670,  -670,   -36,  1029,  -468,   -43,
    -209,  -670,   591,  -670,  -670,   -44,    18,  -305,  -565,    13,
      14,    62,    73,    32,    35,    21,    31,    43,    96,   298,
     300,   118,   146,   308,   310,  -381,  -334,   597,   603,  -670,
    -189,  -670,  -463,  -198,   819,   831,   883,   903,  -670,  -413,
    -137,  -213,   380,   521,   120,   760,   112,  -670,   430,  -670,
     568,   327,  -458,  -670,   189,  -524,  -670,   302,  -670,  -670,
    -139,   314,   138,   157,   -54,   -10,  -670,  -670,  -670,  -670,
    -670,  -670,   504,   -78,  -670,   509,  -670,  -670,   148,   153,
     641,   517,   -95,  -670,  -470,  -190,  -319,  -392,  -670,   618,
    -670,  -670,  -670,  -670,  -670,  -670,  -207,  -670,  -670,  -670,
    -670,   478,    78,  -670,   461,  -670,  -670,  -420,  -670,  -670,
    -670,   -64,   223,  -563,  -362,  -306,  -670,  -670,   114,  -670,
    -670,  -670,  -669,    84,  -670,    82,  -670,   534,  -310,  -670,
    -670,  -670,  -670,   526,  -329,  -670,  -670,  -670,    56
};

  /* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,    15,    16,    17,    18,    19,    20,   553,   178,   254,
     402,   180,   181,   182,   183,    21,   184,   185,   186,   187,
     216,   217,   218,   219,   326,   482,    22,   312,   595,   192,
     193,   194,   195,   196,   197,   198,   199,   331,   332,    33,
      34,   333,   334,    37,    38,    39,    40,   426,   427,   360,
     206,   200,    41,   207,    42,    43,    44,    45,    46,   227,
      69,   220,   228,    70,   313,   209,    48,   296,   297,   298,
      49,   524,   555,   556,   557,   558,   559,   560,   756,   759,
     526,   230,   615,   616,   617,   231,    50,    51,    52,    53,
      54,   672,   369,   234,   235,   362,   535,   539,   536,   540,
     241,   242,   201,   303,   619,   620,   305,   306,   307,   221,
     483,   484,   485,   486,   487,   488,   222,   290,   677,   407,
     408,   409,   441,   442,   291,   490,   188,   443,   600,   601,
     602,   570,   680,   681,   682,   683,   603,   744,   604,   605,
     606,   695,   745,   815,   816,   817,   839,   416,   502,   429,
     430,   645,   431,   508,   317,   432,   433,   480,   189
};

  /* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
     positive, shift that token.  If negative, reduce the rule whose
     number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
     179,   151,   153,   155,   191,   229,   428,   223,   232,   498,
     304,   323,    71,    23,    24,   454,   343,   320,   403,   519,
     342,    29,   500,   594,   348,   705,   319,   337,   598,    23,
      24,    30,    27,   525,   451,    28,   675,    29,   704,   625,
     159,   673,   707,    31,    66,   492,   361,    30,    27,   287,
     287,    28,    64,   -98,     6,    61,    55,   144,   145,    31,
     159,   213,    25,   551,   650,   552,    62,   287,    23,    24,
      63,   599,    55,    26,   237,   783,    29,    12,    25,    12,
     202,   203,   255,   505,   439,   210,    30,    27,   211,    26,
      28,   156,   666,   148,   149,   499,    32,    65,    31,   706,
     -98,   493,   594,   414,   -24,   240,   813,    67,   214,   215,
     596,    55,    32,    66,   244,   822,    68,    25,    35,   743,
     434,   250,   565,   568,   571,   574,   245,   246,    26,   204,
     643,   440,   836,   811,    35,   233,    66,   612,   251,   762,
     205,   295,   256,   146,   598,   735,    36,   403,   236,   737,
     599,    32,   321,   292,   374,   223,   692,   597,   364,   147,
     366,  -419,    36,   190,   380,   223,   381,   148,   149,   223,
     147,   147,   147,    35,   361,   238,   622,   644,   566,   569,
     572,   575,   148,   149,  -420,   623,   215,   147,   208,   621,
     621,    66,   224,   318,   240,     6,   147,   310,   311,   613,
     489,    36,    66,   224,   385,   147,   243,  -399,   614,   215,
     148,   149,   150,    66,   147,  -421,  -422,    72,    12,   801,
      81,   598,   803,   147,   404,   501,   596,   152,   202,   203,
    -400,   159,   147,   400,   401,    12,   327,   328,   202,   203,
      12,   147,   533,    12,   148,   149,   286,   247,   352,   353,
     147,   772,   774,   287,   225,   329,   358,   826,   330,   159,
      12,  -401,  -402,   226,   537,   225,   359,   356,   419,   248,
     357,   249,   422,   597,   226,   528,    67,   204,   452,   214,
     215,   576,   257,   659,   455,    68,   755,   204,   205,   154,
     258,   363,   608,   609,   754,   344,   215,   354,   205,   214,
     215,    12,   421,   596,   214,   215,   344,   215,   355,   371,
     805,   527,   300,   343,   202,   203,   287,   500,   534,   240,
     806,   147,   594,   309,   655,    77,   500,   310,   311,   327,
     328,   202,   203,   796,   316,   301,   723,   823,    86,   834,
     325,   472,   708,   491,   302,   215,   338,   824,   329,   835,
     597,   330,   727,   446,   448,   314,   730,   479,     3,     4,
       5,    95,   295,   204,   714,   215,     7,     8,     9,   239,
     599,   148,   149,   545,   205,   547,   352,   353,   457,   458,
     204,    56,    57,   768,   358,   769,   214,   215,   818,   819,
     499,   205,   349,   339,   359,   356,   340,   210,   357,   499,
     346,   251,   621,   621,     3,     4,     5,   131,     3,     4,
       5,    90,     7,     8,     9,   709,     7,     8,     9,   363,
     491,   491,   415,   491,   718,   354,   733,   315,   327,   328,
     593,   365,   403,   367,    12,   368,   355,   375,   421,   376,
     564,   567,   592,   573,   507,   507,   377,   329,   538,  -238,
     330,     5,    95,   511,   244,   378,   512,     7,     8,     9,
     734,   405,   562,   453,   316,   563,   263,   264,   265,   456,
     266,   267,   268,   269,   270,   271,   272,   273,   274,   275,
     276,   277,   278,   279,   406,   462,     2,     3,     4,     5,
       6,   339,   411,   412,   651,     7,     8,     9,   618,   624,
     210,   413,   667,   652,    23,    24,   244,   339,   435,   593,
     791,    11,    29,   676,   410,   210,   327,   328,   793,   444,
     501,   592,    30,    27,   627,   628,    28,   691,   696,   501,
     530,   445,   633,   532,    31,   329,   447,   503,   330,   459,
     693,   461,   634,   631,   343,   463,   632,   607,   792,     5,
     104,   794,   466,    25,   635,     7,     8,     9,   417,   215,
     757,  -359,  -359,   758,    26,   513,   514,     3,     4,     5,
      95,   292,   470,   629,   473,     7,     8,     9,   277,   278,
     279,   541,   474,   542,   630,   476,   543,    32,   534,   712,
     215,    76,    80,    85,    89,    94,    98,   103,   107,   112,
     116,   121,   125,   130,   134,   139,   143,   636,  -239,    35,
     714,   215,   258,   764,   699,   700,   477,   738,   739,   478,
      23,    24,   496,   742,   746,   506,   202,   203,    29,   639,
     510,   750,   646,   841,   842,   202,   203,    36,    30,    27,
     260,   262,    28,   280,   281,   763,   282,   283,   284,   285,
      31,   449,   450,   440,   656,   766,   767,   640,   660,   327,
     328,   721,   722,   607,   662,     5,    90,   289,   531,    25,
     544,     7,     8,     9,   471,   204,   322,   577,   329,   610,
      26,   330,   611,   742,   204,   647,   205,   213,   657,    12,
     760,   788,   661,   223,   663,   205,   223,    23,    24,   310,
     311,   665,   669,    32,   671,    29,   -25,   670,   310,   311,
     687,   771,   773,   688,   678,    30,    27,   679,   684,    28,
     538,   685,   689,   327,   328,    35,   694,    31,   808,   593,
     809,   697,   327,   328,   710,   711,   701,   702,   716,   724,
     607,   742,   329,   719,   720,   330,    25,   732,   740,   749,
     751,   329,   752,    36,   330,   753,   781,    26,   299,   782,
      47,   828,   784,   814,   821,   785,   790,    58,    59,    60,
     787,   795,   802,   820,   725,   840,    47,   810,   728,   812,
      32,   814,   814,    75,   832,    84,   825,    93,   829,   102,
     827,   111,   838,   120,   833,   129,   287,   138,   844,   837,
     322,   843,    35,  -100,  -100,  -100,  -100,  -100,   845,   637,
     324,   638,  -100,  -100,  -100,    47,     5,    99,   308,   641,
     335,   642,     7,     8,     9,    47,   336,    47,  -100,   147,
      36,   529,   316,   420,   316,   275,   276,   277,   278,   279,
      12,   495,    73,    78,    82,    87,   775,  -100,   345,   777,
     109,   114,   118,   123,    74,    79,    83,    88,   653,   770,
     736,   674,   110,   115,   119,   124,   765,     2,     3,     4,
       5,    72,   460,   789,   467,   776,     7,     8,     9,     3,
       4,     5,    90,   778,   370,   465,   494,     7,     8,     9,
     797,   798,    11,   799,    12,    76,    80,    94,    98,   112,
     116,   130,   134,   520,   807,    12,   741,   831,   830,  -234,
      91,    96,   100,   105,     3,     4,     5,   104,   127,   132,
     136,   141,     7,     8,     9,   418,     3,     4,     5,   104,
      92,    97,   101,   106,     7,     8,     9,    47,   128,   133,
     137,   142,   271,   272,   273,   274,   275,   276,   277,   278,
     279,   504,    75,   509,    84,  -241,    93,     0,   102,     0,
     350,     0,    75,     2,    84,     0,     5,     6,     3,     4,
       5,   140,     7,     8,     9,    47,     7,     8,     9,   299,
       0,     0,     0,     2,     0,    47,     5,    72,    11,     0,
      12,    13,     7,     8,     9,    47,   272,   273,   274,   275,
     276,   277,   278,   279,     0,   351,  -351,     0,    11,    47,
      12,    73,    78,    82,    87,     0,     0,     0,     0,    47,
       0,    47,     0,    74,    79,    83,    88,     2,     3,     4,
       5,    81,   308,   308,     0,     0,     7,     8,     9,     0,
       0,     0,    -2,     1,     0,  -109,     2,     3,     4,     5,
       6,     0,    11,     0,    12,     7,     8,     9,     0,   280,
     281,    47,   282,   283,   698,   285,     0,   345,   345,  -236,
      10,    11,     0,    12,    13,     0,     0,     0,    47,    91,
      96,   100,   105,     0,     0,     0,     0,    75,    14,    93,
       0,   111,     0,   129,     2,     3,     4,     5,   108,    92,
      97,   101,   106,     7,     8,     9,     0,     0,  -109,     0,
       0,     0,    75,     0,    84,     0,    93,  -109,   102,    11,
       0,    12,     0,    47,     0,   423,   308,   308,     2,     3,
       4,     5,     6,     0,     0,   425,  -242,     7,     8,     9,
     148,   149,     3,     4,   293,   294,    73,    78,     0,     0,
     109,   114,     0,    11,     0,     0,     0,     0,    74,    79,
       0,     0,   110,   115,     0,     0,     2,     0,  -496,     5,
      81,    73,    78,    82,    87,     7,     8,     9,     0,     3,
       4,     5,   131,    74,    79,    83,    88,     7,     8,     9,
       0,    11,     0,    12,     0,    76,    80,    85,    89,    94,
      98,   103,   107,   112,   116,   121,   125,   130,   134,   139,
     143,     0,    91,    96,     0,     0,   127,   132,     0,     0,
    -247,   273,   274,   275,   276,   277,   278,   279,    47,     0,
      47,     0,    92,    97,   713,   715,   128,   133,     0,    91,
      96,   100,   105,     2,     3,     4,     5,   117,     0,     0,
       0,    47,     7,     8,     9,     0,     0,     0,     0,    92,
      97,   101,   106,     2,     3,     4,     5,    72,    11,   747,
      12,    47,     7,     8,     9,     0,   372,   373,     0,     0,
       0,     0,     0,     0,     0,  -244,     0,   379,    11,     0,
      12,     0,   382,   383,     0,   386,   387,   388,   389,   390,
     391,   392,   393,   394,   395,   396,   397,   398,   399,   263,
     264,   265,   748,   266,   267,   268,   269,   270,   271,   272,
     273,   274,   275,   276,   277,   278,   279,   308,   308,     0,
       0,     0,     0,     0,     0,     0,   308,   308,     0,   308,
     308,     0,     0,     0,     0,     0,     0,     0,     0,   438,
       0,   423,     0,    66,     2,     3,     4,     5,     6,     0,
       0,   425,     0,     7,     8,     9,     0,    47,     0,     0,
       0,     0,     0,    47,     0,     0,     0,     0,     0,    11,
       0,   717,    47,   713,   715,   715,     0,    75,     0,    84,
       0,    93,     0,   102,  -496,   111,   464,   120,     0,   129,
       0,   138,     0,     0,    -3,     1,     0,  -109,     2,     3,
       4,     5,     6,   475,     0,     0,   613,     7,     8,     9,
       2,     3,     4,     5,    77,   614,   215,     0,     0,     7,
       8,     9,    10,    11,     0,    12,    13,     0,     0,     0,
       0,     0,     0,     0,    47,    11,    73,    78,    82,    87,
      14,     0,     0,     0,   109,   114,   118,   123,    74,    79,
      83,    88,  -235,   515,   516,     0,   110,   115,   119,   124,
    -109,     0,     0,   523,     0,     0,     0,     0,   423,  -109,
     424,     2,     3,     4,     5,     6,     0,     0,   425,     0,
       7,     8,     9,     2,     3,     4,     5,   108,   546,     0,
     554,     0,     7,     8,     9,   561,    11,     0,     0,     0,
       0,     0,     0,     0,    91,    96,   100,   105,    11,     0,
      12,  -496,   127,   132,   136,   141,   212,     0,     0,  -444,
    -444,  -444,  -444,  -444,    92,    97,   101,   106,  -444,  -444,
    -444,     0,   128,   133,   137,   142,     0,     0,     0,     0,
       0,   554,     0,   213,  -444,     0,  -265,     0,     0,     0,
     523,   548,   654,   549,   149,     0,   658,     0,  -265,   158,
     159,  -265,   160,   -97,     0,     0,     0,  -265,     0,   554,
       0,   668,     0,     0,     0,     0,     0,     0,     0,   554,
     161,     0,    13,     0,   162,   163,   164,   165,   166,     0,
     214,   215,   167,     0,     0,     0,     0,  -292,   550,   168,
     169,     0,   548,   686,   549,   149,   170,     0,     0,   171,
     158,   159,     0,   160,   172,   173,   174,     0,     0,     2,
     175,   176,     5,     6,   551,   177,   552,     0,     7,     8,
       9,   161,     0,    13,     0,   162,   163,   164,   165,   166,
       0,     0,     0,   167,    11,     0,    12,     0,  -348,   550,
     168,   169,     0,     3,     4,     5,   126,   170,     0,     0,
     171,     7,     8,     9,     0,   172,   173,   174,     0,     0,
       0,   175,   176,     0,   726,   551,   177,   552,   729,    12,
       0,     0,     0,   731,     0,   548,     0,   157,   554,     0,
     554,     0,   554,   158,   159,     0,   160,     0,     0,     2,
       3,     4,     5,    86,     0,     0,     0,     0,     7,     8,
       9,     0,     0,     0,   161,     0,    13,     0,   162,   163,
     164,   165,   166,     0,    11,     0,   167,     0,     0,     0,
       0,     0,   550,   168,   169,     0,  -303,     0,     0,     0,
     170,  -237,     0,   171,     0,     0,     0,     0,   172,   173,
     174,     0,   780,     0,   175,   176,     0,     0,  -303,   177,
    -303,     0,     0,     0,   347,     0,   786,  -444,  -444,  -444,
    -444,  -444,     0,     0,     0,     0,  -444,  -444,  -444,     2,
       3,     4,     5,   113,     0,     0,     0,     0,     7,     8,
       9,   213,  -444,     0,  -265,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    11,     0,  -265,     0,     0,  -265,
       0,   -97,     0,   322,     0,  -265,  -444,  -444,  -444,  -444,
    -444,  -243,     0,     0,     0,  -444,  -444,  -444,   270,   271,
     272,   273,   274,   275,   276,   277,   278,   279,   214,   215,
     213,  -444,     0,  -265,     3,     4,     5,   140,     0,     0,
       0,     0,     7,     8,     9,  -265,     0,     0,  -265,     0,
     -97,     0,     0,   423,  -265,    66,     2,     3,     4,     5,
       6,     0,     0,   425,     0,     7,     8,     9,     0,     0,
       0,     0,     0,     0,     0,  -249,     0,   214,   215,   423,
       0,    11,     2,     3,     4,     5,     6,     0,     0,   425,
       0,     7,     8,     9,     0,     0,  -496,     0,     0,     2,
       3,     4,     5,   122,     0,     0,     0,    11,     7,     8,
       9,     3,     4,     5,    99,     0,     0,     0,   622,     7,
       8,     9,  -496,     0,    11,     0,     0,   623,   215,     0,
       3,     4,     5,   126,     0,     0,     0,    12,     7,     8,
       9,  -245,     0,     0,   301,     0,     0,     0,     0,     0,
       0,     0,  -240,   302,   215,   288,    12,  -424,  -424,  -424,
    -424,  -424,  -424,  -424,  -424,     0,  -424,  -424,  -424,  -424,
    -424,  -246,  -424,  -424,  -424,  -424,  -424,  -424,  -424,  -424,
    -424,  -424,  -424,  -424,  -424,  -424,  -424,  -424,  -424,  -424,
    -424,  -424,  -424,     0,     0,     0,  -424,     0,     0,     0,
    -424,   289,  -424,  -424,  -424,     0,     0,     0,     0,     0,
    -424,     0,     0,  -424,     0,     0,     0,     0,  -424,  -424,
    -424,     0,     0,     0,  -424,  -424,     0,     0,   481,  -424,
    -444,  -444,  -444,  -444,  -444,  -444,  -444,  -444,     0,  -444,
    -444,  -444,  -444,  -444,     0,  -444,  -444,  -444,  -444,  -444,
    -444,  -444,  -444,  -444,  -444,  -444,  -444,  -444,  -444,  -444,
       0,  -444,  -444,  -444,  -444,  -444,     0,     0,     0,  -444,
       0,     0,     0,  -444,     0,  -444,  -444,  -444,     0,     3,
       4,     5,    99,  -444,     0,     0,  -444,     7,     8,     9,
       0,  -444,  -444,  -444,     0,     0,     0,  -444,  -444,     0,
       0,   703,  -444,  -444,  -444,    12,     0,     0,     0,  -444,
    -444,     0,  -444,     0,     0,     0,  -444,     0,  -444,  -444,
    -444,  -444,  -444,  -444,  -444,  -444,  -444,  -444,  -444,     0,
    -444,     0,  -444,     0,  -444,  -444,  -444,  -444,  -444,     0,
       0,     0,  -444,     0,     0,     0,  -444,     0,  -444,  -444,
    -444,     0,     3,     4,     5,   135,  -444,     0,     0,  -444,
       7,     8,     9,     0,  -444,  -444,  -444,     0,     0,     0,
    -444,  -444,     0,     0,   761,  -444,  -444,  -444,    12,     0,
       0,     0,  -444,  -444,     0,  -444,     0,     0,     0,  -444,
       0,  -444,  -444,  -444,  -444,  -444,  -444,  -444,  -444,  -444,
    -444,  -444,     0,  -444,     0,  -444,     0,  -444,  -444,  -444,
    -444,  -444,     0,     0,     0,  -444,     0,     0,     0,  -444,
       0,  -444,  -444,  -444,     0,     3,     4,     5,   135,  -444,
       0,     0,  -444,     7,     8,     9,     0,  -444,  -444,  -444,
       0,     0,     0,  -444,  -444,     0,     0,   252,  -444,   157,
       2,    12,     0,     5,     6,   158,   159,     0,   160,     7,
       8,     9,     0,     0,     0,     0,  -248,     0,     0,     0,
       0,     0,     0,     0,     0,    11,   161,    12,    13,     0,
     162,   163,   164,   165,   166,     0,     0,     0,   167,   521,
       0,   157,     0,     0,   253,   168,   169,   158,   159,     0,
     160,     0,   170,     0,     2,   171,     0,     5,    77,     0,
     172,   173,   174,     7,     8,     9,   175,   176,   161,     0,
      13,   177,   162,   163,   164,   165,   166,     0,     0,    11,
     167,   548,     0,   157,     0,     0,   522,   168,   169,   158,
     159,     0,   160,   350,   170,     0,     2,   171,     0,     5,
       6,     0,   172,   173,   174,     7,     8,     9,   175,   176,
     161,     0,    13,   177,   162,   163,   164,   165,   166,     0,
       0,    11,   167,    12,    13,     0,     0,     0,   550,   168,
     169,     0,     0,     0,     0,     0,   170,     0,     2,   171,
       0,     5,    86,     0,   172,   173,   174,     7,     8,     9,
     175,   176,     0,     0,     1,   177,  -109,     2,     3,     4,
       5,     6,     0,    11,     0,     0,     7,     8,     9,     2,
       3,     4,     5,    77,     0,     0,    12,     0,     7,     8,
       9,    10,    11,     0,    12,    13,     0,     0,     0,     0,
       0,     0,     0,     0,    11,     0,   263,   264,   265,    14,
     266,   267,   268,   269,   270,   271,   272,   273,   274,   275,
     276,   277,   278,   279,     0,     0,     0,     0,     0,  -109,
     549,   578,     3,     4,     5,     6,   158,   159,  -109,   160,
       7,     8,     9,   579,     0,   580,   581,   582,   583,   584,
     585,   586,   587,   588,   589,   590,    11,   161,    12,    13,
       0,   162,   163,   164,   165,   166,     0,     0,     0,   167,
       0,     0,     0,   591,     0,   440,   168,   169,     0,     0,
       0,     0,     0,   170,     0,     0,   171,     0,     0,     0,
       0,   172,   173,   174,   549,   149,     0,   175,   176,     0,
     158,   159,   177,   160,     0,     0,     0,   579,     0,   580,
     581,   582,   583,   584,   585,   586,   587,   588,   589,   590,
       0,   161,     0,    13,     0,   162,   163,   164,   165,   166,
       0,     0,     0,   167,     0,     0,     0,   591,     0,   440,
     168,   169,     0,     0,     0,     0,     0,   170,     0,     0,
     171,     0,     0,     0,     0,   172,   173,   174,     0,     0,
       0,   175,   176,     0,     0,     0,   177,   157,     2,     3,
       4,     5,     6,   158,   159,     0,   160,     7,     8,     9,
       2,     3,     4,     5,     6,     0,     0,   626,     0,     7,
       8,     9,     0,    11,   161,    12,    13,     0,   162,   163,
     164,   165,   166,     0,     0,    11,   167,    12,     2,     3,
       4,     5,   113,   168,   169,     0,     0,     7,     8,     9,
     170,     0,     0,   171,     0,     0,     0,     0,   172,   173,
     174,     0,     0,    11,   175,   176,   157,     2,     0,   177,
       5,     6,   158,   159,     0,   160,     7,     8,     9,     2,
       3,     4,     5,    81,     0,     0,     0,     0,     7,     8,
       9,     0,    11,   161,    12,    13,     0,   162,   163,   164,
     165,   166,     0,     0,    11,   167,    12,     0,   157,     0,
       0,     0,   168,   169,   158,   159,     0,   160,     0,   170,
       0,     0,   171,     0,     0,     0,     0,   172,   173,   174,
       0,     0,     0,   175,   176,   161,     0,    13,   177,   162,
     163,   164,   165,   166,     0,     0,     0,   167,     0,     0,
       0,     0,     0,     0,   168,   169,   157,     0,     0,   384,
       0,   170,   158,   159,   171,   160,     0,     0,     0,   172,
     173,   174,     0,     0,     0,   175,   176,     0,     0,     0,
     177,     0,     0,   161,     0,    13,     0,   162,   163,   164,
     165,   166,     0,     0,     0,   167,     0,     0,   436,     0,
       0,     0,   168,   169,   157,     0,     0,     0,     0,   170,
     158,   159,   171,   160,     0,     0,     0,   172,   173,   437,
       0,     0,     0,   175,   176,     0,     0,     0,   177,     0,
       0,   161,     0,    13,     0,   162,   163,   164,   165,   166,
       0,     0,     0,   167,     0,     0,   157,     0,     0,   471,
     168,   169,   158,   159,     0,   160,     0,   170,     0,     0,
     171,     0,     0,     0,     0,   172,   173,   174,     0,     0,
       0,   175,   176,   161,     0,    13,   177,   162,   163,   164,
     165,   166,     0,     0,     0,   167,     0,     0,   517,     0,
       0,     0,   168,   169,   157,     0,     0,     0,     0,   170,
     158,   159,   171,   160,     0,     0,     0,   172,   173,   174,
       0,     0,     0,   175,   176,     0,     0,     0,   177,     0,
       0,   161,     0,    13,     0,   162,   163,   164,   165,   166,
       0,     0,     0,   167,     0,     0,   157,   690,     0,     0,
     168,   169,   158,   159,     0,   160,     0,   170,     0,     0,
     171,     0,     0,     0,     0,   172,   173,   174,     0,     0,
       0,   175,   176,   161,     0,    13,   177,   162,   163,   164,
     165,   166,     0,     0,     0,   167,     0,     0,   157,     0,
       0,     0,   168,   169,   158,   159,     0,   160,     0,   170,
       0,     0,   171,     0,     0,     0,     0,   172,   173,   174,
       0,     0,     0,   175,   176,   161,     0,    13,   177,   162,
     163,   164,   165,   166,     0,     0,     0,   167,     0,     0,
     157,     0,     0,     0,   168,   169,   158,   159,     0,   160,
       0,   170,     0,     0,   171,     0,     0,     0,     0,   172,
     173,   174,     0,     0,     0,   175,   176,   161,     0,    13,
     259,   162,   163,   164,   165,   166,     0,     0,     0,   167,
       0,     0,   497,     0,     0,     0,   168,   169,   158,   159,
       0,   160,     0,   170,     0,     0,   171,     0,     0,     0,
       0,   172,   173,   174,     0,     0,     0,   175,   176,   161,
       0,    13,   261,   162,   163,   164,   165,   166,     0,     0,
       0,   167,     2,     3,     4,     5,    86,     0,   168,   169,
       0,     7,     8,     9,     0,   170,     0,     0,   171,     0,
       0,     0,     0,   172,   173,   174,     0,    11,     0,   175,
     176,     0,   341,     0,   177,  -444,  -444,  -444,  -444,  -444,
       0,     0,     0,     0,  -444,  -444,  -444,     2,     3,     4,
       5,   122,     0,     0,     0,     0,     7,     8,     9,   213,
    -444,     0,  -265,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    11,     0,  -265,     0,     0,  -265,     0,   -97,
       0,   322,     0,  -265,  -444,  -444,  -444,  -444,  -444,     0,
       0,     0,     0,  -444,  -444,  -444,   268,   269,   270,   271,
     272,   273,   274,   275,   276,   277,   278,   279,   213,  -444,
       0,  -265,     0,     0,     0,     0,     0,     0,   157,     0,
       0,     0,     0,  -265,   158,   159,  -265,   160,   -97,     0,
       0,   579,  -265,   580,   581,   582,   583,     0,     0,   586,
     587,   588,   589,   590,     0,   161,     0,    13,     0,   162,
     163,   164,   165,   166,     0,     0,     0,   167,     0,     0,
       0,   591,     0,   440,   168,   169,     2,     3,     4,     5,
     117,     0,     0,     0,     0,     7,     8,     9,     0,     0,
       0,     0,     0,     0,     0,     0,   468,     0,     0,     0,
       0,    11,     0,    12,   263,   264,   265,     0,   266,   267,
     268,   269,   270,   271,   272,   273,   274,   275,   276,   277,
     278,   279,   469,     0,     0,     0,     0,     0,     0,     0,
     263,   264,   265,     0,   266,   267,   268,   269,   270,   271,
     272,   273,   274,   275,   276,   277,   278,   279,   664,     0,
       0,     0,     0,     0,     0,     0,   263,   264,   265,     0,
     266,   267,   268,   269,   270,   271,   272,   273,   274,   275,
     276,   277,   278,   279,   779,     0,     0,     0,     0,     0,
       0,   263,   264,   265,     0,   266,   267,   268,   269,   270,
     271,   272,   273,   274,   275,   276,   277,   278,   279,   518,
       0,     0,     0,     0,     0,   263,   264,   265,     0,   266,
     267,   268,   269,   270,   271,   272,   273,   274,   275,   276,
     277,   278,   279,   648,     0,     0,     0,     0,     0,   263,
     264,   265,     0,   266,   267,   268,   269,   270,   271,   272,
     273,   274,   275,   276,   277,   278,   279,   649,     0,     0,
       0,     0,     0,   263,   264,   265,     0,   266,   267,   268,
     269,   270,   271,   272,   273,   274,   275,   276,   277,   278,
     279,   800,     0,     0,     0,     0,     0,   263,   264,   265,
       0,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   263,   264,   265,   804,   266,
     267,   268,   269,   270,   271,   272,   273,   274,   275,   276,
     277,   278,   279,   263,   264,   265,     0,   266,   267,   268,
     269,   270,   271,   272,   273,   274,   275,   276,   277,   278,
     279,   265,     0,   266,   267,   268,   269,   270,   271,   272,
     273,   274,   275,   276,   277,   278,   279,   267,   268,   269,
     270,   271,   272,   273,   274,   275,   276,   277,   278,   279,
     269,   270,   271,   272,   273,   274,   275,   276,   277,   278,
     279
};

static const yytype_int16 yycheck[] =
{
      61,    50,    51,    52,    65,   144,   316,    71,   145,   413,
     200,   218,    22,     0,     0,   344,   229,   215,   284,   439,
     229,     0,   414,   491,   233,     1,   215,   225,   491,    16,
      16,     0,     0,   446,   339,     0,   560,    16,   601,   509,
      10,    52,   607,     0,     3,   407,   235,    16,    16,    10,
      10,    16,    16,     1,     8,    75,     0,    39,    40,    16,
      10,    28,     0,    74,   522,    76,    75,    10,    55,    55,
       0,   491,    16,     0,   152,   744,    55,    31,    16,    31,
      67,    67,   177,    44,     1,    43,    55,    55,    46,    16,
      55,    55,   550,     3,     4,   414,     0,    75,    55,    75,
      48,   407,   570,   301,    54,   154,    76,    66,    75,    76,
     491,    55,    16,     3,   157,    75,    75,    55,     0,   684,
     318,   170,   484,   485,   486,   487,   162,   163,    55,    67,
     511,    48,    75,   802,    16,   145,     3,     4,   174,   702,
      67,   190,   178,    46,   607,   669,     0,   413,    48,   673,
     570,    55,   216,   189,   249,   219,    66,   491,   236,    47,
     238,     1,    16,    75,   259,   229,   261,     3,     4,   233,
      58,    59,    60,    55,   363,    48,    66,   511,   484,   485,
     486,   487,     3,     4,     1,    75,    76,    75,    68,   508,
     509,     3,     4,     6,   243,     8,    84,   207,   208,    66,
     407,    55,     3,     4,   265,    93,    48,    47,    75,    76,
       3,     4,    48,     3,   102,     1,     1,     8,    31,   782,
       8,   684,   785,   111,   285,   415,   607,    48,   215,   215,
      47,    10,   120,   282,   283,    31,   223,   223,   225,   225,
      31,   129,    54,    31,     3,     4,     3,    75,   235,   235,
     138,   721,   722,    10,    66,   223,   235,   820,   223,    10,
      31,    47,    47,    75,    54,    66,   235,   235,    44,    75,
     235,    75,   315,   607,    75,    44,    66,   215,   342,    75,
      76,   488,    44,    54,   348,    75,   699,   225,   215,    48,
      43,   235,    43,    44,   698,    75,    76,   235,   225,    75,
      76,    31,   312,   684,    75,    76,    75,    76,   235,     3,
      44,   448,    44,   526,   301,   301,    10,   709,   457,   368,
      54,   209,   790,    44,    54,     8,   718,   337,   338,   316,
     316,   318,   318,    44,   214,    66,   646,    44,     8,    44,
     220,   377,   608,   407,    75,    76,   226,    54,   316,    54,
     684,   316,   657,   335,   336,    46,   661,   406,     5,     6,
       7,     8,   411,   301,    75,    76,    13,    14,    15,     1,
     790,     3,     4,   468,   301,   470,   363,   363,   360,   361,
     318,    46,    47,   712,   363,   714,    75,    76,   808,   809,
     709,   318,    47,    43,   363,   363,    46,    43,   363,   718,
      46,   437,   721,   722,     5,     6,     7,     8,     5,     6,
       7,     8,    13,    14,    15,   613,    13,    14,    15,   363,
     484,   485,   302,   487,   622,   363,    11,    75,   415,   415,
     491,    47,   698,    52,    31,    43,   363,    44,   448,    44,
     484,   485,   491,   487,   426,   427,    44,   415,   458,    46,
     415,     7,     8,    43,   497,    46,    46,    13,    14,    15,
      45,    44,    43,   343,   344,    46,    51,    52,    53,   349,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    33,   365,     4,     5,     6,     7,
       8,    43,    43,    44,    46,    13,    14,    15,   508,   509,
      43,    75,   551,    46,   491,   491,   549,    43,     6,   570,
      46,    29,   491,   562,    44,    43,   503,   503,    46,    52,
     710,   570,   491,   491,   511,   511,   491,   588,   592,   719,
     452,    46,   511,   455,   491,   503,    46,   417,   503,    46,
     589,    47,   511,   511,   757,    47,   511,   491,   757,     7,
       8,   760,    47,   491,   511,    13,    14,    15,    75,    76,
     699,    46,    47,   700,   491,    43,    44,     5,     6,     7,
       8,   607,    43,   511,    44,    13,    14,    15,    66,    67,
      68,   461,    44,   463,   511,    54,   466,   491,   727,    75,
      76,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,   511,    46,   491,
      75,    76,    43,    44,   596,   597,    44,   678,   679,    45,
     607,   607,    44,   684,   685,    44,   613,   613,   607,   511,
      44,   692,   512,    43,    44,   622,   622,   491,   607,   607,
     182,   183,   607,    70,    71,   706,    73,    74,    75,    76,
     607,   337,   338,    48,   534,   709,   710,   511,   538,   646,
     646,   643,   644,   607,   544,     7,     8,    47,    52,   607,
      47,    13,    14,    15,    48,   613,     1,    47,   646,    44,
     607,   646,    44,   744,   622,     3,   613,    28,    43,    31,
     700,   752,    43,   757,    44,   622,   760,   684,   684,   709,
     710,    44,    54,   607,    43,   684,    54,    47,   718,   719,
      54,   721,   722,    46,    75,   684,   684,    75,    75,   684,
     730,    75,    46,   710,   710,   607,     8,   684,   792,   790,
     794,    46,   719,   719,   614,   615,    46,    17,   618,    47,
     684,   802,   710,   623,   624,   710,   684,    47,    18,    46,
      46,   719,    75,   607,   719,    54,    44,   684,   190,    44,
       0,   822,    46,   806,   813,    44,    44,     7,     8,     9,
      46,    44,    46,    44,   654,   836,    16,    46,   658,    46,
     684,   824,   825,    23,   827,    25,    43,    27,    46,    29,
      45,    31,   835,    33,    44,    35,    10,    37,   841,    46,
       1,    44,   684,     4,     5,     6,     7,     8,    46,   511,
     219,   511,    13,    14,    15,    55,     7,     8,   200,   511,
     223,   511,    13,    14,    15,    65,   223,    67,    29,   717,
     684,   451,   712,   312,   714,    64,    65,    66,    67,    68,
      31,   411,    23,    24,    25,    26,   726,    48,   230,   729,
      31,    32,    33,    34,    23,    24,    25,    26,   531,   721,
     671,   559,    31,    32,    33,    34,   709,     4,     5,     6,
       7,     8,   363,   753,   370,   727,    13,    14,    15,     5,
       6,     7,     8,   730,   243,   368,   408,    13,    14,    15,
     770,   771,    29,   773,    31,   327,   328,   329,   330,   331,
     332,   333,   334,   442,   790,    31,   683,   825,   824,    46,
      27,    28,    29,    30,     5,     6,     7,     8,    35,    36,
      37,    38,    13,    14,    15,   307,     5,     6,     7,     8,
      27,    28,    29,    30,    13,    14,    15,   177,    35,    36,
      37,    38,    60,    61,    62,    63,    64,    65,    66,    67,
      68,   417,   192,   427,   194,    46,   196,    -1,   198,    -1,
       1,    -1,   202,     4,   204,    -1,     7,     8,     5,     6,
       7,     8,    13,    14,    15,   215,    13,    14,    15,   411,
      -1,    -1,    -1,     4,    -1,   225,     7,     8,    29,    -1,
      31,    32,    13,    14,    15,   235,    61,    62,    63,    64,
      65,    66,    67,    68,    -1,    46,    47,    -1,    29,   249,
      31,   192,   193,   194,   195,    -1,    -1,    -1,    -1,   259,
      -1,   261,    -1,   192,   193,   194,   195,     4,     5,     6,
       7,     8,   414,   415,    -1,    -1,    13,    14,    15,    -1,
      -1,    -1,     0,     1,    -1,     3,     4,     5,     6,     7,
       8,    -1,    29,    -1,    31,    13,    14,    15,    -1,    70,
      71,   301,    73,    74,    75,    76,    -1,   449,   450,    46,
      28,    29,    -1,    31,    32,    -1,    -1,    -1,   318,   196,
     197,   198,   199,    -1,    -1,    -1,    -1,   327,    46,   329,
      -1,   331,    -1,   333,     4,     5,     6,     7,     8,   196,
     197,   198,   199,    13,    14,    15,    -1,    -1,    66,    -1,
      -1,    -1,   352,    -1,   354,    -1,   356,    75,   358,    29,
      -1,    31,    -1,   363,    -1,     1,   508,   509,     4,     5,
       6,     7,     8,    -1,    -1,    11,    46,    13,    14,    15,
       3,     4,     5,     6,     7,     8,   327,   328,    -1,    -1,
     331,   332,    -1,    29,    -1,    -1,    -1,    -1,   327,   328,
      -1,    -1,   331,   332,    -1,    -1,     4,    -1,    44,     7,
       8,   352,   353,   354,   355,    13,    14,    15,    -1,     5,
       6,     7,     8,   352,   353,   354,   355,    13,    14,    15,
      -1,    29,    -1,    31,    -1,   627,   628,   629,   630,   631,
     632,   633,   634,   635,   636,   637,   638,   639,   640,   641,
     642,    -1,   329,   330,    -1,    -1,   333,   334,    -1,    -1,
      46,    62,    63,    64,    65,    66,    67,    68,   468,    -1,
     470,    -1,   329,   330,   616,   617,   333,   334,    -1,   356,
     357,   358,   359,     4,     5,     6,     7,     8,    -1,    -1,
      -1,   491,    13,    14,    15,    -1,    -1,    -1,    -1,   356,
     357,   358,   359,     4,     5,     6,     7,     8,    29,    11,
      31,   511,    13,    14,    15,    -1,   247,   248,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    46,    -1,   258,    29,    -1,
      31,    -1,   263,   264,    -1,   266,   267,   268,   269,   270,
     271,   272,   273,   274,   275,   276,   277,   278,   279,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
      62,    63,    64,    65,    66,    67,    68,   709,   710,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   718,   719,    -1,   721,
     722,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   320,
      -1,     1,    -1,     3,     4,     5,     6,     7,     8,    -1,
      -1,    11,    -1,    13,    14,    15,    -1,   607,    -1,    -1,
      -1,    -1,    -1,   613,    -1,    -1,    -1,    -1,    -1,    29,
      -1,   621,   622,   765,   766,   767,    -1,   627,    -1,   629,
      -1,   631,    -1,   633,    44,   635,   367,   637,    -1,   639,
      -1,   641,    -1,    -1,     0,     1,    -1,     3,     4,     5,
       6,     7,     8,   384,    -1,    -1,    66,    13,    14,    15,
       4,     5,     6,     7,     8,    75,    76,    -1,    -1,    13,
      14,    15,    28,    29,    -1,    31,    32,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   684,    29,   627,   628,   629,   630,
      46,    -1,    -1,    -1,   635,   636,   637,   638,   627,   628,
     629,   630,    46,   434,   435,    -1,   635,   636,   637,   638,
      66,    -1,    -1,   444,    -1,    -1,    -1,    -1,     1,    75,
       3,     4,     5,     6,     7,     8,    -1,    -1,    11,    -1,
      13,    14,    15,     4,     5,     6,     7,     8,   469,    -1,
     471,    -1,    13,    14,    15,   476,    29,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   631,   632,   633,   634,    29,    -1,
      31,    44,   639,   640,   641,   642,     1,    -1,    -1,     4,
       5,     6,     7,     8,   631,   632,   633,   634,    13,    14,
      15,    -1,   639,   640,   641,   642,    -1,    -1,    -1,    -1,
      -1,   522,    -1,    28,    29,    -1,    31,    -1,    -1,    -1,
     531,     1,   533,     3,     4,    -1,   537,    -1,    43,     9,
      10,    46,    12,    48,    -1,    -1,    -1,    52,    -1,   550,
      -1,   552,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   560,
      30,    -1,    32,    -1,    34,    35,    36,    37,    38,    -1,
      75,    76,    42,    -1,    -1,    -1,    -1,    47,    48,    49,
      50,    -1,     1,   584,     3,     4,    56,    -1,    -1,    59,
       9,    10,    -1,    12,    64,    65,    66,    -1,    -1,     4,
      70,    71,     7,     8,    74,    75,    76,    -1,    13,    14,
      15,    30,    -1,    32,    -1,    34,    35,    36,    37,    38,
      -1,    -1,    -1,    42,    29,    -1,    31,    -1,    47,    48,
      49,    50,    -1,     5,     6,     7,     8,    56,    -1,    -1,
      59,    13,    14,    15,    -1,    64,    65,    66,    -1,    -1,
      -1,    70,    71,    -1,   655,    74,    75,    76,   659,    31,
      -1,    -1,    -1,   664,    -1,     1,    -1,     3,   669,    -1,
     671,    -1,   673,     9,    10,    -1,    12,    -1,    -1,     4,
       5,     6,     7,     8,    -1,    -1,    -1,    -1,    13,    14,
      15,    -1,    -1,    -1,    30,    -1,    32,    -1,    34,    35,
      36,    37,    38,    -1,    29,    -1,    42,    -1,    -1,    -1,
      -1,    -1,    48,    49,    50,    -1,    52,    -1,    -1,    -1,
      56,    46,    -1,    59,    -1,    -1,    -1,    -1,    64,    65,
      66,    -1,   733,    -1,    70,    71,    -1,    -1,    74,    75,
      76,    -1,    -1,    -1,     1,    -1,   747,     4,     5,     6,
       7,     8,    -1,    -1,    -1,    -1,    13,    14,    15,     4,
       5,     6,     7,     8,    -1,    -1,    -1,    -1,    13,    14,
      15,    28,    29,    -1,    31,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    29,    -1,    43,    -1,    -1,    46,
      -1,    48,    -1,     1,    -1,    52,     4,     5,     6,     7,
       8,    46,    -1,    -1,    -1,    13,    14,    15,    59,    60,
      61,    62,    63,    64,    65,    66,    67,    68,    75,    76,
      28,    29,    -1,    31,     5,     6,     7,     8,    -1,    -1,
      -1,    -1,    13,    14,    15,    43,    -1,    -1,    46,    -1,
      48,    -1,    -1,     1,    52,     3,     4,     5,     6,     7,
       8,    -1,    -1,    11,    -1,    13,    14,    15,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    46,    -1,    75,    76,     1,
      -1,    29,     4,     5,     6,     7,     8,    -1,    -1,    11,
      -1,    13,    14,    15,    -1,    -1,    44,    -1,    -1,     4,
       5,     6,     7,     8,    -1,    -1,    -1,    29,    13,    14,
      15,     5,     6,     7,     8,    -1,    -1,    -1,    66,    13,
      14,    15,    44,    -1,    29,    -1,    -1,    75,    76,    -1,
       5,     6,     7,     8,    -1,    -1,    -1,    31,    13,    14,
      15,    46,    -1,    -1,    66,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    46,    75,    76,     1,    31,     3,     4,     5,
       6,     7,     8,     9,    10,    -1,    12,    13,    14,    15,
      16,    46,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    -1,    -1,    -1,    42,    -1,    -1,    -1,
      46,    47,    48,    49,    50,    -1,    -1,    -1,    -1,    -1,
      56,    -1,    -1,    59,    -1,    -1,    -1,    -1,    64,    65,
      66,    -1,    -1,    -1,    70,    71,    -1,    -1,     1,    75,
       3,     4,     5,     6,     7,     8,     9,    10,    -1,    12,
      13,    14,    15,    16,    -1,    18,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      -1,    34,    35,    36,    37,    38,    -1,    -1,    -1,    42,
      -1,    -1,    -1,    46,    -1,    48,    49,    50,    -1,     5,
       6,     7,     8,    56,    -1,    -1,    59,    13,    14,    15,
      -1,    64,    65,    66,    -1,    -1,    -1,    70,    71,    -1,
      -1,     1,    75,     3,     4,    31,    -1,    -1,    -1,     9,
      10,    -1,    12,    -1,    -1,    -1,    16,    -1,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    -1,
      30,    -1,    32,    -1,    34,    35,    36,    37,    38,    -1,
      -1,    -1,    42,    -1,    -1,    -1,    46,    -1,    48,    49,
      50,    -1,     5,     6,     7,     8,    56,    -1,    -1,    59,
      13,    14,    15,    -1,    64,    65,    66,    -1,    -1,    -1,
      70,    71,    -1,    -1,     1,    75,     3,     4,    31,    -1,
      -1,    -1,     9,    10,    -1,    12,    -1,    -1,    -1,    16,
      -1,    18,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    -1,    30,    -1,    32,    -1,    34,    35,    36,
      37,    38,    -1,    -1,    -1,    42,    -1,    -1,    -1,    46,
      -1,    48,    49,    50,    -1,     5,     6,     7,     8,    56,
      -1,    -1,    59,    13,    14,    15,    -1,    64,    65,    66,
      -1,    -1,    -1,    70,    71,    -1,    -1,     1,    75,     3,
       4,    31,    -1,     7,     8,     9,    10,    -1,    12,    13,
      14,    15,    -1,    -1,    -1,    -1,    46,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    29,    30,    31,    32,    -1,
      34,    35,    36,    37,    38,    -1,    -1,    -1,    42,     1,
      -1,     3,    -1,    -1,    48,    49,    50,     9,    10,    -1,
      12,    -1,    56,    -1,     4,    59,    -1,     7,     8,    -1,
      64,    65,    66,    13,    14,    15,    70,    71,    30,    -1,
      32,    75,    34,    35,    36,    37,    38,    -1,    -1,    29,
      42,     1,    -1,     3,    -1,    -1,    48,    49,    50,     9,
      10,    -1,    12,     1,    56,    -1,     4,    59,    -1,     7,
       8,    -1,    64,    65,    66,    13,    14,    15,    70,    71,
      30,    -1,    32,    75,    34,    35,    36,    37,    38,    -1,
      -1,    29,    42,    31,    32,    -1,    -1,    -1,    48,    49,
      50,    -1,    -1,    -1,    -1,    -1,    56,    -1,     4,    59,
      -1,     7,     8,    -1,    64,    65,    66,    13,    14,    15,
      70,    71,    -1,    -1,     1,    75,     3,     4,     5,     6,
       7,     8,    -1,    29,    -1,    -1,    13,    14,    15,     4,
       5,     6,     7,     8,    -1,    -1,    31,    -1,    13,    14,
      15,    28,    29,    -1,    31,    32,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    29,    -1,    51,    52,    53,    46,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    -1,    -1,    -1,    -1,    -1,    66,
       3,     4,     5,     6,     7,     8,     9,    10,    75,    12,
      13,    14,    15,    16,    -1,    18,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      -1,    34,    35,    36,    37,    38,    -1,    -1,    -1,    42,
      -1,    -1,    -1,    46,    -1,    48,    49,    50,    -1,    -1,
      -1,    -1,    -1,    56,    -1,    -1,    59,    -1,    -1,    -1,
      -1,    64,    65,    66,     3,     4,    -1,    70,    71,    -1,
       9,    10,    75,    12,    -1,    -1,    -1,    16,    -1,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      -1,    30,    -1,    32,    -1,    34,    35,    36,    37,    38,
      -1,    -1,    -1,    42,    -1,    -1,    -1,    46,    -1,    48,
      49,    50,    -1,    -1,    -1,    -1,    -1,    56,    -1,    -1,
      59,    -1,    -1,    -1,    -1,    64,    65,    66,    -1,    -1,
      -1,    70,    71,    -1,    -1,    -1,    75,     3,     4,     5,
       6,     7,     8,     9,    10,    -1,    12,    13,    14,    15,
       4,     5,     6,     7,     8,    -1,    -1,    11,    -1,    13,
      14,    15,    -1,    29,    30,    31,    32,    -1,    34,    35,
      36,    37,    38,    -1,    -1,    29,    42,    31,     4,     5,
       6,     7,     8,    49,    50,    -1,    -1,    13,    14,    15,
      56,    -1,    -1,    59,    -1,    -1,    -1,    -1,    64,    65,
      66,    -1,    -1,    29,    70,    71,     3,     4,    -1,    75,
       7,     8,     9,    10,    -1,    12,    13,    14,    15,     4,
       5,     6,     7,     8,    -1,    -1,    -1,    -1,    13,    14,
      15,    -1,    29,    30,    31,    32,    -1,    34,    35,    36,
      37,    38,    -1,    -1,    29,    42,    31,    -1,     3,    -1,
      -1,    -1,    49,    50,     9,    10,    -1,    12,    -1,    56,
      -1,    -1,    59,    -1,    -1,    -1,    -1,    64,    65,    66,
      -1,    -1,    -1,    70,    71,    30,    -1,    32,    75,    34,
      35,    36,    37,    38,    -1,    -1,    -1,    42,    -1,    -1,
      -1,    -1,    -1,    -1,    49,    50,     3,    -1,    -1,    54,
      -1,    56,     9,    10,    59,    12,    -1,    -1,    -1,    64,
      65,    66,    -1,    -1,    -1,    70,    71,    -1,    -1,    -1,
      75,    -1,    -1,    30,    -1,    32,    -1,    34,    35,    36,
      37,    38,    -1,    -1,    -1,    42,    -1,    -1,    45,    -1,
      -1,    -1,    49,    50,     3,    -1,    -1,    -1,    -1,    56,
       9,    10,    59,    12,    -1,    -1,    -1,    64,    65,    66,
      -1,    -1,    -1,    70,    71,    -1,    -1,    -1,    75,    -1,
      -1,    30,    -1,    32,    -1,    34,    35,    36,    37,    38,
      -1,    -1,    -1,    42,    -1,    -1,     3,    -1,    -1,    48,
      49,    50,     9,    10,    -1,    12,    -1,    56,    -1,    -1,
      59,    -1,    -1,    -1,    -1,    64,    65,    66,    -1,    -1,
      -1,    70,    71,    30,    -1,    32,    75,    34,    35,    36,
      37,    38,    -1,    -1,    -1,    42,    -1,    -1,    45,    -1,
      -1,    -1,    49,    50,     3,    -1,    -1,    -1,    -1,    56,
       9,    10,    59,    12,    -1,    -1,    -1,    64,    65,    66,
      -1,    -1,    -1,    70,    71,    -1,    -1,    -1,    75,    -1,
      -1,    30,    -1,    32,    -1,    34,    35,    36,    37,    38,
      -1,    -1,    -1,    42,    -1,    -1,     3,    46,    -1,    -1,
      49,    50,     9,    10,    -1,    12,    -1,    56,    -1,    -1,
      59,    -1,    -1,    -1,    -1,    64,    65,    66,    -1,    -1,
      -1,    70,    71,    30,    -1,    32,    75,    34,    35,    36,
      37,    38,    -1,    -1,    -1,    42,    -1,    -1,     3,    -1,
      -1,    -1,    49,    50,     9,    10,    -1,    12,    -1,    56,
      -1,    -1,    59,    -1,    -1,    -1,    -1,    64,    65,    66,
      -1,    -1,    -1,    70,    71,    30,    -1,    32,    75,    34,
      35,    36,    37,    38,    -1,    -1,    -1,    42,    -1,    -1,
       3,    -1,    -1,    -1,    49,    50,     9,    10,    -1,    12,
      -1,    56,    -1,    -1,    59,    -1,    -1,    -1,    -1,    64,
      65,    66,    -1,    -1,    -1,    70,    71,    30,    -1,    32,
      75,    34,    35,    36,    37,    38,    -1,    -1,    -1,    42,
      -1,    -1,     3,    -1,    -1,    -1,    49,    50,     9,    10,
      -1,    12,    -1,    56,    -1,    -1,    59,    -1,    -1,    -1,
      -1,    64,    65,    66,    -1,    -1,    -1,    70,    71,    30,
      -1,    32,    75,    34,    35,    36,    37,    38,    -1,    -1,
      -1,    42,     4,     5,     6,     7,     8,    -1,    49,    50,
      -1,    13,    14,    15,    -1,    56,    -1,    -1,    59,    -1,
      -1,    -1,    -1,    64,    65,    66,    -1,    29,    -1,    70,
      71,    -1,     1,    -1,    75,     4,     5,     6,     7,     8,
      -1,    -1,    -1,    -1,    13,    14,    15,     4,     5,     6,
       7,     8,    -1,    -1,    -1,    -1,    13,    14,    15,    28,
      29,    -1,    31,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    29,    -1,    43,    -1,    -1,    46,    -1,    48,
      -1,     1,    -1,    52,     4,     5,     6,     7,     8,    -1,
      -1,    -1,    -1,    13,    14,    15,    57,    58,    59,    60,
      61,    62,    63,    64,    65,    66,    67,    68,    28,    29,
      -1,    31,    -1,    -1,    -1,    -1,    -1,    -1,     3,    -1,
      -1,    -1,    -1,    43,     9,    10,    46,    12,    48,    -1,
      -1,    16,    52,    18,    19,    20,    21,    -1,    -1,    24,
      25,    26,    27,    28,    -1,    30,    -1,    32,    -1,    34,
      35,    36,    37,    38,    -1,    -1,    -1,    42,    -1,    -1,
      -1,    46,    -1,    48,    49,    50,     4,     5,     6,     7,
       8,    -1,    -1,    -1,    -1,    13,    14,    15,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    43,    -1,    -1,    -1,
      -1,    29,    -1,    31,    51,    52,    53,    -1,    55,    56,
      57,    58,    59,    60,    61,    62,    63,    64,    65,    66,
      67,    68,    43,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      51,    52,    53,    -1,    55,    56,    57,    58,    59,    60,
      61,    62,    63,    64,    65,    66,    67,    68,    43,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    51,    52,    53,    -1,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    44,    -1,    -1,    -1,    -1,    -1,
      -1,    51,    52,    53,    -1,    55,    56,    57,    58,    59,
      60,    61,    62,    63,    64,    65,    66,    67,    68,    45,
      -1,    -1,    -1,    -1,    -1,    51,    52,    53,    -1,    55,
      56,    57,    58,    59,    60,    61,    62,    63,    64,    65,
      66,    67,    68,    45,    -1,    -1,    -1,    -1,    -1,    51,
      52,    53,    -1,    55,    56,    57,    58,    59,    60,    61,
      62,    63,    64,    65,    66,    67,    68,    45,    -1,    -1,
      -1,    -1,    -1,    51,    52,    53,    -1,    55,    56,    57,
      58,    59,    60,    61,    62,    63,    64,    65,    66,    67,
      68,    45,    -1,    -1,    -1,    -1,    -1,    51,    52,    53,
      -1,    55,    56,    57,    58,    59,    60,    61,    62,    63,
      64,    65,    66,    67,    68,    51,    52,    53,    54,    55,
      56,    57,    58,    59,    60,    61,    62,    63,    64,    65,
      66,    67,    68,    51,    52,    53,    -1,    55,    56,    57,
      58,    59,    60,    61,    62,    63,    64,    65,    66,    67,
      68,    53,    -1,    55,    56,    57,    58,    59,    60,    61,
      62,    63,    64,    65,    66,    67,    68,    56,    57,    58,
      59,    60,    61,    62,    63,    64,    65,    66,    67,    68,
      58,    59,    60,    61,    62,    63,    64,    65,    66,    67,
      68
};

  /* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
     symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     1,     4,     5,     6,     7,     8,    13,    14,    15,
      28,    29,    31,    32,    46,    98,    99,   100,   101,   102,
     103,   112,   123,   126,   127,   128,   129,   130,   131,   132,
     133,   134,   135,   136,   137,   138,   139,   140,   141,   142,
     143,   149,   151,   152,   153,   154,   155,   162,   163,   167,
     183,   184,   185,   186,   187,   255,    46,    47,   162,   162,
     162,    75,    75,     0,   100,    75,     3,    66,    75,   157,
     160,   182,     8,   151,   152,   162,   167,     8,   151,   152,
     167,     8,   151,   152,   162,   167,     8,   151,   152,   167,
       8,   153,   154,   162,   167,     8,   153,   154,   167,     8,
     153,   154,   162,   167,     8,   153,   154,   167,     8,   151,
     152,   162,   167,     8,   151,   152,   167,     8,   151,   152,
     162,   167,     8,   151,   152,   167,     8,   153,   154,   162,
     167,     8,   153,   154,   167,     8,   153,   154,   162,   167,
       8,   153,   154,   167,   123,   123,    46,   163,     3,     4,
      48,   104,    48,   104,    48,   104,   100,     3,     9,    10,
      12,    30,    34,    35,    36,    37,    38,    42,    49,    50,
      56,    59,    64,    65,    66,    70,    71,    75,   105,   106,
     108,   109,   110,   111,   113,   114,   115,   116,   223,   255,
      75,   106,   126,   127,   128,   129,   130,   131,   132,   133,
     148,   199,   126,   127,   128,   129,   147,   150,   161,   162,
      43,    46,     1,    28,    75,    76,   117,   118,   119,   120,
     158,   206,   213,   228,     4,    66,    75,   156,   159,   177,
     178,   182,   157,   182,   190,   191,    48,   190,    48,     1,
     104,   197,   198,    48,   116,   113,   113,    75,    75,    75,
     104,   113,     1,    48,   106,   199,   113,    44,    43,    75,
     109,    75,   109,    51,    52,    53,    55,    56,    57,    58,
      59,    60,    61,    62,    63,    64,    65,    66,    67,    68,
      70,    71,    73,    74,    75,    76,     3,    10,     1,    47,
     214,   221,   113,     7,     8,   104,   164,   165,   166,   167,
      44,    66,    75,   200,   202,   203,   204,   205,   206,    44,
     182,   182,   124,   161,    46,    75,   161,   251,     6,   147,
     150,   228,     1,   213,   119,   161,   121,   126,   127,   130,
     131,   134,   135,   138,   139,   144,   145,   150,   161,    43,
      46,     1,   117,   158,    75,   206,    46,     1,   117,    47,
       1,    46,   126,   127,   128,   129,   130,   131,   132,   133,
     146,   147,   192,   255,   190,    47,   190,    52,    43,   189,
     197,     3,   114,   114,   199,    44,    44,    44,    46,   114,
     199,   199,   114,   114,    54,   106,   114,   114,   114,   114,
     114,   114,   114,   114,   114,   114,   114,   114,   114,   114,
     104,   104,   107,   108,   106,    44,    33,   216,   217,   218,
      44,    43,    44,    75,   150,   161,   244,    75,   206,    44,
     160,   182,   116,     1,     3,    11,   144,   145,   245,   246,
     247,   249,   252,   253,   150,     6,    45,    66,   114,     1,
      48,   219,   220,   224,    52,    46,   123,    46,   123,   178,
     178,   124,   228,   161,   251,   228,   161,   123,   123,    46,
     192,    47,   161,    47,   114,   198,    47,   189,    43,    43,
      43,    48,   113,    44,    44,   114,    54,    44,    45,   104,
     254,     1,   122,   207,   208,   209,   210,   211,   212,   213,
     222,   228,   231,   232,   218,   165,    44,     3,   107,   203,
     204,   202,   245,   161,   244,    44,    44,   123,   250,   250,
      44,    43,    46,    43,    44,   114,   114,    45,    45,   224,
     221,     1,    48,   114,   168,   156,   177,   157,    44,   159,
     219,    52,   219,    54,   177,   193,   195,    54,   182,   194,
     196,   161,   161,   161,    47,   199,   114,   199,     1,     3,
      48,    74,    76,   104,   114,   169,   170,   171,   172,   173,
     174,   114,    43,    46,   122,   231,   232,   122,   231,   232,
     228,   231,   232,   122,   231,   232,   213,    47,     4,    16,
      18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    46,   104,   106,   115,   125,   142,   143,   149,   224,
     225,   226,   227,   233,   235,   236,   237,   255,    43,    44,
      44,    44,     4,    66,    75,   179,   180,   181,   182,   201,
     202,   203,    66,    75,   182,   201,    11,   126,   127,   128,
     129,   130,   131,   132,   133,   134,   135,   136,   137,   138,
     139,   140,   141,   142,   143,   248,   161,     3,    45,    45,
     169,    46,    46,   168,   114,    54,   161,    43,   114,    54,
     161,    43,   161,    44,    43,    44,   169,   104,   114,    54,
      47,    43,   188,    52,   174,   172,   104,   215,    75,    75,
     229,   230,   231,   232,    75,    75,   114,    54,    46,    46,
      46,   106,    66,   104,     8,   238,   228,    46,    75,   123,
     123,    46,    17,     1,   230,     1,    75,   125,   108,   150,
     161,   161,    75,   206,    75,   206,   161,   162,   150,   161,
     161,   123,   123,   245,    47,   161,   114,   124,   161,   114,
     124,   114,    47,    11,    45,   172,   171,   172,   106,   106,
      18,   229,   106,   125,   234,   239,   106,    11,    54,    46,
     106,    46,    75,    54,   107,   156,   175,   177,   157,   176,
     182,     1,   230,   106,    44,   180,   181,   181,   251,   251,
     179,   182,   201,   182,   201,   161,   195,   161,   196,    44,
     114,    44,    44,   239,    46,    44,   114,    46,   106,   161,
      44,    46,   117,    46,   117,    44,    44,   161,   161,   161,
      45,   230,    46,   230,    54,    44,    54,   235,   228,   228,
      46,   239,    46,    76,   116,   240,   241,   242,   224,   224,
      44,   104,    75,    44,    54,    43,   230,    45,   106,    46,
     240,   242,   116,    44,    44,    54,    75,    46,   116,   243,
     106,    43,    44,    44,   116,    46
};

  /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    97,    98,    98,    99,    99,   100,   101,   101,   101,
     101,   102,   102,   102,   102,   102,   102,   102,   103,   103,
     103,   103,   103,   103,   104,   104,   105,   105,   105,   105,
     105,   105,   105,   106,   107,   107,   108,   108,   109,   109,
     109,   109,   109,   109,   109,   109,   109,   109,   109,   110,
     111,   112,   113,   113,   114,   114,   114,   114,   114,   114,
     114,   114,   114,   114,   114,   114,   114,   114,   114,   114,
     114,   114,   114,   115,   115,   115,   115,   115,   115,   115,
     115,   115,   115,   115,   115,   115,   115,   115,   115,   115,
     115,   115,   115,   115,   116,   116,   117,   118,   118,   119,
     120,   120,   120,   120,   121,   121,   121,   121,   122,   123,
     124,   125,   125,   125,   125,   125,   125,   126,   126,   126,
     127,   128,   128,   129,   129,   130,   130,   130,   130,   130,
     130,   130,   131,   131,   131,   131,   131,   131,   132,   132,
     132,   132,   132,   132,   133,   133,   133,   133,   133,   134,
     134,   134,   134,   134,   134,   134,   135,   136,   136,   136,
     136,   136,   136,   137,   138,   138,   138,   138,   138,   138,
     138,   138,   138,   138,   139,   139,   139,   139,   139,   140,
     140,   140,   140,   140,   140,   140,   140,   140,   140,   141,
     141,   141,   141,   141,   142,   142,   142,   142,   142,   142,
     142,   142,   143,   143,   143,   143,   143,   143,   143,   143,
     144,   144,   144,   144,   145,   145,   145,   145,   146,   146,
     146,   146,   147,   147,   147,   147,   148,   148,   148,   148,
     148,   148,   148,   148,   149,   149,   149,   149,   149,   149,
     149,   149,   149,   149,   149,   149,   149,   149,   149,   149,
     150,   150,   151,   151,   152,   153,   153,   154,   155,   155,
     155,   156,   156,   157,   157,   158,   158,   159,   159,   160,
     160,   161,   161,   162,   162,   163,   164,   164,   165,   165,
     165,   165,   165,   166,   166,   166,   166,   167,   167,   168,
     168,   168,   169,   169,   170,   170,   171,   171,   171,   171,
     172,   172,   172,   173,   173,   174,   174,   174,   175,   176,
     177,   177,   178,   178,   178,   178,   178,   179,   179,   180,
     180,   180,   181,   181,   181,   181,   181,   182,   182,   182,
     182,   182,   183,   183,   184,   184,   185,   185,   186,   186,
     186,   186,   186,   186,   187,   187,   187,   188,   188,   189,
     189,   190,   190,   191,   191,   191,   192,   192,   192,   192,
     192,   192,   193,   193,   194,   194,   195,   195,   195,   196,
     196,   196,   197,   197,   197,   198,   198,   199,   200,   200,
     201,   201,   201,   202,   202,   203,   203,   204,   204,   205,
     205,   205,   205,   205,   206,   206,   206,   206,   206,   207,
     207,   207,   207,   208,   208,   208,   208,   208,   209,   209,
     209,   209,   210,   210,   210,   210,   210,   211,   211,   212,
     212,   212,   212,   213,   214,   215,   216,   216,   217,   217,
     218,   219,   219,   220,   221,   221,   222,   222,   223,   224,
     225,   225,   226,   227,   228,   229,   229,   230,   231,   232,
     233,   233,   233,   233,   233,   233,   233,   233,   234,   234,
     235,   235,   235,   235,   235,   235,   235,   235,   235,   235,
     235,   235,   235,   235,   236,   236,   237,   237,   237,   237,
     238,   238,   239,   239,   240,   240,   241,   241,   242,   242,
     243,   243,   244,   245,   245,   245,   246,   246,   246,   246,
     247,   247,   248,   248,   248,   248,   248,   249,   249,   249,
     249,   249,   250,   251,   252,   252,   253,   253,   254,   254,
     255
};

  /* YYR2[YYN] -- Number of symbols on the right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     0,     1,     1,     2,     1,     1,     1,     5,
       2,     3,     4,     4,     2,     2,     2,     1,     6,     4,
       6,     4,     5,     3,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     0,     1,     1,     3,     1,     2,
       2,     2,     2,     2,     4,     2,     4,     2,     2,     1,
       1,     1,     1,     4,     1,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     5,
       4,     3,     3,     1,     2,     3,     2,     1,     1,     1,
       6,     3,     3,     3,     3,     4,     6,     8,     6,     4,
       3,     3,     2,     2,     1,     2,     1,     0,     1,     2,
       1,     1,     2,     2,     4,     4,     2,     2,     2,     0,
       1,     4,     4,     3,     3,     2,     2,     1,     2,     2,
       2,     2,     2,     1,     2,     1,     2,     2,     2,     2,
       2,     2,     1,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     1,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       0,     1,     1,     1,     1,     1,     1,     1,     1,     4,
       4,     1,     4,     1,     4,     0,     4,     5,     3,     5,
       3,     0,     1,     1,     2,     6,     1,     3,     0,     1,
       4,     6,     4,     1,     1,     1,     1,     1,     1,     1,
       3,     1,     0,     2,     1,     3,     3,     2,     3,     1,
       3,     1,     1,     1,     2,     2,     5,     3,     4,     4,
       1,     1,     4,     3,     2,     3,     1,     1,     1,     3,
       2,     1,     3,     2,     3,     3,     4,     3,     4,     3,
       2,     1,     1,     2,     1,     2,     1,     2,     6,     5,
       6,     5,     7,     6,     2,     2,     2,     0,     1,     0,
       1,     1,     2,     0,     3,     2,     3,     2,     3,     1,
       1,     2,     1,     4,     1,     4,     2,     4,     3,     2,
       4,     3,     1,     3,     1,     1,     3,     2,     0,     1,
       0,     1,     2,     1,     1,     1,     3,     2,     3,     4,
       3,     2,     2,     1,     4,     3,     4,     5,     5,     1,
       1,     1,     1,     1,     2,     2,     2,     2,     1,     2,
       2,     2,     1,     2,     2,     2,     2,     1,     2,     1,
       1,     1,     1,     2,     0,     0,     0,     1,     1,     2,
       3,     1,     2,     1,     1,     5,     1,     1,     2,     2,
       2,     2,     4,     3,     0,     1,     2,     1,     2,     2,
       3,     1,     3,     5,     5,     2,     8,     5,     2,     1,
       1,     1,     2,     2,     2,     3,     6,     8,    10,    12,
       3,     4,     1,     1,     2,     5,     3,     5,     2,     4,
       0,     1,     0,     1,     0,     1,     1,     3,     4,     7,
       1,     3,     2,     2,     4,     2,     0,     1,     1,     3,
       1,     3,     4,     4,     3,     4,     3,     4,     4,     3,
       4,     3,     1,     2,     1,     2,     1,     3,     1,     3,
       1
};


#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)
#define YYEMPTY         (-2)
#define YYEOF           0

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                  \
do                                                              \
  if (yychar == YYEMPTY)                                        \
    {                                                           \
      yychar = (Token);                                         \
      yylval = (Value);                                         \
      YYPOPSTACK (yylen);                                       \
      yystate = *yyssp;                                         \
      goto yybackup;                                            \
    }                                                           \
  else                                                          \
    {                                                           \
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;                                                  \
    }                                                           \
while (0)

/* Error token number */
#define YYTERROR        1
#define YYERRCODE       256



/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)

/* This macro is provided for backward compatibility. */
#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


# define YY_SYMBOL_PRINT(Title, Type, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Type, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*----------------------------------------.
| Print this symbol's value on YYOUTPUT.  |
`----------------------------------------*/

static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  FILE *yyo = yyoutput;
  YYUSE (yyo);
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
  YYUSE (yytype);
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyoutput, "%s %s (",
             yytype < YYNTOKENS ? "token" : "nterm", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yytype_int16 *yyssp, YYSTYPE *yyvsp, int yyrule)
{
  unsigned long int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       yystos[yyssp[yyi + 1 - yynrhs]],
                       &(yyvsp[(yyi + 1) - (yynrhs)])
                                              );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
yystrlen (const char *yystr)
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            /* Fall through.  */
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return 1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return 2 if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYSIZE_T *yymsg_alloc, char **yymsg,
                yytype_int16 *yyssp, int yytoken)
{
  YYSIZE_T yysize0 = yytnamerr (YY_NULLPTR, yytname[yytoken]);
  YYSIZE_T yysize = yysize0;
  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat. */
  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
  /* Number of reported tokens (one for the "unexpected", one per
     "expected"). */
  int yycount = 0;

  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yytoken != YYEMPTY)
    {
      int yyn = yypact[*yyssp];
      yyarg[yycount++] = yytname[yytoken];
      if (!yypact_value_is_default (yyn))
        {
          /* Start YYX at -YYN if negative to avoid negative indexes in
             YYCHECK.  In other words, skip the first -YYN actions for
             this state because they are default actions.  */
          int yyxbegin = yyn < 0 ? -yyn : 0;
          /* Stay within bounds of both yycheck and yytname.  */
          int yychecklim = YYLAST - yyn + 1;
          int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
          int yyx;

          for (yyx = yyxbegin; yyx < yyxend; ++yyx)
            if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR
                && !yytable_value_is_error (yytable[yyx + yyn]))
              {
                if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                  {
                    yycount = 1;
                    yysize = yysize0;
                    break;
                  }
                yyarg[yycount++] = yytname[yyx];
                {
                  YYSIZE_T yysize1 = yysize + yytnamerr (YY_NULLPTR, yytname[yyx]);
                  if (! (yysize <= yysize1
                         && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
                    return 2;
                  yysize = yysize1;
                }
              }
        }
    }

  switch (yycount)
    {
# define YYCASE_(N, S)                      \
      case N:                               \
        yyformat = S;                       \
      break
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
# undef YYCASE_
    }

  {
    YYSIZE_T yysize1 = yysize + yystrlen (yyformat);
    if (! (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
      return 2;
    yysize = yysize1;
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return 1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yyarg[yyi++]);
          yyformat += 2;
        }
      else
        {
          yyp++;
          yyformat++;
        }
  }
  return 0;
}
#endif /* YYERROR_VERBOSE */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
{
  YYUSE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yytype);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
/* The lookahead symbol.  */
int yychar;


/* The semantic value of the lookahead symbol.  */
/* Default value used for initialization, for pacifying older GCCs
   or non-GCC compilers.  */
YY_INITIAL_VALUE (static YYSTYPE yyval_default;)
YYSTYPE yylval YY_INITIAL_VALUE (= yyval_default);

    /* Number of syntax errors so far.  */
    int yynerrs;

    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       'yyss': related to states.
       'yyvs': related to semantic values.

       Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yyssp = yyss = yyssa;
  yyvsp = yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */
  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        YYSTYPE *yyvs1 = yyvs;
        yytype_int16 *yyss1 = yyss;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * sizeof (*yyssp),
                    &yyvs1, yysize * sizeof (*yyvsp),
                    &yystacksize);

        yyss = yyss1;
        yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yytype_int16 *yyss1 = yyss;
        union yyalloc *yyptr =
          (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
        if (! yyptr)
          goto yyexhaustedlab;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
                  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = yylex (&yylval);
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 283 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 14 );
root= (yyval.t);

    }
#line 2540 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 3:
#line 291 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 14 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);
root= (yyval.t);

    }
#line 2554 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 4:
#line 303 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 3 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 2567 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 5:
#line 314 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 3 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 2586 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 6:
#line 331 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 131 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 2599 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 7:
#line 342 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 156 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 2612 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 8:
#line 353 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 156 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 2625 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 9:
#line 364 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 156 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 2662 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 10:
#line 399 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 156 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 2681 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 11:
#line 416 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 22 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 2706 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 12:
#line 439 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 22 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 2737 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 13:
#line 468 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 22 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 2768 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 14:
#line 497 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 22 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 2787 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 15:
#line 514 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 22 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 2800 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 16:
#line 525 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 22 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 2813 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 17:
#line 536 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 22 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 2826 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 18:
#line 547 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 96 );

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 2869 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 19:
#line 588 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 96 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

    }
#line 2894 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 20:
#line 611 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 96 );

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 2937 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 21:
#line 652 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 96 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

    }
#line 2962 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 22:
#line 675 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 96 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 2999 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 23:
#line 710 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 96 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

    }
#line 3018 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 24:
#line 727 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 39 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3031 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 25:
#line 738 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 39 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3044 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 26:
#line 749 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 121 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3057 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 27:
#line 760 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 121 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3070 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 28:
#line 771 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 121 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3083 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 29:
#line 782 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 121 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3096 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 30:
#line 793 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 121 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3109 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 31:
#line 804 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 121 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3122 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 32:
#line 815 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 121 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3135 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 33:
#line 826 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 112 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3148 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 34:
#line 837 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 109 );

    }
#line 3157 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 35:
#line 844 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 109 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3170 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 36:
#line 855 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 16 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3183 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 37:
#line 866 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 16 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3208 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 38:
#line 889 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 83 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3221 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 39:
#line 900 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 83 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3240 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 40:
#line 917 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 83 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3259 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 41:
#line 934 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 83 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3278 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 42:
#line 951 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 83 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3297 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 43:
#line 968 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 83 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3316 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 44:
#line 985 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 83 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3347 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 45:
#line 1014 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 83 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3366 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 46:
#line 1031 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 83 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3397 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 47:
#line 1060 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 83 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3416 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 48:
#line 1077 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 83 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3435 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 49:
#line 1094 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 47 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3448 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 50:
#line 1105 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 140 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3461 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 51:
#line 1116 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 62 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3474 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 52:
#line 1127 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 134 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3487 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 53:
#line 1138 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 134 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3518 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 54:
#line 1167 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 128 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3531 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 55:
#line 1178 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 128 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3556 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 56:
#line 1201 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 128 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3581 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 57:
#line 1224 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 128 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3606 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 58:
#line 1247 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 128 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3631 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 59:
#line 1270 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 128 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3656 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 60:
#line 1293 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 128 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3681 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 61:
#line 1316 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 128 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3706 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 62:
#line 1339 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 128 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3731 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 63:
#line 1362 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 128 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3756 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 64:
#line 1385 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 128 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3781 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 65:
#line 1408 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 128 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3806 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 66:
#line 1431 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 128 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3831 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 67:
#line 1454 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 128 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3856 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 68:
#line 1477 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 128 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3881 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 69:
#line 1500 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 128 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3918 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 70:
#line 1535 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 128 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3949 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 71:
#line 1564 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 128 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3974 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 72:
#line 1587 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 128 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3999 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 73:
#line 1610 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 84 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4012 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 74:
#line 1621 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 84 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4031 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 75:
#line 1638 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 84 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4056 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 76:
#line 1661 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 84 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4075 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 77:
#line 1678 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 84 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4088 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 78:
#line 1689 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 84 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4101 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 79:
#line 1700 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 84 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4114 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 80:
#line 1711 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 84 );

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4157 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 81:
#line 1752 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 84 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4182 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 82:
#line 1775 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 84 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4201 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 83:
#line 1792 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 84 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4226 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 84:
#line 1815 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 84 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4245 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 85:
#line 1832 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 84 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4276 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 86:
#line 1861 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 84 );

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4319 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 87:
#line 1902 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 84 );

        (yyval.t)->addChild((yyvsp[-7].t));

        (yyvsp[-7].t)->parent= (yyval.t);

        (yyvsp[-7].t)->nextSibbling= (yyvsp[-6].t);

        (yyval.t)->addChild((yyvsp[-6].t));

        (yyvsp[-6].t)->parent= (yyval.t);

        (yyvsp[-6].t)->nextSibbling= (yyvsp[-5].t);

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4374 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 88:
#line 1955 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 84 );

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4417 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 89:
#line 1996 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 84 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4448 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 90:
#line 2025 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 84 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4473 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 91:
#line 2048 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 84 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4498 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 92:
#line 2071 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 84 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4517 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 93:
#line 2088 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 84 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4536 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 94:
#line 2105 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 155 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4549 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 95:
#line 2116 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 155 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4568 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 96:
#line 2133 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 42 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4581 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 97:
#line 2144 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 102 );

    }
#line 4590 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 98:
#line 2151 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 102 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4603 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 99:
#line 2162 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 104 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4622 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 100:
#line 2179 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 120 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4635 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 101:
#line 2190 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 120 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4648 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 102:
#line 2201 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 120 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4667 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 103:
#line 2218 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 120 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4686 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 104:
#line 2235 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 50 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4717 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 105:
#line 2264 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 50 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4748 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 106:
#line 2293 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 50 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4767 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 107:
#line 2310 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 50 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4786 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 108:
#line 2327 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 25 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4805 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 109:
#line 2344 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 125 );

    }
#line 4814 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 110:
#line 2351 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 26 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4827 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 111:
#line 2362 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 0 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4858 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 112:
#line 2391 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 0 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4889 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 113:
#line 2420 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 0 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4914 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 114:
#line 2443 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 0 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4939 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 115:
#line 2466 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 0 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4958 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 116:
#line 2483 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 0 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4977 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 117:
#line 2500 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 32 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4990 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 118:
#line 2511 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 32 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5009 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 119:
#line 2528 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 32 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5028 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 120:
#line 2545 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 10 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5047 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 121:
#line 2562 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 150 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5066 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 122:
#line 2579 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 150 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5085 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 123:
#line 2596 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 100 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5098 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 124:
#line 2607 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 100 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5117 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 125:
#line 2624 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 151 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5130 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 126:
#line 2635 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 151 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5149 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 127:
#line 2652 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 151 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5168 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 128:
#line 2669 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 151 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5187 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 129:
#line 2686 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 151 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5206 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 130:
#line 2703 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 151 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5225 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 131:
#line 2720 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 151 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5244 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 132:
#line 2737 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 78 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5257 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 133:
#line 2748 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 78 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5276 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 134:
#line 2765 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 78 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5295 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 135:
#line 2782 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 78 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5314 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 136:
#line 2799 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 78 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5333 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 137:
#line 2816 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 78 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5352 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 138:
#line 2833 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 76 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5371 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 139:
#line 2850 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 76 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5390 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 140:
#line 2867 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 76 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5409 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 141:
#line 2884 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 76 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5428 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 142:
#line 2901 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 76 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5447 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 143:
#line 2918 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 76 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5466 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 144:
#line 2935 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 11 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5485 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 145:
#line 2952 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 11 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5504 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 146:
#line 2969 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 11 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5523 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 147:
#line 2986 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 11 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5542 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 148:
#line 3003 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 11 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5561 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 149:
#line 3020 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 146 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5574 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 150:
#line 3031 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 146 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5593 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 151:
#line 3048 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 146 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5612 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 152:
#line 3065 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 146 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5631 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 153:
#line 3082 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 146 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5650 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 154:
#line 3099 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 146 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5669 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 155:
#line 3116 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 146 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5688 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 156:
#line 3133 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 37 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5707 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 157:
#line 3150 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 1 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5726 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 158:
#line 3167 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 1 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5745 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 159:
#line 3184 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 1 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5764 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 160:
#line 3201 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 1 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5783 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 161:
#line 3218 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 1 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5802 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 162:
#line 3235 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 1 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5821 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 163:
#line 3252 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 4 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5840 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 164:
#line 3269 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 2 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5859 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 165:
#line 3286 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 2 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5878 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 166:
#line 3303 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 2 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5897 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 167:
#line 3320 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 2 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5916 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 168:
#line 3337 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 2 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5935 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 169:
#line 3354 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 2 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5954 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 170:
#line 3371 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 2 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5973 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 171:
#line 3388 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 2 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5992 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 172:
#line 3405 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 2 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6011 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 173:
#line 3422 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 2 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6030 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 174:
#line 3439 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 94 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6049 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 175:
#line 3456 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 94 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6068 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 176:
#line 3473 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 94 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6087 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 177:
#line 3490 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 94 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6106 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 178:
#line 3507 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 94 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6125 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 179:
#line 3524 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 98 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6144 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 180:
#line 3541 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 98 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6163 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 181:
#line 3558 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 98 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6182 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 182:
#line 3575 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 98 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6201 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 183:
#line 3592 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 98 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6220 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 184:
#line 3609 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 98 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6239 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 185:
#line 3626 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 98 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6258 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 186:
#line 3643 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 98 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6277 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 187:
#line 3660 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 98 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6296 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 188:
#line 3677 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 98 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6315 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 189:
#line 3694 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 27 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6334 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 190:
#line 3711 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 27 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6353 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 191:
#line 3728 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 27 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6372 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 192:
#line 3745 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 27 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6391 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 193:
#line 3762 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 27 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6410 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 194:
#line 3779 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 20 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6423 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 195:
#line 3790 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 20 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6436 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 196:
#line 3801 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 20 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6449 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 197:
#line 3812 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 20 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6462 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 198:
#line 3823 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 20 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6475 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 199:
#line 3834 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 20 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6488 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 200:
#line 3845 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 20 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6501 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 201:
#line 3856 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 20 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6514 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 202:
#line 3867 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 75 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6527 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 203:
#line 3878 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 75 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6540 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 204:
#line 3889 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 75 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6553 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 205:
#line 3900 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 75 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6566 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 206:
#line 3911 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 75 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6579 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 207:
#line 3922 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 75 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6592 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 208:
#line 3933 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 75 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6605 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 209:
#line 3944 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 75 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6618 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 210:
#line 3955 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 70 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6631 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 211:
#line 3966 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 70 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6644 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 212:
#line 3977 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 70 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6657 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 213:
#line 3988 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 70 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6670 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 214:
#line 3999 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 145 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6683 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 215:
#line 4010 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 145 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6696 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 216:
#line 4021 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 145 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6709 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 217:
#line 4032 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 145 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6722 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 218:
#line 4043 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 119 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6735 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 219:
#line 4054 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 119 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6748 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 220:
#line 4065 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 119 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6761 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 221:
#line 4076 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 119 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6774 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 222:
#line 4087 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 86 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6787 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 223:
#line 4098 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 86 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6800 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 224:
#line 4109 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 86 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6813 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 225:
#line 4120 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 86 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6826 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 226:
#line 4131 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 93 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6839 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 227:
#line 4142 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 93 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6852 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 228:
#line 4153 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 93 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6865 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 229:
#line 4164 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 93 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6878 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 230:
#line 4175 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 93 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6891 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 231:
#line 4186 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 93 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6904 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 232:
#line 4197 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 93 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6917 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 233:
#line 4208 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 93 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6930 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 234:
#line 4219 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 67 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6943 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 235:
#line 4230 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 67 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6956 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 236:
#line 4241 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 67 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6969 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 237:
#line 4252 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 67 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6982 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 238:
#line 4263 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 67 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6995 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 239:
#line 4274 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 67 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7008 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 240:
#line 4285 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 67 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7021 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 241:
#line 4296 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 67 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7034 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 242:
#line 4307 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 67 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7047 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 243:
#line 4318 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 67 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7060 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 244:
#line 4329 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 67 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7073 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 245:
#line 4340 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 67 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7086 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 246:
#line 4351 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 67 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7099 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 247:
#line 4362 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 67 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7112 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 248:
#line 4373 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 67 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7125 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 249:
#line 4384 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 67 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7138 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 250:
#line 4395 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 68 );

    }
#line 7147 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 251:
#line 4402 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 68 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7160 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 252:
#line 4413 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7173 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 253:
#line 4424 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7186 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 254:
#line 4435 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 31 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7199 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 255:
#line 4446 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 106 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7212 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 256:
#line 4457 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 106 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7225 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 257:
#line 4468 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 44 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7238 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 258:
#line 4479 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 53 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7251 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 259:
#line 4490 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 53 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7282 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 260:
#line 4519 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 53 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7313 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 261:
#line 4548 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 82 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7326 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 262:
#line 4559 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 82 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7357 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 263:
#line 4588 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 153 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7370 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 264:
#line 4599 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 153 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7401 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 265:
#line 4628 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 114 );

    }
#line 7410 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 266:
#line 4635 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 114 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7441 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 267:
#line 4664 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 59 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7478 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 268:
#line 4699 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 59 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7503 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 269:
#line 4722 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 79 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7540 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 270:
#line 4757 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 79 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7565 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 271:
#line 4780 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 74 );

    }
#line 7574 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 272:
#line 4787 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 74 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7587 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 273:
#line 4798 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 8 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7600 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 274:
#line 4809 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 8 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7619 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 275:
#line 4826 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 124 );

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7662 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 276:
#line 4867 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 137 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7675 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 277:
#line 4878 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 137 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7700 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 278:
#line 4901 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 80 );

    }
#line 7709 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 279:
#line 4908 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 80 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7722 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 280:
#line 4919 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 80 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7753 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 281:
#line 4948 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 80 );

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7796 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 282:
#line 4989 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 80 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7827 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 283:
#line 5018 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 129 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7840 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 284:
#line 5029 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 129 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7853 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 285:
#line 5040 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 129 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7866 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 286:
#line 5051 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 129 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7879 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 287:
#line 5062 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 107 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7892 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 288:
#line 5073 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 107 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7905 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 289:
#line 5084 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 13 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7918 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 290:
#line 5095 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 13 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7943 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 291:
#line 5118 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 13 );

    }
#line 7952 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 292:
#line 5125 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 19 );

    }
#line 7961 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 293:
#line 5132 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 19 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7980 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 294:
#line 5149 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 95 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7993 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 295:
#line 5160 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 95 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8018 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 296:
#line 5183 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 108 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8043 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 297:
#line 5206 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 108 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8062 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 298:
#line 5223 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 108 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8087 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 299:
#line 5246 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 108 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8100 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 300:
#line 5257 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 40 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8125 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 301:
#line 5280 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 40 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8138 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 302:
#line 5291 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 40 );

    }
#line 8147 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 303:
#line 5298 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 38 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8160 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 304:
#line 5309 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 38 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8179 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 305:
#line 5326 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 142 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8198 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 306:
#line 5343 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 142 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8235 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 307:
#line 5378 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 142 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8260 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 308:
#line 5401 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 97 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8291 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 309:
#line 5430 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 126 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8322 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 310:
#line 5459 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 36 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8335 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 311:
#line 5470 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 36 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8348 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 312:
#line 5481 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 49 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8379 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 313:
#line 5510 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 49 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8404 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 314:
#line 5533 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 49 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8423 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 315:
#line 5550 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 49 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8448 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 316:
#line 5573 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 49 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8461 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 317:
#line 5584 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 157 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8474 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 318:
#line 5595 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 157 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8487 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 319:
#line 5606 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 136 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8512 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 320:
#line 5629 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 136 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8531 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 321:
#line 5646 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 136 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8544 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 322:
#line 5657 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 73 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8569 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 323:
#line 5680 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 73 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8588 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 324:
#line 5697 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 73 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8613 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 325:
#line 5720 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 73 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8638 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 326:
#line 5743 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 73 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8669 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 327:
#line 5772 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 34 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8694 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 328:
#line 5795 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 34 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8725 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 329:
#line 5824 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 34 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8750 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 330:
#line 5847 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 34 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8769 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 331:
#line 5864 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 34 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8782 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 332:
#line 5875 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 130 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8795 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 333:
#line 5886 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 130 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8814 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 334:
#line 5903 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 149 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8827 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 335:
#line 5914 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 149 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8846 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 336:
#line 5931 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 147 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8859 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 337:
#line 5942 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 147 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8878 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 338:
#line 5959 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 115 );

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8921 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 339:
#line 6000 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 115 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8958 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 340:
#line 6035 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 115 );

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9001 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 341:
#line 6076 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 115 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9038 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 342:
#line 6111 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 115 );

        (yyval.t)->addChild((yyvsp[-6].t));

        (yyvsp[-6].t)->parent= (yyval.t);

        (yyvsp[-6].t)->nextSibbling= (yyvsp[-5].t);

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9087 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 343:
#line 6158 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 115 );

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9130 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 344:
#line 6199 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 46 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9149 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 345:
#line 6216 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 46 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9168 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 346:
#line 6233 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 46 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9187 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 347:
#line 6250 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 113 );

    }
#line 9196 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 348:
#line 6257 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 113 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9209 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 349:
#line 6268 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 144 );

    }
#line 9218 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 350:
#line 6275 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 144 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9231 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 351:
#line 6286 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 9 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9244 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 352:
#line 6297 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 9 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9263 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 353:
#line 6314 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 23 );

    }
#line 9272 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 354:
#line 6321 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 23 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9297 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 355:
#line 6344 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 23 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9316 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 356:
#line 6361 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 88 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9341 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 357:
#line 6384 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 88 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9360 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 358:
#line 6401 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 88 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9385 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 359:
#line 6424 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 88 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9398 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 360:
#line 6435 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 88 );

    }
#line 9407 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 361:
#line 6442 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 88 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9426 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 362:
#line 6459 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 154 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9439 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 363:
#line 6470 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 154 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9470 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 364:
#line 6499 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 92 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9483 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 365:
#line 6510 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 92 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9514 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 366:
#line 6539 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 60 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9533 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 367:
#line 6556 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 60 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9564 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 368:
#line 6585 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 60 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9589 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 369:
#line 6608 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 56 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9608 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 370:
#line 6625 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 56 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9639 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 371:
#line 6654 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 56 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9664 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 372:
#line 6677 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 148 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9677 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 373:
#line 6688 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 148 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9702 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 374:
#line 6711 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 148 );

    }
#line 9711 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 375:
#line 6718 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 24 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9724 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 376:
#line 6729 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 24 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9749 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 377:
#line 6752 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 52 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9768 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 378:
#line 6769 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 7 );

    }
#line 9777 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 379:
#line 6776 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 7 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9790 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 380:
#line 6787 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 61 );

    }
#line 9799 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 381:
#line 6794 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 61 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9812 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 382:
#line 6805 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 61 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9831 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 383:
#line 6822 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 48 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9844 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 384:
#line 6833 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 48 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9857 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 385:
#line 6844 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 43 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9870 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 386:
#line 6855 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 43 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9895 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 387:
#line 6878 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 91 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9914 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 388:
#line 6895 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 91 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9939 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 389:
#line 6918 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 77 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9970 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 390:
#line 6947 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 77 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9995 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 391:
#line 6970 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 77 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10014 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 392:
#line 6987 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 77 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10033 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 393:
#line 7004 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 77 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10046 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 394:
#line 7015 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 15 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10077 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 395:
#line 7044 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 15 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10102 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 396:
#line 7067 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 15 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10133 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 397:
#line 7096 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 15 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10170 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 398:
#line 7131 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 15 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10207 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 399:
#line 7166 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 6 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10220 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 400:
#line 7177 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 6 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10233 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 401:
#line 7188 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 6 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10246 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 402:
#line 7199 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 6 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10259 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 403:
#line 7210 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 71 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10272 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 404:
#line 7221 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 71 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10291 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 405:
#line 7238 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 71 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10310 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 406:
#line 7255 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 71 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10329 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 407:
#line 7272 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 71 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10348 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 408:
#line 7289 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10361 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 409:
#line 7300 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10380 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 410:
#line 7317 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10399 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 411:
#line 7334 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10418 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 412:
#line 7351 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 58 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10431 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 413:
#line 7362 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 58 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10450 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 414:
#line 7379 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 58 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10469 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 415:
#line 7396 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 58 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10488 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 416:
#line 7413 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 58 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10507 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 417:
#line 7430 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 17 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10520 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 418:
#line 7441 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 17 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10539 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 419:
#line 7458 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 110 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10552 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 420:
#line 7469 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 110 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10565 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 421:
#line 7480 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 110 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10578 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 422:
#line 7491 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 110 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10591 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 423:
#line 7502 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 85 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10604 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 424:
#line 7513 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 55 );

    }
#line 10613 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 425:
#line 7520 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 123 );

    }
#line 10622 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 426:
#line 7527 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 87 );

    }
#line 10631 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 427:
#line 7534 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 87 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10644 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 428:
#line 7545 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 135 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10657 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 429:
#line 7556 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 135 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10676 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 430:
#line 7573 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 118 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10701 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 431:
#line 7596 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 69 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10714 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 432:
#line 7607 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 69 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10727 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 433:
#line 7618 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 116 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10740 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 434:
#line 7629 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 141 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10753 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 435:
#line 7640 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 141 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10790 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 436:
#line 7675 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 45 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10803 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 437:
#line 7686 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 45 );

    }
#line 10812 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 438:
#line 7693 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 41 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10831 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 439:
#line 7710 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 72 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10850 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 440:
#line 7727 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 103 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10869 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 441:
#line 7744 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 103 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

    }
#line 10882 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 442:
#line 7755 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 35 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10913 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 443:
#line 7784 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 89 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10938 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 444:
#line 7807 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 105 );

    }
#line 10947 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 445:
#line 7814 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 66 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10960 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 446:
#line 7825 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 66 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10979 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 447:
#line 7842 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 33 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10992 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 448:
#line 7853 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 99 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11011 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 449:
#line 7870 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 127 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11030 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 450:
#line 7887 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 30 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11055 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 451:
#line 7910 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 30 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11068 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 452:
#line 7921 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 30 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

    }
#line 11087 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 453:
#line 7938 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 30 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11124 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 454:
#line 7973 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 30 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11161 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 455:
#line 8008 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 30 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

    }
#line 11174 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 456:
#line 8019 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 30 );

        (yyval.t)->addChild((yyvsp[-7].t));

        (yyvsp[-7].t)->parent= (yyval.t);

        (yyvsp[-7].t)->nextSibbling= (yyvsp[-6].t);

        (yyval.t)->addChild((yyvsp[-6].t));

        (yyvsp[-6].t)->parent= (yyval.t);

        (yyvsp[-6].t)->nextSibbling= (yyvsp[-5].t);

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11229 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 457:
#line 8072 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 30 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11266 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 458:
#line 8107 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 143 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11285 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 459:
#line 8124 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 143 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11298 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 460:
#line 8135 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 65 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11311 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 461:
#line 8146 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 65 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11324 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 462:
#line 8157 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 65 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11343 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 463:
#line 8174 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 65 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11362 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 464:
#line 8191 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 65 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11381 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 465:
#line 8208 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 65 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11406 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 466:
#line 8231 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 65 );

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11449 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 467:
#line 8272 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 65 );

        (yyval.t)->addChild((yyvsp[-7].t));

        (yyvsp[-7].t)->parent= (yyval.t);

        (yyvsp[-7].t)->nextSibbling= (yyvsp[-6].t);

        (yyval.t)->addChild((yyvsp[-6].t));

        (yyvsp[-6].t)->parent= (yyval.t);

        (yyvsp[-6].t)->nextSibbling= (yyvsp[-5].t);

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11504 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 468:
#line 8325 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 65 );

        (yyval.t)->addChild((yyvsp[-9].t));

        (yyvsp[-9].t)->parent= (yyval.t);

        (yyvsp[-9].t)->nextSibbling= (yyvsp[-8].t);

        (yyval.t)->addChild((yyvsp[-8].t));

        (yyvsp[-8].t)->parent= (yyval.t);

        (yyvsp[-8].t)->nextSibbling= (yyvsp[-7].t);

        (yyval.t)->addChild((yyvsp[-7].t));

        (yyvsp[-7].t)->parent= (yyval.t);

        (yyvsp[-7].t)->nextSibbling= (yyvsp[-6].t);

        (yyval.t)->addChild((yyvsp[-6].t));

        (yyvsp[-6].t)->parent= (yyval.t);

        (yyvsp[-6].t)->nextSibbling= (yyvsp[-5].t);

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11571 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 469:
#line 8390 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 65 );

        (yyval.t)->addChild((yyvsp[-11].t));

        (yyvsp[-11].t)->parent= (yyval.t);

        (yyvsp[-11].t)->nextSibbling= (yyvsp[-10].t);

        (yyval.t)->addChild((yyvsp[-10].t));

        (yyvsp[-10].t)->parent= (yyval.t);

        (yyvsp[-10].t)->nextSibbling= (yyvsp[-9].t);

        (yyval.t)->addChild((yyvsp[-9].t));

        (yyvsp[-9].t)->parent= (yyval.t);

        (yyvsp[-9].t)->nextSibbling= (yyvsp[-8].t);

        (yyval.t)->addChild((yyvsp[-8].t));

        (yyvsp[-8].t)->parent= (yyval.t);

        (yyvsp[-8].t)->nextSibbling= (yyvsp[-7].t);

        (yyval.t)->addChild((yyvsp[-7].t));

        (yyvsp[-7].t)->parent= (yyval.t);

        (yyvsp[-7].t)->nextSibbling= (yyvsp[-6].t);

        (yyval.t)->addChild((yyvsp[-6].t));

        (yyvsp[-6].t)->parent= (yyval.t);

        (yyvsp[-6].t)->nextSibbling= (yyvsp[-5].t);

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11650 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 470:
#line 8467 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 65 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11675 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 471:
#line 8490 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 65 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11706 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 472:
#line 8519 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 65 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11719 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 473:
#line 8530 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 65 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11732 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 474:
#line 8541 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 122 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11751 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 475:
#line 8558 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 122 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11788 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 476:
#line 8593 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 57 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11813 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 477:
#line 8616 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 57 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11850 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 478:
#line 8651 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 57 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11869 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 479:
#line 8668 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 57 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11900 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 480:
#line 8697 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 81 );

    }
#line 11909 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 481:
#line 8704 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 81 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11922 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 482:
#line 8715 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 132 );

    }
#line 11931 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 483:
#line 8722 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 132 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11944 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 484:
#line 8733 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 117 );

    }
#line 11953 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 485:
#line 8740 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 117 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11966 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 486:
#line 8751 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 18 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 11979 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 487:
#line 8762 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 18 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12004 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 488:
#line 8785 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 90 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12035 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 489:
#line 8814 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 90 );

        (yyval.t)->addChild((yyvsp[-6].t));

        (yyvsp[-6].t)->parent= (yyval.t);

        (yyvsp[-6].t)->nextSibbling= (yyvsp[-5].t);

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12084 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 490:
#line 8861 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 29 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12097 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 491:
#line 8872 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 29 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12122 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 492:
#line 8895 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 138 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12141 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 493:
#line 8912 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 139 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12160 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 494:
#line 8929 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 139 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12191 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 495:
#line 8958 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 139 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12204 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 496:
#line 8969 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 133 );

    }
#line 12213 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 497:
#line 8976 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 133 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12226 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 498:
#line 8987 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 133 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12239 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 499:
#line 8998 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 133 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12264 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 500:
#line 9021 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 54 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12277 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 501:
#line 9032 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 54 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12302 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 502:
#line 9055 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 101 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12333 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 503:
#line 9084 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 101 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12364 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 504:
#line 9113 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 101 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12389 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 505:
#line 9136 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 101 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12420 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 506:
#line 9165 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 101 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12445 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 507:
#line 9188 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 12 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12476 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 508:
#line 9217 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 12 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12507 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 509:
#line 9246 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 12 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12532 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 510:
#line 9269 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 12 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12563 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 511:
#line 9298 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 12 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12588 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 512:
#line 9321 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 5 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12601 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 513:
#line 9332 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 21 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12620 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 514:
#line 9349 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 64 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12633 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 515:
#line 9360 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 64 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12652 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 516:
#line 9377 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 152 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12665 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 517:
#line 9388 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 152 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12690 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 518:
#line 9411 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 63 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12703 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 519:
#line 9422 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 63 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12728 "pt_c.tab.cc" /* yacc.c:1646  */
    break;

  case 520:
#line 9445 "pt_c.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 111 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 12741 "pt_c.tab.cc" /* yacc.c:1646  */
    break;


#line 12745 "pt_c.tab.cc" /* yacc.c:1646  */
      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYEMPTY : YYTRANSLATE (yychar);

  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
# define YYSYNTAX_ERROR yysyntax_error (&yymsg_alloc, &yymsg, \
                                        yyssp, yytoken)
      {
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = YYSYNTAX_ERROR;
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == 1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = (char *) YYSTACK_ALLOC (yymsg_alloc);
            if (!yymsg)
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = 2;
              }
            else
              {
                yysyntax_error_status = YYSYNTAX_ERROR;
                yymsgp = yymsg;
              }
          }
        yyerror (yymsgp);
        if (yysyntax_error_status == 2)
          goto yyexhaustedlab;
      }
# undef YYSYNTAX_ERROR
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYTERROR;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined yyoverflow || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  return yyresult;
}
#line 9457 "pt_c.y" /* yacc.c:1906  */



#include <stdio.h>

extern char yytext[];
extern int column;
extern int line;

void yyerror( char *s)
{
fflush(stdout);
fprintf(stderr,"%s: %d.%d\n",s,line,column);
}


