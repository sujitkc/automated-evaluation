/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "3.0.4"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 1

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* Copy the first part of user declarations.  */
#line 4 "pt_zend_language_parser.y" /* yacc.c:339  */

#include<ptree.h>

using namespace std;

#line 72 "pt_zend_language_parser.tab.cc" /* yacc.c:339  */

# ifndef YY_NULLPTR
#  if defined __cplusplus && 201103L <= __cplusplus
#   define YY_NULLPTR nullptr
#  else
#   define YY_NULLPTR 0
#  endif
# endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* In a future release of Bison, this section will be replaced
   by #include "pt_zend_language_parser.tab.hh".  */
#ifndef YY_YY_PT_ZEND_LANGUAGE_PARSER_TAB_HH_INCLUDED
# define YY_YY_PT_ZEND_LANGUAGE_PARSER_TAB_HH_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    T_INCLUDE = 258,
    T_INCLUDE_ONCE = 259,
    T_EVAL = 260,
    T_REQUIRE = 261,
    T_REQUIRE_ONCE = 262,
    T_LOGICAL_OR = 263,
    T_LOGICAL_XOR = 264,
    T_LOGICAL_AND = 265,
    T_PRINT = 266,
    T_PLUS_EQUAL = 267,
    T_MINUS_EQUAL = 268,
    T_MUL_EQUAL = 269,
    T_DIV_EQUAL = 270,
    T_CONCAT_EQUAL = 271,
    T_MOD_EQUAL = 272,
    T_AND_EQUAL = 273,
    T_OR_EQUAL = 274,
    T_XOR_EQUAL = 275,
    T_SL_EQUAL = 276,
    T_SR_EQUAL = 277,
    T_BOOLEAN_OR = 278,
    T_BOOLEAN_AND = 279,
    T_IS_EQUAL = 280,
    T_IS_NOT_EQUAL = 281,
    T_IS_IDENTICAL = 282,
    T_IS_NOT_IDENTICAL = 283,
    T_IS_SMALLER_OR_EQUAL = 284,
    T_IS_GREATER_OR_EQUAL = 285,
    T_SL = 286,
    T_SR = 287,
    T_INSTANCEOF = 288,
    T_INC = 289,
    T_DEC = 290,
    T_INT_CAST = 291,
    T_DOUBLE_CAST = 292,
    T_STRING_CAST = 293,
    T_ARRAY_CAST = 294,
    T_OBJECT_CAST = 295,
    T_BOOL_CAST = 296,
    T_UNSET_CAST = 297,
    T_NEW = 298,
    T_CLONE = 299,
    T_EXIT = 300,
    T_IF = 301,
    T_ELSEIF = 302,
    T_ELSE = 303,
    T_ENDIF = 304,
    T_LNUMBER = 305,
    T_DNUMBER = 306,
    T_STRING = 307,
    T_STRING_VARNAME = 308,
    T_VARIABLE = 309,
    T_NUM_STRING = 310,
    T_INLINE_HTML = 311,
    T_CHARACTER = 312,
    T_BAD_CHARACTER = 313,
    T_ENCAPSED_AND_WHITESPACE = 314,
    T_CONSTANT_ENCAPSED_STRING = 315,
    T_ECHO = 316,
    T_DO = 317,
    T_WHILE = 318,
    T_ENDWHILE = 319,
    T_FOR = 320,
    T_ENDFOR = 321,
    T_FOREACH = 322,
    T_ENDFOREACH = 323,
    T_DECLARE = 324,
    T_ENDDECLARE = 325,
    T_AS = 326,
    T_SWITCH = 327,
    T_ENDSWITCH = 328,
    T_CASE = 329,
    T_DEFAULT = 330,
    T_BREAK = 331,
    T_CONTINUE = 332,
    T_FUNCTION = 333,
    T_CONST = 334,
    T_RETURN = 335,
    T_TRY = 336,
    T_CATCH = 337,
    T_THROW = 338,
    T_USE = 339,
    T_GLOBAL = 340,
    T_STATIC = 341,
    T_ABSTRACT = 342,
    T_FINAL = 343,
    T_PRIVATE = 344,
    T_PROTECTED = 345,
    T_PUBLIC = 346,
    T_VAR = 347,
    T_UNSET = 348,
    T_ISSET = 349,
    T_EMPTY = 350,
    T_HALT_COMPILER = 351,
    T_CLASS = 352,
    T_INTERFACE = 353,
    T_EXTENDS = 354,
    T_IMPLEMENTS = 355,
    T_OBJECT_OPERATOR = 356,
    T_DOUBLE_ARROW = 357,
    T_LIST = 358,
    T_ARRAY = 359,
    T_CLASS_C = 360,
    T_METHOD_C = 361,
    T_FUNC_C = 362,
    T_LINE = 363,
    T_FILE = 364,
    T_COMMENT = 365,
    T_DOC_COMMENT = 366,
    T_OPEN_TAG = 367,
    T_OPEN_TAG_WITH_ECHO = 368,
    T_CLOSE_TAG = 369,
    T_WHITESPACE = 370,
    T_START_HEREDOC = 371,
    T_END_HEREDOC = 372,
    T_DOLLAR_OPEN_CURLY_BRACES = 373,
    T_CURLY_OPEN = 374,
    T_PAAMAYIM_NEKUDOTAYIM = 375
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 10 "pt_zend_language_parser.y" /* yacc.c:355  */

Tree *t;

#line 237 "pt_zend_language_parser.tab.cc" /* yacc.c:355  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif



int yyparse (void);

#endif /* !YY_YY_PT_ZEND_LANGUAGE_PARSER_TAB_HH_INCLUDED  */

/* Copy the second part of user declarations.  */
#line 14 "pt_zend_language_parser.y" /* yacc.c:358  */

void yyerror(char*s);
int yylex(YYSTYPE *yylvalp);

Tree *root;

#line 259 "pt_zend_language_parser.tab.cc" /* yacc.c:358  */

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif

#ifndef YY_ATTRIBUTE
# if (defined __GNUC__                                               \
      && (2 < __GNUC__ || (__GNUC__ == 2 && 96 <= __GNUC_MINOR__)))  \
     || defined __SUNPRO_C && 0x5110 <= __SUNPRO_C
#  define YY_ATTRIBUTE(Spec) __attribute__(Spec)
# else
#  define YY_ATTRIBUTE(Spec) /* empty */
# endif
#endif

#ifndef YY_ATTRIBUTE_PURE
# define YY_ATTRIBUTE_PURE   YY_ATTRIBUTE ((__pure__))
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# define YY_ATTRIBUTE_UNUSED YY_ATTRIBUTE ((__unused__))
#endif

#if !defined _Noreturn \
     && (!defined __STDC_VERSION__ || __STDC_VERSION__ < 201112)
# if defined _MSC_VER && 1200 <= _MSC_VER
#  define _Noreturn __declspec (noreturn)
# else
#  define _Noreturn YY_ATTRIBUTE ((__noreturn__))
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(E) ((void) (E))
#else
# define YYUSE(E) /* empty */
#endif

#if defined __GNUC__ && 407 <= __GNUC__ * 100 + __GNUC_MINOR__
/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN \
    _Pragma ("GCC diagnostic push") \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")\
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# define YY_IGNORE_MAYBE_UNINITIALIZED_END \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif


#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYSIZE_T yynewbytes;                                            \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / sizeof (*yyptr);                          \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, (Count) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYSIZE_T yyi;                         \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  3
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   6299

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  150
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  105
/* YYNRULES -- Number of rules.  */
#define YYNRULES  360
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  723

/* YYTRANSLATE[YYX] -- Symbol number corresponding to YYX as returned
   by yylex, with out-of-bounds checking.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   375

#define YYTRANSLATE(YYX)                                                \
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, without out-of-bounds checking.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    28,    12,     2,    17,    10,    24,     8,
       5,    31,    14,     9,    20,    18,     6,    25,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     7,     4,
      19,    15,    23,    21,    22,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    26,     2,    29,    13,     2,    11,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    16,    30,    27,     3,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,    46,    47,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    57,    58,    59,    60,    61,    62,    63,
      64,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    83,
      84,    85,    86,    87,    88,    89,    90,    91,    92,    93,
      94,    95,    96,    97,    98,    99,   100,   101,   102,   103,
     104,   105,   106,   107,   108,   109,   110,   111,   112,   113,
     114,   115,   116,   117,   118,   119,   120,   121,   122,   123,
     124,   125,   126,   127,   128,   129,   130,   131,   132,   133,
     134,   135,   136,   137,   138,   139,   140,   141,   142,   143,
     144,   145,   146,   147,   148,   149
};

#if YYDEBUG
  /* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   370,   370,   382,   400,   406,   417,   428,   439,   468,
     486,   492,   503,   514,   525,   554,   565,   576,   587,   610,
     657,   722,   757,   804,   863,   898,   915,   938,   955,   978,
     995,  1018,  1041,  1064,  1087,  1110,  1121,  1138,  1161,  1196,
    1249,  1302,  1337,  1348,  1431,  1454,  1466,  1472,  1483,  1500,
    1553,  1564,  1587,  1598,  1609,  1632,  1643,  1655,  1661,  1672,
    1731,  1778,  1819,  1830,  1847,  1865,  1871,  1888,  1900,  1906,
    1924,  1930,  1947,  1958,  1982,  1988,  2005,  2016,  2033,  2044,
    2073,  2084,  2113,  2124,  2153,  2176,  2211,  2234,  2263,  2292,
    2328,  2334,  2369,  2398,  2409,  2420,  2431,  2461,  2467,  2509,
    2515,  2563,  2569,  2587,  2593,  2616,  2628,  2634,  2651,  2674,
    2709,  2738,  2767,  2802,  2849,  2891,  2897,  2908,  2919,  2931,
    2937,  2948,  2959,  2976,  2999,  3022,  3051,  3074,  3085,  3096,
    3113,  3142,  3165,  3200,  3211,  3234,  3252,  3258,  3281,  3298,
    3351,  3362,  3385,  3396,  3408,  3414,  3425,  3436,  3453,  3464,
    3475,  3486,  3497,  3508,  3519,  3542,  3577,  3588,  3611,  3646,
    3675,  3698,  3710,  3716,  3727,  3750,  3761,  3802,  3825,  3854,
    3895,  3918,  3935,  3958,  3981,  4004,  4027,  4050,  4073,  4096,
    4119,  4142,  4165,  4188,  4205,  4222,  4239,  4256,  4279,  4302,
    4325,  4348,  4371,  4394,  4417,  4440,  4463,  4486,  4509,  4532,
    4555,  4578,  4601,  4624,  4641,  4658,  4675,  4692,  4715,  4738,
    4761,  4784,  4807,  4830,  4853,  4876,  4899,  4922,  4957,  4968,
    4985,  5002,  5019,  5036,  5053,  5070,  5087,  5104,  5121,  5132,
    5161,  5184,  5201,  5230,  5271,  5312,  5341,  5352,  5363,  5374,
    5403,  5414,  5432,  5438,  5456,  5462,  5479,  5503,  5509,  5532,
    5543,  5554,  5565,  5576,  5587,  5598,  5609,  5620,  5631,  5642,
    5659,  5676,  5705,  5716,  5739,  5750,  5761,  5772,  5783,  5806,
    5829,  5853,  5859,  5877,  5883,  5894,  5929,  5952,  5975,  5986,
    5997,  6008,  6019,  6030,  6041,  6076,  6087,  6105,  6111,  6134,
    6158,  6164,  6175,  6192,  6215,  6226,  6237,  6248,  6265,  6276,
    6305,  6334,  6345,  6356,  6386,  6392,  6403,  6414,  6425,  6454,
    6483,  6494,  6505,  6528,  6539,  6556,  6579,  6590,  6601,  6631,
    6638,  6644,  6661,  6696,  6719,  6742,  6753,  6794,  6823,  6852,
    6869,  6886,  6903,  6920,  6937,  6954,  6971,  6988,  7005,  7022,
    7039,  7057,  7063,  7074,  7103,  7126,  7149,  7190,  7213,  7224,
    7235,  7246,  7275,  7304,  7321,  7338,  7367,  7384,  7401,  7412,
    7435
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || 0
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "'~'", "';'", "'('", "'.'", "':'",
  "'\\''", "'+'", "'%'", "'`'", "'\"'", "'^'", "'*'", "'='", "'{'", "'$'",
  "'-'", "'<'", "','", "'?'", "'@'", "'>'", "'&'", "'/'", "'['", "'}'",
  "'!'", "']'", "'|'", "')'", "T_INCLUDE", "T_INCLUDE_ONCE", "T_EVAL",
  "T_REQUIRE", "T_REQUIRE_ONCE", "T_LOGICAL_OR", "T_LOGICAL_XOR",
  "T_LOGICAL_AND", "T_PRINT", "T_PLUS_EQUAL", "T_MINUS_EQUAL",
  "T_MUL_EQUAL", "T_DIV_EQUAL", "T_CONCAT_EQUAL", "T_MOD_EQUAL",
  "T_AND_EQUAL", "T_OR_EQUAL", "T_XOR_EQUAL", "T_SL_EQUAL", "T_SR_EQUAL",
  "T_BOOLEAN_OR", "T_BOOLEAN_AND", "T_IS_EQUAL", "T_IS_NOT_EQUAL",
  "T_IS_IDENTICAL", "T_IS_NOT_IDENTICAL", "T_IS_SMALLER_OR_EQUAL",
  "T_IS_GREATER_OR_EQUAL", "T_SL", "T_SR", "T_INSTANCEOF", "T_INC",
  "T_DEC", "T_INT_CAST", "T_DOUBLE_CAST", "T_STRING_CAST", "T_ARRAY_CAST",
  "T_OBJECT_CAST", "T_BOOL_CAST", "T_UNSET_CAST", "T_NEW", "T_CLONE",
  "T_EXIT", "T_IF", "T_ELSEIF", "T_ELSE", "T_ENDIF", "T_LNUMBER",
  "T_DNUMBER", "T_STRING", "T_STRING_VARNAME", "T_VARIABLE",
  "T_NUM_STRING", "T_INLINE_HTML", "T_CHARACTER", "T_BAD_CHARACTER",
  "T_ENCAPSED_AND_WHITESPACE", "T_CONSTANT_ENCAPSED_STRING", "T_ECHO",
  "T_DO", "T_WHILE", "T_ENDWHILE", "T_FOR", "T_ENDFOR", "T_FOREACH",
  "T_ENDFOREACH", "T_DECLARE", "T_ENDDECLARE", "T_AS", "T_SWITCH",
  "T_ENDSWITCH", "T_CASE", "T_DEFAULT", "T_BREAK", "T_CONTINUE",
  "T_FUNCTION", "T_CONST", "T_RETURN", "T_TRY", "T_CATCH", "T_THROW",
  "T_USE", "T_GLOBAL", "T_STATIC", "T_ABSTRACT", "T_FINAL", "T_PRIVATE",
  "T_PROTECTED", "T_PUBLIC", "T_VAR", "T_UNSET", "T_ISSET", "T_EMPTY",
  "T_HALT_COMPILER", "T_CLASS", "T_INTERFACE", "T_EXTENDS", "T_IMPLEMENTS",
  "T_OBJECT_OPERATOR", "T_DOUBLE_ARROW", "T_LIST", "T_ARRAY", "T_CLASS_C",
  "T_METHOD_C", "T_FUNC_C", "T_LINE", "T_FILE", "T_COMMENT",
  "T_DOC_COMMENT", "T_OPEN_TAG", "T_OPEN_TAG_WITH_ECHO", "T_CLOSE_TAG",
  "T_WHITESPACE", "T_START_HEREDOC", "T_END_HEREDOC",
  "T_DOLLAR_OPEN_CURLY_BRACES", "T_CURLY_OPEN", "T_PAAMAYIM_NEKUDOTAYIM",
  "$accept", "start", "top_statement_list", "top_statement",
  "inner_statement_list", "inner_statement", "stmt_end", "statement",
  "unticked_statement", "additional_catches",
  "non_empty_additional_catches", "additional_catch", "unset_variables",
  "unset_variable", "use_filename", "function_declaration_statement",
  "class_declaration_statement", "is_reference",
  "unticked_function_declaration_statement",
  "unticked_class_declaration_statement", "class_entry_type",
  "extends_from", "interface_entry", "interface_extends_list",
  "implements_list", "interface_list", "foreach_optional_arg",
  "foreach_variable", "for_statement", "foreach_statement",
  "declare_statement", "declare_list", "switch_case_list", "case_list",
  "case_separator", "while_statement", "elseif_list", "new_elseif_list",
  "else_single", "new_else_single", "parameter_list",
  "non_empty_parameter_list", "optional_class_type",
  "function_call_parameter_list", "non_empty_function_call_parameter_list",
  "global_var_list", "global_var", "static_var_list",
  "class_statement_list", "class_statement", "method_body",
  "variable_modifiers", "method_modifiers", "non_empty_member_modifiers",
  "member_modifier", "class_variable_declaration",
  "class_constant_declaration", "echo_expr_list", "for_expr",
  "non_empty_for_expr", "expr_without_variable", "function_call",
  "fully_qualified_class_name", "class_name_reference",
  "dynamic_class_name_reference", "dynamic_class_name_variable_properties",
  "dynamic_class_name_variable_property", "exit_expr", "ctor_arguments",
  "common_scalar", "static_scalar", "static_class_constant", "scalar",
  "static_array_pair_list", "possible_comma",
  "non_empty_static_array_pair_list", "expr", "r_variable", "w_variable",
  "rw_variable", "variable", "variable_properties", "variable_property",
  "method_or_not", "variable_without_objects", "static_member",
  "base_variable_with_function_calls", "base_variable",
  "reference_variable", "compound_variable", "dim_offset",
  "object_property", "object_dim_list", "variable_name",
  "simple_indirect_reference", "assignment_list",
  "assignment_list_element", "array_pair_list",
  "non_empty_array_pair_list", "encaps_list", "encaps_var",
  "encaps_var_offset", "internal_functions_in_yacc", "isset_variables",
  "class_constant", YY_NULLPTR
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[NUM] -- (External) token number corresponding to the
   (internal) symbol number NUM (which must be that of a token).  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   126,    59,    40,    46,    58,    39,    43,
      37,    96,    34,    94,    42,    61,   123,    36,    45,    60,
      44,    63,    64,    62,    38,    47,    91,   125,    33,    93,
     124,    41,   258,   259,   260,   261,   262,   263,   264,   265,
     266,   267,   268,   269,   270,   271,   272,   273,   274,   275,
     276,   277,   278,   279,   280,   281,   282,   283,   284,   285,
     286,   287,   288,   289,   290,   291,   292,   293,   294,   295,
     296,   297,   298,   299,   300,   301,   302,   303,   304,   305,
     306,   307,   308,   309,   310,   311,   312,   313,   314,   315,
     316,   317,   318,   319,   320,   321,   322,   323,   324,   325,
     326,   327,   328,   329,   330,   331,   332,   333,   334,   335,
     336,   337,   338,   339,   340,   341,   342,   343,   344,   345,
     346,   347,   348,   349,   350,   351,   352,   353,   354,   355,
     356,   357,   358,   359,   360,   361,   362,   363,   364,   365,
     366,   367,   368,   369,   370,   371,   372,   373,   374,   375
};
# endif

#define YYPACT_NINF -459

#define yypact_value_is_default(Yystate) \
  (!!((Yystate) == (-459)))

#define YYTABLE_NINF -293

#define yytable_value_is_error(Yytable_value) \
  (!!((Yytable_value) == (-293)))

  /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
     STATE-NUM.  */
static const yytype_int16 yypact[] =
{
    -459,    48,  2466,  -459,  4286,  -459,  4286,  -459,  4286,  -459,
    -459,  -459,   120,  4286,  4286,  4286,  4286,  4286,    28,  4286,
    4286,  4286,    69,    69,  4286,  4286,  4286,  4286,  4286,  4286,
    4286,    96,  4286,   144,   154,  -459,  -459,     9,  -459,  -459,
    -459,  -459,  4286,  3467,   175,   190,   220,   222,   231,   788,
     788,   218,   788,   238,  4286,    21,     7,   -40,   134,   146,
     274,   276,   278,   280,  -459,  -459,   281,   282,  -459,  -459,
    -459,  -459,  -459,  -459,  -459,  -459,  -459,  -459,  -459,  -459,
    -459,  -459,  -459,   207,   208,  -459,  -459,   142,  -459,  -459,
    4508,  -459,    44,   980,   287,  -459,   163,  -459,   214,  -459,
      56,  -459,  -459,  -459,  4738,    43,   182,   187,   284,  1030,
    4286,   182,  -459,   232,  5707,  5707,  4286,  5707,  5707,  5878,
     293,   153,  -459,  -459,  -459,  -459,  -459,  -459,  -459,  -459,
    -459,  -459,   155,   156,   298,  -459,   176,    41,    56,  -459,
    3606,  -459,  4286,  3691,    17,  5707,   215,  4286,  4286,  4286,
     227,  4286,  -459,  4508,  -459,  4508,  -459,   228,  -459,    31,
    5707,   664,  -459,  4508,   223,  -459,    31,    33,  -459,    18,
    -459,   299,    19,  -459,  -459,    69,    69,    69,   285,    15,
    3776,   869,   191,   194,   101,  4286,  4286,  4286,  4286,  4286,
    4286,  4286,  4286,  4286,  4286,  4286,  4286,  4286,  4286,  4286,
    4286,  4286,  4286,  4286,  4286,  4286,  4286,  4286,  4286,  4286,
      96,  -459,  -459,  -459,  3861,  4286,  4286,  4286,  4286,  4286,
    4286,  4286,  4286,  4286,  4286,  4286,  3691,    60,  4286,  4286,
     120,   243,  -459,  -459,  -459,  -459,  -459,  -459,  -459,    -7,
    -459,  -459,  -459,  -459,  -459,  4371,    69,  -459,  -459,  -459,
    -459,   313,  -459,  -459,  -459,  -459,  4795,  4852,   104,    57,
    3691,  -459,    60,    41,  -459,  4909,  4966,    69,   290,   304,
      35,  6198,  4286,  -459,   320,  5023,   324,   311,  5707,   233,
     919,   317,    63,  5080,  -459,  -459,   332,  -459,  -459,  1179,
    -459,   307,  -459,  4286,  -459,  -459,     7,  -459,   537,   256,
    -459,   173,  -459,  -459,  -459,   174,   310,    31,   339,  -459,
     197,  -459,    69,  4565,   314,   327,  -459,   269,   234,   269,
     335,   359,   364,    41,    56,   182,   182,   232,  6091,   232,
     182,   437,  5137,   437,  6148,   232,  6071,  5764,  5821,  5878,
    5992,  6014,  6166,  6166,  6166,  6166,   437,   437,   237,   237,
    -459,    61,  5878,  5878,  5878,  5878,  5878,  5878,  5878,  5878,
    5878,  5878,  5878,  5878,   343,  4286,  -459,  -459,   373,    76,
    -459,  5194,  5707,   352,   169,   301,   353,  5251,   356,   354,
    -459,  -459,   359,  -459,   360,  -459,  -459,  2752,  -459,  -459,
    -459,  3946,  5707,  4286,  2895,  4286,  4286,    69,    65,   537,
     303,  3038,    64,   -13,   288,  -459,  5308,  -459,   537,   537,
     244,   387,  -459,  -459,  -459,   383,    69,    31,    69,  -459,
    -459,  -459,    15,    15,   388,  -459,  4031,  -459,  4116,  -459,
    -459,  -459,   269,   392,   384,  -459,  -459,  3691,  3691,    41,
    4286,    96,  -459,  -459,  5365,  3691,  -459,  4286,  4286,  -459,
    -459,  -459,  -459,  -459,   380,  -459,  4286,  -459,  -459,    31,
    -459,   283,  -459,  -459,    69,   198,  6235,  5422,  -459,  -459,
    -459,   412,  5707,   291,    69,   291,  -459,  -459,   403,  -459,
    -459,  -459,   417,   419,  -459,  -459,  -459,   393,   405,    10,
     423,  -459,  -459,  -459,   348,   537,   537,  -459,  -459,  -459,
     203,  -459,  4286,    69,  5707,    69,  4622,   384,  -459,   269,
     240,   399,   402,  5935,   298,  -459,   404,   306,  5479,   408,
    -459,  5536,  -459,    60,  -459,  2609,    99,  -459,    31,  1322,
    4286,    65,   407,  -459,   410,   537,  1465,  -459,   118,  -459,
       0,   428,   -36,   362,   424,   269,  -459,   318,   426,   430,
    -459,  -459,  5878,  -459,  -459,  4201,   350,  -459,  -459,   367,
    -459,  -459,  -459,  -459,  -459,  -459,  -459,  -459,   371,   357,
     -55,  -459,    27,  -459,  -459,  -459,  -459,    60,  -459,  -459,
    -459,   432,  -459,   201,   456,  3467,  -459,  -459,    31,   441,
    -459,  3181,  3181,  -459,    31,   162,    31,  4286,   193,     2,
    -459,  -459,    29,   458,   537,   391,   537,  -459,   537,  -459,
      69,  5707,  -459,   461,   462,    38,   218,  -459,   397,  -459,
     373,  -459,   474,   473,   411,  4286,  -459,  -459,  3324,  -459,
    -459,  -459,  -459,  -459,    31,  -459,  4681,  -459,  -459,  -459,
    -459,  1608,   418,   467,   537,  -459,   454,  -459,   355,  -459,
     537,   537,   421,  -459,   409,   476,  -459,  4286,  -459,    31,
    5593,  -459,  -459,  -459,  1751,  -459,  -459,  2609,  -459,   478,
     537,  -459,   472,   537,  -459,  -459,   485,   500,   537,  5650,
    2609,  -459,  3467,  1894,    31,  2609,   537,  -459,  -459,  -459,
     537,   -13,  -459,   499,  -459,    31,  -459,  -459,  2037,  -459,
     477,  -459,  -459,   396,    24,  2609,   505,  -459,   396,  -459,
    -459,  -459,  -459,   269,  -459,  2180,   429,  -459,   480,   498,
    -459,  2323,  -459
};

  /* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
     Performed when YYTABLE does not specify something else to do.  Zero
     means the default is an error.  */
static const yytype_uint16 yydefact[] =
{
       4,     0,     2,     1,     0,    16,     0,   341,     0,   341,
     341,    10,   313,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   244,     0,   249,   250,   264,   265,   302,
      35,   251,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    57,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    62,    67,     0,     0,   254,   255,
     256,   252,   253,    15,   341,     3,    42,     5,    17,     6,
       7,    55,    56,     0,     0,   280,   295,     0,   267,   228,
       0,   279,     0,   281,     0,   298,   285,   294,   296,   301,
       0,   218,   266,   206,     0,     0,   203,     0,     0,     0,
       0,   204,   227,   205,   353,   354,     0,   356,   357,   231,
     236,     0,   184,   283,   186,   219,   220,   221,   222,   223,
     224,   225,   237,     0,   247,   238,   240,   296,     0,   171,
       0,   226,     0,   119,     0,   161,     0,     0,   162,     0,
       0,     0,    25,     0,    27,     0,    58,     0,    29,   280,
       0,   281,    10,     0,     0,    53,     0,     0,   128,     0,
     127,   133,     0,    63,    64,     0,     0,     0,     0,   319,
     320,     0,    65,    68,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    36,   183,   185,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   119,     0,     0,   304,
     314,   297,   216,   269,   338,   336,   339,   337,   331,   342,
     332,   334,   335,   333,   340,     0,     0,   330,   230,   268,
      18,     0,     9,    11,    12,    13,     0,     0,     0,     0,
     119,   170,     0,   297,   245,     0,     0,     0,     0,   118,
     280,   281,     0,    34,     0,     0,     0,   163,   165,   280,
     281,     0,     0,     0,    26,    28,     0,    30,    31,     0,
      44,     0,    37,     0,   129,   281,     0,    32,     0,     0,
      33,     0,    50,    52,   358,     0,     0,     0,     0,   317,
       0,   316,     0,   325,     0,   273,   270,     0,    70,     0,
       0,   360,   293,   291,     0,   195,   196,   200,   194,   198,
     197,   211,     0,   213,   193,   199,   192,   189,   191,   190,
     187,   188,   209,   210,   207,   208,   212,   214,   201,   202,
     215,     0,   167,   172,   173,   174,   175,   176,   177,   178,
     179,   180,   181,   182,     0,     0,   311,   307,   290,   306,
     310,     0,   305,     0,     0,     0,   265,     0,     0,     0,
     303,   355,     0,   293,     0,   242,   246,     0,   122,   282,
     232,     0,   160,     0,     0,   162,     0,     0,     0,     0,
       0,     0,     0,   115,     0,    54,     0,   126,     0,     0,
     258,     0,   257,   134,   262,   131,     0,     0,     0,   351,
     352,     8,   319,   319,     0,   329,     0,   229,   274,   321,
     236,    66,     0,     0,    69,    72,   136,   119,   119,   292,
       0,     0,   168,   235,     0,   119,   287,     0,   304,   300,
     299,   348,   350,   349,     0,   344,     0,   345,   347,     0,
     248,   239,    10,    97,     0,   280,   281,     0,    10,    95,
      21,     0,   164,    74,     0,    74,    76,    84,     0,    10,
      82,    41,    90,    90,    24,   116,   117,     0,   105,     0,
       0,   130,   259,   260,     0,   271,     0,    51,    38,   359,
       0,   315,     0,     0,   324,     0,   323,    71,   136,     0,
     144,     0,     0,   217,   247,   312,     0,   284,     0,     0,
     343,     0,    14,     0,   241,    99,   101,   125,     0,     0,
     162,     0,     0,    77,     0,     0,     0,    90,     0,    90,
       0,     0,   115,     0,   107,     0,   263,   278,     0,   273,
     132,   318,   166,   328,   327,     0,   144,    73,    61,     0,
     151,   152,   153,   150,   149,   148,   143,   135,     0,     0,
     142,   146,     0,   233,   234,   169,   289,     0,   286,   309,
     308,     0,   243,   103,     0,     0,    19,    22,     0,     0,
      75,     0,     0,    85,     0,     0,     0,     0,     0,     0,
      86,    10,     0,   108,     0,     0,     0,   261,   274,   272,
       0,   322,    60,     0,   156,     0,    57,   147,     0,   138,
     290,   346,     0,     0,     0,     0,   102,    96,     0,    10,
      80,    40,    39,    83,     0,    88,     0,    94,    93,    10,
      87,     0,     0,   111,     0,   110,     0,   277,   276,   326,
       0,     0,     0,   137,     0,     0,   288,     0,    10,     0,
       0,    10,    78,    23,     0,    89,    10,    92,    59,   112,
       0,   109,     0,     0,   159,   157,   154,     0,     0,     0,
     104,    20,     0,     0,     0,    91,     0,   114,    10,   275,
       0,   115,   158,     0,    98,     0,    81,   113,     0,   155,
       0,    10,    79,    46,     0,   100,     0,    43,    45,    47,
      10,   140,   139,     0,    48,     0,     0,   141,     0,     0,
      10,     0,    49
};

  /* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -459,  -459,  -459,  -459,  -126,  -459,   -44,     1,  -459,  -459,
    -459,  -193,  -459,   100,  -459,   515,   516,   -97,  -459,  -459,
    -459,  -459,  -459,  -459,  -459,    89,    49,    -6,  -459,   -66,
    -459,  -459,  -459,  -458,  -107,  -459,  -459,  -459,  -459,  -459,
    -161,  -459,    -9,  -206,  -459,  -459,   235,  -459,    26,  -459,
    -459,  -459,  -459,  -459,   -34,  -459,  -459,  -459,  -379,  -459,
     -48,  -459,   -22,  -208,  -459,  -459,  -459,  -459,    23,   229,
    -324,  -459,  -459,  -459,   -10,  -459,   553,   374,  -295,   179,
     -11,  -459,  -459,   -82,  -171,  -459,  -459,   -24,    -1,  -459,
      94,  -247,  -459,  -459,   -21,   121,   122,  -459,  -459,   125,
    -459,  -459,  -459,  -459,  -459
};

  /* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     1,     2,    75,   109,   252,    76,   253,    78,   707,
     708,   709,   301,   302,   166,   254,   255,   157,    81,    82,
      83,   318,    84,   320,   433,   434,   532,   475,   663,   631,
     481,   282,   484,   538,   639,   470,   526,   583,   586,   624,
     487,   488,   489,   268,   269,   169,   170,   172,   510,   567,
     712,   568,   569,   570,   571,   615,   572,   144,   276,   277,
      85,    86,    87,   134,   135,   461,   524,   141,   261,    88,
     413,   414,    89,   548,   429,   549,    90,    91,   388,    92,
      93,   517,   578,   446,    94,    95,    96,    97,    98,    99,
     373,   368,   369,   370,   100,   310,   311,   314,   315,   105,
     247,   454,   101,   305,   102
};

  /* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
     positive, shift that token.  If negative, reduce the rule whose
     number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
     121,   121,   350,    77,   159,   152,   154,   136,   158,   133,
     138,   123,   123,   322,   143,   385,   471,   425,  -106,   374,
     364,     5,     5,     5,   167,   540,   164,   600,     5,   640,
     137,     5,    12,   116,   543,     5,   289,   272,   296,   299,
     710,   161,     5,   171,   146,   485,   211,   618,     3,   293,
      12,   233,  -145,   642,   384,  -120,   367,   228,   652,   234,
     560,   561,   562,   563,   564,   565,  -120,   229,   485,   235,
     236,   482,   237,   230,    12,   477,   365,    12,    12,   595,
     483,   599,    12,   400,   492,   493,    12,   322,   383,   474,
     168,   367,   447,   544,   401,   270,   120,   486,    39,   231,
     273,   279,   448,   597,   598,   597,   598,   212,   213,   284,
     165,   285,   643,    12,   120,   287,    39,   288,    12,   290,
     486,    12,   292,   375,   238,   297,   239,   240,   300,   241,
     242,   243,   271,   441,   107,   108,   110,   263,   280,    39,
      39,   366,   120,    39,    39,   121,   120,   308,    39,   140,
     120,   589,    39,   121,   121,   121,   295,   121,  -236,   142,
      73,    73,    73,   324,   303,   304,   306,    73,   309,   527,
      73,   547,   550,   244,    73,   584,   585,   132,   270,    39,
     147,    73,   321,   323,    39,   382,   136,    39,   133,   138,
     245,   246,   187,   416,   418,   148,   189,   637,   248,   181,
     638,   122,   124,   234,   417,   419,   324,   195,   553,   137,
     554,   593,   270,   235,   236,   271,   237,   423,  -123,  -291,
     596,   597,   598,   423,   121,   149,   323,   150,   424,  -123,
     228,   511,   512,   514,   551,   378,   151,   324,   324,   516,
     229,   324,   156,   185,   210,   121,   186,   187,  -292,   271,
     451,   189,   452,   453,   162,   190,   389,   323,   323,   228,
     173,   323,   195,   421,   634,   597,   598,   558,   238,   229,
     239,   240,   174,   241,   242,   243,   582,   622,   623,   175,
     645,   176,   647,   177,   648,   178,   179,   180,   182,   183,
     121,   184,   226,   227,   210,   431,   249,   435,   143,   210,
     234,   389,   258,   260,  -236,   259,   262,   274,   281,   286,
     235,   236,   291,   237,   298,   649,   307,   244,   379,   317,
     671,   390,   319,   439,   391,   393,   674,   675,   395,   121,
     620,   396,   399,   397,   245,   246,   525,   403,   405,   415,
     442,   420,   529,   465,   422,   427,   687,   428,   559,   689,
     430,   436,   367,   536,   692,   560,   561,   562,   563,   564,
     565,   566,   697,   432,   437,   238,   699,   239,   240,   438,
     241,   242,   243,   498,   443,   121,   121,   612,   445,   456,
     466,   450,   455,   458,   478,   459,   473,   476,   463,   270,
     270,   460,   495,   494,   121,   469,   121,   270,   496,   490,
     121,   121,   480,   502,   509,   303,   367,   499,   508,   520,
     435,   309,   309,   523,   244,   522,   530,   136,   535,   133,
     138,   537,   531,   539,   541,   542,   271,   271,   545,   546,
     573,   245,   246,   574,   271,   576,   577,   580,   591,   604,
     137,   592,   121,   185,   601,   603,   186,   187,   613,   606,
     608,   189,   121,   389,   614,   190,  -293,   607,   559,   621,
    -293,   625,   195,   533,   616,   560,   561,   562,   563,   564,
     565,   566,   628,   644,   646,   641,   650,   651,   655,   657,
     658,   121,   670,   121,   587,   672,   673,   557,   688,   659,
     677,   678,   389,   686,   389,  -293,  -293,   208,   209,   210,
     690,   669,   324,   664,   676,   691,   701,   706,   704,   121,
     713,   719,   718,   667,   720,   714,   497,    79,    80,   654,
     476,   507,   323,   605,   534,   590,   632,   412,   619,   666,
     700,   407,   680,   602,   556,   683,   617,   575,   656,   609,
     685,   294,   519,   500,   627,   501,   408,     0,     0,     0,
     633,     0,   635,     0,     0,   409,   324,   103,     0,   104,
       0,   106,   698,     0,     0,     0,   111,   112,   113,   114,
     115,   653,   117,   118,   119,   705,   323,   125,   126,   127,
     128,   129,   130,   131,   715,   139,   626,     0,   121,     0,
     665,     0,   630,   630,   721,   145,     0,     0,     0,   389,
       0,     0,   153,   155,     0,   160,     0,   163,     0,     0,
       0,     0,     0,     0,     0,   681,    35,    36,   410,     0,
       0,     0,     0,     0,     0,     0,    41,     0,   412,   662,
       0,     0,     0,     0,     0,     0,     0,   412,   412,     0,
     696,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   702,     0,     0,     0,     0,     0,     0,     0,     0,
     711,     0,     0,   256,     0,     0,     0,     0,     5,   257,
     411,    68,    69,    70,    71,    72,     0,     0,     0,   214,
       0,     0,     0,   694,     0,     0,     0,     0,     0,     0,
       0,   716,     0,   265,     0,   266,   160,     0,     0,     0,
     275,   278,   160,     0,   283,   215,   216,   217,   218,   219,
     220,   221,   222,   223,   224,   225,     0,     0,     0,     0,
       0,     0,     0,     0,   412,   412,     0,  -283,  -283,     0,
       0,     0,     0,   313,     0,     0,     0,     0,   325,   326,
     327,   328,   329,   330,   331,   332,   333,   334,   335,   336,
     337,   338,   339,   340,   341,   342,   343,   344,   345,   346,
     347,   348,   349,     0,   412,     0,     0,   352,   353,   354,
     355,   356,   357,   358,   359,   360,   361,   362,   363,   160,
       0,   371,   372,     0,     0,     0,     0,     0,     0,     0,
       0,     4,     5,     6,     0,     0,     7,     8,   377,     9,
      10,     0,     0,     0,     0,    12,    13,    73,     0,     0,
      14,     0,     0,   160,     0,     0,    15,     0,     0,     0,
      16,    17,    18,    19,    20,   392,     0,     0,    21,     0,
       0,     0,     0,   412,     0,   412,     0,   412,     0,     0,
       0,     0,     0,     0,     0,     0,   406,     0,     0,     0,
       0,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    33,     0,     0,     0,     0,    35,    36,    37,
      38,    39,     0,   412,     0,     0,     0,    41,     0,   412,
     412,     0,     0,     0,     0,   234,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   235,   236,     0,   237,   412,
       0,     0,   412,     0,     0,     0,     0,   412,     0,     0,
       0,    61,    62,     0,     0,   412,     0,     0,   444,   412,
      66,    67,    68,    69,    70,    71,    72,     0,     0,     0,
       0,    73,     0,    74,   214,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   160,     0,   467,     0,   278,   472,
     238,     0,   239,   240,     0,   241,   242,   243,     0,     0,
     215,   216,   217,   218,   219,   220,   221,   222,   223,   224,
     225,     0,     0,     0,     0,     0,     0,     0,     0,   504,
       0,   506,  -283,  -283,     0,     0,     0,     0,     0,     0,
     160,   160,     0,   513,     0,   214,     0,     0,   160,   244,
     518,   372,     0,     0,     0,     0,     0,     0,     0,   521,
       0,     0,     0,     0,     0,   316,   245,   246,     0,   398,
       0,   215,   216,   217,   218,   219,   220,   221,   222,   223,
     224,   225,     0,     4,     5,     6,     0,     0,     7,     8,
       0,     9,    10,  -283,  -283,     0,    11,    12,    13,     0,
       0,     0,    14,     0,     0,   552,     0,   250,    15,     0,
       0,     0,    16,    17,    18,    19,    20,     0,     0,     0,
      21,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   278,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,     0,     0,   611,    35,
      36,    37,    38,    39,     0,    40,     0,     0,     0,    41,
      42,    43,    44,     0,    45,     0,    46,     0,    47,     0,
       0,    48,     0,     0,     0,    49,    50,    51,     0,    52,
      53,     0,    54,    55,    56,    57,    58,    59,     0,     0,
     636,     0,    60,    61,    62,   251,    64,    65,     0,     0,
       0,     0,    66,    67,    68,    69,    70,    71,    72,     0,
       0,     0,     0,    73,     0,    74,     0,     0,   660,     0,
       0,     0,     4,     5,     6,     0,     0,     7,     8,     0,
       9,    10,     0,     0,     0,    11,    12,    13,     0,     0,
       0,    14,     0,     0,     0,     0,   404,    15,     0,     0,
     679,    16,    17,    18,    19,    20,     0,     0,     0,    21,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    33,    34,     0,     0,     0,    35,    36,
      37,    38,    39,     0,    40,     0,     0,     0,    41,    42,
      43,    44,     0,    45,     0,    46,     0,    47,     0,     0,
      48,     0,     0,     0,    49,    50,    51,     0,    52,    53,
       0,    54,    55,    56,    57,    58,    59,     0,     0,     0,
       0,    60,    61,    62,   251,    64,    65,     0,     0,     0,
       0,    66,    67,    68,    69,    70,    71,    72,     0,     0,
       0,     0,    73,     0,    74,     4,     5,     6,     0,     0,
       7,     8,     0,     9,    10,     0,     0,     0,    11,    12,
      13,     0,     0,     0,    14,     0,     0,     0,     0,     0,
      15,     0,     0,     0,    16,    17,    18,    19,    20,     0,
       0,     0,    21,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,     0,     0,
       0,    35,    36,    37,    38,    39,     0,    40,     0,     0,
       0,    41,    42,    43,    44,   588,    45,     0,    46,     0,
      47,     0,     0,    48,     0,     0,     0,    49,    50,    51,
       0,    52,    53,     0,    54,    55,    56,    57,    58,    59,
       0,     0,     0,     0,    60,    61,    62,   251,    64,    65,
       0,     0,     0,     0,    66,    67,    68,    69,    70,    71,
      72,     0,     0,     0,     0,    73,     0,    74,     4,     5,
       6,     0,     0,     7,     8,     0,     9,    10,     0,     0,
       0,    11,    12,    13,     0,     0,     0,    14,     0,     0,
       0,     0,     0,    15,     0,     0,     0,    16,    17,    18,
      19,    20,     0,     0,     0,    21,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,     0,     0,     0,    35,    36,    37,    38,    39,     0,
      40,     0,     0,     0,    41,    42,    43,    44,     0,    45,
       0,    46,     0,    47,   594,     0,    48,     0,     0,     0,
      49,    50,    51,     0,    52,    53,     0,    54,    55,    56,
      57,    58,    59,     0,     0,     0,     0,    60,    61,    62,
     251,    64,    65,     0,     0,     0,     0,    66,    67,    68,
      69,    70,    71,    72,     0,     0,     0,     0,    73,     0,
      74,     4,     5,     6,     0,     0,     7,     8,     0,     9,
      10,     0,     0,     0,    11,    12,    13,     0,     0,     0,
      14,     0,     0,     0,     0,   668,    15,     0,     0,     0,
      16,    17,    18,    19,    20,     0,     0,     0,    21,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,     0,     0,     0,    35,    36,    37,
      38,    39,     0,    40,     0,     0,     0,    41,    42,    43,
      44,     0,    45,     0,    46,     0,    47,     0,     0,    48,
       0,     0,     0,    49,    50,    51,     0,    52,    53,     0,
      54,    55,    56,    57,    58,    59,     0,     0,     0,     0,
      60,    61,    62,   251,    64,    65,     0,     0,     0,     0,
      66,    67,    68,    69,    70,    71,    72,     0,     0,     0,
       0,    73,     0,    74,     4,     5,     6,     0,     0,     7,
       8,     0,     9,    10,     0,     0,     0,    11,    12,    13,
       0,     0,     0,    14,     0,     0,     0,     0,     0,    15,
       0,     0,     0,    16,    17,    18,    19,    20,     0,     0,
       0,    21,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,    34,     0,     0,     0,
      35,    36,    37,    38,    39,     0,    40,     0,     0,     0,
      41,    42,    43,    44,     0,    45,     0,    46,   684,    47,
       0,     0,    48,     0,     0,     0,    49,    50,    51,     0,
      52,    53,     0,    54,    55,    56,    57,    58,    59,     0,
       0,     0,     0,    60,    61,    62,   251,    64,    65,     0,
       0,     0,     0,    66,    67,    68,    69,    70,    71,    72,
       0,     0,     0,     0,    73,     0,    74,     4,     5,     6,
       0,     0,     7,     8,     0,     9,    10,     0,     0,     0,
      11,    12,    13,     0,     0,     0,    14,     0,     0,     0,
       0,     0,    15,     0,     0,     0,    16,    17,    18,    19,
      20,     0,     0,     0,    21,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
       0,     0,     0,    35,    36,    37,    38,    39,     0,    40,
       0,     0,     0,    41,    42,    43,    44,     0,    45,   695,
      46,     0,    47,     0,     0,    48,     0,     0,     0,    49,
      50,    51,     0,    52,    53,     0,    54,    55,    56,    57,
      58,    59,     0,     0,     0,     0,    60,    61,    62,   251,
      64,    65,     0,     0,     0,     0,    66,    67,    68,    69,
      70,    71,    72,     0,     0,     0,     0,    73,     0,    74,
       4,     5,     6,     0,     0,     7,     8,     0,     9,    10,
       0,     0,     0,    11,    12,    13,     0,     0,     0,    14,
       0,     0,     0,     0,   703,    15,     0,     0,     0,    16,
      17,    18,    19,    20,     0,     0,     0,    21,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      22,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,     0,     0,     0,    35,    36,    37,    38,
      39,     0,    40,     0,     0,     0,    41,    42,    43,    44,
       0,    45,     0,    46,     0,    47,     0,     0,    48,     0,
       0,     0,    49,    50,    51,     0,    52,    53,     0,    54,
      55,    56,    57,    58,    59,     0,     0,     0,     0,    60,
      61,    62,   251,    64,    65,     0,     0,     0,     0,    66,
      67,    68,    69,    70,    71,    72,     0,     0,     0,     0,
      73,     0,    74,     4,     5,     6,     0,     0,     7,     8,
       0,     9,    10,     0,     0,     0,    11,    12,    13,     0,
       0,     0,    14,     0,     0,     0,     0,   717,    15,     0,
       0,     0,    16,    17,    18,    19,    20,     0,     0,     0,
      21,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,     0,     0,     0,    35,
      36,    37,    38,    39,     0,    40,     0,     0,     0,    41,
      42,    43,    44,     0,    45,     0,    46,     0,    47,     0,
       0,    48,     0,     0,     0,    49,    50,    51,     0,    52,
      53,     0,    54,    55,    56,    57,    58,    59,     0,     0,
       0,     0,    60,    61,    62,   251,    64,    65,     0,     0,
       0,     0,    66,    67,    68,    69,    70,    71,    72,     0,
       0,     0,     0,    73,     0,    74,     4,     5,     6,     0,
       0,     7,     8,     0,     9,    10,     0,     0,     0,    11,
      12,    13,     0,     0,     0,    14,     0,     0,     0,     0,
     722,    15,     0,     0,     0,    16,    17,    18,    19,    20,
       0,     0,     0,    21,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    22,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    33,    34,     0,
       0,     0,    35,    36,    37,    38,    39,     0,    40,     0,
       0,     0,    41,    42,    43,    44,     0,    45,     0,    46,
       0,    47,     0,     0,    48,     0,     0,     0,    49,    50,
      51,     0,    52,    53,     0,    54,    55,    56,    57,    58,
      59,     0,     0,     0,     0,    60,    61,    62,   251,    64,
      65,     0,     0,     0,     0,    66,    67,    68,    69,    70,
      71,    72,     0,     0,     0,     0,    73,     0,    74,     4,
       5,     6,     0,     0,     7,     8,     0,     9,    10,     0,
       0,     0,    11,    12,    13,     0,     0,     0,    14,     0,
       0,     0,     0,     0,    15,     0,     0,     0,    16,    17,
      18,    19,    20,     0,     0,     0,    21,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      33,    34,     0,     0,     0,    35,    36,    37,    38,    39,
       0,    40,     0,     0,     0,    41,    42,    43,    44,     0,
      45,     0,    46,     0,    47,     0,     0,    48,     0,     0,
       0,    49,    50,    51,     0,    52,    53,     0,    54,    55,
      56,    57,    58,    59,     0,     0,     0,     0,    60,    61,
      62,    63,    64,    65,     0,     0,     0,     0,    66,    67,
      68,    69,    70,    71,    72,     0,     0,     0,     0,    73,
       0,    74,     4,     5,     6,     0,     0,     7,     8,     0,
       9,    10,     0,     0,     0,    11,    12,    13,     0,     0,
       0,    14,     0,     0,     0,     0,     0,    15,     0,     0,
       0,    16,    17,    18,    19,    20,     0,     0,     0,    21,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    33,    34,     0,     0,     0,    35,    36,
      37,    38,    39,     0,    40,     0,     0,     0,    41,    42,
      43,    44,     0,    45,     0,    46,     0,    47,     0,     0,
      48,     0,     0,     0,    49,    50,    51,     0,    52,    53,
       0,    54,    55,    56,    57,    58,    59,     0,     0,     0,
       0,    60,    61,    62,   251,    64,    65,     0,     0,     0,
       0,    66,    67,    68,    69,    70,    71,    72,     0,     0,
       0,     0,    73,     0,    74,     4,     5,     6,     0,   462,
       7,     8,     0,     9,    10,     0,     0,     0,    11,    12,
      13,     0,     0,     0,    14,     0,     0,     0,     0,     0,
      15,     0,     0,     0,    16,    17,    18,    19,    20,     0,
       0,     0,    21,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    22,    23,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,     0,     0,
       0,    35,    36,    37,    38,    39,     0,    40,     0,     0,
       0,    41,    42,    43,    44,     0,    45,     0,    46,     0,
      47,     0,     0,    48,     0,     0,     0,    49,    50,     0,
       0,    52,    53,     0,    54,    55,    56,    57,     0,     0,
       0,     0,     0,     0,    60,    61,    62,     0,     0,     0,
       0,     0,     0,     0,    66,    67,    68,    69,    70,    71,
      72,     0,     0,     0,     0,    73,     0,    74,     4,     5,
       6,     0,   468,     7,     8,     0,     9,    10,     0,     0,
       0,    11,    12,    13,     0,     0,     0,    14,     0,     0,
       0,     0,     0,    15,     0,     0,     0,    16,    17,    18,
      19,    20,     0,     0,     0,    21,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,     0,     0,     0,    35,    36,    37,    38,    39,     0,
      40,     0,     0,     0,    41,    42,    43,    44,     0,    45,
       0,    46,     0,    47,     0,     0,    48,     0,     0,     0,
      49,    50,     0,     0,    52,    53,     0,    54,    55,    56,
      57,     0,     0,     0,     0,     0,     0,    60,    61,    62,
       0,     0,     0,     0,     0,     0,     0,    66,    67,    68,
      69,    70,    71,    72,     0,     0,     0,     0,    73,     0,
      74,     4,     5,     6,     0,   479,     7,     8,     0,     9,
      10,     0,     0,     0,    11,    12,    13,     0,     0,     0,
      14,     0,     0,     0,     0,     0,    15,     0,     0,     0,
      16,    17,    18,    19,    20,     0,     0,     0,    21,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    22,    23,    24,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,     0,     0,     0,    35,    36,    37,
      38,    39,     0,    40,     0,     0,     0,    41,    42,    43,
      44,     0,    45,     0,    46,     0,    47,     0,     0,    48,
       0,     0,     0,    49,    50,     0,     0,    52,    53,     0,
      54,    55,    56,    57,     0,     0,     0,     0,     0,     0,
      60,    61,    62,     0,     0,     0,     0,     0,     0,     0,
      66,    67,    68,    69,    70,    71,    72,     0,     0,     0,
       0,    73,     0,    74,     4,     5,     6,     0,   629,     7,
       8,     0,     9,    10,     0,     0,     0,    11,    12,    13,
       0,     0,     0,    14,     0,     0,     0,     0,     0,    15,
       0,     0,     0,    16,    17,    18,    19,    20,     0,     0,
       0,    21,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,    34,     0,     0,     0,
      35,    36,    37,    38,    39,     0,    40,     0,     0,     0,
      41,    42,    43,    44,     0,    45,     0,    46,     0,    47,
       0,     0,    48,     0,     0,     0,    49,    50,     0,     0,
      52,    53,     0,    54,    55,    56,    57,     0,     0,     0,
       0,     0,     0,    60,    61,    62,     0,     0,     0,     0,
       0,     0,     0,    66,    67,    68,    69,    70,    71,    72,
       0,     0,     0,     0,    73,     0,    74,     4,     5,     6,
       0,   661,     7,     8,     0,     9,    10,     0,     0,     0,
      11,    12,    13,     0,     0,     0,    14,     0,     0,     0,
       0,     0,    15,     0,     0,     0,    16,    17,    18,    19,
      20,     0,     0,     0,    21,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
       0,     0,     0,    35,    36,    37,    38,    39,     0,    40,
       0,     0,     0,    41,    42,    43,    44,     0,    45,     0,
      46,     0,    47,     0,     0,    48,     0,     0,     0,    49,
      50,     0,     0,    52,    53,     0,    54,    55,    56,    57,
       0,     0,     0,     0,     0,     0,    60,    61,    62,     0,
       0,     0,     0,     0,     0,     0,    66,    67,    68,    69,
      70,    71,    72,     0,     0,     0,     0,    73,     0,    74,
       4,     5,     6,     0,     0,     7,     8,     0,     9,    10,
       0,     0,     0,    11,    12,    13,     0,     0,     0,    14,
       0,     0,     0,     0,     0,    15,     0,     0,     0,    16,
      17,    18,    19,    20,     0,     0,     0,    21,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      22,    23,    24,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,     0,     0,     0,    35,    36,    37,    38,
      39,     0,    40,     0,     0,     0,    41,    42,    43,    44,
       0,    45,     0,    46,     0,    47,     0,     0,    48,     0,
       0,     0,    49,    50,     0,     0,    52,    53,     0,    54,
      55,    56,    57,     0,     0,     0,     0,     0,     0,    60,
      61,    62,     0,     0,     0,     0,     0,     0,     0,    66,
      67,    68,    69,    70,    71,    72,     0,     0,     0,     4,
      73,     6,    74,     0,     7,     8,     0,     9,    10,     0,
       0,     0,     0,    12,    13,     0,     0,     0,    14,     0,
       0,     0,     0,     0,    15,     0,     0,   264,    16,    17,
      18,    19,    20,     0,     0,     0,    21,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      33,     0,     0,     0,     0,    35,    36,    37,    38,    39,
       0,     0,     0,     0,     4,    41,     6,     0,     0,     7,
       8,     0,     9,    10,     0,     0,     0,     0,    12,    13,
       0,     0,     0,    14,     0,   267,     0,     0,     0,    15,
       0,     0,     0,    16,    17,    18,    19,    20,     0,    61,
      62,    21,     0,     0,     0,     0,     0,     0,    66,    67,
      68,    69,    70,    71,    72,     0,     0,     0,     0,     0,
       0,    74,     0,     0,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,     0,     0,     0,     0,
      35,    36,    37,    38,    39,     0,     0,     0,     0,     4,
      41,     6,     0,     0,     7,     8,     0,     9,    10,     0,
       0,     0,     0,    12,    13,     0,     0,     0,    14,     0,
     312,     0,     0,     0,    15,     0,     0,     0,    16,    17,
      18,    19,    20,     0,    61,    62,    21,     0,     0,     0,
       0,     0,     0,    66,    67,    68,    69,    70,    71,    72,
       0,     0,     0,     0,     0,     0,    74,     0,     0,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      33,     0,     0,     0,     0,    35,    36,    37,    38,    39,
       0,     0,     0,     0,     4,    41,     6,     0,     0,     7,
       8,     0,     9,    10,     0,     0,     0,     0,    12,    13,
       0,     0,     0,    14,     0,   351,     0,     0,     0,    15,
       0,     0,     0,    16,    17,    18,    19,    20,     0,    61,
      62,    21,     0,     0,     0,     0,     0,     0,    66,    67,
      68,    69,    70,    71,    72,     0,     0,     0,     0,     0,
       0,    74,     0,     0,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,     0,     0,     0,     0,
      35,    36,    37,    38,    39,     0,     0,     0,     0,     4,
      41,     6,     0,     0,     7,     8,     0,     9,    10,     0,
       0,     0,     0,    12,    13,     0,     0,     0,    14,     0,
     464,     0,     0,     0,    15,     0,     0,     0,    16,    17,
      18,    19,    20,     0,    61,    62,    21,     0,     0,     0,
       0,     0,     0,    66,    67,    68,    69,    70,    71,    72,
       0,     0,     0,     0,     0,     0,    74,     0,     0,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      33,     0,     0,     0,     0,    35,    36,    37,    38,    39,
       0,     0,     0,     0,     4,    41,     6,     0,     0,     7,
       8,     0,     9,    10,     0,     0,     0,     0,    12,    13,
       0,     0,     0,    14,     0,   503,     0,     0,     0,    15,
       0,     0,     0,    16,    17,    18,    19,    20,     0,    61,
      62,    21,     0,     0,     0,     0,     0,     0,    66,    67,
      68,    69,    70,    71,    72,     0,     0,     0,     0,     0,
       0,    74,     0,     0,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,     0,     0,     0,     0,
      35,    36,    37,    38,    39,     0,     0,     0,     0,     4,
      41,     6,     0,     0,     7,     8,     0,     9,    10,     0,
       0,     0,     0,    12,    13,     0,     0,     0,    14,     0,
     505,     0,     0,     0,    15,     0,     0,     0,    16,    17,
      18,    19,    20,     0,    61,    62,    21,     0,     0,     0,
       0,     0,     0,    66,    67,    68,    69,    70,    71,    72,
       0,     0,     0,     0,     0,     0,    74,     0,     0,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      33,     0,     0,     0,     0,    35,    36,    37,    38,    39,
       0,     0,     0,     0,     4,    41,     6,     0,     0,     7,
       8,     0,     9,    10,     0,     0,     0,     0,    12,    13,
       0,     0,     0,    14,     0,   610,     0,     0,     0,    15,
       0,     0,     0,    16,    17,    18,    19,    20,     0,    61,
      62,    21,     0,     0,     0,     0,     0,     0,    66,    67,
      68,    69,    70,    71,    72,     0,     0,     0,     0,     0,
       0,    74,     0,     0,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,     0,     0,     0,     0,
      35,    36,    37,    38,    39,     0,     0,     0,     0,     4,
      41,     6,     0,     0,     7,     8,     0,     9,    10,     0,
       0,     0,     0,    12,    13,     0,     0,     0,    14,     0,
       0,     0,     0,     0,    15,     0,     0,     0,    16,    17,
      18,    19,    20,     0,    61,    62,    21,     0,     0,     0,
       0,     0,     0,    66,    67,    68,    69,    70,    71,    72,
       0,     0,     0,     0,     0,     0,    74,     0,     0,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
      33,     0,     0,     0,     0,    35,    36,    37,    38,    39,
       0,     0,     0,     0,     4,    41,     6,     0,     0,     7,
       8,     0,     9,    10,     0,     0,     0,     0,    12,    13,
       0,     0,     0,    14,     0,     0,     0,     0,     0,    15,
       0,     0,     0,    16,    17,    18,    19,    20,     0,    61,
      62,    21,     0,     0,     0,     0,     0,     0,    66,    67,
      68,    69,    70,    71,    72,     0,     0,     0,     0,     0,
       0,    74,     0,     0,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    31,    32,    33,     0,     0,     0,     0,
      35,    36,    37,   376,    39,     0,     0,     0,     0,     0,
      41,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    61,    62,     0,     0,     0,     0,
       0,     0,     0,    66,    67,    68,    69,    70,    71,    72,
       0,     0,     5,     0,   185,     0,    74,   186,   187,     0,
       0,   188,   189,     0,     0,     0,   190,   191,     0,   192,
       0,   193,   194,   195,     0,     0,     0,     0,   196,     0,
       0,     0,     0,     0,     0,   197,   198,   199,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     200,   201,   202,   203,   204,   205,   206,   207,   208,   209,
     210,   185,     0,     0,   186,   187,     0,     0,   188,   189,
       0,     0,     0,   190,   191,     0,   192,     0,   193,   194,
     195,     0,     0,     0,     0,   196,     0,     0,     0,     0,
       0,     0,   197,   198,   199,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   200,   201,   202,
     203,   204,   205,   206,   207,   208,   209,   210,   185,     0,
       0,   186,   187,     0,     0,   188,   189,     0,     0,     0,
     190,   191,     0,   192,     0,   193,   194,   195,     0,     0,
       0,    73,   196,     0,     0,     0,     0,     0,     0,   197,
     198,   199,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   200,   201,   202,   203,   204,   205,
     206,   207,   208,   209,   210,   637,     0,   185,   638,     0,
     186,   187,     0,     0,   188,   189,   426,     0,     0,   190,
     191,     0,   192,     0,   193,   194,   195,     0,     0,     0,
       0,   196,     0,     0,     0,     0,     0,     0,   197,   198,
     199,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   200,   201,   202,   203,   204,   205,   206,
     207,   208,   209,   210,   185,     0,     0,   186,   187,     0,
       0,   188,   189,   555,     0,     0,   190,   191,     0,   192,
       0,   193,   194,   195,     0,     0,     0,     0,   196,   232,
       0,     0,     0,     0,     0,   197,   198,   199,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     200,   201,   202,   203,   204,   205,   206,   207,   208,   209,
     210,   185,     0,     0,   186,   187,     0,     0,   188,   189,
       0,     0,     0,   190,   191,     0,   192,     0,   193,   194,
     195,     0,   380,     0,     0,   196,     0,     0,     0,     0,
       0,     0,   197,   198,   199,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   200,   201,   202,
     203,   204,   205,   206,   207,   208,   209,   210,   185,     0,
       0,   186,   187,     0,     0,   188,   189,     0,     0,     0,
     190,   191,     0,   192,     0,   193,   194,   195,     0,     0,
       0,     0,   196,   381,     0,     0,     0,     0,     0,   197,
     198,   199,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   200,   201,   202,   203,   204,   205,
     206,   207,   208,   209,   210,   185,     0,     0,   186,   187,
       0,     0,   188,   189,     0,     0,     0,   190,   191,     0,
     192,     0,   193,   194,   195,     0,     0,     0,     0,   196,
     386,     0,     0,     0,     0,     0,   197,   198,   199,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   200,   201,   202,   203,   204,   205,   206,   207,   208,
     209,   210,   185,     0,     0,   186,   187,     0,     0,   188,
     189,     0,     0,     0,   190,   191,     0,   192,     0,   193,
     194,   195,     0,     0,     0,     0,   196,   387,     0,     0,
       0,     0,     0,   197,   198,   199,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   200,   201,
     202,   203,   204,   205,   206,   207,   208,   209,   210,   185,
       0,     0,   186,   187,     0,     0,   188,   189,     0,     0,
       0,   190,   191,     0,   192,     0,   193,   194,   195,     0,
       0,     0,     0,   196,   394,     0,     0,     0,     0,     0,
     197,   198,   199,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   200,   201,   202,   203,   204,
     205,   206,   207,   208,   209,   210,   185,     0,     0,   186,
     187,     0,     0,   188,   189,     0,     0,     0,   190,   191,
       0,   192,     0,   193,   194,   195,     0,     0,     0,     0,
     196,   402,     0,     0,     0,     0,     0,   197,   198,   199,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   200,   201,   202,   203,   204,   205,   206,   207,
     208,   209,   210,   185,   440,     0,   186,   187,     0,     0,
     188,   189,     0,     0,     0,   190,   191,     0,   192,     0,
     193,   194,   195,     0,     0,     0,     0,   196,     0,     0,
       0,     0,     0,     0,   197,   198,   199,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   200,
     201,   202,   203,   204,   205,   206,   207,   208,   209,   210,
     185,     0,     0,   186,   187,     0,     0,   188,   189,     0,
       0,     0,   190,   191,     0,   192,     0,   193,   194,   195,
       0,   449,     0,     0,   196,     0,     0,     0,     0,     0,
       0,   197,   198,   199,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   200,   201,   202,   203,
     204,   205,   206,   207,   208,   209,   210,   185,     0,     0,
     186,   187,     0,     0,   188,   189,     0,     0,     0,   190,
     191,     0,   192,     0,   193,   194,   195,     0,   457,     0,
       0,   196,     0,     0,     0,     0,     0,     0,   197,   198,
     199,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   200,   201,   202,   203,   204,   205,   206,
     207,   208,   209,   210,   185,     0,     0,   186,   187,     0,
       0,   188,   189,     0,     0,     0,   190,   191,     0,   192,
       0,   193,   194,   195,     0,   491,     0,     0,   196,     0,
       0,     0,     0,     0,     0,   197,   198,   199,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     200,   201,   202,   203,   204,   205,   206,   207,   208,   209,
     210,   185,     0,     0,   186,   187,     0,     0,   188,   189,
       0,     0,     0,   190,   191,     0,   192,     0,   193,   194,
     195,     0,   515,     0,     0,   196,     0,     0,     0,     0,
       0,     0,   197,   198,   199,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   200,   201,   202,
     203,   204,   205,   206,   207,   208,   209,   210,   185,     0,
       0,   186,   187,     0,     0,   188,   189,     0,     0,     0,
     190,   191,     0,   192,     0,   193,   194,   195,     0,     0,
       0,     0,   196,   528,     0,     0,     0,     0,     0,   197,
     198,   199,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   200,   201,   202,   203,   204,   205,
     206,   207,   208,   209,   210,   185,     0,     0,   186,   187,
       0,     0,   188,   189,     0,     0,     0,   190,   191,     0,
     192,     0,   193,   194,   195,     0,   579,     0,     0,   196,
       0,     0,     0,     0,     0,     0,   197,   198,   199,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   200,   201,   202,   203,   204,   205,   206,   207,   208,
     209,   210,   185,     0,     0,   186,   187,     0,     0,   188,
     189,     0,     0,     0,   190,   191,     0,   192,     0,   193,
     194,   195,     0,     0,     0,   581,   196,     0,     0,     0,
       0,     0,     0,   197,   198,   199,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   200,   201,
     202,   203,   204,   205,   206,   207,   208,   209,   210,   185,
       0,     0,   186,   187,     0,     0,   188,   189,     0,     0,
       0,   190,   191,     0,   192,     0,   193,   194,   195,     0,
       0,     0,     0,   196,   682,     0,     0,     0,     0,     0,
     197,   198,   199,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   200,   201,   202,   203,   204,
     205,   206,   207,   208,   209,   210,   185,     0,     0,   186,
     187,     0,     0,   188,   189,     0,     0,     0,   190,   191,
       0,   192,     0,   193,   194,   195,     0,     0,     0,     0,
     196,   693,     0,     0,     0,     0,     0,   197,   198,   199,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   200,   201,   202,   203,   204,   205,   206,   207,
     208,   209,   210,   185,     0,     0,   186,   187,     0,     0,
     188,   189,     0,     0,     0,   190,   191,     0,   192,     0,
     193,   194,   195,     0,     0,     0,     0,   196,     0,     0,
       0,     0,     0,     0,   197,   198,   199,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   200,
     201,   202,   203,   204,   205,   206,   207,   208,   209,   210,
     185,     0,     0,   186,   187,     0,     0,   188,   189,     0,
       0,     0,   190,   191,     0,   192,     0,   193,   194,   195,
       0,     0,     0,     0,   196,     0,     0,     0,     0,     0,
       0,     0,   198,   199,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   200,   201,   202,   203,
     204,   205,   206,   207,   208,   209,   210,   185,     0,     0,
     186,   187,     0,     0,   188,   189,     0,     0,     0,   190,
     191,     0,   192,     0,   193,   194,   195,     0,     0,     0,
       0,   196,     0,     0,     0,     0,     0,     0,     0,     0,
     199,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   200,   201,   202,   203,   204,   205,   206,
     207,   208,   209,   210,   185,     0,     0,   186,   187,     0,
       0,   188,   189,     0,     0,     0,   190,   191,     0,   192,
       0,   193,   194,   195,     0,     0,     0,     0,   196,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     200,   201,   202,   203,   204,   205,   206,   207,   208,   209,
     210,   185,     0,     0,   186,   187,     0,     0,   188,   189,
       0,     0,     0,   190,   191,     0,     0,     0,   193,   194,
     195,     0,     0,     0,     0,   196,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   200,   201,   202,
     203,   204,   205,   206,   207,   208,   209,   210,   185,     0,
       0,   186,   187,     0,     0,   188,   189,     0,     0,     0,
     190,   191,     0,     0,     0,   193,   194,   195,     0,     0,
     185,     0,   196,   186,   187,     0,     0,   188,   189,     0,
       0,     0,   190,   191,     0,     0,     0,   193,   194,   195,
       0,     0,     0,     0,   196,   201,   202,   203,   204,   205,
     206,   207,   208,   209,   210,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   202,   203,
     204,   205,   206,   207,   208,   209,   210,   185,     0,     0,
     186,   187,     0,     0,   188,   189,     0,     0,     0,   190,
     191,     0,     0,     0,   193,   194,   195,   185,     0,     0,
     186,   187,     0,     0,     0,   189,     0,     0,     0,   190,
     191,     0,     0,     0,   193,   194,   195,     0,     0,     0,
       0,     0,     0,     0,     0,   202,   203,   204,   205,   206,
     207,   208,   209,   210,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   202,   203,   204,   205,   206,
     207,   208,   209,   210,   185,     0,     0,   186,   187,     0,
       0,     0,   189,     0,     0,     0,   190,   191,     0,     0,
       0,   193,   185,   195,     0,   186,   187,     0,     0,     0,
     189,     0,     0,     0,   190,   191,     0,     0,     0,   193,
       0,   195,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   202,   203,   204,   205,   206,   207,   208,   209,
     210,     0,     0,   214,     0,     0,     0,     0,  -121,     0,
    -293,  -293,  -293,  -293,   206,   207,   208,   209,   210,  -121,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   215,
     216,   217,   218,   219,   220,   221,   222,   223,   224,   225,
     214,     0,     0,     0,     0,  -124,     0,     0,     0,     0,
       0,  -283,  -283,     0,     0,     0,  -124,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   215,   216,   217,   218,
     219,   220,   221,   222,   223,   224,   225,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,  -283,  -283
};

static const yytype_int16 yycheck[] =
{
      22,    23,   210,     2,    52,    49,    50,    31,    52,    31,
      31,    22,    23,   184,     5,   262,   395,   312,    31,    26,
     226,     4,     4,     4,    17,   483,     5,    27,     4,    27,
      31,     4,    17,     5,    24,     4,   162,    20,    20,    20,
      16,    52,     4,    83,    43,    81,    90,    20,     0,    16,
      17,     8,   107,    24,   260,    20,   227,    16,    20,    16,
     115,   116,   117,   118,   119,   120,    31,    26,    81,    26,
      27,     7,    29,    17,    17,   399,    16,    17,    17,   537,
      16,   539,    17,    20,   408,   409,    17,   258,   259,    24,
      83,   262,    16,    83,    31,   143,    81,   133,    83,   100,
     144,   149,    26,   103,   104,   103,   104,    63,    64,   153,
      89,   155,    83,    17,    81,   159,    83,   161,    17,   163,
     133,    17,   166,   130,    81,   169,    83,    84,   172,    86,
      87,    88,   143,    72,     9,    10,    16,   138,   149,    83,
      83,    81,    81,    83,    83,   167,    81,   132,    83,     5,
      81,   530,    83,   175,   176,   177,   167,   179,   149,     5,
     143,   143,   143,   184,   175,   176,   177,   143,   179,   464,
     143,   495,   496,   130,   143,    76,    77,    81,   226,    83,
       5,   143,    81,   184,    83,    81,   210,    83,   210,   210,
     147,   148,    10,    20,    20,     5,    14,     4,    11,    74,
       7,    22,    23,    16,    31,    31,   227,    25,   503,   210,
     505,   535,   260,    26,    27,   226,    29,    20,    20,     5,
     102,   103,   104,    20,   246,     5,   227,     5,    31,    31,
      16,   437,   438,   441,    31,   246,     5,   258,   259,   445,
      26,   262,    24,     6,    62,   267,     9,    10,     5,   260,
      81,    14,    83,    84,    16,    18,   267,   258,   259,    16,
     126,   262,    25,   307,   102,   103,   104,    27,    81,    26,
      83,    84,   126,    86,    87,    88,   523,    76,    77,     5,
     604,     5,   606,     5,   608,     5,     5,     5,    81,    81,
     312,   149,     5,   130,    62,   317,    12,   319,     5,    62,
      16,   312,   149,     5,   149,   149,   130,    92,    81,    81,
      26,    27,    89,    29,    15,   610,    31,   130,     5,   128,
     644,    31,   128,   324,    20,     5,   650,   651,     4,   351,
     577,    20,    15,   100,   147,   148,   462,     5,    31,    83,
     351,    31,   468,   391,     5,    31,   670,    20,   108,   673,
      81,    16,   523,   479,   678,   115,   116,   117,   118,   119,
     120,   121,   686,   129,     5,    81,   690,    83,    84,     5,
      86,    87,    88,   417,    31,   397,   398,    27,     5,    26,
     391,    29,    81,    27,    81,    31,   397,   398,   387,   437,
     438,    31,     5,   149,   416,   394,   418,   445,    15,   111,
     422,   423,   401,    15,    20,   416,   577,   418,    16,    29,
     432,   422,   423,   130,   130,   459,     4,   441,    15,   441,
     441,     4,   131,     4,    31,    20,   437,   438,     5,    81,
      31,   147,   148,    31,   445,    31,   130,    29,    31,    15,
     441,    31,   464,     6,    16,    83,     9,    10,    81,   131,
      20,    14,   474,   464,    83,    18,    19,    31,   108,    27,
      23,     5,    25,   474,   107,   115,   116,   117,   118,   119,
     120,   121,    31,    15,    83,   601,    15,    15,    81,     5,
       7,   503,    15,   505,   528,    31,   131,   509,    16,    78,
      81,    15,   503,    15,   505,    58,    59,    60,    61,    62,
      15,    83,   523,   629,    83,     5,     7,   111,    31,   531,
       5,    31,    83,   639,    16,   708,   416,     2,     2,   616,
     531,   432,   523,   545,   475,   531,   592,   298,   572,   636,
     691,   296,   658,   542,   508,   661,   570,   514,   620,   549,
     666,   167,   448,   422,   588,   423,     9,    -1,    -1,    -1,
     594,    -1,   596,    -1,    -1,    18,   577,     4,    -1,     6,
      -1,     8,   688,    -1,    -1,    -1,    13,    14,    15,    16,
      17,   615,    19,    20,    21,   701,   577,    24,    25,    26,
      27,    28,    29,    30,   710,    32,   585,    -1,   610,    -1,
     634,    -1,   591,   592,   720,    42,    -1,    -1,    -1,   610,
      -1,    -1,    49,    50,    -1,    52,    -1,    54,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   659,    79,    80,    81,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    89,    -1,   399,   628,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   408,   409,    -1,
     684,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   695,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     704,    -1,    -1,   110,    -1,    -1,    -1,    -1,     4,   116,
     133,   134,   135,   136,   137,   138,    -1,    -1,    -1,    15,
      -1,    -1,    -1,   682,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   713,    -1,   140,    -1,   142,   143,    -1,    -1,    -1,
     147,   148,   149,    -1,   151,    41,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   495,   496,    -1,    63,    64,    -1,
      -1,    -1,    -1,   180,    -1,    -1,    -1,    -1,   185,   186,
     187,   188,   189,   190,   191,   192,   193,   194,   195,   196,
     197,   198,   199,   200,   201,   202,   203,   204,   205,   206,
     207,   208,   209,    -1,   535,    -1,    -1,   214,   215,   216,
     217,   218,   219,   220,   221,   222,   223,   224,   225,   226,
      -1,   228,   229,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,     3,     4,     5,    -1,    -1,     8,     9,   245,    11,
      12,    -1,    -1,    -1,    -1,    17,    18,   143,    -1,    -1,
      22,    -1,    -1,   260,    -1,    -1,    28,    -1,    -1,    -1,
      32,    33,    34,    35,    36,   272,    -1,    -1,    40,    -1,
      -1,    -1,    -1,   604,    -1,   606,    -1,   608,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   293,    -1,    -1,    -1,
      -1,    63,    64,    65,    66,    67,    68,    69,    70,    71,
      72,    73,    74,    -1,    -1,    -1,    -1,    79,    80,    81,
      82,    83,    -1,   644,    -1,    -1,    -1,    89,    -1,   650,
     651,    -1,    -1,    -1,    -1,    16,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    26,    27,    -1,    29,   670,
      -1,    -1,   673,    -1,    -1,    -1,    -1,   678,    -1,    -1,
      -1,   123,   124,    -1,    -1,   686,    -1,    -1,   365,   690,
     132,   133,   134,   135,   136,   137,   138,    -1,    -1,    -1,
      -1,   143,    -1,   145,    15,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   391,    -1,   393,    -1,   395,   396,
      81,    -1,    83,    84,    -1,    86,    87,    88,    -1,    -1,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      51,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   426,
      -1,   428,    63,    64,    -1,    -1,    -1,    -1,    -1,    -1,
     437,   438,    -1,   440,    -1,    15,    -1,    -1,   445,   130,
     447,   448,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   456,
      -1,    -1,    -1,    -1,    -1,   146,   147,   148,    -1,   100,
      -1,    41,    42,    43,    44,    45,    46,    47,    48,    49,
      50,    51,    -1,     3,     4,     5,    -1,    -1,     8,     9,
      -1,    11,    12,    63,    64,    -1,    16,    17,    18,    -1,
      -1,    -1,    22,    -1,    -1,   502,    -1,    27,    28,    -1,
      -1,    -1,    32,    33,    34,    35,    36,    -1,    -1,    -1,
      40,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   530,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    63,    64,    65,    66,    67,    68,    69,
      70,    71,    72,    73,    74,    75,    -1,    -1,   555,    79,
      80,    81,    82,    83,    -1,    85,    -1,    -1,    -1,    89,
      90,    91,    92,    -1,    94,    -1,    96,    -1,    98,    -1,
      -1,   101,    -1,    -1,    -1,   105,   106,   107,    -1,   109,
     110,    -1,   112,   113,   114,   115,   116,   117,    -1,    -1,
     597,    -1,   122,   123,   124,   125,   126,   127,    -1,    -1,
      -1,    -1,   132,   133,   134,   135,   136,   137,   138,    -1,
      -1,    -1,    -1,   143,    -1,   145,    -1,    -1,   625,    -1,
      -1,    -1,     3,     4,     5,    -1,    -1,     8,     9,    -1,
      11,    12,    -1,    -1,    -1,    16,    17,    18,    -1,    -1,
      -1,    22,    -1,    -1,    -1,    -1,    27,    28,    -1,    -1,
     657,    32,    33,    34,    35,    36,    -1,    -1,    -1,    40,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    63,    64,    65,    66,    67,    68,    69,    70,
      71,    72,    73,    74,    75,    -1,    -1,    -1,    79,    80,
      81,    82,    83,    -1,    85,    -1,    -1,    -1,    89,    90,
      91,    92,    -1,    94,    -1,    96,    -1,    98,    -1,    -1,
     101,    -1,    -1,    -1,   105,   106,   107,    -1,   109,   110,
      -1,   112,   113,   114,   115,   116,   117,    -1,    -1,    -1,
      -1,   122,   123,   124,   125,   126,   127,    -1,    -1,    -1,
      -1,   132,   133,   134,   135,   136,   137,   138,    -1,    -1,
      -1,    -1,   143,    -1,   145,     3,     4,     5,    -1,    -1,
       8,     9,    -1,    11,    12,    -1,    -1,    -1,    16,    17,
      18,    -1,    -1,    -1,    22,    -1,    -1,    -1,    -1,    -1,
      28,    -1,    -1,    -1,    32,    33,    34,    35,    36,    -1,
      -1,    -1,    40,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    63,    64,    65,    66,    67,
      68,    69,    70,    71,    72,    73,    74,    75,    -1,    -1,
      -1,    79,    80,    81,    82,    83,    -1,    85,    -1,    -1,
      -1,    89,    90,    91,    92,    93,    94,    -1,    96,    -1,
      98,    -1,    -1,   101,    -1,    -1,    -1,   105,   106,   107,
      -1,   109,   110,    -1,   112,   113,   114,   115,   116,   117,
      -1,    -1,    -1,    -1,   122,   123,   124,   125,   126,   127,
      -1,    -1,    -1,    -1,   132,   133,   134,   135,   136,   137,
     138,    -1,    -1,    -1,    -1,   143,    -1,   145,     3,     4,
       5,    -1,    -1,     8,     9,    -1,    11,    12,    -1,    -1,
      -1,    16,    17,    18,    -1,    -1,    -1,    22,    -1,    -1,
      -1,    -1,    -1,    28,    -1,    -1,    -1,    32,    33,    34,
      35,    36,    -1,    -1,    -1,    40,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    -1,    -1,    -1,    79,    80,    81,    82,    83,    -1,
      85,    -1,    -1,    -1,    89,    90,    91,    92,    -1,    94,
      -1,    96,    -1,    98,    99,    -1,   101,    -1,    -1,    -1,
     105,   106,   107,    -1,   109,   110,    -1,   112,   113,   114,
     115,   116,   117,    -1,    -1,    -1,    -1,   122,   123,   124,
     125,   126,   127,    -1,    -1,    -1,    -1,   132,   133,   134,
     135,   136,   137,   138,    -1,    -1,    -1,    -1,   143,    -1,
     145,     3,     4,     5,    -1,    -1,     8,     9,    -1,    11,
      12,    -1,    -1,    -1,    16,    17,    18,    -1,    -1,    -1,
      22,    -1,    -1,    -1,    -1,    27,    28,    -1,    -1,    -1,
      32,    33,    34,    35,    36,    -1,    -1,    -1,    40,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    63,    64,    65,    66,    67,    68,    69,    70,    71,
      72,    73,    74,    75,    -1,    -1,    -1,    79,    80,    81,
      82,    83,    -1,    85,    -1,    -1,    -1,    89,    90,    91,
      92,    -1,    94,    -1,    96,    -1,    98,    -1,    -1,   101,
      -1,    -1,    -1,   105,   106,   107,    -1,   109,   110,    -1,
     112,   113,   114,   115,   116,   117,    -1,    -1,    -1,    -1,
     122,   123,   124,   125,   126,   127,    -1,    -1,    -1,    -1,
     132,   133,   134,   135,   136,   137,   138,    -1,    -1,    -1,
      -1,   143,    -1,   145,     3,     4,     5,    -1,    -1,     8,
       9,    -1,    11,    12,    -1,    -1,    -1,    16,    17,    18,
      -1,    -1,    -1,    22,    -1,    -1,    -1,    -1,    -1,    28,
      -1,    -1,    -1,    32,    33,    34,    35,    36,    -1,    -1,
      -1,    40,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    63,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    75,    -1,    -1,    -1,
      79,    80,    81,    82,    83,    -1,    85,    -1,    -1,    -1,
      89,    90,    91,    92,    -1,    94,    -1,    96,    97,    98,
      -1,    -1,   101,    -1,    -1,    -1,   105,   106,   107,    -1,
     109,   110,    -1,   112,   113,   114,   115,   116,   117,    -1,
      -1,    -1,    -1,   122,   123,   124,   125,   126,   127,    -1,
      -1,    -1,    -1,   132,   133,   134,   135,   136,   137,   138,
      -1,    -1,    -1,    -1,   143,    -1,   145,     3,     4,     5,
      -1,    -1,     8,     9,    -1,    11,    12,    -1,    -1,    -1,
      16,    17,    18,    -1,    -1,    -1,    22,    -1,    -1,    -1,
      -1,    -1,    28,    -1,    -1,    -1,    32,    33,    34,    35,
      36,    -1,    -1,    -1,    40,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    63,    64,    65,
      66,    67,    68,    69,    70,    71,    72,    73,    74,    75,
      -1,    -1,    -1,    79,    80,    81,    82,    83,    -1,    85,
      -1,    -1,    -1,    89,    90,    91,    92,    -1,    94,    95,
      96,    -1,    98,    -1,    -1,   101,    -1,    -1,    -1,   105,
     106,   107,    -1,   109,   110,    -1,   112,   113,   114,   115,
     116,   117,    -1,    -1,    -1,    -1,   122,   123,   124,   125,
     126,   127,    -1,    -1,    -1,    -1,   132,   133,   134,   135,
     136,   137,   138,    -1,    -1,    -1,    -1,   143,    -1,   145,
       3,     4,     5,    -1,    -1,     8,     9,    -1,    11,    12,
      -1,    -1,    -1,    16,    17,    18,    -1,    -1,    -1,    22,
      -1,    -1,    -1,    -1,    27,    28,    -1,    -1,    -1,    32,
      33,    34,    35,    36,    -1,    -1,    -1,    40,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      63,    64,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    74,    75,    -1,    -1,    -1,    79,    80,    81,    82,
      83,    -1,    85,    -1,    -1,    -1,    89,    90,    91,    92,
      -1,    94,    -1,    96,    -1,    98,    -1,    -1,   101,    -1,
      -1,    -1,   105,   106,   107,    -1,   109,   110,    -1,   112,
     113,   114,   115,   116,   117,    -1,    -1,    -1,    -1,   122,
     123,   124,   125,   126,   127,    -1,    -1,    -1,    -1,   132,
     133,   134,   135,   136,   137,   138,    -1,    -1,    -1,    -1,
     143,    -1,   145,     3,     4,     5,    -1,    -1,     8,     9,
      -1,    11,    12,    -1,    -1,    -1,    16,    17,    18,    -1,
      -1,    -1,    22,    -1,    -1,    -1,    -1,    27,    28,    -1,
      -1,    -1,    32,    33,    34,    35,    36,    -1,    -1,    -1,
      40,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    63,    64,    65,    66,    67,    68,    69,
      70,    71,    72,    73,    74,    75,    -1,    -1,    -1,    79,
      80,    81,    82,    83,    -1,    85,    -1,    -1,    -1,    89,
      90,    91,    92,    -1,    94,    -1,    96,    -1,    98,    -1,
      -1,   101,    -1,    -1,    -1,   105,   106,   107,    -1,   109,
     110,    -1,   112,   113,   114,   115,   116,   117,    -1,    -1,
      -1,    -1,   122,   123,   124,   125,   126,   127,    -1,    -1,
      -1,    -1,   132,   133,   134,   135,   136,   137,   138,    -1,
      -1,    -1,    -1,   143,    -1,   145,     3,     4,     5,    -1,
      -1,     8,     9,    -1,    11,    12,    -1,    -1,    -1,    16,
      17,    18,    -1,    -1,    -1,    22,    -1,    -1,    -1,    -1,
      27,    28,    -1,    -1,    -1,    32,    33,    34,    35,    36,
      -1,    -1,    -1,    40,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    63,    64,    65,    66,
      67,    68,    69,    70,    71,    72,    73,    74,    75,    -1,
      -1,    -1,    79,    80,    81,    82,    83,    -1,    85,    -1,
      -1,    -1,    89,    90,    91,    92,    -1,    94,    -1,    96,
      -1,    98,    -1,    -1,   101,    -1,    -1,    -1,   105,   106,
     107,    -1,   109,   110,    -1,   112,   113,   114,   115,   116,
     117,    -1,    -1,    -1,    -1,   122,   123,   124,   125,   126,
     127,    -1,    -1,    -1,    -1,   132,   133,   134,   135,   136,
     137,   138,    -1,    -1,    -1,    -1,   143,    -1,   145,     3,
       4,     5,    -1,    -1,     8,     9,    -1,    11,    12,    -1,
      -1,    -1,    16,    17,    18,    -1,    -1,    -1,    22,    -1,
      -1,    -1,    -1,    -1,    28,    -1,    -1,    -1,    32,    33,
      34,    35,    36,    -1,    -1,    -1,    40,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    63,
      64,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    75,    -1,    -1,    -1,    79,    80,    81,    82,    83,
      -1,    85,    -1,    -1,    -1,    89,    90,    91,    92,    -1,
      94,    -1,    96,    -1,    98,    -1,    -1,   101,    -1,    -1,
      -1,   105,   106,   107,    -1,   109,   110,    -1,   112,   113,
     114,   115,   116,   117,    -1,    -1,    -1,    -1,   122,   123,
     124,   125,   126,   127,    -1,    -1,    -1,    -1,   132,   133,
     134,   135,   136,   137,   138,    -1,    -1,    -1,    -1,   143,
      -1,   145,     3,     4,     5,    -1,    -1,     8,     9,    -1,
      11,    12,    -1,    -1,    -1,    16,    17,    18,    -1,    -1,
      -1,    22,    -1,    -1,    -1,    -1,    -1,    28,    -1,    -1,
      -1,    32,    33,    34,    35,    36,    -1,    -1,    -1,    40,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    63,    64,    65,    66,    67,    68,    69,    70,
      71,    72,    73,    74,    75,    -1,    -1,    -1,    79,    80,
      81,    82,    83,    -1,    85,    -1,    -1,    -1,    89,    90,
      91,    92,    -1,    94,    -1,    96,    -1,    98,    -1,    -1,
     101,    -1,    -1,    -1,   105,   106,   107,    -1,   109,   110,
      -1,   112,   113,   114,   115,   116,   117,    -1,    -1,    -1,
      -1,   122,   123,   124,   125,   126,   127,    -1,    -1,    -1,
      -1,   132,   133,   134,   135,   136,   137,   138,    -1,    -1,
      -1,    -1,   143,    -1,   145,     3,     4,     5,    -1,     7,
       8,     9,    -1,    11,    12,    -1,    -1,    -1,    16,    17,
      18,    -1,    -1,    -1,    22,    -1,    -1,    -1,    -1,    -1,
      28,    -1,    -1,    -1,    32,    33,    34,    35,    36,    -1,
      -1,    -1,    40,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    63,    64,    65,    66,    67,
      68,    69,    70,    71,    72,    73,    74,    75,    -1,    -1,
      -1,    79,    80,    81,    82,    83,    -1,    85,    -1,    -1,
      -1,    89,    90,    91,    92,    -1,    94,    -1,    96,    -1,
      98,    -1,    -1,   101,    -1,    -1,    -1,   105,   106,    -1,
      -1,   109,   110,    -1,   112,   113,   114,   115,    -1,    -1,
      -1,    -1,    -1,    -1,   122,   123,   124,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   132,   133,   134,   135,   136,   137,
     138,    -1,    -1,    -1,    -1,   143,    -1,   145,     3,     4,
       5,    -1,     7,     8,     9,    -1,    11,    12,    -1,    -1,
      -1,    16,    17,    18,    -1,    -1,    -1,    22,    -1,    -1,
      -1,    -1,    -1,    28,    -1,    -1,    -1,    32,    33,    34,
      35,    36,    -1,    -1,    -1,    40,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    -1,    -1,    -1,    79,    80,    81,    82,    83,    -1,
      85,    -1,    -1,    -1,    89,    90,    91,    92,    -1,    94,
      -1,    96,    -1,    98,    -1,    -1,   101,    -1,    -1,    -1,
     105,   106,    -1,    -1,   109,   110,    -1,   112,   113,   114,
     115,    -1,    -1,    -1,    -1,    -1,    -1,   122,   123,   124,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   132,   133,   134,
     135,   136,   137,   138,    -1,    -1,    -1,    -1,   143,    -1,
     145,     3,     4,     5,    -1,     7,     8,     9,    -1,    11,
      12,    -1,    -1,    -1,    16,    17,    18,    -1,    -1,    -1,
      22,    -1,    -1,    -1,    -1,    -1,    28,    -1,    -1,    -1,
      32,    33,    34,    35,    36,    -1,    -1,    -1,    40,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    63,    64,    65,    66,    67,    68,    69,    70,    71,
      72,    73,    74,    75,    -1,    -1,    -1,    79,    80,    81,
      82,    83,    -1,    85,    -1,    -1,    -1,    89,    90,    91,
      92,    -1,    94,    -1,    96,    -1,    98,    -1,    -1,   101,
      -1,    -1,    -1,   105,   106,    -1,    -1,   109,   110,    -1,
     112,   113,   114,   115,    -1,    -1,    -1,    -1,    -1,    -1,
     122,   123,   124,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     132,   133,   134,   135,   136,   137,   138,    -1,    -1,    -1,
      -1,   143,    -1,   145,     3,     4,     5,    -1,     7,     8,
       9,    -1,    11,    12,    -1,    -1,    -1,    16,    17,    18,
      -1,    -1,    -1,    22,    -1,    -1,    -1,    -1,    -1,    28,
      -1,    -1,    -1,    32,    33,    34,    35,    36,    -1,    -1,
      -1,    40,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    63,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    75,    -1,    -1,    -1,
      79,    80,    81,    82,    83,    -1,    85,    -1,    -1,    -1,
      89,    90,    91,    92,    -1,    94,    -1,    96,    -1,    98,
      -1,    -1,   101,    -1,    -1,    -1,   105,   106,    -1,    -1,
     109,   110,    -1,   112,   113,   114,   115,    -1,    -1,    -1,
      -1,    -1,    -1,   122,   123,   124,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   132,   133,   134,   135,   136,   137,   138,
      -1,    -1,    -1,    -1,   143,    -1,   145,     3,     4,     5,
      -1,     7,     8,     9,    -1,    11,    12,    -1,    -1,    -1,
      16,    17,    18,    -1,    -1,    -1,    22,    -1,    -1,    -1,
      -1,    -1,    28,    -1,    -1,    -1,    32,    33,    34,    35,
      36,    -1,    -1,    -1,    40,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    63,    64,    65,
      66,    67,    68,    69,    70,    71,    72,    73,    74,    75,
      -1,    -1,    -1,    79,    80,    81,    82,    83,    -1,    85,
      -1,    -1,    -1,    89,    90,    91,    92,    -1,    94,    -1,
      96,    -1,    98,    -1,    -1,   101,    -1,    -1,    -1,   105,
     106,    -1,    -1,   109,   110,    -1,   112,   113,   114,   115,
      -1,    -1,    -1,    -1,    -1,    -1,   122,   123,   124,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   132,   133,   134,   135,
     136,   137,   138,    -1,    -1,    -1,    -1,   143,    -1,   145,
       3,     4,     5,    -1,    -1,     8,     9,    -1,    11,    12,
      -1,    -1,    -1,    16,    17,    18,    -1,    -1,    -1,    22,
      -1,    -1,    -1,    -1,    -1,    28,    -1,    -1,    -1,    32,
      33,    34,    35,    36,    -1,    -1,    -1,    40,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      63,    64,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    74,    75,    -1,    -1,    -1,    79,    80,    81,    82,
      83,    -1,    85,    -1,    -1,    -1,    89,    90,    91,    92,
      -1,    94,    -1,    96,    -1,    98,    -1,    -1,   101,    -1,
      -1,    -1,   105,   106,    -1,    -1,   109,   110,    -1,   112,
     113,   114,   115,    -1,    -1,    -1,    -1,    -1,    -1,   122,
     123,   124,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   132,
     133,   134,   135,   136,   137,   138,    -1,    -1,    -1,     3,
     143,     5,   145,    -1,     8,     9,    -1,    11,    12,    -1,
      -1,    -1,    -1,    17,    18,    -1,    -1,    -1,    22,    -1,
      -1,    -1,    -1,    -1,    28,    -1,    -1,    31,    32,    33,
      34,    35,    36,    -1,    -1,    -1,    40,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    63,
      64,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    -1,    -1,    -1,    -1,    79,    80,    81,    82,    83,
      -1,    -1,    -1,    -1,     3,    89,     5,    -1,    -1,     8,
       9,    -1,    11,    12,    -1,    -1,    -1,    -1,    17,    18,
      -1,    -1,    -1,    22,    -1,    24,    -1,    -1,    -1,    28,
      -1,    -1,    -1,    32,    33,    34,    35,    36,    -1,   123,
     124,    40,    -1,    -1,    -1,    -1,    -1,    -1,   132,   133,
     134,   135,   136,   137,   138,    -1,    -1,    -1,    -1,    -1,
      -1,   145,    -1,    -1,    63,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    -1,    -1,    -1,    -1,
      79,    80,    81,    82,    83,    -1,    -1,    -1,    -1,     3,
      89,     5,    -1,    -1,     8,     9,    -1,    11,    12,    -1,
      -1,    -1,    -1,    17,    18,    -1,    -1,    -1,    22,    -1,
      24,    -1,    -1,    -1,    28,    -1,    -1,    -1,    32,    33,
      34,    35,    36,    -1,   123,   124,    40,    -1,    -1,    -1,
      -1,    -1,    -1,   132,   133,   134,   135,   136,   137,   138,
      -1,    -1,    -1,    -1,    -1,    -1,   145,    -1,    -1,    63,
      64,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    -1,    -1,    -1,    -1,    79,    80,    81,    82,    83,
      -1,    -1,    -1,    -1,     3,    89,     5,    -1,    -1,     8,
       9,    -1,    11,    12,    -1,    -1,    -1,    -1,    17,    18,
      -1,    -1,    -1,    22,    -1,    24,    -1,    -1,    -1,    28,
      -1,    -1,    -1,    32,    33,    34,    35,    36,    -1,   123,
     124,    40,    -1,    -1,    -1,    -1,    -1,    -1,   132,   133,
     134,   135,   136,   137,   138,    -1,    -1,    -1,    -1,    -1,
      -1,   145,    -1,    -1,    63,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    -1,    -1,    -1,    -1,
      79,    80,    81,    82,    83,    -1,    -1,    -1,    -1,     3,
      89,     5,    -1,    -1,     8,     9,    -1,    11,    12,    -1,
      -1,    -1,    -1,    17,    18,    -1,    -1,    -1,    22,    -1,
      24,    -1,    -1,    -1,    28,    -1,    -1,    -1,    32,    33,
      34,    35,    36,    -1,   123,   124,    40,    -1,    -1,    -1,
      -1,    -1,    -1,   132,   133,   134,   135,   136,   137,   138,
      -1,    -1,    -1,    -1,    -1,    -1,   145,    -1,    -1,    63,
      64,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    -1,    -1,    -1,    -1,    79,    80,    81,    82,    83,
      -1,    -1,    -1,    -1,     3,    89,     5,    -1,    -1,     8,
       9,    -1,    11,    12,    -1,    -1,    -1,    -1,    17,    18,
      -1,    -1,    -1,    22,    -1,    24,    -1,    -1,    -1,    28,
      -1,    -1,    -1,    32,    33,    34,    35,    36,    -1,   123,
     124,    40,    -1,    -1,    -1,    -1,    -1,    -1,   132,   133,
     134,   135,   136,   137,   138,    -1,    -1,    -1,    -1,    -1,
      -1,   145,    -1,    -1,    63,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    -1,    -1,    -1,    -1,
      79,    80,    81,    82,    83,    -1,    -1,    -1,    -1,     3,
      89,     5,    -1,    -1,     8,     9,    -1,    11,    12,    -1,
      -1,    -1,    -1,    17,    18,    -1,    -1,    -1,    22,    -1,
      24,    -1,    -1,    -1,    28,    -1,    -1,    -1,    32,    33,
      34,    35,    36,    -1,   123,   124,    40,    -1,    -1,    -1,
      -1,    -1,    -1,   132,   133,   134,   135,   136,   137,   138,
      -1,    -1,    -1,    -1,    -1,    -1,   145,    -1,    -1,    63,
      64,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    -1,    -1,    -1,    -1,    79,    80,    81,    82,    83,
      -1,    -1,    -1,    -1,     3,    89,     5,    -1,    -1,     8,
       9,    -1,    11,    12,    -1,    -1,    -1,    -1,    17,    18,
      -1,    -1,    -1,    22,    -1,    24,    -1,    -1,    -1,    28,
      -1,    -1,    -1,    32,    33,    34,    35,    36,    -1,   123,
     124,    40,    -1,    -1,    -1,    -1,    -1,    -1,   132,   133,
     134,   135,   136,   137,   138,    -1,    -1,    -1,    -1,    -1,
      -1,   145,    -1,    -1,    63,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    -1,    -1,    -1,    -1,
      79,    80,    81,    82,    83,    -1,    -1,    -1,    -1,     3,
      89,     5,    -1,    -1,     8,     9,    -1,    11,    12,    -1,
      -1,    -1,    -1,    17,    18,    -1,    -1,    -1,    22,    -1,
      -1,    -1,    -1,    -1,    28,    -1,    -1,    -1,    32,    33,
      34,    35,    36,    -1,   123,   124,    40,    -1,    -1,    -1,
      -1,    -1,    -1,   132,   133,   134,   135,   136,   137,   138,
      -1,    -1,    -1,    -1,    -1,    -1,   145,    -1,    -1,    63,
      64,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    -1,    -1,    -1,    -1,    79,    80,    81,    82,    83,
      -1,    -1,    -1,    -1,     3,    89,     5,    -1,    -1,     8,
       9,    -1,    11,    12,    -1,    -1,    -1,    -1,    17,    18,
      -1,    -1,    -1,    22,    -1,    -1,    -1,    -1,    -1,    28,
      -1,    -1,    -1,    32,    33,    34,    35,    36,    -1,   123,
     124,    40,    -1,    -1,    -1,    -1,    -1,    -1,   132,   133,
     134,   135,   136,   137,   138,    -1,    -1,    -1,    -1,    -1,
      -1,   145,    -1,    -1,    63,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    -1,    -1,    -1,    -1,
      79,    80,    81,    82,    83,    -1,    -1,    -1,    -1,    -1,
      89,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   123,   124,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   132,   133,   134,   135,   136,   137,   138,
      -1,    -1,     4,    -1,     6,    -1,   145,     9,    10,    -1,
      -1,    13,    14,    -1,    -1,    -1,    18,    19,    -1,    21,
      -1,    23,    24,    25,    -1,    -1,    -1,    -1,    30,    -1,
      -1,    -1,    -1,    -1,    -1,    37,    38,    39,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
      62,     6,    -1,    -1,     9,    10,    -1,    -1,    13,    14,
      -1,    -1,    -1,    18,    19,    -1,    21,    -1,    23,    24,
      25,    -1,    -1,    -1,    -1,    30,    -1,    -1,    -1,    -1,
      -1,    -1,    37,    38,    39,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,     6,    -1,
      -1,     9,    10,    -1,    -1,    13,    14,    -1,    -1,    -1,
      18,    19,    -1,    21,    -1,    23,    24,    25,    -1,    -1,
      -1,   143,    30,    -1,    -1,    -1,    -1,    -1,    -1,    37,
      38,    39,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    52,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    62,     4,    -1,     6,     7,    -1,
       9,    10,    -1,    -1,    13,    14,   131,    -1,    -1,    18,
      19,    -1,    21,    -1,    23,    24,    25,    -1,    -1,    -1,
      -1,    30,    -1,    -1,    -1,    -1,    -1,    -1,    37,    38,
      39,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    52,    53,    54,    55,    56,    57,    58,
      59,    60,    61,    62,     6,    -1,    -1,     9,    10,    -1,
      -1,    13,    14,   131,    -1,    -1,    18,    19,    -1,    21,
      -1,    23,    24,    25,    -1,    -1,    -1,    -1,    30,    31,
      -1,    -1,    -1,    -1,    -1,    37,    38,    39,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
      62,     6,    -1,    -1,     9,    10,    -1,    -1,    13,    14,
      -1,    -1,    -1,    18,    19,    -1,    21,    -1,    23,    24,
      25,    -1,    27,    -1,    -1,    30,    -1,    -1,    -1,    -1,
      -1,    -1,    37,    38,    39,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,     6,    -1,
      -1,     9,    10,    -1,    -1,    13,    14,    -1,    -1,    -1,
      18,    19,    -1,    21,    -1,    23,    24,    25,    -1,    -1,
      -1,    -1,    30,    31,    -1,    -1,    -1,    -1,    -1,    37,
      38,    39,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    52,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    62,     6,    -1,    -1,     9,    10,
      -1,    -1,    13,    14,    -1,    -1,    -1,    18,    19,    -1,
      21,    -1,    23,    24,    25,    -1,    -1,    -1,    -1,    30,
      31,    -1,    -1,    -1,    -1,    -1,    37,    38,    39,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    52,    53,    54,    55,    56,    57,    58,    59,    60,
      61,    62,     6,    -1,    -1,     9,    10,    -1,    -1,    13,
      14,    -1,    -1,    -1,    18,    19,    -1,    21,    -1,    23,
      24,    25,    -1,    -1,    -1,    -1,    30,    31,    -1,    -1,
      -1,    -1,    -1,    37,    38,    39,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    52,    53,
      54,    55,    56,    57,    58,    59,    60,    61,    62,     6,
      -1,    -1,     9,    10,    -1,    -1,    13,    14,    -1,    -1,
      -1,    18,    19,    -1,    21,    -1,    23,    24,    25,    -1,
      -1,    -1,    -1,    30,    31,    -1,    -1,    -1,    -1,    -1,
      37,    38,    39,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    52,    53,    54,    55,    56,
      57,    58,    59,    60,    61,    62,     6,    -1,    -1,     9,
      10,    -1,    -1,    13,    14,    -1,    -1,    -1,    18,    19,
      -1,    21,    -1,    23,    24,    25,    -1,    -1,    -1,    -1,
      30,    31,    -1,    -1,    -1,    -1,    -1,    37,    38,    39,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    52,    53,    54,    55,    56,    57,    58,    59,
      60,    61,    62,     6,     7,    -1,     9,    10,    -1,    -1,
      13,    14,    -1,    -1,    -1,    18,    19,    -1,    21,    -1,
      23,    24,    25,    -1,    -1,    -1,    -1,    30,    -1,    -1,
      -1,    -1,    -1,    -1,    37,    38,    39,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    52,
      53,    54,    55,    56,    57,    58,    59,    60,    61,    62,
       6,    -1,    -1,     9,    10,    -1,    -1,    13,    14,    -1,
      -1,    -1,    18,    19,    -1,    21,    -1,    23,    24,    25,
      -1,    27,    -1,    -1,    30,    -1,    -1,    -1,    -1,    -1,
      -1,    37,    38,    39,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    52,    53,    54,    55,
      56,    57,    58,    59,    60,    61,    62,     6,    -1,    -1,
       9,    10,    -1,    -1,    13,    14,    -1,    -1,    -1,    18,
      19,    -1,    21,    -1,    23,    24,    25,    -1,    27,    -1,
      -1,    30,    -1,    -1,    -1,    -1,    -1,    -1,    37,    38,
      39,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    52,    53,    54,    55,    56,    57,    58,
      59,    60,    61,    62,     6,    -1,    -1,     9,    10,    -1,
      -1,    13,    14,    -1,    -1,    -1,    18,    19,    -1,    21,
      -1,    23,    24,    25,    -1,    27,    -1,    -1,    30,    -1,
      -1,    -1,    -1,    -1,    -1,    37,    38,    39,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
      62,     6,    -1,    -1,     9,    10,    -1,    -1,    13,    14,
      -1,    -1,    -1,    18,    19,    -1,    21,    -1,    23,    24,
      25,    -1,    27,    -1,    -1,    30,    -1,    -1,    -1,    -1,
      -1,    -1,    37,    38,    39,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,     6,    -1,
      -1,     9,    10,    -1,    -1,    13,    14,    -1,    -1,    -1,
      18,    19,    -1,    21,    -1,    23,    24,    25,    -1,    -1,
      -1,    -1,    30,    31,    -1,    -1,    -1,    -1,    -1,    37,
      38,    39,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    52,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    62,     6,    -1,    -1,     9,    10,
      -1,    -1,    13,    14,    -1,    -1,    -1,    18,    19,    -1,
      21,    -1,    23,    24,    25,    -1,    27,    -1,    -1,    30,
      -1,    -1,    -1,    -1,    -1,    -1,    37,    38,    39,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    52,    53,    54,    55,    56,    57,    58,    59,    60,
      61,    62,     6,    -1,    -1,     9,    10,    -1,    -1,    13,
      14,    -1,    -1,    -1,    18,    19,    -1,    21,    -1,    23,
      24,    25,    -1,    -1,    -1,    29,    30,    -1,    -1,    -1,
      -1,    -1,    -1,    37,    38,    39,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    52,    53,
      54,    55,    56,    57,    58,    59,    60,    61,    62,     6,
      -1,    -1,     9,    10,    -1,    -1,    13,    14,    -1,    -1,
      -1,    18,    19,    -1,    21,    -1,    23,    24,    25,    -1,
      -1,    -1,    -1,    30,    31,    -1,    -1,    -1,    -1,    -1,
      37,    38,    39,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    52,    53,    54,    55,    56,
      57,    58,    59,    60,    61,    62,     6,    -1,    -1,     9,
      10,    -1,    -1,    13,    14,    -1,    -1,    -1,    18,    19,
      -1,    21,    -1,    23,    24,    25,    -1,    -1,    -1,    -1,
      30,    31,    -1,    -1,    -1,    -1,    -1,    37,    38,    39,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    52,    53,    54,    55,    56,    57,    58,    59,
      60,    61,    62,     6,    -1,    -1,     9,    10,    -1,    -1,
      13,    14,    -1,    -1,    -1,    18,    19,    -1,    21,    -1,
      23,    24,    25,    -1,    -1,    -1,    -1,    30,    -1,    -1,
      -1,    -1,    -1,    -1,    37,    38,    39,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    52,
      53,    54,    55,    56,    57,    58,    59,    60,    61,    62,
       6,    -1,    -1,     9,    10,    -1,    -1,    13,    14,    -1,
      -1,    -1,    18,    19,    -1,    21,    -1,    23,    24,    25,
      -1,    -1,    -1,    -1,    30,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    38,    39,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    52,    53,    54,    55,
      56,    57,    58,    59,    60,    61,    62,     6,    -1,    -1,
       9,    10,    -1,    -1,    13,    14,    -1,    -1,    -1,    18,
      19,    -1,    21,    -1,    23,    24,    25,    -1,    -1,    -1,
      -1,    30,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      39,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    52,    53,    54,    55,    56,    57,    58,
      59,    60,    61,    62,     6,    -1,    -1,     9,    10,    -1,
      -1,    13,    14,    -1,    -1,    -1,    18,    19,    -1,    21,
      -1,    23,    24,    25,    -1,    -1,    -1,    -1,    30,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
      62,     6,    -1,    -1,     9,    10,    -1,    -1,    13,    14,
      -1,    -1,    -1,    18,    19,    -1,    -1,    -1,    23,    24,
      25,    -1,    -1,    -1,    -1,    30,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,     6,    -1,
      -1,     9,    10,    -1,    -1,    13,    14,    -1,    -1,    -1,
      18,    19,    -1,    -1,    -1,    23,    24,    25,    -1,    -1,
       6,    -1,    30,     9,    10,    -1,    -1,    13,    14,    -1,
      -1,    -1,    18,    19,    -1,    -1,    -1,    23,    24,    25,
      -1,    -1,    -1,    -1,    30,    53,    54,    55,    56,    57,
      58,    59,    60,    61,    62,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    54,    55,
      56,    57,    58,    59,    60,    61,    62,     6,    -1,    -1,
       9,    10,    -1,    -1,    13,    14,    -1,    -1,    -1,    18,
      19,    -1,    -1,    -1,    23,    24,    25,     6,    -1,    -1,
       9,    10,    -1,    -1,    -1,    14,    -1,    -1,    -1,    18,
      19,    -1,    -1,    -1,    23,    24,    25,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    54,    55,    56,    57,    58,
      59,    60,    61,    62,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    54,    55,    56,    57,    58,
      59,    60,    61,    62,     6,    -1,    -1,     9,    10,    -1,
      -1,    -1,    14,    -1,    -1,    -1,    18,    19,    -1,    -1,
      -1,    23,     6,    25,    -1,     9,    10,    -1,    -1,    -1,
      14,    -1,    -1,    -1,    18,    19,    -1,    -1,    -1,    23,
      -1,    25,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    54,    55,    56,    57,    58,    59,    60,    61,
      62,    -1,    -1,    15,    -1,    -1,    -1,    -1,    20,    -1,
      54,    55,    56,    57,    58,    59,    60,    61,    62,    31,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    41,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      15,    -1,    -1,    -1,    -1,    20,    -1,    -1,    -1,    -1,
      -1,    63,    64,    -1,    -1,    -1,    31,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    63,    64
};

  /* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
     symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,   151,   152,     0,     3,     4,     5,     8,     9,    11,
      12,    16,    17,    18,    22,    28,    32,    33,    34,    35,
      36,    40,    63,    64,    65,    66,    67,    68,    69,    70,
      71,    72,    73,    74,    75,    79,    80,    81,    82,    83,
      85,    89,    90,    91,    92,    94,    96,    98,   101,   105,
     106,   107,   109,   110,   112,   113,   114,   115,   116,   117,
     122,   123,   124,   125,   126,   127,   132,   133,   134,   135,
     136,   137,   138,   143,   145,   153,   156,   157,   158,   165,
     166,   168,   169,   170,   172,   210,   211,   212,   219,   222,
     226,   227,   229,   230,   234,   235,   236,   237,   238,   239,
     244,   252,   254,   226,   226,   249,   226,   249,   249,   154,
      16,   226,   226,   226,   226,   226,     5,   226,   226,   226,
      81,   212,   229,   230,   229,   226,   226,   226,   226,   226,
     226,   226,    81,   212,   213,   214,   237,   238,   244,   226,
       5,   217,     5,     5,   207,   226,   157,     5,     5,     5,
       5,     5,   156,   226,   156,   226,    24,   167,   156,   210,
     226,   230,    16,   226,     5,    89,   164,    17,    83,   195,
     196,    83,   197,   126,   126,     5,     5,     5,     5,     5,
       5,   249,    81,    81,   149,     6,     9,    10,    13,    14,
      18,    19,    21,    23,    24,    25,    30,    37,    38,    39,
      52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
      62,   156,    63,    64,    15,    41,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51,     5,   130,    16,    26,
      17,   238,    31,     8,    16,    26,    27,    29,    81,    83,
      84,    86,    87,    88,   130,   147,   148,   250,    11,    12,
      27,   125,   155,   157,   165,   166,   226,   226,   149,   149,
       5,   218,   130,   238,    31,   226,   226,    24,   193,   194,
     210,   230,    20,   156,    92,   226,   208,   209,   226,   210,
     230,    81,   181,   226,   156,   156,    81,   156,   156,   154,
     156,    89,   156,    16,   227,   230,    20,   156,    15,    20,
     156,   162,   163,   230,   230,   253,   230,    31,   132,   230,
     245,   246,    24,   226,   247,   248,   146,   128,   171,   128,
     173,    81,   234,   238,   244,   226,   226,   226,   226,   226,
     226,   226,   226,   226,   226,   226,   226,   226,   226,   226,
     226,   226,   226,   226,   226,   226,   226,   226,   226,   226,
     213,    24,   226,   226,   226,   226,   226,   226,   226,   226,
     226,   226,   226,   226,   193,    16,    81,   234,   241,   242,
     243,   226,   226,   240,    26,   130,    82,   226,   230,     5,
      27,    31,    81,   234,   193,   241,    31,    31,   228,   230,
      31,    20,   226,     5,    31,     4,    20,   100,   100,    15,
      20,    31,    31,     5,    27,    31,   226,   196,     9,    18,
      81,   133,   219,   220,   221,    83,    20,    31,    20,    31,
      31,   156,     5,    20,    31,   228,   131,    31,    20,   224,
      81,   212,   129,   174,   175,   212,    16,     5,     5,   238,
       7,    72,   230,    31,   226,     5,   233,    16,    26,    27,
      29,    81,    83,    84,   251,    81,    26,    27,    27,    31,
      31,   215,     7,   157,    24,   210,   230,   226,     7,   157,
     185,   208,   226,   230,    24,   177,   230,   220,    81,     7,
     157,   180,     7,    16,   182,    81,   133,   190,   191,   192,
     111,    27,   220,   220,   149,     5,    15,   163,   156,   230,
     245,   246,    15,    24,   226,    24,   226,   175,    16,    20,
     198,   193,   193,   226,   213,    27,   193,   231,   226,   240,
      29,   226,   156,   130,   216,   154,   186,   228,    31,   154,
       4,   131,   176,   230,   176,    15,   154,     4,   183,     4,
     183,    31,    20,    24,    83,     5,    81,   220,   223,   225,
     220,    31,   226,   228,   228,   131,   198,   212,    27,   108,
     115,   116,   117,   118,   119,   120,   121,   199,   201,   202,
     203,   204,   206,    31,    31,   218,    31,   130,   232,    27,
      29,    29,   241,   187,    76,    77,   188,   156,    93,   208,
     177,    31,    31,   220,    99,   183,   102,   103,   104,   183,
      27,    16,   192,    83,    15,   212,   131,    31,    20,   224,
      24,   226,    27,    81,    83,   205,   107,   204,    20,   156,
     241,    27,    76,    77,   189,     5,   157,   156,    31,     7,
     157,   179,   179,   156,   102,   156,   226,     4,     7,   184,
      27,   154,    24,    83,    15,   220,    83,   220,   220,   228,
      15,    15,    20,   156,   167,    81,   233,     5,     7,    78,
     226,     7,   157,   178,   154,   156,   184,   154,    27,    83,
      15,   220,    31,   131,   220,   220,    83,    81,    15,   226,
     154,   156,    31,   154,    97,   154,    15,   220,    16,   220,
      15,     5,   220,    31,   157,    95,   156,   220,   154,   220,
     190,     7,   156,    27,    31,   154,   111,   159,   160,   161,
      16,   156,   200,     5,   161,   154,   212,    27,    83,    31,
      16,   154,    27
};

  /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,   150,   151,   152,   152,   153,   153,   153,   153,   154,
     154,   155,   155,   155,   155,   156,   156,   157,   158,   158,
     158,   158,   158,   158,   158,   158,   158,   158,   158,   158,
     158,   158,   158,   158,   158,   158,   158,   158,   158,   158,
     158,   158,   158,   158,   158,   159,   159,   160,   160,   161,
     162,   162,   163,   164,   164,   165,   166,   167,   167,   168,
     169,   169,   170,   170,   170,   171,   171,   172,   173,   173,
     174,   174,   175,   175,   176,   176,   177,   177,   178,   178,
     179,   179,   180,   180,   181,   181,   182,   182,   182,   182,
     183,   183,   183,   184,   184,   185,   185,   186,   186,   187,
     187,   188,   188,   189,   189,   190,   190,   191,   191,   191,
     191,   191,   191,   191,   191,   192,   192,   192,   193,   193,
     194,   194,   194,   194,   194,   194,   195,   195,   196,   196,
     196,   197,   197,   197,   197,   198,   198,   199,   199,   199,
     200,   200,   201,   201,   202,   202,   203,   203,   204,   204,
     204,   204,   204,   204,   205,   205,   205,   205,   206,   206,
     207,   207,   208,   208,   209,   209,   210,   210,   210,   210,
     210,   210,   210,   210,   210,   210,   210,   210,   210,   210,
     210,   210,   210,   210,   210,   210,   210,   210,   210,   210,
     210,   210,   210,   210,   210,   210,   210,   210,   210,   210,
     210,   210,   210,   210,   210,   210,   210,   210,   210,   210,
     210,   210,   210,   210,   210,   210,   210,   210,   210,   210,
     210,   210,   210,   210,   210,   210,   210,   210,   210,   210,
     210,   210,   211,   211,   211,   211,   212,   213,   213,   214,
     214,   215,   215,   216,   217,   217,   217,   218,   218,   219,
     219,   219,   219,   219,   219,   219,   219,   220,   220,   220,
     220,   220,   220,   221,   222,   222,   222,   222,   222,   222,
     222,   223,   223,   224,   224,   225,   225,   225,   225,   226,
     226,   227,   228,   229,   230,   230,   231,   231,   232,   233,
     233,   234,   234,   235,   236,   236,   237,   237,   237,   238,
     238,   238,   239,   239,   240,   240,   241,   241,   242,   242,
     242,   243,   243,   244,   244,   245,   245,   246,   246,   246,
     247,   247,   248,   248,   248,   248,   248,   248,   248,   248,
     249,   249,   249,   249,   249,   249,   249,   249,   249,   249,
     249,   249,   250,   250,   250,   250,   250,   250,   251,   251,
     251,   252,   252,   252,   252,   252,   252,   252,   253,   253,
     254
};

  /* YYR2[YYN] -- Number of symbols on the right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,     2,     0,     1,     1,     1,     4,     2,
       0,     1,     1,     1,     4,     1,     1,     1,     3,     7,
      10,     5,     7,     9,     5,     2,     3,     2,     3,     2,
       3,     3,     3,     3,     3,     1,     2,     3,     5,     8,
       8,     5,     1,    13,     3,     1,     0,     1,     2,     8,
       1,     3,     1,     1,     3,     1,     1,     0,     1,     9,
       7,     6,     1,     2,     2,     0,     2,     1,     0,     2,
       0,     2,     1,     3,     0,     2,     1,     2,     1,     4,
       1,     4,     1,     4,     3,     5,     3,     4,     4,     5,
       0,     5,     4,     1,     1,     1,     4,     0,     6,     0,
       7,     0,     2,     0,     3,     1,     0,     2,     3,     5,
       4,     4,     5,     7,     6,     0,     1,     1,     1,     0,
       1,     1,     2,     3,     3,     4,     3,     1,     1,     2,
       4,     3,     5,     1,     3,     2,     0,     3,     2,     8,
       1,     3,     1,     1,     0,     1,     1,     2,     1,     1,
       1,     1,     1,     1,     3,     5,     1,     3,     5,     4,
       3,     1,     0,     1,     3,     1,     6,     3,     4,     6,
       3,     2,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     2,     2,     2,     2,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     2,     2,     2,     2,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     5,     1,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     1,     4,
       3,     2,     4,     6,     6,     4,     1,     1,     1,     4,
       1,     2,     0,     2,     0,     2,     3,     0,     3,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     2,
       2,     4,     1,     3,     1,     1,     1,     1,     3,     3,
       3,     0,     2,     0,     1,     5,     3,     3,     1,     1,
       1,     1,     1,     1,     5,     1,     2,     0,     3,     3,
       0,     1,     2,     3,     1,     1,     1,     2,     1,     4,
       4,     1,     1,     4,     0,     1,     1,     1,     4,     4,
       1,     1,     3,     1,     2,     3,     1,     1,     4,     0,
       0,     2,     5,     3,     3,     1,     6,     4,     4,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     0,     1,     4,     3,     3,     6,     3,     1,     1,
       1,     4,     4,     2,     2,     4,     2,     2,     1,     3,
       3
};


#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)
#define YYEMPTY         (-2)
#define YYEOF           0

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                  \
do                                                              \
  if (yychar == YYEMPTY)                                        \
    {                                                           \
      yychar = (Token);                                         \
      yylval = (Value);                                         \
      YYPOPSTACK (yylen);                                       \
      yystate = *yyssp;                                         \
      goto yybackup;                                            \
    }                                                           \
  else                                                          \
    {                                                           \
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;                                                  \
    }                                                           \
while (0)

/* Error token number */
#define YYTERROR        1
#define YYERRCODE       256



/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)

/* This macro is provided for backward compatibility. */
#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


# define YY_SYMBOL_PRINT(Title, Type, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Type, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*----------------------------------------.
| Print this symbol's value on YYOUTPUT.  |
`----------------------------------------*/

static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  FILE *yyo = yyoutput;
  YYUSE (yyo);
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
  YYUSE (yytype);
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyoutput, "%s %s (",
             yytype < YYNTOKENS ? "token" : "nterm", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yytype_int16 *yyssp, YYSTYPE *yyvsp, int yyrule)
{
  unsigned long int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       yystos[yyssp[yyi + 1 - yynrhs]],
                       &(yyvsp[(yyi + 1) - (yynrhs)])
                                              );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
yystrlen (const char *yystr)
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            /* Fall through.  */
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return 1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return 2 if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYSIZE_T *yymsg_alloc, char **yymsg,
                yytype_int16 *yyssp, int yytoken)
{
  YYSIZE_T yysize0 = yytnamerr (YY_NULLPTR, yytname[yytoken]);
  YYSIZE_T yysize = yysize0;
  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat. */
  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
  /* Number of reported tokens (one for the "unexpected", one per
     "expected"). */
  int yycount = 0;

  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yytoken != YYEMPTY)
    {
      int yyn = yypact[*yyssp];
      yyarg[yycount++] = yytname[yytoken];
      if (!yypact_value_is_default (yyn))
        {
          /* Start YYX at -YYN if negative to avoid negative indexes in
             YYCHECK.  In other words, skip the first -YYN actions for
             this state because they are default actions.  */
          int yyxbegin = yyn < 0 ? -yyn : 0;
          /* Stay within bounds of both yycheck and yytname.  */
          int yychecklim = YYLAST - yyn + 1;
          int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
          int yyx;

          for (yyx = yyxbegin; yyx < yyxend; ++yyx)
            if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR
                && !yytable_value_is_error (yytable[yyx + yyn]))
              {
                if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                  {
                    yycount = 1;
                    yysize = yysize0;
                    break;
                  }
                yyarg[yycount++] = yytname[yyx];
                {
                  YYSIZE_T yysize1 = yysize + yytnamerr (YY_NULLPTR, yytname[yyx]);
                  if (! (yysize <= yysize1
                         && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
                    return 2;
                  yysize = yysize1;
                }
              }
        }
    }

  switch (yycount)
    {
# define YYCASE_(N, S)                      \
      case N:                               \
        yyformat = S;                       \
      break
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
# undef YYCASE_
    }

  {
    YYSIZE_T yysize1 = yysize + yystrlen (yyformat);
    if (! (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
      return 2;
    yysize = yysize1;
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return 1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yyarg[yyi++]);
          yyformat += 2;
        }
      else
        {
          yyp++;
          yyformat++;
        }
  }
  return 0;
}
#endif /* YYERROR_VERBOSE */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
{
  YYUSE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yytype);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
/* The lookahead symbol.  */
int yychar;


/* The semantic value of the lookahead symbol.  */
/* Default value used for initialization, for pacifying older GCCs
   or non-GCC compilers.  */
YY_INITIAL_VALUE (static YYSTYPE yyval_default;)
YYSTYPE yylval YY_INITIAL_VALUE (= yyval_default);

    /* Number of syntax errors so far.  */
    int yynerrs;

    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       'yyss': related to states.
       'yyvs': related to semantic values.

       Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yyssp = yyss = yyssa;
  yyvsp = yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */
  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        YYSTYPE *yyvs1 = yyvs;
        yytype_int16 *yyss1 = yyss;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * sizeof (*yyssp),
                    &yyvs1, yysize * sizeof (*yyvsp),
                    &yystacksize);

        yyss = yyss1;
        yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yytype_int16 *yyss1 = yyss;
        union yyalloc *yyptr =
          (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
        if (! yyptr)
          goto yyexhaustedlab;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
                  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = yylex (&yylval);
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 371 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 55 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);
root= (yyval.t);

    }
#line 3029 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 3:
#line 383 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 65 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3048 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 4:
#line 400 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 65 );

    }
#line 3057 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 5:
#line 407 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 42 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3070 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 6:
#line 418 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 42 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3083 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 7:
#line 429 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 42 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3096 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 8:
#line 440 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 42 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3127 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 9:
#line 469 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 27 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3146 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 10:
#line 486 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 27 );

    }
#line 3155 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 11:
#line 493 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 17 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3168 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 12:
#line 504 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 17 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3181 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 13:
#line 515 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 17 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3194 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 14:
#line 526 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 17 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3225 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 15:
#line 555 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 59 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3238 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 16:
#line 566 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 59 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3251 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 17:
#line 577 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 57 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3264 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 18:
#line 588 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3289 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 19:
#line 611 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-6].t));

        (yyvsp[-6].t)->parent= (yyval.t);

        (yyvsp[-6].t)->nextSibbling= (yyvsp[-5].t);

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3338 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 20:
#line 658 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-9].t));

        (yyvsp[-9].t)->parent= (yyval.t);

        (yyvsp[-9].t)->nextSibbling= (yyvsp[-8].t);

        (yyval.t)->addChild((yyvsp[-8].t));

        (yyvsp[-8].t)->parent= (yyval.t);

        (yyvsp[-8].t)->nextSibbling= (yyvsp[-7].t);

        (yyval.t)->addChild((yyvsp[-7].t));

        (yyvsp[-7].t)->parent= (yyval.t);

        (yyvsp[-7].t)->nextSibbling= (yyvsp[-6].t);

        (yyval.t)->addChild((yyvsp[-6].t));

        (yyvsp[-6].t)->parent= (yyval.t);

        (yyvsp[-6].t)->nextSibbling= (yyvsp[-5].t);

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3405 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 21:
#line 723 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3442 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 22:
#line 758 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-6].t));

        (yyvsp[-6].t)->parent= (yyval.t);

        (yyvsp[-6].t)->nextSibbling= (yyvsp[-5].t);

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3491 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 23:
#line 805 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-8].t));

        (yyvsp[-8].t)->parent= (yyval.t);

        (yyvsp[-8].t)->nextSibbling= (yyvsp[-7].t);

        (yyval.t)->addChild((yyvsp[-7].t));

        (yyvsp[-7].t)->parent= (yyval.t);

        (yyvsp[-7].t)->nextSibbling= (yyvsp[-6].t);

        (yyval.t)->addChild((yyvsp[-6].t));

        (yyvsp[-6].t)->parent= (yyval.t);

        (yyvsp[-6].t)->nextSibbling= (yyvsp[-5].t);

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3552 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 24:
#line 864 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3589 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 25:
#line 899 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3608 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 26:
#line 916 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3633 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 27:
#line 939 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3652 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 28:
#line 956 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3677 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 29:
#line 979 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3696 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 30:
#line 996 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3721 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 31:
#line 1019 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3746 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 32:
#line 1042 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3771 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 33:
#line 1065 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3796 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 34:
#line 1088 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3821 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 35:
#line 1111 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3834 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 36:
#line 1122 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3853 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 37:
#line 1139 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3878 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 38:
#line 1162 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3915 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 39:
#line 1197 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-7].t));

        (yyvsp[-7].t)->parent= (yyval.t);

        (yyvsp[-7].t)->nextSibbling= (yyvsp[-6].t);

        (yyval.t)->addChild((yyvsp[-6].t));

        (yyvsp[-6].t)->parent= (yyval.t);

        (yyvsp[-6].t)->nextSibbling= (yyvsp[-5].t);

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 3970 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 40:
#line 1250 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-7].t));

        (yyvsp[-7].t)->parent= (yyval.t);

        (yyvsp[-7].t)->nextSibbling= (yyvsp[-6].t);

        (yyval.t)->addChild((yyvsp[-6].t));

        (yyvsp[-6].t)->parent= (yyval.t);

        (yyvsp[-6].t)->nextSibbling= (yyvsp[-5].t);

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4025 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 41:
#line 1303 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4062 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 42:
#line 1338 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4075 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 43:
#line 1349 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-12].t));

        (yyvsp[-12].t)->parent= (yyval.t);

        (yyvsp[-12].t)->nextSibbling= (yyvsp[-11].t);

        (yyval.t)->addChild((yyvsp[-11].t));

        (yyvsp[-11].t)->parent= (yyval.t);

        (yyvsp[-11].t)->nextSibbling= (yyvsp[-10].t);

        (yyval.t)->addChild((yyvsp[-10].t));

        (yyvsp[-10].t)->parent= (yyval.t);

        (yyvsp[-10].t)->nextSibbling= (yyvsp[-9].t);

        (yyval.t)->addChild((yyvsp[-9].t));

        (yyvsp[-9].t)->parent= (yyval.t);

        (yyvsp[-9].t)->nextSibbling= (yyvsp[-8].t);

        (yyval.t)->addChild((yyvsp[-8].t));

        (yyvsp[-8].t)->parent= (yyval.t);

        (yyvsp[-8].t)->nextSibbling= (yyvsp[-7].t);

        (yyval.t)->addChild((yyvsp[-7].t));

        (yyvsp[-7].t)->parent= (yyval.t);

        (yyvsp[-7].t)->nextSibbling= (yyvsp[-6].t);

        (yyval.t)->addChild((yyvsp[-6].t));

        (yyvsp[-6].t)->parent= (yyval.t);

        (yyvsp[-6].t)->nextSibbling= (yyvsp[-5].t);

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4160 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 44:
#line 1432 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 28 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4185 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 45:
#line 1455 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 92 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4198 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 46:
#line 1466 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 92 );

    }
#line 4207 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 47:
#line 1473 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 87 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4220 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 48:
#line 1484 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 87 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4239 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 49:
#line 1501 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 8 );

        (yyval.t)->addChild((yyvsp[-7].t));

        (yyvsp[-7].t)->parent= (yyval.t);

        (yyvsp[-7].t)->nextSibbling= (yyvsp[-6].t);

        (yyval.t)->addChild((yyvsp[-6].t));

        (yyvsp[-6].t)->parent= (yyval.t);

        (yyvsp[-6].t)->nextSibbling= (yyvsp[-5].t);

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4294 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 50:
#line 1554 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 4 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4307 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 51:
#line 1565 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 4 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4332 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 52:
#line 1588 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 62 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4345 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 53:
#line 1599 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 49 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4358 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 54:
#line 1610 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 49 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4383 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 55:
#line 1633 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 56 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4396 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 56:
#line 1644 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 33 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4409 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 57:
#line 1655 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 64 );

    }
#line 4418 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 58:
#line 1662 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 64 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4431 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 59:
#line 1673 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 77 );

        (yyval.t)->addChild((yyvsp[-8].t));

        (yyvsp[-8].t)->parent= (yyval.t);

        (yyvsp[-8].t)->nextSibbling= (yyvsp[-7].t);

        (yyval.t)->addChild((yyvsp[-7].t));

        (yyvsp[-7].t)->parent= (yyval.t);

        (yyvsp[-7].t)->nextSibbling= (yyvsp[-6].t);

        (yyval.t)->addChild((yyvsp[-6].t));

        (yyvsp[-6].t)->parent= (yyval.t);

        (yyvsp[-6].t)->nextSibbling= (yyvsp[-5].t);

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4492 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 60:
#line 1732 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 35 );

        (yyval.t)->addChild((yyvsp[-6].t));

        (yyvsp[-6].t)->parent= (yyval.t);

        (yyvsp[-6].t)->nextSibbling= (yyvsp[-5].t);

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4541 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 61:
#line 1779 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 35 );

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4584 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 62:
#line 1820 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 45 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4597 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 63:
#line 1831 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 45 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4616 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 64:
#line 1848 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 45 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4635 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 65:
#line 1865 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 80 );

    }
#line 4644 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 66:
#line 1872 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 80 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4663 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 67:
#line 1889 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 66 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4676 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 68:
#line 1900 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 38 );

    }
#line 4685 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 69:
#line 1907 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 38 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4704 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 70:
#line 1924 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 30 );

    }
#line 4713 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 71:
#line 1931 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 30 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4732 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 72:
#line 1948 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 41 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4745 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 73:
#line 1959 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 41 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4770 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 74:
#line 1982 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 91 );

    }
#line 4779 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 75:
#line 1989 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 91 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4798 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 76:
#line 2006 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 0 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4811 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 77:
#line 2017 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 0 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4830 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 78:
#line 2034 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 7 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4843 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 79:
#line 2045 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 7 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4874 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 80:
#line 2074 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 85 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4887 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 81:
#line 2085 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 85 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4918 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 82:
#line 2114 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 22 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4931 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 83:
#line 2125 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 22 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4962 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 84:
#line 2154 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 95 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 4987 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 85:
#line 2177 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 95 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5024 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 86:
#line 2212 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 75 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5049 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 87:
#line 2235 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 75 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5080 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 88:
#line 2264 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 75 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5111 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 89:
#line 2293 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 75 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5148 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 90:
#line 2328 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 48 );

    }
#line 5157 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 91:
#line 2335 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 48 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5194 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 92:
#line 2370 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 48 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5225 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 93:
#line 2399 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 93 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5238 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 94:
#line 2410 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 93 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5251 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 95:
#line 2421 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 5 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5264 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 96:
#line 2432 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 5 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5295 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 97:
#line 2461 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 46 );

    }
#line 5304 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 98:
#line 2468 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 46 );

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5347 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 99:
#line 2509 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 79 );

    }
#line 5356 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 100:
#line 2516 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 79 );

        (yyval.t)->addChild((yyvsp[-6].t));

        (yyvsp[-6].t)->parent= (yyval.t);

        (yyvsp[-6].t)->nextSibbling= (yyvsp[-5].t);

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5405 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 101:
#line 2563 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 25 );

    }
#line 5414 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 102:
#line 2570 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 25 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5433 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 103:
#line 2587 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 69 );

    }
#line 5442 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 104:
#line 2594 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 69 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5467 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 105:
#line 2617 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 12 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5480 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 106:
#line 2628 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 12 );

    }
#line 5489 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 107:
#line 2635 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 34 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5508 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 108:
#line 2652 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 34 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5533 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 109:
#line 2675 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 34 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5570 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 110:
#line 2710 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 34 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5601 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 111:
#line 2739 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 34 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5632 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 112:
#line 2768 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 34 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5669 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 113:
#line 2803 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 34 );

        (yyval.t)->addChild((yyvsp[-6].t));

        (yyvsp[-6].t)->parent= (yyval.t);

        (yyvsp[-6].t)->nextSibbling= (yyvsp[-5].t);

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5718 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 114:
#line 2850 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 34 );

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5761 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 115:
#line 2891 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 103 );

    }
#line 5770 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 116:
#line 2898 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 103 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5783 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 117:
#line 2909 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 103 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5796 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 118:
#line 2920 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 89 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5809 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 119:
#line 2931 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 89 );

    }
#line 5818 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 120:
#line 2938 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 40 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5831 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 121:
#line 2949 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 40 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5844 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 122:
#line 2960 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 40 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5863 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 123:
#line 2977 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 40 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5888 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 124:
#line 3000 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 40 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5913 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 125:
#line 3023 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 40 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5944 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 126:
#line 3052 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 74 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5969 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 127:
#line 3075 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 74 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5982 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 128:
#line 3086 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 63 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 5995 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 129:
#line 3097 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 63 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6014 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 130:
#line 3114 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 63 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6045 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 131:
#line 3143 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 31 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6070 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 132:
#line 3166 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 31 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6107 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 133:
#line 3201 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 31 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6120 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 134:
#line 3212 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 31 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6145 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 135:
#line 3235 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 50 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6164 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 136:
#line 3252 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 50 );

    }
#line 6173 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 137:
#line 3259 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 47 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6198 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 138:
#line 3282 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 47 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6217 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 139:
#line 3299 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 47 );

        (yyval.t)->addChild((yyvsp[-7].t));

        (yyvsp[-7].t)->parent= (yyval.t);

        (yyvsp[-7].t)->nextSibbling= (yyvsp[-6].t);

        (yyval.t)->addChild((yyvsp[-6].t));

        (yyvsp[-6].t)->parent= (yyval.t);

        (yyvsp[-6].t)->nextSibbling= (yyvsp[-5].t);

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6272 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 140:
#line 3352 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 94 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6285 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 141:
#line 3363 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 94 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6310 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 142:
#line 3386 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 37 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6323 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 143:
#line 3397 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 37 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6336 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 144:
#line 3408 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 73 );

    }
#line 6345 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 145:
#line 3415 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 73 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6358 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 146:
#line 3426 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 90 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6371 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 147:
#line 3437 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 90 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6390 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 148:
#line 3454 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 20 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6403 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 149:
#line 3465 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 20 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6416 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 150:
#line 3476 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 20 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6429 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 151:
#line 3487 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 20 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6442 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 152:
#line 3498 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 20 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6455 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 153:
#line 3509 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 20 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6468 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 154:
#line 3520 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 14 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6493 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 155:
#line 3543 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 14 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6530 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 156:
#line 3578 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 14 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6543 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 157:
#line 3589 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 14 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6568 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 158:
#line 3612 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 76 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6605 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 159:
#line 3647 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 76 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6636 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 160:
#line 3676 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 70 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6661 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 161:
#line 3699 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 70 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6674 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 162:
#line 3710 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 102 );

    }
#line 6683 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 163:
#line 3717 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 102 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6696 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 164:
#line 3728 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 44 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6721 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 165:
#line 3751 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 44 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6734 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 166:
#line 3762 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6777 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 167:
#line 3803 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6802 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 168:
#line 3826 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6833 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 169:
#line 3855 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6876 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 170:
#line 3896 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6901 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 171:
#line 3919 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6920 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 172:
#line 3936 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6945 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 173:
#line 3959 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6970 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 174:
#line 3982 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 6995 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 175:
#line 4005 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7020 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 176:
#line 4028 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7045 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 177:
#line 4051 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7070 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 178:
#line 4074 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7095 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 179:
#line 4097 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7120 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 180:
#line 4120 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7145 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 181:
#line 4143 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7170 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 182:
#line 4166 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7195 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 183:
#line 4189 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7214 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 184:
#line 4206 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7233 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 185:
#line 4223 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7252 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 186:
#line 4240 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7271 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 187:
#line 4257 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7296 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 188:
#line 4280 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7321 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 189:
#line 4303 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7346 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 190:
#line 4326 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7371 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 191:
#line 4349 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7396 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 192:
#line 4372 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7421 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 193:
#line 4395 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7446 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 194:
#line 4418 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7471 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 195:
#line 4441 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7496 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 196:
#line 4464 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7521 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 197:
#line 4487 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7546 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 198:
#line 4510 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7571 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 199:
#line 4533 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7596 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 200:
#line 4556 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7621 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 201:
#line 4579 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7646 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 202:
#line 4602 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7671 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 203:
#line 4625 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7690 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 204:
#line 4642 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7709 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 205:
#line 4659 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7728 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 206:
#line 4676 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7747 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 207:
#line 4693 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7772 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 208:
#line 4716 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7797 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 209:
#line 4739 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7822 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 210:
#line 4762 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7847 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 211:
#line 4785 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7872 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 212:
#line 4808 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7897 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 213:
#line 4831 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7922 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 214:
#line 4854 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7947 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 215:
#line 4877 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7972 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 216:
#line 4900 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 7997 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 217:
#line 4923 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8034 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 218:
#line 4958 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8047 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 219:
#line 4969 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8066 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 220:
#line 4986 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8085 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 221:
#line 5003 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8104 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 222:
#line 5020 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8123 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 223:
#line 5037 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8142 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 224:
#line 5054 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8161 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 225:
#line 5071 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8180 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 226:
#line 5088 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8199 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 227:
#line 5105 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8218 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 228:
#line 5122 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8231 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 229:
#line 5133 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8262 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 230:
#line 5162 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8287 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 231:
#line 5185 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 51 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8306 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 232:
#line 5202 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 19 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8337 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 233:
#line 5231 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 19 );

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8380 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 234:
#line 5272 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 19 );

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8423 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 235:
#line 5313 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 19 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8454 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 236:
#line 5342 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 86 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8467 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 237:
#line 5353 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 24 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8480 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 238:
#line 5364 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 24 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8493 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 239:
#line 5375 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 101 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8524 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 240:
#line 5404 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 101 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8537 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 241:
#line 5415 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 15 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8556 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 242:
#line 5432 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 15 );

    }
#line 8565 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 243:
#line 5439 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 16 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8584 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 244:
#line 5456 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 9 );

    }
#line 8593 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 245:
#line 5463 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 9 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8612 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 246:
#line 5480 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 9 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8637 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 247:
#line 5503 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 10 );

    }
#line 8646 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 248:
#line 5510 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 10 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8671 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 249:
#line 5533 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 82 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8684 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 250:
#line 5544 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 82 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8697 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 251:
#line 5555 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 82 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8710 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 252:
#line 5566 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 82 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8723 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 253:
#line 5577 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 82 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8736 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 254:
#line 5588 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 82 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8749 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 255:
#line 5599 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 82 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8762 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 256:
#line 5610 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 82 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8775 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 257:
#line 5621 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 3 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8788 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 258:
#line 5632 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 3 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8801 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 259:
#line 5643 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 3 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8820 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 260:
#line 5660 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 3 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8839 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 261:
#line 5677 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 3 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8870 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 262:
#line 5706 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 3 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8883 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 263:
#line 5717 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 32 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8908 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 264:
#line 5740 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 1 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8921 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 265:
#line 5751 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 1 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8934 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 266:
#line 5762 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 1 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8947 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 267:
#line 5773 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 1 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8960 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 268:
#line 5784 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 1 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 8985 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 269:
#line 5807 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 1 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9010 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 270:
#line 5830 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 1 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9035 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 271:
#line 5853 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 100 );

    }
#line 9044 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 272:
#line 5860 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 100 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9063 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 273:
#line 5877 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 81 );

    }
#line 9072 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 274:
#line 5884 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 81 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9085 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 275:
#line 5895 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 23 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9122 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 276:
#line 5930 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 23 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9147 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 277:
#line 5953 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 23 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9172 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 278:
#line 5976 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 23 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9185 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 279:
#line 5987 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 71 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9198 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 280:
#line 5998 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 71 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9211 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 281:
#line 6009 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 96 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9224 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 282:
#line 6020 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 2 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9237 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 283:
#line 6031 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 52 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9250 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 284:
#line 6042 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 97 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9287 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 285:
#line 6077 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 97 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9300 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 286:
#line 6088 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 83 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9319 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 287:
#line 6105 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 83 );

    }
#line 9328 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 288:
#line 6112 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 99 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9353 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 289:
#line 6135 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 98 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9378 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 290:
#line 6158 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 98 );

    }
#line 9387 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 291:
#line 6165 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 84 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9400 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 292:
#line 6176 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 84 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9419 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 293:
#line 6193 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 88 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9444 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 294:
#line 6216 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 26 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9457 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 295:
#line 6227 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 26 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9470 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 296:
#line 6238 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 53 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9483 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 297:
#line 6249 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 53 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9502 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 298:
#line 6266 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 53 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9515 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 299:
#line 6277 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 6 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9546 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 300:
#line 6306 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 6 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9577 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 301:
#line 6335 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 6 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9590 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 302:
#line 6346 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 72 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9603 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 303:
#line 6357 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 72 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9634 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 304:
#line 6386 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 61 );

    }
#line 9643 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 305:
#line 6393 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 61 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9656 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 306:
#line 6404 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 29 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9669 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 307:
#line 6415 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 29 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9682 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 308:
#line 6426 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 36 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9713 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 309:
#line 6455 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 36 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9744 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 310:
#line 6484 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 36 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9757 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 311:
#line 6495 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 58 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9770 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 312:
#line 6506 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 58 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9795 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 313:
#line 6529 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 67 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9808 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 314:
#line 6540 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 67 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9827 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 315:
#line 6557 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 39 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9852 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 316:
#line 6580 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 39 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9865 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 317:
#line 6591 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 13 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9878 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 318:
#line 6602 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 13 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9909 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 319:
#line 6631 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 13 );

    }
#line 9918 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 320:
#line 6638 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 68 );

    }
#line 9927 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 321:
#line 6645 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 68 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9946 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 322:
#line 6662 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 60 );

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 9983 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 323:
#line 6697 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 60 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10008 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 324:
#line 6720 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 60 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10033 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 325:
#line 6743 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 60 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10046 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 326:
#line 6754 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 60 );

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10089 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 327:
#line 6795 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 60 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10120 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 328:
#line 6824 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 60 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10151 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 329:
#line 6853 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 60 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10170 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 330:
#line 6870 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 78 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10189 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 331:
#line 6887 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 78 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10208 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 332:
#line 6904 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 78 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10227 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 333:
#line 6921 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 78 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10246 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 334:
#line 6938 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 78 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10265 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 335:
#line 6955 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 78 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10284 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 336:
#line 6972 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 78 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10303 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 337:
#line 6989 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 78 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10322 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 338:
#line 7006 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 78 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10341 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 339:
#line 7023 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 78 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10360 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 340:
#line 7040 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 78 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10379 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 341:
#line 7057 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 78 );

    }
#line 10388 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 342:
#line 7064 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 11 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10401 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 343:
#line 7075 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 11 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10432 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 344:
#line 7104 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 11 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10457 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 345:
#line 7127 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 11 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10482 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 346:
#line 7150 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 11 );

        (yyval.t)->addChild((yyvsp[-5].t));

        (yyvsp[-5].t)->parent= (yyval.t);

        (yyvsp[-5].t)->nextSibbling= (yyvsp[-4].t);

        (yyval.t)->addChild((yyvsp[-4].t));

        (yyvsp[-4].t)->parent= (yyval.t);

        (yyvsp[-4].t)->nextSibbling= (yyvsp[-3].t);

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10525 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 347:
#line 7191 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 11 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10550 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 348:
#line 7214 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 43 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10563 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 349:
#line 7225 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 43 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10576 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 350:
#line 7236 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 43 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10589 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 351:
#line 7247 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 21 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10620 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 352:
#line 7276 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 21 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10651 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 353:
#line 7305 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 21 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10670 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 354:
#line 7322 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 21 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10689 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 355:
#line 7339 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 21 );

        (yyval.t)->addChild((yyvsp[-3].t));

        (yyvsp[-3].t)->parent= (yyval.t);

        (yyvsp[-3].t)->nextSibbling= (yyvsp[-2].t);

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10720 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 356:
#line 7368 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 21 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10739 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 357:
#line 7385 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 21 );

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10758 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 358:
#line 7402 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 54 );

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10771 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 359:
#line 7413 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 54 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10796 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 360:
#line 7436 "pt_zend_language_parser.y" /* yacc.c:1646  */
    {
        (yyval.t)= new NonTerminal( 18 );

        (yyval.t)->addChild((yyvsp[-2].t));

        (yyvsp[-2].t)->parent= (yyval.t);

        (yyvsp[-2].t)->nextSibbling= (yyvsp[-1].t);

        (yyval.t)->addChild((yyvsp[-1].t));

        (yyvsp[-1].t)->parent= (yyval.t);

        (yyvsp[-1].t)->nextSibbling= (yyvsp[0].t);

        (yyval.t)->addChild((yyvsp[0].t));

        (yyvsp[0].t)->parent= (yyval.t);

    }
#line 10821 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
    break;


#line 10825 "pt_zend_language_parser.tab.cc" /* yacc.c:1646  */
      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYEMPTY : YYTRANSLATE (yychar);

  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
# define YYSYNTAX_ERROR yysyntax_error (&yymsg_alloc, &yymsg, \
                                        yyssp, yytoken)
      {
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = YYSYNTAX_ERROR;
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == 1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = (char *) YYSTACK_ALLOC (yymsg_alloc);
            if (!yymsg)
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = 2;
              }
            else
              {
                yysyntax_error_status = YYSYNTAX_ERROR;
                yymsgp = yymsg;
              }
          }
        yyerror (yymsgp);
        if (yysyntax_error_status == 2)
          goto yyexhaustedlab;
      }
# undef YYSYNTAX_ERROR
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYTERROR;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined yyoverflow || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  return yyresult;
}
#line 7460 "pt_zend_language_parser.y" /* yacc.c:1906  */



#include <stdio.h>

extern char yytext[];
extern int column;
extern int line;

void yyerror( char *s)
{
fflush(stdout);
fprintf(stderr,"%s: %d.%d\n",s,line,column);
}


