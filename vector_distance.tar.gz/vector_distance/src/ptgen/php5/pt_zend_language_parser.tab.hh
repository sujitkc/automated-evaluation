/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_PT_ZEND_LANGUAGE_PARSER_TAB_HH_INCLUDED
# define YY_YY_PT_ZEND_LANGUAGE_PARSER_TAB_HH_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    T_INCLUDE = 258,
    T_INCLUDE_ONCE = 259,
    T_EVAL = 260,
    T_REQUIRE = 261,
    T_REQUIRE_ONCE = 262,
    T_LOGICAL_OR = 263,
    T_LOGICAL_XOR = 264,
    T_LOGICAL_AND = 265,
    T_PRINT = 266,
    T_PLUS_EQUAL = 267,
    T_MINUS_EQUAL = 268,
    T_MUL_EQUAL = 269,
    T_DIV_EQUAL = 270,
    T_CONCAT_EQUAL = 271,
    T_MOD_EQUAL = 272,
    T_AND_EQUAL = 273,
    T_OR_EQUAL = 274,
    T_XOR_EQUAL = 275,
    T_SL_EQUAL = 276,
    T_SR_EQUAL = 277,
    T_BOOLEAN_OR = 278,
    T_BOOLEAN_AND = 279,
    T_IS_EQUAL = 280,
    T_IS_NOT_EQUAL = 281,
    T_IS_IDENTICAL = 282,
    T_IS_NOT_IDENTICAL = 283,
    T_IS_SMALLER_OR_EQUAL = 284,
    T_IS_GREATER_OR_EQUAL = 285,
    T_SL = 286,
    T_SR = 287,
    T_INSTANCEOF = 288,
    T_INC = 289,
    T_DEC = 290,
    T_INT_CAST = 291,
    T_DOUBLE_CAST = 292,
    T_STRING_CAST = 293,
    T_ARRAY_CAST = 294,
    T_OBJECT_CAST = 295,
    T_BOOL_CAST = 296,
    T_UNSET_CAST = 297,
    T_NEW = 298,
    T_CLONE = 299,
    T_EXIT = 300,
    T_IF = 301,
    T_ELSEIF = 302,
    T_ELSE = 303,
    T_ENDIF = 304,
    T_LNUMBER = 305,
    T_DNUMBER = 306,
    T_STRING = 307,
    T_STRING_VARNAME = 308,
    T_VARIABLE = 309,
    T_NUM_STRING = 310,
    T_INLINE_HTML = 311,
    T_CHARACTER = 312,
    T_BAD_CHARACTER = 313,
    T_ENCAPSED_AND_WHITESPACE = 314,
    T_CONSTANT_ENCAPSED_STRING = 315,
    T_ECHO = 316,
    T_DO = 317,
    T_WHILE = 318,
    T_ENDWHILE = 319,
    T_FOR = 320,
    T_ENDFOR = 321,
    T_FOREACH = 322,
    T_ENDFOREACH = 323,
    T_DECLARE = 324,
    T_ENDDECLARE = 325,
    T_AS = 326,
    T_SWITCH = 327,
    T_ENDSWITCH = 328,
    T_CASE = 329,
    T_DEFAULT = 330,
    T_BREAK = 331,
    T_CONTINUE = 332,
    T_FUNCTION = 333,
    T_CONST = 334,
    T_RETURN = 335,
    T_TRY = 336,
    T_CATCH = 337,
    T_THROW = 338,
    T_USE = 339,
    T_GLOBAL = 340,
    T_STATIC = 341,
    T_ABSTRACT = 342,
    T_FINAL = 343,
    T_PRIVATE = 344,
    T_PROTECTED = 345,
    T_PUBLIC = 346,
    T_VAR = 347,
    T_UNSET = 348,
    T_ISSET = 349,
    T_EMPTY = 350,
    T_HALT_COMPILER = 351,
    T_CLASS = 352,
    T_INTERFACE = 353,
    T_EXTENDS = 354,
    T_IMPLEMENTS = 355,
    T_OBJECT_OPERATOR = 356,
    T_DOUBLE_ARROW = 357,
    T_LIST = 358,
    T_ARRAY = 359,
    T_CLASS_C = 360,
    T_METHOD_C = 361,
    T_FUNC_C = 362,
    T_LINE = 363,
    T_FILE = 364,
    T_COMMENT = 365,
    T_DOC_COMMENT = 366,
    T_OPEN_TAG = 367,
    T_OPEN_TAG_WITH_ECHO = 368,
    T_CLOSE_TAG = 369,
    T_WHITESPACE = 370,
    T_START_HEREDOC = 371,
    T_END_HEREDOC = 372,
    T_DOLLAR_OPEN_CURLY_BRACES = 373,
    T_CURLY_OPEN = 374,
    T_PAAMAYIM_NEKUDOTAYIM = 375
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 10 "pt_zend_language_parser.y" /* yacc.c:1909  */

Tree *t;

#line 179 "pt_zend_language_parser.tab.hh" /* yacc.c:1909  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif



int yyparse (void);

#endif /* !YY_YY_PT_ZEND_LANGUAGE_PARSER_TAB_HH_INCLUDED  */
