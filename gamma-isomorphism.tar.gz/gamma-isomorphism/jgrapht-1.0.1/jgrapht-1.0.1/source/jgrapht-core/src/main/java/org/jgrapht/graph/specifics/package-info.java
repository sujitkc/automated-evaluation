/**
 * Implementations of specifics for various graph types.
 */
package org.jgrapht.graph.specifics;
