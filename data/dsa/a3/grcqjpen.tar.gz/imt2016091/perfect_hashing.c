#include <stdio.h>
#include <stdlib.h>
struct node
{
	int came;
	int c;
	int d;
	int length;
	int data[1000000];
};
void perfect_hash(int a,int b);
void go_hash_main(struct node *arr[] ,int hash,int val,int i,int size);
void go_hash_sec(struct node *arr[] ,int hash,int val);

void main()
{
	int a=rand()%100;
	int b=rand()%1000;
	perfect_hash(a,b);
}

void perfect_hash(int a,int b)
{
	int size=2000000;
	struct node *arr[size];
	int i,j,val,hash,in_a,in_b,inte_hash,len,del;
	struct node *acc;
	struct node *ha;
	for (i=0;i<size;i++)
		{
			struct node *newNode = (struct node*) malloc(sizeof(struct node));
			int in_a=rand()%100;
			int in_b=rand()%1000;
			newNode->length=0;
			newNode->came=-1;
			newNode->c=in_a;
			newNode->d=in_b;
			arr[i]=newNode;
			for(j=0;j<1000000;j++){newNode->data[i]=-1;}
		}
	for(i=0;i<size;i++)	
	{
		val=i*i%1000000;
		hash=((((a*val)+b)%997)%971);
		go_hash_main(arr ,hash,val,i,size);
	}

}

go_hash_main(struct node *arr[] ,int hash,int val,int i,int size)
{	
	int j,count=0,new_a,new_b;
	for(j=0;j<size;j++)
	{
		if (arr[j]->came==0){count+=(arr[j]->length)*(arr[j]->length);}
	}
	if(count <2*i)
	{
		go_hash_sec( arr ,hash,val);
	}
	else if(count>=2*i)
	{
	 	new_a=rand()%100;
		new_b=rand()%1000;	
		perfect_hash(new_a,new_b);
	}	
}

void go_hash_sec(struct node *arr[] ,int hash,int val)
{
	int i,sec_a,sec_b,l,hash_sec;
	struct node *temp;
	temp=arr[hash];
	sec_a=temp->c;
	sec_b=temp->d;
	temp->length=(temp->length)+1;
	l=temp->length;
	hash_sec=((((sec_a*val)+sec_b)%997)%(l*l));
	if(temp->data[hash_sec]==-1)
		{
			temp->data[hash_sec]=val;
		}
	else
		{
			temp->length=(temp->length)-1;
			change_sec_hash(temp);
		}

}

void change_sec_hash(struct node *p)
{
	int i,value,change_hash;
	int len=p->length;
	struct node *cha;
	cha->c=rand()%100;
	cha->d=rand()%1000;
	cha->length=p->length;
	for(i=0;i<1000000;i++)
	{
			if(p->data[i]==-1)
			{
				value=p->data;
				change_hash=(((((cha->c)*value)*cha->d)%997)%(len*len));
				if(cha->data[change_hash]==-1)
						{
													
							(cha->length)+=1;
							 cha->data[change_hash];
							 p->length=-1;
						}	
				else if(cha->data[change_hash]!=-1)
				{
					change_sec_hash(p);
				}		
			}
	}
	return; 
}
