#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>

struct tree{
  int data,height,level,rank;
  struct tree *parent;
  struct tree *lc;
  struct tree *rc;
};

void insert(struct tree **root,int n);
int height(struct tree *root);
void delete(struct tree **root,struct tree *ptr);
void right_rotate(struct tree **root,struct tree *ptr);
void left_rotate(struct tree **root,struct tree *ptr);
int rank(struct tree *root,int n);
struct tree *find_rank(struct tree *root,int k);
bool search(struct tree *root,int n);
int abs(int a);
void rec_in(struct tree *root);
void rec_pre(struct tree *root);
void avl_convert(struct tree **root,struct tree *ptr);
void del(struct tree **root,int n);
int maxi(int a,int b);
int rank_num(struct tree *ptr);
int main(){
    struct tree *root=malloc(sizeof(struct tree));
    root->data=10;
    root->height=0;
    root->rank=1;
    root->lc=NULL;
    root->rc=NULL;
    root->parent=NULL;
    insert(&root,31);
		//insert(&root,2);
		insert(&root,36);
    insert(&root,30);
    insert(&root,20);
		insert(&root,100);
    search(root,30);
		insert(&root,1);
    insert(&root,32);
    del(&root,10);
    del(&root,32);
		del(&root,2);
    for(int i=0;i<1000000;i++) insert(&root,rand());
    //rec_in(root);
		//printf("\n");
		//rec_pre(root);
    //printf("rank=%d\n",rank(root,36));
}
bool search(struct tree *root,int n){
  while(1){
    if(root==NULL){
      return false;
    }
    else if(root->data==n) return true;
    else if((root->data)<n) root=root->rc;
    else root=root->lc;
  }
}
void insert(struct tree **root,int n){
  struct tree *cur=*root,*new,*prev;
  int h=1;bool violated=false;
  new=malloc(sizeof(struct tree));
  new->data=n;
  new->lc=NULL;new->rc=NULL;
  new->height=0;
  new->rank=1;
  while(1){
    cur->rank++;
    if(n>cur->data){
      if(cur->rc==NULL) break;
      else cur=cur->rc;
    }
    else{if(n==1) search(*root,30);
      if(cur->lc==NULL) break;
      else cur=cur->lc;
    }
  }
  if(n>cur->data) cur->rc=new;
  else cur->lc=new;
  new->parent=cur;
  while(cur->height<h){
    cur->height++;
    h++;
    if(abs(height(cur->rc)-height(cur->lc))>1) violated=true;break;
    if(cur->parent==NULL) break;
    prev=cur;
    cur=cur->parent;
  }
  if(violated){
    if(prev=cur->rc) right_rotate(root,cur);
    else left_rotate(root,cur);
  }
}
void delete(struct tree **root,struct tree *cur){
    struct tree *prev=cur->parent,*inpre;
    if(cur==*(root) && cur->rc==NULL &&cur->lc==NULL){
      (*root)=NULL;
    }
    else if(cur->lc==NULL || cur->rc==NULL){
      if(cur->rc==NULL){
        if(prev->rc==cur) prev->rc=cur->lc;
        else prev->lc=cur->lc;
        if(cur->lc!=NULL)cur->lc->parent=prev;
      }
      else{
        if(prev->rc==cur) prev->rc=cur->rc;
        else prev->lc=cur->rc;
        if(cur->rc!=NULL) cur->rc->parent=prev;
      }
       avl_convert(root,cur);
    }
    else{
      struct tree *inpre=cur->lc;
      while(inpre->rc!=NULL){
        inpre=inpre->rc;
      }
      cur->data=inpre->data;
      delete(root,inpre);
      }

}
void right_rotate(struct tree **root,struct tree *ptr){
  struct tree *z,*x,*y,*r=ptr->parent;
  int h;
    z=ptr;
    h=z->height;
if(height(z->rc->lc)==h-2){
      y=z->rc;
      x=z->rc->lc;
      z->rc=x->lc;
      x->height=h-1;
      y->height=h-2;
      z->height=h-2;
      y->rank=rank_num(y->rc)+rank_num(x->rc);
      z->rank=rank_num(z->lc)+rank_num(x->lc);
      x->rank=rank_num(y)+rank_num(z);
      if(x->lc!=NULL) x->lc->parent=z;
      y->lc=x->rc;
      if(x->rc!=NULL) x->rc->parent=y;
      x->rc=y;
      y->parent=x;
      x->lc=z;
      z->parent=x;
      if(r!=NULL){
        if(r->lc==ptr) r->lc=x;
        else r->rc=x;
        x->parent=r;
      }
      else{
        x->parent=NULL;
        (*root)=x;
      }
    }
    else{
      y=z->rc;
      x=z->rc->rc;
      y->parent=r;
      z->rc=y->lc;
      y->height=h-1;
      x->height=h-2;
      z->height=h-2;
      z->rank=rank_num(y->lc)+rank_num(z->lc);
      x->rank=rank_num(y)+rank_num(z);
      if(y->lc !=NULL) y->lc->parent=z;
      y->rc=x;
      x->parent=y;
      y->lc=z ;
      z->parent=y;
      if(r!=NULL){
        if(r->lc==ptr) r->lc=y;
        else r->rc=y;
        x->parent=r;
      }
      else{
        (*root)=y;
        y->parent=NULL;
      }
  }
}
void left_rotate(struct tree **root,struct tree *ptr){
  struct tree *z,*x,*y,*r=ptr->parent;
  int h;
    z=ptr;
    h=z->height;
    if(height(z->lc->rc)==h-2){
      y=z->lc;
      x=z->lc->rc;
      x->height=h-1;
      y->height=h-2;
      z->height=h-2;
      y->rank=rank_num(y->lc)+rank_num(x->lc);
      z->rank=rank_num(z->rc)+rank_num(x->rc);
      x->rank=rank_num(y)+rank_num(z);
      z->lc=x->rc;
      if(x->rc!=NULL) x->rc->parent=z;
      y->rc=x->lc;
      if(x->lc!=NULL) x->lc->parent=y;
      x->lc=y;
      y->parent=x;
      x->rc=z;
      z->parent=x;
      if(r!=NULL){
        if(r->lc==ptr) r->lc=x;
        else r->rc=x;
        x->parent=ptr->parent;
      }
      else{
        x->parent=NULL;
        (*root)=x;
      }
    }
    else{
      y=z->lc;
      x=z->lc->lc;
      y->height=h-1;
      x->height=h-2;
      z->height=h-2;
      z->rank=rank_num(y->rc)+rank_num(z->rc);
      x->rank=rank_num(y)+rank_num(z);
      y->parent=r;
      z->lc=y->rc;
      if(y->rc !=NULL) y->rc->parent=z;
      y->lc=x;
      x->parent=y;
      y->rc=z ;
      z->parent=y;
      if(r!=NULL){
        if(r->lc==ptr) r->lc=y;
        else r->rc=y;
        x->parent=r;
      }
      else{
        (*root)=y;
        y->parent=NULL;
      }
  }
}
void del(struct tree **root,int n){
  struct tree *cur=(*root);
  while(cur!=NULL){
    cur->rank--;
    if(cur->data==n) break;
    else if(n>cur->data) cur=cur->rc;
    else cur=cur->lc;
  }
  if(cur!=NULL) delete(root,cur);
}
void avl_convert(struct tree **root,struct tree *ptr){
    struct tree *parent=ptr->parent;
    int h;
    while(parent!=NULL){
      if(parent->height==1+maxi(height(parent->lc),height(parent->rc))){
       if(abs(height(parent->lc)-height(parent->rc))<=1) break;
       else if(height(parent->rc)<height(parent->lc))left_rotate(root,parent);
       else right_rotate(root,parent);
      }
      else
        parent->height--;
      parent=parent->parent;
    }
}
int rank(struct tree *root,int n){
  int r=1;struct tree *cur=root;
  while(cur!=NULL){
    if(cur->data>n){
      r+=(1+rank_num(cur->rc));
      cur=cur->lc;
    }
    else if(cur->data<n) cur=cur->rc;
    else return r+rank_num(cur->rc);
  }
}
struct tree *find_rank(struct tree *root,int k){
  struct tree *cur=root;
  while(cur!=NULL){
    if(k==1+rank_num(cur->rc)) return cur;
    else if(k>1+rank_num(cur->rc))  cur=cur->lc;
    else{
      cur=cur->rc;
      k=k-1-(rank_num(cur->rc));
    }
  }
  return cur;
}
int height(struct tree *root){
  if(root==NULL) return -1;
  else return root->height;
}
int abs(int a){
  if(a<0) return -a;
  else return a;
}
int maxi(int a,int b){
  if(a>b) return a;
  else return b;
}
void rec_in(struct tree *root){
  if(root!=NULL){
    rec_in(root->lc);
    printf("%d\n",root->data);
    rec_in(root->rc);
  }
}
void rec_pre(struct tree *root){
  if(root!=NULL){
    printf("%d\n",root->data);
    rec_pre(root->lc);
    rec_pre(root->rc);
  }
}
int rank_num(struct tree *ptr){
  if(ptr==NULL) return 0;
  else return ptr->rank;
}
