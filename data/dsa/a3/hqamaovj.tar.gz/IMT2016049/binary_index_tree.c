#include<stdio.h>

void update(int value,int bit[],int size,int index)
{
    index=index+1;
    while(index<=size)
    {
        bit[index]+=value;
        index+= index&(-index);
    }
}

int Sum(int bit[],int index)
{
    index+=1;
    int sum=0;
    while(index>0)
    {
        sum+=bit[index];
        index -=index&(-index);
    }
    
    return sum;
}

void buildTree(int arr[],int bit[],int size)
{
    for(int i=0;i<=size;i++)
        bit[i]=0;
    for(int i=0;i<size;i++)
        update(arr[i],bit,size,i);
}

int main()
{
    int arr[]={1,4,3,2,6,5,4};
    int size=sizeof(arr)/sizeof(arr[0]);
    int bit[size+1];
    buildTree(arr,bit,size);
    int sum=Sum(bit,3);
    printf("%d\n",sum);
    return 0;
}
