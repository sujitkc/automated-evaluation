#include<stdio.h>
#include<math.h>
int infinite = 999999999;
int Min(int a,int b)
{
    if(a<b)
        return a;
    return b;
}
int segmentTree(int arr[],int segTree[],int low, int high, int pos)
{
    if(low==high)
    {
        segTree[pos]=arr[low];
        return segTree[pos];
    }
    int mid = (low+high)/2;
    segTree[pos]= Min(segmentTree(arr,segTree,low,mid,2*pos+1),segmentTree(arr,segTree,mid+1,high,2*pos+2));
    return segTree[pos];
}
int RMQ(int segTree[],int low_current,int high_current,int min, int max,int pos)// here min and max are that of range
{
    if(min<=low_current && max>=high_current)
        return segTree[pos];
    
    if(min>high_current || max<low_current)
        return infinite;
    int mid= (low_current+high_current)/2;
    return Min(RMQ(segTree,low_current,mid,min,max,2*pos+1),RMQ(segTree,mid+1,high_current,min,max,2*pos+2));
    
}
int main()
{

    int arr[]={3,4,9,1,8};
    int size=sizeof(arr)/sizeof(arr[0]);
    int x = (int)(ceil(log2(size)));
    int max_size = 2*(int)pow(2, x) - 1;
    int segTree[max_size];
    segmentTree(arr,segTree,0,size-1,0);
    int min=1,max=2;
    if(min>=0 && max<=size-1)
    {
        int m=RMQ(segTree,0,size-1,min,max,0);//exact indices
        if(m!=infinite)
            printf("min= %d",m);
        else
            printf("Not possible");
    }
    else
        printf("Not possible");
    return 0;
}
