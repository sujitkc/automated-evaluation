#include<stdio.h>
int arr[20];
int hashfunction(int x)
{
	return x%m;
}
void insert(int x)
{
	int y=hashfunction(x);
	while(arr[y]!=0&&arr[y]!=-1)
	{
		y++;
		y=hashfunction(y);
	}
	arr[y]=x;
}
void search(int x)
{
	int k=0;
	int y=hashfunction(x);
	while(arr[y]!=0)
	{
		k++;
		if(arr[y]==x)
		{
			printf("Element found at %d th location\n",y);
			k=-1;
			break;
		}	
		if(k==20)
			break;
		y++;
		//printf("%d ",k);
		y=hashfunction(y);
	}
	if(k!=-1)
		printf("Element not found\n");
}
void delete(int x)
{
	int k=0;
	int y=hashfunction(x);
	while(arr[y]!=0)
	{
		k++;
		if(arr[y]==x)
		{
			arr[y]=-1;
			k=-1;
			break;
		}	
		if(k==20)
			break;
		y++;
		//printf("%d ",k);
		y=hashfunction(y);
	}
}
int main()
{
	int n;
	scanf("%d",&n);
	int a[n],i;
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	for(i=0;i<n;i++)
		insert(a[i]);
	for(i=0;i<20;i++)
		printf("%d %d\n",i,arr[i]);
	int x=1;
	int choice=0;
	while(choice!=4)
	{
		printf("1.Insert\n2.Search\n3.Delete\n4.Exit\n");
		scanf("%d",&choice);
		if(choice==1)
		{
			scanf("%d",&x);
			insert(x);
			for(i=0;i<20;i++)
				printf("%d %d\n",i,arr[i]);
		}
		else if(choice==2)
		{
			scanf("%d",&x);
			search(x);
		}
		else if(choice==3)
		{
			scanf("%d",&x);
			delete(x);
			for(i=0;i<20;i++)
				printf("%d %d\n",i,arr[i]);
		}
	}
	return 0;
}
