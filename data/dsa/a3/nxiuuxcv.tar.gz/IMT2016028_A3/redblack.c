#include<stdio.h>
#include<stdlib.h>
struct node
{
	int key,h;
	char c;
	struct node *lc;
	struct node *rc;
	struct node *p;
};
struct node *gp(struct node *n)
{
	if((n!=NULL)&&(n->p!=NULL))
		return n->p->p;
	else
		return NULL;
}
struct node *u(struct node *n)
{
	struct node *g = gp(n);
	if (g == NULL)
		return NULL;
	if(n->p==g->lc)
		return g->rc;
	else
		return g->lc;
}
void in_1(struct node ** g_p,struct node ** u_n,struct node ** p_a,struct node ** n,struct node ** root)
{
	(*g_p)->c='r';
	(*u_n)->c='b';
	(*p_a)->c='b';
	if((*g_p)==(*root))
		(*g_p)->c='b';
	struct node * pa, *gpa, *un, *new;
	new=(*g_p);
	if(new->p->p!=NULL)
	{
		pa=new->p;
		*gpa=new->p->p;
		if(pa
	}	 	
}
void in_2(struct node ** g_p,struct node ** u_n,struct node ** p_a,struct node ** n,struct node ** root,int a)
{
	if(a==0)
	{
		(*p_a)->rc=(*n)->lc;
		if((*n)->lc)
			(*n)->lc->p=(*p_a);
		(*g_p)->lc=(*n)->rc;
		if((*n)->rc)
			(*n)->rc->p=(*g_p);
		(*n)->lc=(*p_a);
		(*n)->rc=(*g_p);
		(*n)->p=(*g_p)->p;
		(*g_p)->p=(*n);
		(*p_a)->p=(*n);
		(*g_p)->c='r';
		(*n)->c='b';
	}
	else if(a==1)
	{
		(*p_a)->lc=(*n)->rc;
		if((*n)->rc)
			(*n)->rc->p=(*p_a);
		(*g_p)->rc=(*n)->lc;
		if((*n)->lc)
			(*n)->lc->p=(*g_p);
		(*n)->lc=(*g_p);
		(*n)->rc=(*p_a);
		(*n)->p=(*g_p)->p;
		(*g_p)->p=(*n);
		(*p_a)=(*n);
		(*g_p)->c='r';
		(*n)->c='b';	
	}
}
void in_3(struct node ** g_p,struct node ** u_n,struct node ** p_a,struct node ** n,struct node ** root,int a)
{
	if(a==0)
	{
		(*g_p)->lc=(*p_a)->rc;
		if((*p_a)->rc))
			(*p_a)->rc->p=(*g_p);
		(*p_a)->rc=(*g_p);
		(*p_a)->p=(*g_p)->p;
		(*g_p)->p=(*p_a);
		(*p_a)->c='b';
		(*g_p)->c='r';	
	}
	else if(a==1)
	{
		(*g_p)->rc=(*p_a)->lc;
		if((*p_a)->lc))
			(*p_a)->lc->p=(*g_p);
		(*p_a)->lc=(*g_p);
		(*p_a)->p=(*g_p)->p;
		(*g_p)->p=(*p_a);
		(*p_a)->c='b';
		(*g_p)->c='r';	
	}
}
void insert(int val,struct node ** root)
{
	struct node *new,*prev,*curr;
	new=malloc(sizeof(struct node));
	new->key=val;
  	new->h=0;
	new->lc=NULL;
	new->rc=NULL;
  	new->p=NULL;
	new->c='r';
	if(*root==NULL)
	{
		*root=new;
		(*root)->c='b';
	}		
	else
	{
		prev=NULL;
		curr=*root;
		while(curr)
		{
			if(curr->key==val)
			{
				printf("key already present\n");
				return;
			}		
			else if(curr->key>val)
			{
				prev=curr;
				curr=curr->lc;
			}
			else
			{
				prev=curr;
				curr=curr->rc;
			}
		}
		if(val>prev->key)
		{
			prev->rc=new;
      		new->p=prev;
		}
		else if(val<prev->key)
		{
			prev->lc=new;
      		new->p=prev;
		}
		struct node * grandparent,* uncle,* parent,* curr;
		curr=new;
		grandparent=gp(curr);
		uncle=u(curr);
		parent=new->p;
		if(parent->c=='r'&&uncle!=NULL&&uncle->c=='r')
			in_1(&grandparent,&uncle,&parent,&curr,root);
		else if(parent->c=='r'&&(uncle==NULL||uncle->c=='b'))
		{
			if(parent==grandparent->lc&&curr==parent->rc)
				in_2(&grandparent,&uncle,&parent,&curr,root,0);
			else if(parent==grandparent->rc&&curr==parent->lc)
				in_2(&grandparent,&uncle,&parent,&curr,root,1);
			else if(parent==grandparent->lc&&curr==parent->lc)
				in_3(&grandparent,&uncle,&parent,&curr,root,0);
			else if(parent==grandparent->rc&&curr==parent->rc)
				in_3(&grandparent,&uncle,&parent,&curr,root);
		}
	}	
}
int main()
{
	struct node *root;
	root=malloc(sizeof(struct node));
	root=NULL;
	insert(10,&root);
	struct node * new,* new1;
	new=malloc(sizeof(struct node));
	new->key=5;
	new->h=0;
	new->lc=NULL;
	new->rc=NULL;
	new->c='r';
	new->p=root;
	root->lc=new;
	new1=malloc(sizeof(struct node));
	new1->key=12;
	new1->h=0;
	new1->lc=NULL;
	new1->rc=NULL;
	new1->c='r';
	new1->p=root;
	root->rc=new1;
	insert(7,&root);
	printf("%d %c\n%d %c\n%d %c\n%d %c\n",root->key,root->c,root->lc->key,root->lc->c,root->rc->key,root->rc->c,root->lc->rc->key,root->lc->rc->c);
}
