#include<stdio.h>
#include<stdlib.h>
struct node * arr[20];
struct node{
	int x;
	struct node * nextptr;
};
int hashfunction(int x)
{
	return x%20;
}
void insert(int x)
{
	int y=hashfunction(x);
	if(arr[y]==NULL)
	{
		arr[y]=malloc(sizeof(struct node));
		arr[y]->x=x;
	}
	else
	{
		struct node * ptr;
		ptr=(struct node *)malloc(sizeof(struct node));
		struct node * ptr1;
		ptr1=(struct node *)malloc(sizeof(struct node));
		ptr=arr[y];
		ptr1->x=x;
		ptr1->nextptr=NULL;	
		while(ptr->nextptr!=NULL)
			ptr=ptr->nextptr;
		ptr->nextptr=ptr1;
	}
}
void search(int x)
{
	int y=hashfunction(x);
	struct node * ptr;
	ptr=(struct node *)malloc(sizeof(struct node));
	ptr=arr[y];
	while(ptr!=NULL)
	{
		if(ptr->x==x)
		{
			printf("Element found at %d th location\n",y);
			break;
		}
		ptr=ptr->nextptr;
	}
	if(ptr==NULL)
		printf("Element not found");
}
void delete(int x)
{
	int y=hashfunction(x);
	struct node * ptr;
	ptr=(struct node *)malloc(sizeof(struct node));
	ptr=arr[y];
	if(ptr->x==x)
		arr[y]=ptr->nextptr;
	while(ptr->nextptr!=NULL)
	{
		if(ptr->nextptr->x==x)
		{
			ptr->nextptr=ptr->nextptr->nextptr;
			break;
		}
		ptr=ptr->nextptr;
	}
}
int main()
{
	int n,x,i;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&x);
		insert(x);
	}
	int choice=0;
	while(choice!=4)
	{
		printf("1.Insert\n2.Search\n3.Delete\n4.Exit\n");
		scanf("%d",&choice);
		if(choice==1)
		{
			scanf("%d",&x);
			insert(x);
			struct node * ptr;
			ptr=malloc(sizeof(struct node));
			ptr=arr[0];
			for(i=0;i<20;i++)
			{
				ptr=arr[i];
				if(ptr==NULL)
					printf("0");
				while(ptr!=NULL)
				{
					printf("%d ",ptr->x);
					ptr=ptr->nextptr;
				}	
				printf("\n");
			}
		}
		else if(choice==2)
		{
			scanf("%d",&x);
			search(x);
		}
		else if(choice==3)
		{
			scanf("%d",&x);
			delete(x);
			struct node * ptr;
			ptr=malloc(sizeof(struct node));
			ptr=arr[0];
			for(i=0;i<20;i++)
			{
				ptr=arr[i];
				if(ptr==NULL)
					printf("0");
				while(ptr!=NULL)
				{
					printf("%d ",ptr->x);
					ptr=ptr->nextptr;
				}
				printf("\n");
			}
		}
	}
}		
