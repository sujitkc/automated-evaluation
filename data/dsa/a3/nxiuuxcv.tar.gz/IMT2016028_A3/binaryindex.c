#include<stdio.h>
int tree[100000];
int getsum(int index)
{
	int sum=0;
	index=index+1;
	while(index>0)
	{
		sum=sum+tree[index];
		index=index-(index&(-index));
	}
	return sum;
}
void updatetree(int n,int index,int val)
{
	index=index+1;
	while(index<=n)
	{
		tree[index]=tree[index]+val;
		index=index+(index&(-index));
	}
}
void buildtree(int arr[],int n)
{
	int i;
	for(i=1;i<=n;i++)
		tree[i]=0;
	for(i=0;i<n;i++)
		updatetree(n,i,arr[i]);	
}
int main()
{
    int arr[] = {2, 1, 1, 3, 2, 3, 4, 5, 6, 7, 8, 9, 2, 5, 7, 6, 3, 1, 2, 2, 9, 7, 8, 6, 3, 4, 5, 2, 1, 6};
    int n=30,i;
    buildtree(arr, n);
	for(i=0;i<n;i++)
		printf("%d ",arr[i]);
	printf("\n");
	for(i=1;i<=n;i++)
		printf("%d ",tree[i]);
	printf("\n");
	printf("%d %d %d %d %d\n",getsum(5),getsum(7),getsum(12),getsum(16),getsum(26));
    return 0;
}
