#include <stdio.h>
#include <limits.h>
#include <algorithm>

const int N = 1e5;
int n;
int arr[2*N];

void build();
int query(int l, int r); // [l, r)

using namespace std;

int main()
{
    int t, q;
    scanf("%d", &t);
    for(int j = 0; j < t; j++){
        scanf("%d %d", &n, &q);
        for(int i = 0; i < n; i++)
            scanf("%d", arr+n+i);
        build();
        int l, r;
        for(int k = 0; k < q; k++){
            scanf("%d %d", &l, &r);
            printf("\n%d", query(l-1,r));
        }
    }
}

void build()
{
    for(int i = n-1; i > 0; i--)
        arr[i] = min(arr[2*i], arr[2*i+1]);
}

int query(int l, int r) // [l, r)
{
    int res = INT_MAX, x;
    for (l += n, r += n; l < r; l >>= 1, r >>= 1) {
        if (l&1) {
            x = arr[l++];
            if(x < res)
            res = x;}
        if (r&1) {
            x = arr[--r];
            if(x < res)
                res = x;}
    }
  return res;
}