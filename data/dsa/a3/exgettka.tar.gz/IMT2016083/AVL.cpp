#include <iostream>
#include <algorithm>

struct Node{
    int data;
    int height;
    Node* lC;
    Node* rC;
};

using namespace std;

Node* newNode(int value);
Node* rightRotate(Node* root);
Node* leftRotate(Node* root);
Node* insert(int value, Node** root);
Node* deleteNode(Node* root, int data);
void inorder(Node *tree);

int main()
{
	Node* root = NULL;
	insert(6, &root);
	insert(-23, &root);
	insert(1, &root);
	insert(43, &root);
	insert(12, &root);
	insert(98, &root);
	insert(0, &root);
	insert(76, &root);   
	inorder(root);
}

int height(Node* root)
{
    if(root == NULL)
        return -1;
    return max(height(root->lC), height(root->rC));
}

Node* newNode(int value)
{
    Node* newNode = new Node;
    newNode->data = value;
    newNode->rC = NULL;
    newNode->lC = NULL;
    newNode->height = 0;
    return newNode;
}

Node* rightRotate(Node* root)
{
    Node* newRoot = root->lC;
    root->lC = newRoot->rC;
    newRoot->rC = root;
    root->height = height(root);
    newRoot->height = height(newRoot);
    return newRoot;
}

Node* leftRotate(Node* root)
{
    Node* newRoot = root->rC;
    root->rC = newRoot->lC;
    newRoot->lC = root;
    root->height = height(root);
    newRoot->height = height(root);
    return newRoot;
}

Node* insert(int value, Node** root)
{
    if(*root == NULL)
        return newNode(value);

    if(value > (*root)->data)
        (*root)->rC = insert(value, &((*root)->rC));
    else if(value < (*root)->data)
        (*root)->lC = insert(value, &((*root)->lC));
    
    int difference = height((*root)->lC) - height((*root)->rC);

    if(difference > 1)
    {
        if(height((*root)->lC->lC) >= height((*root)->lC->rC))
            return rightRotate((*root));
        else
        {
            (*root)->lC = leftRotate((*root)->lC);
            return rightRotate(*root);
        }
    }
    else if(difference < -1)
    {
        if(height((*root)->rC->rC) > height((*root)->rC->lC))
            return leftRotate((*root));
        else
        {
            (*root)->rC = rightRotate((*root)->rC);
            return leftRotate(*root);
        }
    }
    (*root)->height = 1 + max(height((*root)->lC), height((*root)->rC));
    return (*root);
    
}
/*
Node* deleteNode(Node* root, int data)
{   
    if (root == NULL)
        return root;
 
    if ( data < root->data )
        root->left = deleteNode(root->left, data);

    else if( data > root->data )
        root->right = deleteNode(root->right, data);

    else
    {
        if( (root->left == NULL) || (root->right == NULL) )
        {
            Node *temp = root->left ? root->left :
                                             root->right;
 
            if (temp == NULL)
            {
                temp = root;
                root = NULL;
            }
            else 
             *root = *temp; 
            free(temp);
        }
        else
        {
            Node* temp = minValueNode(root->right);
 
            root->data = temp->data;
 
            root->right = deleteNode(root->right, temp->data);
        }
    }
 
    if (root == NULL)
      return root;
 
    root->height = 1 + max(height(root->left),
                           height(root->right));
 
    int balance = getBalance(root);
 
    if (balance > 1 && getBalance(root->left) >= 0)
        return rightRotate(root);

    if (balance > 1 && getBalance(root->left) < 0)
    {
        root->left =  leftRotate(root->left);
        return rightRotate(root);
    }

    if (balance < -1 && getBalance(root->right) <= 0)
        return leftRotate(root);

    if (balance < -1 && getBalance(root->right) > 0)
    {
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }
 
    return root;
}

*/


void inorder(Node *tree){
	if(tree!=NULL){
		inorder(tree->lC);
		cout << tree->data << " ";
		inorder(tree->rC);
	}
}

