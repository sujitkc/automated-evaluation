#include <stdio.h>
#include <string.h>

int main()
{
    char T[] = "adsfasdasabc";
    char P[] = "abc";
    int x = 0, y = 0, h = 1, p = 97;
    int m = strlen(P), n = strlen(T);
    for(int i = 0; i < m-1; i++)
        h = (256*h)%p;
    for(int i = 0; i < m; i++)
    {
        x = (256*x + P[i])%p;
        y = (256*y + T[i])%p;
    }
    int  i, j;
    for(i = 0; i <= n-m; i++)
    {
        if(x == y)
        {
            for(j = 0; j < m; j++)
                if(P[j] != T[i+j])
                    break;
            if(j == m)
                printf("Match at %d", i);
        }
    
        y = (256*(y - h*T[i]) + T[i+m]) % p;
        if(y < 0)
            y = y + p;
    }
}







