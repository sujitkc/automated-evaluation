#include <stdio.h>
#include <stdlib.h>

int n;
int p = 101; 

struct item{
    int key;
    int value;
};

struct primary{
    int a;
    int b;
    int m; //number of values mapping to that slot.
    int* arr;
};

int h1(int x);
int h2(int x, int a, int b, int m);

int main(){
    scanf("%d", &n);
    item arrayofitems[n];

    int index_count[2*n] = {0};
    primary prim_array[2*n];

    int k, v;
    for(int i = 0; i < 2*n; i++)
        prim_array[i].m = 0;
    for(int i = 0; i < n; i++){
        scanf("%d %d", &k, &v);
        arrayofitems[i].key = k;
        arrayofitems[i].value = v;
        prim_array[h1(k)].m += 1;
    }

    int num;

    for(int i = 0; i < 2*n; i++){
        num = (prim_array[i].m)*(prim_array[i].m);
        prim_array[i].arr = (int*)malloc(num * sizeof(int));
        prim_array[i].a = rand()%100;
        prim_array[i].b= rand()%100;

    }


    for(int i = 0; i < n; i++){
        if(prim_array[h1(arrayofitems[i].key)].m > 0){
            //*(prim_array[h1(arrayofitems[i].key)].arr + h2(arrayofitems[i].key, prim_array[i].a, prim_array[i].b, prim_array[i].m)) = arrayofitems[i].value;
            *(prim_array[h1(arrayofitems[i].key)].arr +  h2(arrayofitems[i].key, prim_array[h1(arrayofitems[i].key)].a, prim_array[h1(arrayofitems[i].key)].b, prim_array[h1(arrayofitems[i].key)].m) )= arrayofitems[i].value;
        }
    }


    int q;
    printf("Enter your query below: ");
    while(true){
        scanf("%d", &q);
        if(prim_array[h1(q)].m > 0)
            printf("%d\n", *(prim_array[h1(q)].arr+h2(q, prim_array[h1(q)].a, prim_array[h1(q)].b, prim_array[h1(q)].m)));
        else
            printf("The item does not exist\n");
    }

    
}

int h1(int x){
    return ((3*x + 42)%p)%(2*n);
}

int h2(int x, int a, int b, int m){
    return ((a*x + b)%p)%(m*m);
}