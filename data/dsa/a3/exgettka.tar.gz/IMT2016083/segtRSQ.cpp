#include <stdio.h>

const int N = 1e5;
int n;
int arr[2*N];

int query(int l, int r);
void build();

int main()
{
    scanf("%d", &n);
    for(int i = 0; i < n; i++)
        scanf("%d", arr + n + i);
    build();
    printf("%d",query(0,5));
}

void build()
{
    for(int i = n-1; i > 0; i--)
        arr[i] = arr[2*i] + arr[2*i+1];
}

int query(int l, int r) {  // sum on interval [l, r)
  int res = 0;
  for (l += n, r += n; l < r; l >>= 1, r >>= 1) {
    if (l&1) res += arr[l++];
    if (r&1) res += arr[--r];
  }
  return res;
}

void modify(int p, int value){ //set value at position p 
    for(arr[p += n] = value; p > 1; p >>= 1)
        arr[p >> 1] = arr[p] + arr[p^1];
}