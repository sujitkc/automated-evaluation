﻿#include <stdio.h>

const int N = 1e5;
int n;
int BIT[2*N];

void build(int arr[]);
void update(int i, int value);
int sum(int l, int r);
int getSum(int i);
void rangeUpdate(int l, int r, int value);

int main(){
    int u;
    scanf("%d %d", &n, &u);
    int arr[n];

    for(int i = 0; i < n; i++) arr[i] = 0;
    
    build(arr);

    int l, r, v;
    for(int i = 0; i < u; i++){
        scanf("%d %d %d", &l, &r, &v);
        rangeUpdate(l, r, v);
    }
    for(int i = 0; i <= n; i++)
        printf("%d ", BIT[i]);
    
    int q, in;
    //scanf("%d", &q);
    while(true){
        scanf("%d", &in);
        printf("%d ", getSum(in));
    }
}

void build(int arr[]){
    for(int i = 0; i <= n; i++) BIT[i] = 0;
    for(int i = 0; i < n; i++)
        update(i, arr[i]);
}

void update(int i, int value){
    i += 1;
    while(i < n+1){
        BIT[i] += value;
        i += (i)&(-i);
    }
}

int getSum(int i){
    i+=1;
    int res = 0;
    while(i > 0){
        res += BIT[i];
        i -= (i) & (-i);
    }
    return res;
}

void rangeUpdate(int l, int r, int value){
    update(l, value);
    update(r+1, -value);
}
