#include <stdio.h>
#include <iostream>

struct Node{
    int data;
    Node* left;
    Node* right;
};

void insert(Node** root, int value);
void inOrderTraversal(Node* root);
bool delNode(Node** root, int value, Node* y);
int findmin(Node* root);

using namespace std;

int main(){
    Node* root = NULL;
    insert(&root, 5);
    insert(&root, 3);
    insert(&root, 1);
    insert(&root, 4);
    insert(&root, 7);
    insert(&root, 6);
    insert(&root, 8);

    inOrderTraversal(root);

    delNode(&root, 3, NULL);
    cout << endl;
    inOrderTraversal(root);

    delNode(&root, 7, NULL);
    cout << endl;
    inOrderTraversal(root);

    delNode(&root, 8, NULL);
    cout << endl;
    inOrderTraversal(root);

    delNode(&root, 5, NULL);
    cout << endl;
    inOrderTraversal(root);

}

void insert(Node** root, int value){
    Node* z = new Node;
    z->data = value;
    z->left = z->right = NULL;

    Node* x = *root;
    Node* y = NULL;

    while(x != NULL){
        y = x;
        if(value > x->data)
            x = x->right;
        else
            x = x->left;
    }
    if(y == NULL)
        (*root) = z;
    else if(y->data > value)
        y->left = z;
    else    
        y->right = z;
}

bool delNode(Node** root, int value, Node* y){
    if(*root == NULL)
        return false;
    Node* x = *root;
    //Node* y = NULL;

    while(x->data != value){
        y = x;
        if(value > x->data)
            x = x->right;
        else
            x = x->left;
    }
    //printf("\nthe parent is %d\nthe child is %d\n", y->data, x->data);

    //No Children
    if(x->left == NULL && x->right == NULL){
            if(y->left == x)
                y->left = NULL;
            else
                y->right = NULL;
    
        delete x;
        return true;
    }

    //One child
    if((x->left == NULL && x->right != NULL) || (x->left != NULL && x->right == NULL)){
        if(y->left == x){
            if(x->left == NULL){
                y->left = x->right;
            }
            else
                y->left = x->left;
        }
        else{
            if(x->left == NULL){
                y->right = x->right;
            }
            else
                y->right = x->left;
        }
        delete x;
        return true;
    }

    //Two Children
    if((x->left != NULL && x->right != NULL)){
        int k = findmin(x->right);
        //cout << "The minimum is " << k << endl;
        x->data = k;
        //cout << "going to right sub tree" << endl;
        delNode(&(x->right), k, x);
    }
    
}

void inOrderTraversal(Node* root)
{
    if(root == NULL)
        return;
    inOrderTraversal(root->left);
    cout << root->data << " ";//("%d ", root->data);
    inOrderTraversal(root->right);
}

int findmin(Node* root){
    Node* current = root;
    Node* temp;
    while(current != NULL){
        temp = current;
        current = current->left;
    }
    return temp->data;
}