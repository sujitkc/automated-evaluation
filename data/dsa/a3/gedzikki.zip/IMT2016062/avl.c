#include<stdio.h>
#include<stdlib.h>
struct Node{
    int key;
    struct Node *left;
    struct Node *right;
    int height;
};
int max(int a,int b){
    if(a>b){
      return a;
    }
    else{
      return b;
    }
}
int height(struct Node *root){
    if (root==NULL)
        return 0;
    return root->height;
}
struct Node *rightR(struct Node *y){
    struct Node *x=y->left;
    struct Node *z=x->right;
    x->right=y;
    y->left=z;
    y->height=max(height(y->left),height(y->right))+1;
    x->height=max(height(x->left),height(x->right))+1;
    return x;
}
struct Node *leftR(struct Node *y){
    struct Node *x=y->right;
    struct Node *z=x->left;
    y->left=y;
    x->right=z;
    x->height=max(height(y->left),height(y->right))+1;
    y->height=max(height(x->left),height(x->right))+1;
    return x;
}
int balance(struct Node *root){
    if (root==NULL)
        return 0;
    else
      return height(root->left)-height(root->right);
}
struct Node* insert(struct Node* node, int key){
    if (node==NULL){
        struct Node* node=(struct Node*)malloc(sizeof(struct Node));
        node->key=key;
        node->left=NULL;
        node->right=NULL;
        node->height=1;
        return(node);
    }
    if (key<node->key)
        node->left=insert(node->left,key);
    else if (key>node->key)
        node->right=insert(node->right,key);
    else
        return node;
    node->height=1+max(height(node->left),height(node->right));
    int balanc=balance(node);
    if (balanc>1&&key<node->left->key)
        return rightR(node);
    if (balanc<-1&&key>node->right->key)
        return leftR(node);
    if (balanc>1&&key>node->left->key){
        node->left=leftR(node->left);
        return rightR(node);
    }
    if (balanc<-1&&key<node->right->key){
        node->right=rightR(node->right);
        return leftR(node);
    }
    return node;
}
struct Node * min(struct Node* node){
    struct Node* current=node;
    while (current->left!=NULL)
        current=current->left;
    return current;
}
struct Node* deleteNode(struct Node* root, int key){
    if (root==NULL)
        return root;
    if (key<root->key)
        root->left=deleteNode(root->left,key);
    else if(key>root->key)
        root->right=deleteNode(root->right,key);
    else{
        if( (root->left==NULL)||(root->right==NULL) ){
            struct Node *temp=root->left?root->left:root->right;
            if (temp==NULL){
                temp=root;
                root=NULL;
            }
            else
             *root=*temp;
            free(temp);
        }
        else{
            struct Node* temp=min(root->right);
            root->key=temp->key;
            root->right=deleteNode(root->right,temp->key);
        }
    }
    if (root==NULL){
      return root;
    }
    root->height=1+max(height(root->left),height(root->right));
    int balanc=balance(root);
    if (balanc>1&& balance(root->left)>=0)
        return rightR(root);
    if (balanc>1&& balance(root->left)<0){
        root->left=leftR(root->left);
        return rightR(root);
    }
    if (balanc<-1&&balance(root->right)<=0)
        return leftR(root);
    if (balanc<-1&&balance(root->right)>0){
        root->right=rightR(root->right);
        return leftR(root);
    }
    return root;
}
void pre(struct Node *root){
    if(root!=NULL){
        printf("%d ",root->key);
        pre(root->left);
        pre(root->right);
    }
}
void inorder(struct Node* root)
{
  if(root!=NULL)
  {
    inorder(root->left);
    printf("%d ",root->key);
    inorder(root->right);
  }
}
int main(){
  struct Node *root=NULL;
    root=insert(root,9);
    root=insert(root,5);
    root=insert(root,10);
    root=insert(root,0);
    root=insert(root,6);
    printf("AVL IN IN-ORDER--> \n");
    inorder(root);
    root=deleteNode(root,10);
    printf("after deletion\n");
    inorder(root);
    return 0;
}
