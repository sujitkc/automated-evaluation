#include<stdio.h>
#include<math.h>
int minv(int a,int b){
  if(a<=b){
    return a;
  }
  else{
    return b;
  }
}
int construct(int arr[], int low, int high, int *st, int pos){
    if (low == high)
    {
        st[pos] = arr[low];
        return arr[low];
    }
    int mid = (high+low)/2;
    st[pos] =  minv(construct(arr, low, mid, st, pos*2+1),construct(arr, mid+1, high, st, pos*2+2));
    return st[pos];
}
int *create(int arr[], int n){
    int x = (int)(ceil(log2(n)));                        //the line 22 and 23 are used to define the size of segment tree
    int max = 2*(int)pow(2, x) - 1;                               //Maximum size of segment tree
    int *st=(int*)malloc(max*sizeof(int));               //defining dynamic size
    construct(arr, 0, n-1, st, 0);
    return st;
}
int min1(int *st, int low, int high, int qs, int qe, int in){
    if(qs <= low && qe >= high){
        return st[in];
      }
    int mid = (low+high)/2;
    return minv(min1(st, low, mid, qs, qe, 2*in+1),min1(st, mid+1, high, qs, qe, 2*in+2));
}
int min(int *st, int n, int qs, int qe){
    if (qs < 0 || qe > n-1 || qs > qe){
        printf("invalid");
        return -1;
    }
    return min1(st, 0, n-1, qs, qe, 0);
}
int main(){
  int arr[] = {1,3,5,-1,6};
    int n = sizeof(arr)/sizeof(arr[0]);
    int *st = create(arr, n);
    int qs = 1;                                                    // Starting index
    int qe = 3;                                                    // Ending index
    printf("minimum value of range= %d\n",min(st, n, qs, qe));
    return 0;
}
