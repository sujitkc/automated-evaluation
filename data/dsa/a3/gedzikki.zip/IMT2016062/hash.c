#include<stdio.h>
#include<math.h>
#include<stdlib.h>
struct point{
    int a,b,prime,n;
    int *arr;
};
int primecheck(int n){
    int a=sqrt(n);
    for(int i=2;i<=a;i++){
        if(i%n==0){
            return 0;
        }
    }
    return 1;
}
int primefind(int m){
    int x1=6*m+1;
    int x2=6*m-1;
    if(primecheck(x1)){
        return x1;
    }
    return x2;
}
int finda(int p){
    return sqrt(p);
}
int findb(int a,int p){
    return rand()%a;
}
int main(){
    int n;
    scanf("%d",&n);
    int *marr;
    marr=malloc(sizeof(int)*n);
    for(int i=0;i<n;i++){
        scanf("%d",&marr[i]);
    }
    struct point *arr[2*n];
    for(int i=0;i<2*n;i++){
        arr[i]=NULL;
    }
    int prime=primefind(2*n);
    int a=finda(prime);
    int b=findb(a,prime);
    int m=2*n;
    int k;
    for(int i=0;i<n;i++){
        k=((marr[i]*a+b)%prime)%m;
        if(arr[((marr[i]*a+b)%prime)%m]==NULL){
            arr[k]=malloc(sizeof(struct point));
            arr[k]->n=1;
        }
        else{
            arr[k]->n++;
        }
    }
    for(int i=0;i<m;i++){
        if(arr[i]!=NULL){
            arr[i]->prime=primefind(2*(arr[i]->n));
            arr[i]->a=finda(arr[i]->prime);
            arr[i]->b=findb(arr[i]->a,arr[i]->prime);
            arr[i]->arr=malloc(sizeof(int)*2*(arr[i]->n));
            for(int j=0;j<2*arr[i]->n;j++){
                arr[i]->arr[j]=-1;
            }
        }
    }
    int temp;
    for(int i=0;i<n;i++){
        k=((marr[i]*a+b)%prime)%m;
        temp=((marr[i]*(arr[k]->a)+arr[k]->b)%arr[k]->prime)%(arr[k]->n*2);
        arr[k]->arr[temp]=marr[i];
    }
    for(int i=0;i<m;i++){
        if(arr[i]!=NULL){
            for(int j=0;j<(arr[i]->n)*2;j++){
                printf("%d ",arr[i]->arr[j]);
            }puts("");
        }
    }
    return 0;
}
