#include<stdio.h>
#include<string.h>
#include<math.h>

int check(int n,int len,char sub[],char string[]){
    int i;
    for(i=0;i<len;i++)
    {
        if(sub[i]!=string[i+n-1])
            return 0;
    }
    printf("Same string at index %d\n",(n-len)+1);
    return 0;
}
int main(){
    char string[10000],sub[1000];
    printf("Main string-->");
    gets(string);
    printf("Sub string-->");
    gets(sub);
    int lstring,lsub;
    lstring=strlen(string);
    lsub=strlen(sub);
    int prime=3,i,sc=0;
    for(i=0;i<lsub;i++){
        sc=sc+sub[i]*pow(prime,i);
      }
    int s=0;
    for(i=0;i<lsub;i++){
        s=s+string[i]*pow(prime,i);
      }
    if(s==sc){
        check(i-1,lsub,sub,string);
      }
    for(i=lsub;i<lstring;i++){
        s=(s-string[i-lsub])/prime;
        s=s+string[i]*pow(prime,lsub-1);
        if(s==sc){
            check(i,lsub,sub,string);
          }
    }
    return 0;
}
