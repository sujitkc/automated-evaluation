#include <stdio.h>
#include <stdlib.h>

int sum(int bt[], int i){
	int s = 0;
	while(i>0){
		s += bt[i];
		i -= i & (-i);
	}
	return s;
}
void update(int bt[], int n, int i, int x){
	int index = i+1;
	while(index <= n){
		bt[index] += x;
		index += index & (-index);
	}
}
void create(int arr[], int bt[], int n)
{
	int i;
	for(i=0; i<=n; i++)
		bt[i] = 0;

	for(i=0; i<n; i++)
		update(bt, n, i, arr[i]);
}

int main(){
	int  n;
	printf("array length--> ");
	scanf("%d",&n);
	int arr[n];
	for(int i=0; i<n; i++){
		scanf("%d",&arr[i]);
	}
	int bt[n+1];
	create(arr, bt, n);
	for(int i=1; i<=n; i++)
		printf("%d ",bt[i]);
	int q;
	printf("queries--> ");
	scanf("%d",&q);
	printf("\n");
	printf("sum = %d",sum(bt, q));
}
