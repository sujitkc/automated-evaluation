#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(){
	char *txt,*pattern;
	txt=(char *)malloc(sizeof(char)*100);
	pattern=(char *)malloc(sizeof(char)*10);
	printf("Enter text and pattern:\n");
	scanf("%s%s",txt,pattern);
	int i,j,n,m,p=101,x=0,y=0,h=1,d=10;
	n=strlen(txt);
	m=strlen(pattern);
	for(i=0;i<m;i++){
		x=(d*x+(pattern[i]-'0'))%p;
		y=(d*y+(txt[i]-'0'))%p;
		if(i<m-1)
			h=(d*h)%p;
	}
	for(i=0;i<=n-m;i++){
		if(x==y){
			for(j=0;j<m;j++){
				if(pattern[j]!=txt[i+j])
					break;
			}
			if(j==m){
				printf("match at %d\n",i);	
			}
		}
		y=(d*(y-h*(txt[i]-'0'))+(txt[i+m]-'0'))%p;
	}
}
