#include<stdio.h>
#include<time.h>
#include<stdlib.h>
#include<math.h>
int prime(int k)
{
    for(int i=2;i<=pow(k,1/2);i++)
        if(k%i==0)
            return 0;
    return 1;
}
struct array
{
    int size,a,b;
    int *secondary ;
};

struct node
{
    int value;
    struct node *next;
};

int hash(int x,int m,int a,int b)
{
    int p=10000019;
    return ((a*x+b)%p)%m;
}

int main()
{
    int size=21;
    struct array arr[2*size];
    int num[]={3,6,5,8,29,11,13,15,17,19,21,23,45,40,4,87,67,56,90,88,94};
    srand((unsigned int)time(NULL));
    int r,a0,b;
    label:                                          //find another random number if sigma(Ni)>2*size
    r = rand()%(10000018-1000)+2*1000;
    a0=r;
    r = rand()%(10000018-1000)+2*1000;
    b=r;
    
    for(int i=0;i<2*size;i++)                       // initialise the array
    {
        arr[i].size=0;
        arr[i].a=a0;
        arr[i].b=b;
        arr[i].secondary=NULL;
    }
    
    for(int i=0;i<size;i++)                         //calculate the size of every block of array
    {
        int key=hash(num[i],2*size,a0,b);
        arr[key].size++;
    }
    
    int size_check=0;                               //to check if sigma(Ni)>2*size
    
    for(int i=0;i<size*2;i++)
    {
        size_check+=arr[i].size*arr[i].size;
        if(size_check>2*size)
        {
            goto label;
        }
    }
    
    
    for(int i=0;i<size;i++)
    {
        int k=hash(num[i],2*size,a0,b);
        int s=arr[k].size*arr[k].size;
        if(arr[k].secondary==NULL)
        {
            arr[k].secondary=malloc(sizeof(int)*s);
            for(int l=0;l<s;l++){
                arr[k].secondary[l]=-99999999;
            }
        }
        
        int key=hash(num[i],s,a0,b);
        if(arr[k].secondary[key]==-99999999)
            arr[k].secondary[key]=num[i];
        else
        {
            arr[k].a=-1;
            arr[k].b=-1;
            for(int j=0;j<s;j++)
            {
                if(arr[k].secondary[j]==-99999999)
                {
                    arr[k].secondary[j]=num[i];
                    break;
                }
            }
        }
    }
    
    for(int i=0;i<2*size;i++)
    {
        if(arr[i].a==-1)
        {
            int s=arr[i].size*arr[i].size;
            
            int a[s];
            for(int z=0;z<s;z++)
                a[z]=arr[i].secondary[z];
            
        label1:
            for(int z=0;z<s;z++){
                arr[i].secondary[z]=-99999999;
            }
            int sec_r;
            sec_r = rand()%(10000018-100000)+100000;      //random number for secondary arrays
            int a1=sec_r;
            sec_r = rand()%(10000018-100000)+100000;      //random number for secondary arrays
            int b1=sec_r;
        
            
            for(int z=0;z<s;z++)
                if(a[z]!=-99999999)
                {
                   int key=hash(a[z],s,a1,b1);
                    if(arr[i].secondary[key]==-99999999)
                        arr[i].secondary[key]=a[z];
                    else
                        goto label1;
                    
                }
            
            arr[i].a=a1;
            arr[i].b=b1;
        }
    }
    
    for(int i=0;i<size;i++){
        int s=hash(num[i],2*size,a0,b);
        int y=hash(num[i],arr[s].size*arr[s].size,arr[s].a,arr[s].b);
        printf("%d ",arr[s].secondary[y]);
    }
    
    return 0;
}
