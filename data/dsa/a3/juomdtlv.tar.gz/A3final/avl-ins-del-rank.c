#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
typedef struct node
	{
	int val;
	int h;
	int num;
	struct node *parent;
	struct node *left;
	struct node *right;
	}node;
node *create(int x)
	{
	node *temp=(node*)malloc(sizeof(node));
	temp->val=x;
	temp->h=1;
	temp->num=1;
	temp->parent=NULL;
	temp->left=NULL;
	temp->right=NULL;
	return temp;
	}
int check(node *head)
	{
	int l=0,r=0;
	if(head->left!=NULL)
		{
		l=(head->left)->h;
		}
	if(head->right!=NULL)
		{
		r=(head->right)->h;
		}
	if(abs(l-r)<=1)
		{
		return 1;
		}
	return 0;
	}
int new_h(node *head)
	{
	int l=0,r=0;
	if(head->left!=NULL)
		{
		l=(head->left)->h;
		}
	if(head->right!=NULL)
		{
		r=(head->right)->h;
		}
	if(l>=r)
		{
		return l+1;
		}
	return r+1;
	}
//void up_num(
void print_post(node *head)
	{
//	printf("printing tree ");
	if(head==NULL)
		{
		return;
		}
	printf("value %d has hight %d\n",head->val,head->h);
	print_post(head->left);
	print_post(head->right);
	}
int find_case(node *x,node *y,node *z)
	{
	int count=0;
	if(z->left==y)
		count=count+2;
	else if(z->right==y)
		count=count+4;
	if(y->left==x)
		count=count+6;
	else if(y->right==x)
		count=count+10;
	if(count==8)
		return 1;
	else if(count==14)
		return 2;
	else if(count==12)
		return 3;
	else if(count==10)
		return 4;
	}
	
void ll(node *x,node *y,node *z,node **head)
	{
	int l=0;
	node *z_par=NULL;
	if(z->parent!=NULL)
		{
		z_par=z->parent;
		if(z_par->left==z)
			l=1;
		}
	node *temp_t=y->right;
	y->parent=NULL;
	y->right=NULL;
	z->left=temp_t;
	z->parent=y;
	y->right=z;
	if(z_par!=NULL)
		{
		y->parent=z_par;
		if(l==1)
			{
			z_par->left=y;
			}
		else 
			{
			z_par->right=y;
			}
		return;
		}
	else
		{
		*head=y;
		}
	}
void rr(node *x,node *y,node *z,node **head)
	{
//	printf("in rr\n");
	z->h=(y->h)-1;
	int l=0;
	node *z_par=NULL;
	if(z->parent!=NULL)
		{
		z_par=z->parent;
		if(z_par->left==z)
			l=1;
		}
	node *temp_t=y->left;
	y->parent=NULL;
	y->left=NULL;
	z->right=temp_t;
	z->parent=y;
	y->left=z;
	if(z_par!=NULL)
		{
		y->parent=z_par;
		if(l==1)
			{
			z_par->left=y;
			}
		else 
			{
			z_par->right=y;
			}
		return;
		}
	else
		{
		*head=y;
//	printf("in rr head is %d \n",(*head)->val);
		}
	}
void lr(node *x,node *y,node *z,node **head)
	{
	int tem=x->h;
	y->right=x->left;
	z->left=x;
	x->left=y;
	x->parent=z;
	y->parent=x;
	ll(y,x,z,head);
	y->h=tem;
	z->h=tem;
	x->h=tem+1;
	}

void rl(node *x,node *y,node *z,node **head)
	{
	int tem=x->h;
	y->left=x->right;
	x->right=y;
	z->right=x;
	x->parent=z;
	y->parent=x;
	rr(y,x,z,head);
	y->h=tem;
	z->h=tem;
	x->h=tem+1;
	}

node *search(node *head,int x)
	{
	if(head==NULL)
		{
		return NULL;
		}
	if(head->val==x)
		{
		return head;
		}
	if(x<=head->val)
		{
		return search(head->left,x);
		}
	else
		{
		return search(head->right,x);
		}
	}
void up_num(node *head)
	{
	int sum=1;
	if(head->left!=NULL)
		{
		sum=sum+(head->left)->num;
		}
	if(head->right!=NULL)
		{
		sum=sum+(head->right)->num;
		}
	head->num=sum;
	}
void insert(node **head,int xi)
	{
	if(search(*head,xi)!=NULL)
		{
		printf("already in tree\n");
		return;
		}
	if(*head==NULL)
		{
		*head=create(xi);
		return;
		}
	else
		{
		node *temp=*head;
		node *x=NULL,*y=NULL,*z=NULL;
		while(1)
			{
			if(xi<=(temp->val))
				{
				temp->num=temp->num+1;
				if(temp->left==NULL)
					{
					temp->left=create(xi);
					x=temp->left;
					(temp->left)->parent=temp;
					break;
					}
				temp=temp->left;
				}
			else
				{
				temp->num=temp->num+1;
				if(temp->right==NULL)
					{
					temp->right=create(xi);
					x=temp->right;
					(temp->right)->parent=temp;
					break;
					}
				temp=temp->right;
				}
			}
		y=temp;
		temp->h=new_h(temp);
		temp=temp->parent;

		if(y->parent==NULL)
			{
			return;
			}
		else
			{
			z=y->parent;
			}	
		while(z!=NULL)
			{
			printf("running the loop\n");
			if(check(z)==0)
				{
				printf("not balanceed at %d\n",z->val);
				int c=find_case(x,y,z);
				if(c==1)
					{
					ll(x,y,z,head);
					up_num(x);
					up_num(z);
					up_num(y);
					}
				else if(c==2)
					{
					rr(x,y,z,head);
		//			printf("rotation donn\n");
					up_num(x);
					up_num(z);
					up_num(y);
		//			printf("height updated donn\n");
					}
				else if(c==3)
					{
					lr(x,y,z,head);
					up_num(z);
					up_num(y);
					up_num(x);
					}
				else if(c==4)
					{
					rl(x,y,z,head);
					up_num(z);
					up_num(y);
					up_num(x);
					}
				break;
				}
			z->h=new_h(z);
			x=y;
			y=z;
			z=z->parent;
			}
		return;
		}
	}
node *sussesor(node *head)
	{
	node *temp=head->right;
	while(temp->left!=NULL)
		{
		temp=temp->left;
		}
	return temp;
	}
int num_child(node *head)
	{
	if(head->left==NULL && head->right==NULL)
		{
		return 0;
		}
	if(head->left!=NULL && head->right!=NULL)
		{
		return 2;
		}
	return 1;
	}
void get_nodess(node **x,node **y,node **z,node *papa)
	{
	*z=papa;
	if(papa->left==NULL)
		{
		*y=papa->right;
		}
	else if(papa->right==NULL)
		{
		*y=papa->left;
		}
	else if(((papa->left)->h)>((papa->right)->h))
		{
		*y=papa->left;
		}
	else
		{
		*y=papa->right;
		}

	if(((*y)->left)==NULL)
		{
		*x=(*y)->right;
		}
	else if(((*y)->right)==NULL)
		{
		*x=(*y)->left;
		}
	else if((((*y)->left)->h)==(((*y)->right)->h))
		{
		if((*z)->left==NULL)
			{
			*x=(*y)->right;
			}
		else if((*z)->right==NULL)
			{
			*x=(*y)->left;
			}
		else if((*y)==((*z)->left))
			{
			*x=(*y)->left;
			}
		else
			{
			*x=(*y)->right;
			}
		}
	else if((((*y)->left)->h)>(((*y)->left)->h))
		{
		*x=(*y)->left;
		}
	else
		{
		*x=(*y)->right;
		}
	}


void delete(node **head,int x)
	{
	node *del_me=search(*head,x);
	if(del_me==NULL)
		{
		printf("element not found \n");
		return;
		}
	if(del_me->parent==NULL && del_me->left==NULL && del_me->right==NULL)
		{
		*head=NULL;
		return;
		}
	int num=num_child(del_me);
	int is_head=0;
	node *ff_del=NULL;
	if(del_me->parent==NULL)
		is_head=1;
	if(num==1)
		{
		if(del_me->left!=NULL)
			{
			del_me->val=(del_me->left)->val;
			ff_del=del_me->left;
			}
		else
			{
			del_me->val=(del_me->right)->val;
			ff_del=del_me->right;
			}
		}
	else if(num==2)
		{
		node *ttmp=sussesor(del_me);
		del_me->val=ttmp->val;
		if(ttmp->right==NULL)
			{
			ff_del=ttmp;
			}
		else
			{
			ttmp->val=(ttmp->right)->val;
			ff_del=ttmp->right;
			}
		}
	else
		{
		ff_del=del_me;
		}
	node *papa=ff_del->parent;
	if((ff_del->parent)->left==ff_del)
		{
		(ff_del->parent)->left=NULL;
		}
	else 
		{
		(ff_del->parent)->right=NULL;
		}
	up_num(papa);
	while(papa!=NULL)
		{
		if(check(papa)==0)
			{
			node *x=NULL,*y=NULL,*z=NULL;
			printf("unbalanced due to deleteing at %d\n",papa->val);
			get_nodess(&x,&y,&z,papa);
			int c=find_case(x,y,z);
			if(c==1)
				{
				ll(x,y,z,head);
				papa=y;
				x->h=new_h(x);
				z->h=new_h(z);
				y->h=new_h(y);
				up_num(x);
				up_num(z);
				up_num(y);
				}
			else if(c==2)
				{
				rr(x,y,z,head);
				papa=y;
				x->h=new_h(x);
				z->h=new_h(z);
				y->h=new_h(y);
				up_num(x);
				up_num(z);
				up_num(y);
				}
			else if(c==3)
				{
				lr(x,y,z,head);
				papa=x;
				z->h=new_h(z);
				y->h=new_h(y);
				x->h=new_h(x);
				up_num(z);
				up_num(y);
				up_num(x);
				}
			else if(c==4)
				{
				rl(x,y,z,head);
				papa=x;
				z->h=new_h(z);
				y->h=new_h(y);
				x->h=new_h(x);
				up_num(z);
				up_num(y);
				up_num(x);
				}
			}
		else 
			{
			papa->h=new_h(papa);
			}
		up_num(papa);
		papa=papa->parent;
		}
	}
int rank(int x,node *head,int *ans)
	{
	if(head==NULL)
		{
		return *ans;
		}
	if(head->val==x)
		{
		if(head->left!=NULL)
			{
			*ans=*ans-((head->left)->num);
			}
		return *ans;
		}
	if(x<head->val)//left
		{
		return rank(x,head->left,ans);
		}
	else//right
		{
		if(head->left!=NULL)
			{
			*ans=*ans-((head->left)->num);
			}
		*ans=*ans-1;
		return rank(x,head->right,ans);
		}
	}
int main()
	{
	int scc=0;
	node *head=NULL;
	while(1)
		{
		printf("press 0 to enter delete mode ");
		printf("element to insert: ");
		scanf("%d",&scc);
		if(scc==0)
			break;
		insert(&head,scc);
	//	printf("elemet inserted");
		print_post(head);
		}
	while(1)
		{
		printf("press 0 to enter rank mode ");
		printf("element to delete : ");
		scanf("%d",&scc);
		if(scc==0)
			break;
//		printf("elemten is at pos %d\n",search(head,scc));
		delete(&head,scc);
		print_post(head);
		}
	while(1)
		{
		if(head==NULL)
			return 0;
		int ans=head->num;
		printf("press 0 to exit	");
		printf("element who's rank you want : ");
		scanf("%d",&scc);
		if(scc==0)
			break;
		printf("rank of %d is %d \n",scc,rank(scc,head,&ans));
		}
	}
