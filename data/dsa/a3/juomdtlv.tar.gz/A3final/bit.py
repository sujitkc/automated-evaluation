def getsum(BITTree,i):
    s = 0  #initialize result
    # index in BITree[] is 1 more than the index in arr[]
    i = i+1
    while i > 0:        
        s += BITTree[i]
        i -= i & (-i)
    return s
 
 
def updatebit(BITTree , n , i ,v):    
    i += 1
    while i <= n:
        BITTree[i] += v
        i += i & (-i)
 
 

def construct(arr, n):
    BITTree = [0]*(n+1)
 
    for i in range(n):
        updatebit(BITTree, n, i, arr[i])
    return BITTree
 
 
# Driver code to test above methods
freq = [2, 1, 1, 3, 2, 3, 4, 5, 6, 7, 8, 9]
BITTree = construct(freq,len(freq))
print("enter range (i,j) to get sum from arr[i to j]:")
i=input("i=")
j=input("j=")
print("Sum of elements in arr[i to j] is " + str(getsum(BITTree,j)-getsum(BITTree,i-1)))
print("enter index k which you want to increase by 6")
k=input("k=")
freq[k] += 6
updatebit(BITTree, len(freq), k, 6)
print("Sum of elements in updated arr[i to j] is " + str(getsum(BITTree,j)-getsum(BITTree,i-1)))
 
