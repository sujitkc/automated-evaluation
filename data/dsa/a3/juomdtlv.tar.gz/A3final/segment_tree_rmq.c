#include<stdio.h>
#include<math.h>

int max(int x, int y)
{
if(x>y)
	return x;
else
	return y;
}

int construct(int *narray, int *use, int beg, int end, int index)
{
if(beg==end)
	{
	use[index]=narray[beg];
	return narray[beg];	
	}
else
	{
	use[index] = max(construct(narray,use,beg,(beg+end)/2,2*index+1),construct(narray,use,((beg+end)/2)+1,end,2*index+2));
	return use[index];	
	}
}

void update(int *narray, int *use, int index, int value, int ans)
{
narray[index] = value;
int waste = construct(narray,use,0,ans-1,0);
}

int rmq(int *use, int start, int stop, int beg, int end, int index)
{
if( start<=beg && stop>=end )
	return use[index];

else if( stop<beg || start>end )
	return 0;

else
	return max(rmq(use,start,stop,beg,(beg+end)/2,2*index+1),rmq(use,start,stop,((beg+end)/2)+1,end,2*index+2));
}

int main()
{
int i;
int array[] = {3,1,5,2,6,4};
int size = sizeof(array)/sizeof(*array);
int useless;
int ans=1;
int a = (int)(ceil(log2(6)));

for(i=0;i<a;i+=1)
	ans = ans*2;

int narray[ans];

for(i=0;i<ans;i+=1)
{
	if(i<size)
		narray[i]=array[i];	
	else
		narray[i]=0;
}

int use[2*ans-1];

useless = construct(narray,use,0,ans-1,0);

update(narray,use,1,10,ans);

int start = 1;
int stop = 3;

int final = rmq(use,start,stop,0,ans-1,0);

printf("%d\n",final);

//for(i=0;i<2*ans-1;i+=1)
	//printf("%d\n",use[i]);

}
