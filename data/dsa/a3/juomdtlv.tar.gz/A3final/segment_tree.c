#include<stdio.h>
#include<stdlib.h>
void build_tree(int *a, int t)
{
	int i;
	for(i=t-2;i>=0;i--)
	{
		a[i]=a[2*i+1]+a[2*i+2];
	}
	
}
void update(int *a, int i, int x)
{
	int j;
	a[i]=x;
	for(j=(i+1)/2-1;j>=0;j=(j+1)/2-1)
	{
		a[j]=a[2*j+1]+a[2*j+2];
	}
}
void print(int *a, int size)
{
	int i;
	for(i=0;i<size;i++)
	{
		printf("%d	",a[i]);
	}
}
int query(int *a, int t, int l, int r)
{
	int sum=0;
	for(l=t-1+l, r=t-1+r; l<r; l=(l-1)/2,r=(r-1)/2)
	{
		if(l%2==0)
			sum=sum+a[l++];
		if(r%2==1)
			sum=sum+a[r--];
	}
	if(l==r)
		return sum+a[l];
	else
		return sum;
}
int main()
{
	int n,t=2,i;
	scanf("%d",&n);
	while(t<n)
	{
		t=2*t;
	}
	int size=2*t-1;
	int a[size];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[t-1+i]);
	}
	while((t-1+i)<size)
	{
		a[t-1+i]=0;
		i++;
	}
	build_tree(a,t);
	print(a,size);
	printf("\n%d\n",query(a,t, 1,n-1));
	update(a,3,7);
	print(a,size);
	printf("\n%d\n",query(a,t, 1,n-1));
}
