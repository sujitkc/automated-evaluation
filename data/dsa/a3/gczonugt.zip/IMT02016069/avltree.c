#include <stdio.h>
#include <stdlib.h>
struct node{
    int data;
    struct node *left;
    struct node *right;
}
int nodecreate(int data){
	struct node* node = (struct node*) malloc(sizeof(struct *node));
	node->data=data;
	node->left=NULL;
	node->right=NULL;
	return (node);
}
int binarydelete(struct node* root, int data){}
    if (root == NULL){
        return root;
    }
    if (data<root->data){
        root->left = binarydelete(root->left, data);
    }
    else if (data > root->data){
            root->right = binarydelete(root->right, data);
    }
    else{
        if (root->left == NULL){
            struct node *temp = root->right;
            free(root);
            return temp;
        }
        else if (root->right == NULL){
            struct node *temp = root->left;
            free(root);
            return temp;
        }
        struct node* temp = minValueNode(root->right)
        root->data = temp->data;
        root->right = binarydelete(root->right, temp->data);
    }
    return root;
}
int binarysearch(struct node* root, int data){
    if (root==NULL){
        return root->value;
    }
    if(data>root->data){
        binarysearch(struct node* root->right, int data);
    }
    else{
        binarysearch(struct, node* rott->left, int data);
    }
}
int binaryinsert(struct node* node, int data){
    if (node == NULL){
         return nodecreate(data);
    }
    if (data < node->data){
        node->left  = binaryinsert(node->left, data);
    }
    else if (data > node->data){
        node->right = binaryinsert(node->right, data);
    }
    return node;
}
//this function will work only if the binaryarray used as a parameter is sorted.
struct node* constructtree(struct node* root, int binaryarray[], int start, int end){
    int mid = (start+end)/2;
    struct node* root = nodecreate(binaryarray[mid]);
    root->left = constructtree(binaryarray[], start, mid);
    root->right = constructtree(binaryarray[], mid+1, end);
}
void main(){
    int end, data;
    int binaryarray[50]={30,26,34,20,27,31,40};
    end = sizeof(binaryarray[])/sizeof(binaryarray[0]);
    struct node* root = nodecreate(30);
    root->left = nodecreate(26);
    root->right = nodecreate(34);
    root->left->left = nodecreate(20);
    root->left->right = nodecreate(27);
    root->right->left = nodecreate(31);
    root->right->right = nodecreate(40);
    printf("enter the number you want to search\n");
    scanf("%d", %data);
    binarysearch(data);
}
