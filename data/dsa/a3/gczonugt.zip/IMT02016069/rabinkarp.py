mainstring = raw_input("enter the main string")
substring = raw_input("enter the sub-string you want to find")
l1=len(mainstring)
l2=len(substring)
prm = 137
mainhash=0
subhash=0
for j, i in enumerate(substring):
    subhash=subhash+int(i)*(prm)^^j
for j, i in enumerate(mainstring):
    mainhash=mainhash+int(i)*(prm)^^j
y=mainhash
mainhash=mainhash%99
hashpattern = hashfunction(substring)
for i in range(l1-l2+1):
    y=y/prm-mainstring[i]+mainstring[i+l2]*prm^^(l2)
    mainhash=y%99
    if (subhash==mainhash):
        for j in range(l2):
            if (mainstring(i+j)!=substring(j)):
                break
            print "substring found at index - " +i
