#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
struct hf
{
	int a,b,p,num,*sht;
};

int checkprime(int n)
{
	float s = sqrt(n);
	for(int i = 2;i<=s;i++)
	{
		if(n%i == 0)
		{
			return 0;
		}
	}
	return 1;
}

int power(int n, int p)
{
	int ans = 1;
	while(p >0)
	{
		if(p%2 == 1)
		{
			ans = ans*n;
		}
		n = n*n;
		p = p/2;
	}
	return ans;
}

int Search(int key, struct hf *HashTable[], struct hf *PrimaryHash,int HashSize)
{
	int ph = ((PrimaryHash->a*key + PrimaryHash->b)%PrimaryHash->p)%HashSize;
	if(ph<0)
	{
		ph += HashSize;
	}
	if(HashTable[ph]->num == 0)
	{
		return 0;
	}
	int sh = ((HashTable[ph]->a*key + HashTable[ph]->b)%HashTable[ph]->p)%power(HashTable[ph]->num,2);
	if(sh<0)
	{
		sh += power(HashTable[ph]->num,2);
	}
	if(HashTable[ph]->sht[sh] == key)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}


int main()
{	
	srand(time(0));
	int n;
	printf("Enter number of elements: ");
	scanf("%d",&n);
	int HashSize = 2*n;
	struct hf *PrimaryHash = (struct hf*)malloc(sizeof(struct hf));
	int prime;
	do
	{
		prime = 2 + rand();
	}
	while(checkprime(prime) == 0 || prime < HashSize);
	PrimaryHash->p = prime;
	PrimaryHash->a = 1 + rand() % prime;
	PrimaryHash->b = rand() % prime;
	
	printf("p = %d a = %d b = %d\n\n",PrimaryHash->p,PrimaryHash->a,PrimaryHash->b);
	struct hf *HashTable[HashSize]; 
	
	for(int x = 0; x<HashSize; x++)
	{
		HashTable[x] = (struct hf*)malloc(sizeof(struct hf));
		HashTable[x]->num = 0;
		do
		{
			HashTable[x]->p = rand();
		}
		while(HashTable[x]->p < power(n,2));
		HashTable[x]->a = 1 + rand() % HashTable[x]->p;
		HashTable[x]->b = rand() % HashTable[x]->p;
	}
	
	for(int i = 0; i<HashSize; i++)
	{
		for(int j = 0; j<power(HashTable[i]->num,2) ;j++)
		{
			printf("%d ",HashTable[i]->sht[j]);
		}
		printf("\n");
	}

	int num1;
	for(int x = 0; x<n; x++)
	{
		printf("Enter numbers: ");
		scanf("%d",&num1);
		int ph = ((PrimaryHash->a*num1 +PrimaryHash->b)%PrimaryHash->p)%HashSize;
		if(ph < 0)
		{
			ph += HashSize;
		}
		printf("%d\n\n",ph);
		HashTable[ph]->num++;
		int ss = power(HashTable[ph]->num,2);
		printf("%d %d %d %d\n\n",HashTable[ph]->p,HashTable[ph]->a,HashTable[ph]->b,HashTable[ph]->num);
		HashTable[ph]->sht = (int*)realloc(HashTable[ph]->sht,ss);
		for(int i = power(HashTable[ph]->num -1,2);i<ss;i++)
		{
			HashTable[ph]->sht[i] = 0;
		}
		int sh = (((HashTable[ph]->a)*num1 + HashTable[ph]->b)%HashTable[ph]->p)%ss;
		if(sh < 0)
		{
			sh+=ss;
		}
		printf("%d\n\n",sh);
		if(HashTable[ph]->sht[sh] != 0)
		{
			printf("yep\n");
			printf("%d\n",ss);
			int *secarr = (int *)calloc(ss,sizeof(int));
			for(int i = 0; i<ss; i++)
			{
				if(HashTable[ph]->sht[i] != 0)
				{
					secarr[i] = HashTable[ph]->sht[i]; 
				}
			}
			for(int i = 0; i<ss; i++)
			{
				printf("%d ",secarr[i]);
			}
			printf("\n");
			int flag;
			do
			{
				flag = 0;
				do
				{
					HashTable[ph]->p = rand();
				}
				while(HashTable[ph]->p < power(n,2));
				HashTable[ph]->a = 1 + rand() % HashTable[ph]->p;
				HashTable[ph]->b = rand() % HashTable[ph]->p;
				printf("%d %d %d %d\n\n",HashTable[ph]->p,HashTable[ph]->a,HashTable[ph]->b,HashTable[ph]->num);
				for(int i = 0; i<ss; i++)
				{
					HashTable[ph]->sht[i] = 0;
				}
				for(int i = 0; i<ss; i++)
				{
					if(secarr[i] != 0)
					{
						printf("secarr = %d\n\n",secarr[i]);
						sh = (((HashTable[ph]->a)*secarr[i] + HashTable[ph]->b)%HashTable[ph]->p)%ss;
						printf("new sh = %d\n\n",sh);
						if(sh<0)
						{
							sh+=ss;
						}
						if(HashTable[ph]->sht[sh] != 0)
						{
							flag = 1;
							break;
						}
						else
						{
							HashTable[ph]->sht[sh] = secarr[i];
						}
					}
				}
				if(flag == 0)
				{
					int sh = (((HashTable[ph]->a)*num1 + HashTable[ph]->b)%HashTable[ph]->p)%ss;
					if(sh < 0)
					{
						sh+=ss;
					}
					if(HashTable[ph]->sht[sh] != 0)
					{
						flag = 1;
					}			
					else
					{
						HashTable[ph]->sht[sh] = num1;
					}
				}	
			}
			while(flag == 1);
		}
		else
		{
			HashTable[ph]->sht[sh] = num1;
		}
	}
	for(int i = 0; i<HashSize; i++)
	{
		printf(" i = %d\n",i);
		for(int j = 0; j<power(HashTable[i]->num,2) ;j++)
		{
			printf("%d ",HashTable[i]->sht[j]);
		}
		printf("\n");
	}
	int key;
	printf("Enter search query: ");
	scanf("%d",&key);
	printf("%d\n",Search(key,HashTable,PrimaryHash,HashSize));
}
