#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
int checkifprime(int n)
{
	float s = sqrt(n);
	for(int i = 2;i<=s;i++)
	{
		if(n%i == 0)
		{
			return 0;
		}
	}
	return 1;
}
int power(int n, int p)
{
	int ans = 1;
	while(p >0)
	{
		if(p%2 == 1)
		{
			ans = ans*n;
		}
		n = n*n;
		p = p/2;
	}
	return ans;
}
int main()
{
	char string[1000000];
	char substr[1000];
	printf("Enter string: ");
	fgets(string,1000000,stdin);
	int len1 = strlen(string)-1;
	string[len1] = '\0';
	printf("Enter substring: ");
	fgets(substr,1000,stdin);
	int len2 = strlen(substr)-1;
	printf("%s%s",string,substr);
	int sum1 = 0,sum2 = 0,i,j;
	int prime;
	do
	{
		prime = (rand() % 1000000) + 100;
	}
	while(checkifprime(prime) == 0);
	printf("%d\n",prime);
	printf("%d\n%d\n",len1,len2);
	printf("%d\n%d\n",sum1,sum2);
	for(i = 0; i<len2; i++)
	{
		sum1 = (2*sum1 + (string[i]-48))%prime;
		sum2 = (2*sum2 + (substr[i]-48))%prime;
	}
	if(sum1 == sum2)
	{
		for(i = 0; i<len2; i++)
		{
			if(string[i] != substr[i])
			{
				break;
			}
		}
		if(i == len2)
		{
			printf("String found at 0\n");
		}
	}
	printf("%d\n",len1-len2);
	for(i = 0; i < len1-len2; i++)
	{
		sum1 = ((sum1 - (string[i]-48)*power(2,len2 -1))*2 + (string[len2+i]-48))%prime;
		if(sum1 == sum2)
		{
			for(j = 0; j<len2; j++)
			{
				if(string[i+j+1] != substr[j])
				{
					break;
				}
			}
			if(j == len2)
			{
				printf("String found at %d\n\n",i+1);
			}
		}
	}	
}