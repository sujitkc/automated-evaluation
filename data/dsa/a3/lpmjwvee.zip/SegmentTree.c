#include<stdio.h>
#include<stdlib.h>

int power(int n, int p)
{
	int ans = 1;
	while(p>0)
	{
		if(p%2 == 1)
		{
			ans = ans*n;
		}
		n = n*n;
		p = p/2;
	}
	return ans;
} 

int size(int n)
{
	int count = 0;
	for(int i = 0; i<1000; i++)
	{
		if(power(2,i) > n)
		{
			count++;
			if(count == 2)
			{
				return power(2,i);
			}
		}
	}
}

int min(int arr[],int a,int b)
{
	if(arr[a]<arr[b])
	{
		return a;
	}
	else
	{
		return b;
	}
}
int Maketree(int tree[], int ts, int arr[], int n)
{
	while(ts>0)
	{
		for(int i = 0; i<=n/2;i++)
		{

			if(arr[tree[ts+(2*i)]] < arr[tree[ts+(2*i)+1]]|| tree[ts+(2*i)+1] == -1)
			{
				tree[(n/2)+i] = tree[ts+2*i];
			}
			else
			{
				tree[(n/2)+i] = tree[ts+(2*i)+1];
			}
		}
		n = n/2;
		ts = ts/2;
	}
}

void Update(int index, int value,int ts,int tree[], int arr[])
{
	int in = ts/2 + index;
	arr[tree[in]] = value;
	while(in > 0)
	{
		if(in%2 == 1)
		{;
			if(arr[tree[in]]>arr[tree[in+1]])
			{
				tree[(in-1)/2] = tree[in+1];
			}
			else
			{
				tree[(in-1)/2] = tree[in];
			}
		}
		else
		{
			if(arr[tree[in]]>arr[tree[in-1]])
			{
				tree[(in-1)/2] = tree[in-1];
			}
			else
			{
				tree[(in-1)/2] = tree[in];
			}
		}
		in = (in-1)/2;
	}
}

int RMQ(int tree[], int ts, int i, int j, int node, int rangeleft, int rangeright,int arr[])
{
	if(i == rangeleft && j == rangeright)
	{
		return tree[node];
	}
	else if(j<=(rangeright+rangeleft-1)/2)
	{
		return RMQ(tree,ts,i,j,2*node+1,rangeleft,(rangeright+rangeleft-1)/2,arr);
	}
	else if(i > (rangeright+rangeleft-1)/2)
	{
		return RMQ(tree,ts,i,j,2*node+2,((rangeright+rangeleft-1)/2)+1,rangeright,arr);
	}
	else
	{
		return min(arr,RMQ(tree,ts,i,(rangeright+rangeleft-1)/2,2*node+1,rangeleft,(rangeright+rangeleft-1)/2,arr),RMQ(tree,ts,((rangeright+rangeleft-1)/2)+1,j,2*node+2,((rangeright+rangeleft-1)/2)+1,rangeright,arr));
	}
}

int main()
{
	int arr[] = {24,3,17,78,45,100};
	int n = 6;
	int ts = size(n) - 1;
	int *tree = (int*)calloc(ts,sizeof(int));
	for(int i = 0; i<n; i++)
	{
		tree[ts/2 + i] = i;
		if(i == n-1)
		{
			i++;
			while(i<ts)
			{
				tree[ts/2 + i] = -1;
				i++;
			}
		}
	}
	Maketree(tree,ts/2,arr,ts/2);
	for(int i = 0; i<ts; i++)
	{
		printf("%d ",tree[i]);
	}
	printf("\n");
	Update(1,280,ts,tree,arr);
	for(int i = 0; i<ts; i++)
	{
		printf("%d ",tree[i]);
	}
	printf("\n%d\n",arr[RMQ(tree,ts,4,5,0,0,7,arr)]);
}