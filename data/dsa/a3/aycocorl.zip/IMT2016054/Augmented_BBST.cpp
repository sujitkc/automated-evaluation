#include<iostream>
#include<stdlib.h>
#include<limits.h>
using namespace std;

class AVL{
	struct node{
		int data, height, size, sum, minGap;
		node *left, *right;

		static int get_size(node *x){
			if(!x) return 0;
			return x->size;
		}

		static int get_sum(node *x){
			if(!x) return 0;
			return x->sum;
		}

		static int get_min_gap(node *x){
			if(!x) return INT_MAX;
			return x->minGap;
		}

		void update(){
			size = get_size(left) + get_size(right) + 1;
			sum = get_sum(left) + get_sum(right) + data;

			{
				minGap = min(get_min_gap(left), get_min_gap(right));
				if(left) minGap = min(minGap, data - AVL(this).inorder_predecessor(this)->data);
				if(right) minGap = min(minGap, AVL(this).inorder_successor(this)->data - data);
			}
		}

		node(int d, node *l = NULL, node *r = NULL){
			height = 0;
			size = 1;
			sum = d;
			minGap = INT_MAX;
			data = d;
			left = l;
			right = r;
		}
	} *root;

	int get_height(node *x){
		if(!x) return -1;
		else return x->height;
	}

	AVL::node* inorder_successor(node *x);

	void set_height(node *x){
		x->height = AVL::max(get_height(x->left), get_height(x->right)) + 1;
	}

	int balance_factor(node *x){
		return get_height(x->left) - get_height(x->right);
	}

	static int max(int x, int y){
		return ((x > y) ? x : y);
	}

	static int min(int x, int y){
		return ((x < y) ? x : y);
	}

	void right_rotate(node *&x){
		node *newParent = x->left;
		node *moveSubTree = newParent->right;

		newParent->right = x;
		x->left = moveSubTree;
		set_height(x);

		x->update();
		newParent->update();

		x = newParent;
	}

	void left_rotate(node *&x){
		node *newParent = x->right;
		node *moveSubTree = newParent->left;

		newParent->left = x;
		x->right = moveSubTree;
		set_height(x);

		x->update();
		newParent->update();

		x = newParent;
	}

	void rebalance(node *&x);
	bool insert(node *&x, int k);
	bool delete_node(node *&x, int k);
	AVL::node* inorder_predecessor(node *x);
	void pretty_print(node *x, int indent);
	void inorder_traversal(node *x);

public:

	AVL(node *rt = NULL){
		root = rt;
	}

	bool insert(int k){
		return insert(root, k);
	}

	bool search(int k);

	bool delete_node(int k){
		return delete_node(root, k);
	}

	void pretty_print(){
		pretty_print(root, 0);
	}

	void inorder_traversal(){
		inorder_traversal(root);
	}

	int kth_smallest_element(int k);
	int rank(int k);
	int prefix_sum(int k);

	int min_gap(){
		return node::get_min_gap(root);
	}

	int average(){
		return node::get_sum(root)/node::get_size(root);
	}

	int num_btwn(int a, int b){
		return abs(rank(a) - rank(b)) + 1;
	}
};

int AVL::prefix_sum(int k){
	node *temp = root;
	int ans = 0;

	while(temp){
		if(temp->data == k) return ans + node::get_sum(temp->left) + temp->data;
		else if(k > temp->data) ans += node::get_sum(temp->left) + temp->data, temp = temp->right;
		else temp = temp->left;
	}

	return 0;
}

bool AVL::search(int k){
	node *temp = root;
	while(temp){
		if(k > temp->data) temp = temp->right;
		else if(k < temp->data) temp = temp->left;
		else return true;
	}
	return false;
}

void AVL::rebalance(node *&x){
	node *&heavyChild = (get_height(x->left) > get_height(x->right)) ? x->left : x->right;

	int bfhc = balance_factor(heavyChild), bfx = balance_factor(x);

	//zig-zag : rotation  of child
	if(bfhc * bfx < 0){
		(bfhc == -1) ? left_rotate(heavyChild) : right_rotate(heavyChild);
	}

	//zig-zag : rotation of parent
	//zig-zig
	(bfx < 0) ? left_rotate(x) : right_rotate(x);
}

bool AVL::insert(node *&x, int k){
	if(!x){
		x = new node(k);
		//Overflow
		if(!x) return false;
		return true;
	}

	bool retVal;

	if(k > x->data) retVal = insert(x->right, k);
	else if(k < x->data) retVal = insert(x->left, k);
	else return false;

	x->update();

	if(abs(balance_factor(x)) > 1) rebalance(x);
	set_height(x);

	return retVal;
}

bool AVL::delete_node(node *&x, int k){
	if(!x) return false;

	bool retVal;

	if(k > x->data) retVal = delete_node(x->right, k);
	else if(k < x->data) retVal = delete_node(x->left, k);
	else{
		//1 or 0 children
		if(!x->left || !x->right){
            node *temp = x->left ? x->left : x->right;

			delete x;
			x = NULL;
			//1 child
            if(temp) x = temp;
			return true;
        }
		//2 children
        else{
            node *temp = inorder_predecessor(x);
            x->data = temp->data;
            retVal = delete_node(x->left, temp->data);
        }
	}

	if(abs(balance_factor(x)) > 1)	rebalance(x);
	set_height(x);
	x->update();

	return retVal;
}

AVL::node* AVL::inorder_predecessor(node *x){
	x = x->left;

	while(x->right){
		x = x->right;
	}

	return x;
}

AVL::node* AVL::inorder_successor(node *x){
	x = x->right;

	while(x->left){
		x = x->left;
	}

	return x;
}

int AVL::kth_smallest_element(int k){
	node *temp = root;
	int t;

	while(temp){
		t = node::get_size(temp->left) + 1;

		if(k == t) return temp->data;

		if(k > t){
			k -= t;
			temp = temp->right;
		}
		else{
			temp = temp->left;
		}
	}

	return INT_MAX;
}

int AVL::rank(int k){
	node *temp = root;
	int ans = 1;

	while(temp){
		if(k > temp->data){
			temp = temp->right;
		}
		else if(k < temp->data){
			ans += node::get_size(temp->right) + 1;
			temp = temp->left;
		}
		else{
			return ans + node::get_size(temp->right);
		}
	}

	return ans;
}

void AVL::inorder_traversal(node *x){
	if(!x){
		return;
	}

	inorder_traversal(x->left);
	cout<<x->data<<" ";
	inorder_traversal(x->right);
}

void AVL::pretty_print(node *x, int indent){
	if(!x){
		return;
	}
	for(int i = 0; i < indent; ++i){
		cout<<"\t";
	}
	cout<<x->data<<endl;
	pretty_print(x->left, indent+1);
	pretty_print(x->right, indent+1);
}

int main(){
	AVL t;
	int n, k;
	while(true){
		cout<<"1 - Insert \n2 - Delete \n3 - Search \n4 - In-order traversal \n5 - Kth smallest element \n6 - Rank of a number\n7 - Minimum Diff \n8 - Average \n9 - Numbers between \n10 - Prefix Sum \n11 - Exit \nChoice: ";
		cin>>n;
		cout<<endl;

		switch(n){
			case 1:
				cout<<"Number to insert: ";
				cin>>k;
				if(t.insert(k)) cout<<"Insertion successful!\n";
				else cout<<"Insertion unsuccessful!\n";
				break;

			case 2:
				cout<<"Number to delete: ";
				cin>>k;
				if(t.delete_node(k)) cout<<"Deletion successful!\n";
				else cout<<"Deletion unsuccessful!\n";
				break;

			case 3:
				cout<<"Number to search: ";
				cin>>k;
				if(t.search(k)) cout<<"Found number!\n";
				else cout<<"Number not present in tree!\n";
				break;

			case 4:
				t.inorder_traversal();
				cout<<endl;
				break;

			case 11:
				exit(0);

			case 5:
				cout<<"K: ";
				cin>>k;
				cout<<"Ans: "<<t.kth_smallest_element(k)<<endl;
				break;

			case 6:
				cout<<"Number: ";
				cin>>k;
				cout<<"Ans: "<<t.rank(k)<<endl;
				break;

			case 7:
				cout<<"Min diff: "<<t.min_gap()<<endl;
				break;

			case 8:
				cout<<"Average: "<<t.average()<<endl;
				break;

			case 9:
				cout<<"Num1: ";
				cin>>k;
				cout<<"Num2: ";
				cin>>n;
				cout<<"Ans: "<<t.num_btwn(k, n)<<endl;
				break;

			case 10:
				cout<<"Number: ";
				cin>>k;
				cout<<"Ans: "<<t.prefix_sum(k)<<endl;
				break;

			default:
				t.pretty_print();
				cout<<"\nInvalid choice!\n";
		}
		cout<<endl;
	}
	return 0;
}
