#include <stdio.h>
#include <stdlib.h>
struct Node{
	int key;
	struct Node *left;
	struct Node *right;
	int height;
    int num;
};
int max(int a, int b);
struct Node* newNode(int key);
int height(struct Node *N);
struct Node *rightRotate(struct Node *y);
struct Node *leftRotate(struct Node *x);
int getBalance(struct Node *N);
struct Node* insert(struct Node* node, int key);
void printGivenLevel(struct Node *tree,int level);
void levelOrderTravesal(struct Node *tree);
void inorder(struct Node *tree);
struct Node* deleteNode(struct Node* root, int key);
struct Node * minValueNode(struct Node* node);
int num(struct Node *node);
int rank(int x,struct Node *root);
struct Node * FindRank(int k,struct Node *root);
struct Node* search(struct Node *tree,int val);

int main(){
	struct Node *root=NULL;
	int arr[]={9,1,10,0,5,11,-1,2,6};
	int n=9,i;
	for(i=0;i<n;i++)
		root=insert(root,arr[i]);
	printf("levelOrder:\n");
    levelOrderTravesal(root);
    printf("Inorder:\n");
	inorder(root);
    printf("\n");
    printf("Rank 0: %d\n",rank(0,root));
    if(FindRank(9,root))
        printf("Element with rank 9: %d\n",(FindRank(9,root))->key);
    else
        printf("No such element exists\n");
    root=deleteNode(root,10);
    printf("levelOrder:\n");
    levelOrderTravesal(root);
    printf("Inorder:\n");
    inorder(root);
    printf("\n");
    printf("Rank 0: %d\n",rank(0,root));
    printf("Element with rank 3: %d\n",(FindRank(3,root))->key);

}
int max(int a, int b)
{
    return (a > b)? a : b;
}
struct Node* newNode(int key)
{
    struct Node* node = (struct Node*)malloc(sizeof(struct Node));
    node->key   = key;
    node->left   = NULL;
    node->right  = NULL;
    node->height = 0; 
    node->num=1;
    return(node);
}
int height(struct Node *N)
{
    if (N == NULL)
        return -1;
    return N->height;
}
struct Node *rightRotate(struct Node *y)
{
    struct Node *x = y->left;
    x->num=y->num;
    struct Node *t = x->right;
    x->right = y;
    y->left = t;
    y->height = max(height(y->left), height(y->right))+1;
    x->height = max(height(x->left), height(x->right))+1;
    y->num=num(y->left)+num(y->right)+1;
    return x;
}
struct Node *leftRotate(struct Node *x)
{
    struct Node *y = x->right;
    y->num=x->num;
    struct Node *t = y->left;
    y->left = x;
    x->right = t;
    x->height = max(height(x->left), height(x->right))+1;
    y->height = max(height(y->left), height(y->right))+1;
    x->num=num(x->left)+num(x->right)+1;
    return y;
}
int getBalance(struct Node *N)
{
    if (N == NULL)
        return 0;
    return height(N->left) - height(N->right);
}
struct Node* insert(struct Node* node, int key)
{   
    if(node!=NULL)
        node->num+=1;
    if (node == NULL)
        return(newNode(key));
    if (key < node->key)
        node->left  = insert(node->left, key);
    else if (key > node->key)
        node->right = insert(node->right, key);
    else
        return node;
    node->height = 1 + max(height(node->left),
                           height(node->right));
    int balance = getBalance(node);
    // Left Left Case
    if (balance > 1 && key < node->left->key)
        return rightRotate(node);
 
    // Right Right Case
    if (balance < -1 && key > node->right->key)
        return leftRotate(node);
 
    // Left Right Case
    if (balance > 1 && key > node->left->key)
    {
        node->left =  leftRotate(node->left);
        return rightRotate(node);
    }
 
    // Right Left Case
    if (balance < -1 && key < node->right->key)
    {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }
 
    return node;
}
void printGivenLevel(struct Node *tree,int level){
  if(tree==NULL){
    return;
  }
  if(level==0){
    printf("%d ",tree->key);
  }
  else if(level>0){
    printGivenLevel(tree->left,level-1);
    printGivenLevel(tree->right,level-1);
  }
}
void levelOrderTravesal(struct Node *tree){
  int i;
  for(i=0;i<=height(tree);i++){
    printGivenLevel(tree,i);
  }
  printf("\n");
}
void inorder(struct Node *tree){
	if(tree!=NULL){
		inorder(tree->left);
		printf("%d ",tree->key);
		inorder(tree->right);
	}
}
struct Node* deleteNode(struct Node* root, int key)
{   if(root!=NULL){
    root->num-=1;
}
    // STEP 1: PERFORM STANDARD BST DELETE
 
    if (root == NULL)
        return root;
 
    // If the key to be deleted is smaller than the
    // root's key, then it lies in left subtree
    if ( key < root->key )
        root->left = deleteNode(root->left, key);
 
    // If the key to be deleted is greater than the
    // root's key, then it lies in right subtree
    else if( key > root->key )
        root->right = deleteNode(root->right, key);
 
    // if key is same as root's key, then This is
    // the node to be deleted
    else
    {
        // node with only one child or no child
        if( (root->left == NULL) || (root->right == NULL) )
        {
            struct Node *temp = root->left ? root->left :
                                             root->right;
 
            // No child case
            if (temp == NULL)
            {
                temp = root;
                root = NULL;
            }
            else // One child case
             *root = *temp; // Copy the contents of
                            // the non-empty child
            free(temp);
        }
        else
        {
            // node with two children: Get the inorder
            // successor (smallest in the right subtree)
            struct Node* temp = minValueNode(root->right);
 
            // Copy the inorder successor's data to this node
            root->key = temp->key;
 
            // Delete the inorder successor
            root->right = deleteNode(root->right, temp->key);
        }
    }
 
    // If the tree had only one node then return
    if (root == NULL)
      return root;
 
    // STEP 2: UPDATE HEIGHT OF THE CURRENT NODE
    root->height = 1 + max(height(root->left),
                           height(root->right));
 
    // STEP 3: GET THE BALANCE FACTOR OF THIS NODE (to
    // check whether this node became unbalanced)
    int balance = getBalance(root);
 
    // If this node becomes unbalanced, then there are 4 cases
 
    // Left Left Case
    if (balance > 1 && getBalance(root->left) >= 0)
        return rightRotate(root);
 
    // Left Right Case
    if (balance > 1 && getBalance(root->left) < 0)
    {
        root->left =  leftRotate(root->left);
        return rightRotate(root);
    }
 
    // Right Right Case
    if (balance < -1 && getBalance(root->right) <= 0)
        return leftRotate(root);
 
    // Right Left Case
    if (balance < -1 && getBalance(root->right) > 0)
    {
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }
 
    return root;
}
struct Node * minValueNode(struct Node* node)
{
    struct Node* current = node;
    while (current->left != NULL)
        current = current->left;
    return current;
}
int num(struct Node *node){
    if(node==NULL)
        return 0;
    return node->num;
}
int rank(int x,struct Node *root){
    int r=1;
    struct Node *temp=root;
    while(temp){
        if(temp->key==x){
            if(temp->right!=NULL)
                return r+temp->right->num;
            else
                return r;
        }
        else if(temp->key>x){
            if(temp->right!=NULL)
                r=r+1+temp->right->num;
            else
                r++;
            temp=temp->left;
        }
        else
            temp=temp->right;
    }
    return r;
}
struct Node * FindRank(int k,struct Node *root){
    struct Node *temp=root;
    if(temp==NULL)
        return temp;
    while(k){
        if(temp==NULL)
            return temp;
        if(k==1+num(temp->right))
            return temp;
        else if(k>1+num(temp->right)){
            k=k-1-num(temp->right);
            temp=temp->left;
        }
        else{
            temp=temp->right;
        }
    }
    return temp;
}
struct Node* search(struct Node *tree,int val){
    if(tree==NULL || tree->key==val)
        return tree;
    if(tree->key<val)
        return search(tree->right,val);
    if(tree->key>val)
        return search(tree->left,val);
}