#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>
struct hash{
	int a;
	int b;
	int p;
	int m;
	int *S;
};
int FindGreaterPrime(int n);
int isPrime(int n);
void PerfectHash(struct hash P[],int i,int arr[],int n,int aPH,int bPH,int pPH,int mPH,int defaul);
void PrintPerfectHash(struct hash P[],int i,int defaul);
int search(int value,int aPH,int bPH,int pPH,int mPH,struct hash P[],int defaul);
int main(){
	srand ( time(NULL) );
	int n;
	n=5;
	// printf("Enter the number of elements of the data\n");
	// scanf("%d",&n);
	int arr[n],i,max=1;
	// printf("Enter the elements of the data\n");
	for(i=0;i<n;i++){
		arr[i]=rand()%30000;
		// scanf("%d",arr+i);
		if(arr[i]>max)
			max=arr[i];
	}
	int pPH=FindGreaterPrime(max);
	int mPH=2*n;
	int aPH=rand()%(pPH-1)+1;
	int bPH=rand()%(pPH);
	int temp[mPH];
	for(i=0;i<mPH;i++){
		temp[i]=0;
	}
	for(i=0;i<n;i++){
		int index=((aPH*arr[i]+bPH)%pPH)%mPH;
		temp[index]+=1;
	}
	struct hash P[mPH];
	for(i=0;i<mPH;i++){
		P[i].p=pPH;
		P[i].m=temp[i]*temp[i];
		P[i].S=(int*)malloc((P[i].m)*sizeof(int));
		int j;
		for(j=0;j<P[i].m;j++){
			(P[i].S)[j]=max+1;
		}
	}
	for(i=0;i<mPH;i++){
		PerfectHash(P,i,arr,n,aPH,bPH,pPH,mPH,max+1);
	}
	printf("PRIMARY HASHING PARAMETERS:\na=%d b=%d p=%d m=%d\n\n",aPH,bPH,pPH,mPH);
	printf("HASH TABLE: \n");
	for(i=0;i<mPH;i++){
		PrintPerfectHash(P,i,max+1);
	}
	while(1){
		printf("Enter value to be searched:\t");
		int value;
		scanf("%d",&value);
		if(search(value,aPH,bPH,pPH,mPH,P,max+1)==1)
			printf("FOUND\n");
		else{
			printf("NOT FOUND\n");
		}
	}
}
int FindGreaterPrime(int n)
{
    int i=n+1;
    while(1)
    {
        if(isPrime(i))
            break;
        i++;
    }
    return i;
}
int isPrime(int n)
{
	if(n<=1)
		return 0;
    int i,root;

    if (n%2 == 0 || n%3 == 0)
        return 0;

    root = (int)sqrt(n);

    for (i=5; i<=root; i+=6)
    {
        if (n%i == 0)
           return 0;
    }

    for (i=7; i<=root; i+=6)
    {
        if (n%i == 0)
           return 0;
    }

}
void PerfectHash(struct hash P[],int i,int arr[],int n,int aPH,int bPH,int pPH,int mPH,int defaul){
	int size=(int)sqrt(P[i].m);
	int temp[size];
	int j,a=0;
	for(j=0;j<n;j++){
		if(i==((aPH*arr[j]+bPH)%pPH)%mPH)
			temp[a++]=arr[j];
	}
	while(1){
		P[i].a=rand()%(P[i].p-1)+1;
		P[i].b=rand()%(P[i].p);
		for(j=0;j<size;j++){
			
				int index=((P[i].a*temp[j]+P[i].b)%P[i].p)%P[i].m;
				if((P[i].S)[index]==defaul){
					(P[i].S)[index]=temp[j];
				}
				else{
					int k;
					for(k=0;k<P[i].m;k++)
						(P[i].S)[k]=defaul;
					break;
				}
			}		
		if(j==size)
			return;
	}
	}

void PrintPerfectHash(struct hash P[],int i,int defaul){
	printf("a=%d b=%d p=%d m=%d -->> ",P[i].a,P[i].b,P[i].p,P[i].m);
	int j;
	for(j=0;j<P[i].m;j++){
		if((P[i].S)[j]==defaul)
			printf("NULL ");
		else
			printf("%d ",(P[i].S)[j]);
	}
	printf("\n");
}
int search(int value,int aPH,int bPH,int pPH,int mPH,struct hash P[],int defaul){
	int primaryIndex=((aPH*value+bPH)%pPH)%mPH;
	if(P[primaryIndex].m==0)
		return 0;
	int secondaryIndex=(((P[primaryIndex].a)*value+P[primaryIndex].b)%P[primaryIndex].p)%P[primaryIndex].m;
	if((P[primaryIndex].S)[secondaryIndex]==value)
		return 1;
	return 0;
}