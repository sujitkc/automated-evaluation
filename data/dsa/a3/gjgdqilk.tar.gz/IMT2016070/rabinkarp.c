#include <stdio.h>
#include <string.h>
void rabinKarp(char text[],char pat[],long int q);
#define d 256
int main(){
	char text[200],pat[20];
	printf("Enter main text\n");
	scanf("%s",text);
	printf("Enter pattern\n");
	scanf("%s",pat);
	long int q=211;
	rabinKarp(text,pat,q);
}
void rabinKarp(char text[],char pat[],long int q){
	int n=strlen(text),m=strlen(pat);
	int t=0,p=0,h=1;
	int i,j;
	for (i=0;i<m-1;i++)
        h=(h*d)%q;
    for(i=0;i<m;i++)
    {
        p=((d*p)%q+pat[i])%q;
        t=((d*t)%q+text[i])%q;
    }
    for(i=0;i<n-m+1;i++){
    	if(p==t){
    		for(j=0;j<m;j++){
    			if(text[i+j]!=pat[j])
    				break;
    		}
    		if(j==m)
    			printf("Pattern match at index %d\n",i);
    	}
    	 if(i<n-m)
        {
            t=((d*(t-(text[i]*h)%q))%q+text[i+m])%q;
            if(t<0)
            t=(t+q);
        }
    }
}