#include <stdio.h>
void buildSegTree(int node,int start,int end,int arr[],int segTree[]);
void update(int node,int start,int end,int idx,int val,int arr[],int segTree[]);
int query(int node, int start, int end, int l, int r,int arr[],int segTree[],int max);
int main(){
	int n;
	printf("Enter no of elememts in the array\n");
	scanf("%d",&n);
	int arr[n],i;
	int max=0;
	printf("Enter the elememts of the array\n");
	for (i=0;i<n;i++){
		scanf("%d",arr+i);
		if(arr[i]>arr[max])
			max=i;
	}
	int segTree[4*n];
	buildSegTree(0,0,n-1,arr,segTree);
	while(1){
		printf("1. UPDATE\n2. Find RMQ\n3. Print array\n");
		int choice;
		scanf("%d",&choice);
		if(choice==1){
			printf("Enter index to be updated\n");
			scanf("%d",&i);
			int value;
			printf("Enter value\n");
			scanf("%d",&value);
			update(0,0,n-1,i,value,arr,segTree);
			printf("Value updated\n");
		}
		else if(choice == 2){
			printf("Enter start index\n");
			int start;
			scanf("%d",&start);
			printf("Enter end index\n");
			int end;
			scanf("%d",&end);
			int RMQindex=query(0,0,n-1,start,end,arr,segTree,max);
			printf("RMQ between %d and %d is %d at index %d\n",start,end,arr[RMQindex],RMQindex);
			

		}
		
		else if(choice==3){
			for(i=0;i<n;i++)
				printf("%d ",arr[i]);
			printf("\n");
		}
		else{
			break;
		}
	}
}
void buildSegTree(int node,int start,int end,int arr[],int segTree[]){
	if(start==end){
		segTree[node]=start;
		return;
	}
	int mid=(start+end)/2;
	buildSegTree(2*node+1,start,mid,arr,segTree);
	buildSegTree(2*node+2,mid+1,end,arr,segTree);
	if(arr[segTree[2*node+1]]<arr[segTree[2*node+2]]){
		segTree[node]=segTree[2*node+1];
	}
	else{
		segTree[node]=segTree[2*node+2];
	}
}
void update(int node,int start,int end,int idx,int val,int arr[],int segTree[]){
	if(start==end){
		arr[idx]=val;
		segTree[node]=start;
		return;
	}
	int mid=(start+end)/2;
	if(start <= idx && idx <= mid)
    {
        update(2*node+1, start, mid, idx, val,arr,segTree);
    }
    else
    {
        update(2*node+2, mid+1, end, idx, val,arr,segTree);
    }
    if(arr[segTree[2*node+1]]<arr[segTree[2*node+2]]){
		segTree[node]=segTree[2*node+1];
	}
	else{
		segTree[node]=segTree[2*node+2];
	}

}
int query(int node, int start, int end, int l, int r,int arr[],int segTree[],int max)
{
    if(r < start || end < l)
    {
        return max;
    }
    if(l <= start && end <= r)
    {
        return segTree[node];
    }
    // range represented by a node is partially inside and partially outside the given range
    int mid = (start + end) / 2;
    int p1 = query(2*node+1, start, mid, l, r,arr,segTree,max);
    int p2 = query(2*node+2, mid+1, end, l, r,arr,segTree,max);
    if(arr[p1]<arr[p2])
    	return p1;
    return p2;
}