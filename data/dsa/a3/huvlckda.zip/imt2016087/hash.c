#include<stdio.h>
int inf=-999999999;
void hash(int hashTable[],int num,int size,int type)
{
    if(type==0)
    {
        int a,pos=0;
        while(pos<size)
        {
            a=(num+pos)%size;
            if(hashTable[a]==inf){
                hashTable[a]=num;
                break;
            }
            else
                pos++;
        }

    }
    else if(type==1)
    {
        int a,pos=0;
        while(pos<size)
        {
            int c1=2,c2=3;
            a=(num+pos*c1+pos*pos*c2)%size;
            if(hashTable[a]==inf){
                hashTable[a]=num;
                break;
            }
            else
                pos++;
        }
    }
    else if(type==2)
    {
        int a,pos=0;
        while(pos<size)
        {
            a=(num+pos*(1+num%(size-1)))%size;     // h2=1+num%(size-1)
            if(hashTable[a]==inf){
                hashTable[a]=num;
                break;
            }
            else
                pos++;
        }
    }
}
void delete(int hashTable[],int num,int size,int type)
{
    int i=0;
    while(1){
        
        if(type==0){
            int a=(num+i)%size;
            if(hashTable[a]==num){
                hashTable[a]=inf;
                break;
            }
            else
                i++;
        }
        else if(type==1)
        {
            int c1=5,c2=7;
            int a=(num+i*c1+i*i*c2)%size;
            if(hashTable[a]==num){
                hashTable[a]=inf;
                break;
            }
            else
                i++;
        }
        else if(type==2)
        {
            int a=(num+i*(1+num%(size-1)))%size;     // h2=1+num%(size-1)
            if(hashTable[a]==num){
                hashTable[a]=inf;
                break;
            }
            else
                i++;

        }
    }

}
int main()
{
    int size=21;
    int hashTable[size];
    int arr[]={3,6,5,8,29,11,13,15,17,19,21,23,45,40,4,87,67,56,90,7,94};
    //0-lin,1-quad,2-double
    for(int i=0;i<size;i++)
        hashTable[i]=inf;
    for(int i=0;i<size;i++)
        hash(hashTable,arr[i],size,0);
    for(int i=0;i<size;i++)
        printf("%d ",hashTable[i]);
    delete(hashTable,29,size,0);
    printf("\n");
    for(int i=0;i<size;i++)
        printf("%d ",hashTable[i]);
    return 0;
}
