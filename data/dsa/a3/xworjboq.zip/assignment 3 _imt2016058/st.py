import sys
global l
l=[6,4,12,43,78,5,21,93]
global n
n=len(l)
global b
b=[]
for i in range(n):
    b.append(i)
    if i>n-1:
        l.append(sys.maxint)
y=0
for i in range((n)-1):
    if l[b[y]]>l[b[y+1]]:
        b.append(b[y+1])
    else:
        b.append(b[y])
    y=y+2
def update(i,X):
    y=n-1
    l[i]=X
    j=i
    while j < (2*n)-2:
        if j%2==0:
            if l[b[j]]>l[b[j+1]]:
                b[y+(j/2)+1]=b[j+1]
            else:
                b[y+(j/2)+1]=b[j]
        if j%2!=0:
            if l[b[j]]>l[b[j-1]]:
                b[y+((j+1)/2)]=b[j-1]
            else:
                b[y+((j+1)/2)]=b[j]
        j=y+((j+1)/2)+1
        print j
def RMQ(i,j):
    l=bitLen(j-1)
    p=pow(2,l-1)
    
    while True: b
def bitLen(int_type):
    length = 0
    while (int_type):
        int_type >>= 1
        length += 1
    return(length)
 
update(0,3)
print pow(2,3)
