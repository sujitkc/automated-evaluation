a=[0,0,0,0,0,0,0,0]
t=[0,0,0,0,0,0,0,0]
global n
n=8
def prefixsum(i):
    s=0
    while(i>-1):
        s=s+t[i]
        j=(i+1) & -(i+1)
        i=i-j
    return s
def update(i,X):
        a[i]=a[i]+X
        while i<n:
            t[i]=t[i]+X
            j=(i+1) & (-i-1)
            i=i+j
def rsq(i,j):
    return prefixsum(j)-prefixsum(i-1)
update(0,2)
update(1,1)
update(2,4)
update(3,5)
update(4,2)
update(5,1)
update(6,3)
update(7,8)
print a
print t
print rsq(0,7)
