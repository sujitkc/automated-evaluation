class node():
    def __init__(self,value):
        self.value=value
        self.right=None
        self.left=None
        self.parent=None
        self.height=0
class tree():
    def __init__(self,root):
        self.rootnode=root
    def search(self,element):
        ctr=root
        while True:
            if ctr.value==element:
                return ctr
            if ctr.value>element and ctr.left!=None:
                ctr=ctr.left 
            if ctr.value<element and ctr.right!=None:
                ctr=ctr.right
            return ctr
    def insert(self,value):
        cptr=self.search(value)
        new_node=node(value)
        if new_node.value>cptr.value:
            cptr.right=new_node
            new_node.parent=cptr
        if new_node.value<cptr.value:
            cptr.left=new_node
            new_node.parent=cptr
        cptr=new_node            
        while True:
            if new_node.parent.left==None or new_node.parent.right==None:
                new_node.parent.height=new_node.parent.height+1
                new_node=new_node.parent
                continue
            if(new_node.parent.left.height==new_node.parent.right.height):
                new_node.parent.height=max(new_node.parent.left.height,new_node.parent.right.height)+1
                break
            if abs(new_node.parent.left.height-new_node.parent.right.height)<=1:
                new_node.parent.height=max(new_node.parent.left.height,new_node.parent.right.height)+1
                new_node=new_node.parent
            else:
                if new_node.parent.value<new_node.value and new_node.parent.parent.value<new_node.parent.value:
                    self.zigzig(new_node,new_node.parent,new_node.parent.parent)
                    break
                if new_node.parent.value<new_node.value and new_node.parent.parent.value<new_node.parent.value:
                    self.zigzig(new_node.parent.parent,new_node.parent,new_node)
                    break
                if new_node.value<new_node.parent.value and new_node.parent.parent.value>new_node.parent.value:
                    self.zigzag(new_node.parent.parent,new_node.parent,new_node)
                    break
                if new_node.value<new_node.parent.value and new_node.parent.parent.value<new_node.parent.value:
                    self.zigzag(new_node,new_node.parent,new_node.parent.parent)
                    break
            
    def zigzag(self,x,y,z):
        if(z.right.value==y.value):
            if z.parent.value>z.value:
                z.parent.left=x
            else:
                z.parent.right=x
            y.left=z.left
            y.height=max(y.left.height,y.right.height)+1
            z.left=x.left
            z.right=x.right
            z.height=max(z.left.height,z.right.height)+1
            x.left=z
            x.right=y
            x.height=max(z.height,y.height)+1
            x.parent=z.parent
            x=cptr
            for i in range(1,4):
                cptr.left.parent=cptr
                cptr.right.parent=cptr
                if i==2:
                    cptr=cptr.left
                if i==3:
                    cptr=cptr.parent.right
        else:
            if x.parent.value>x.value:
                x.parent.left=z
            else:
                x.parent.right=z
            y.right=z.left
            y.height=max(y.left.height,y.right.height)+1
            x.left=z.right
            x.height=max(x.left.height,x.right.height)+1
            z.left=y
            z.right=x
            z.height=max(z.left.height,z.right.height)+1
            z.parent=x.parent
            z=cptr
            for i in range(1,4):
                cptr.left.parent=cptr
                cptr.right.parent=cptr
                if i==2:
                    cptr=cptr.left
                if i==3:
                    cptr=cptr.parent.right
    def zigzig(self,x,y,z):
        if(y.right.value==x.value):
            if z.parent.value>z.value:
                z.parent.left=y
            else:
                z.parent.right=y
            z.right=y.left
            z.height=max(z.left.height,z.right.height)+1
            y.left=z
            y.right=x
            y.height=max(y.left.height,y.right.height)+1
            y.parent=z.parent
            y=cptr
            for i in range(1,4):
                cptr.left.parent=cptr
                cptr.right.parent=cptr
                if i==2:
                    cptr=cptr.left
                if i==3:
                    cptr=cptr.parent.right     
        else:
            if x.parent.value>x.value:
                x.parent.left=y
            else:
                x.parent.right=y
            x.left=y.right
            x.height=max(x.left.height,x.right.height)+1
            y.left=z
            y.right=x
            y.height=max(y.left.height,y.right.height)+1
            y.parent=x.parent
            y=cptr
            for i in range(1,4):
                cptr.left.parent=cptr
                cptr.right.parent=cptr
                if i==2:
                    cptr=cptr.left
                if i==3:
                    cptr=cptr.parent.right
            
            

if __name__=="__main__":
    root=None
    root=node(10)
    avl_tree=tree(root)
    avl_tree.insert(20)
    
    
    
      
