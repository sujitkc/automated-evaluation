#include<stdio.h>
void constructbitree(int a[],int tree[],int n);
int getsum(int tree[],int index);

int main()
{
	int n,i,j,k=1;
	printf("enter the size of array    ");
	scanf("%d",&n);
	int a[n+1],tree[n+1];
	a[0]=0;
	tree[0]=0;
	printf("enter   \n");
	for(i=1;i<n+1;i++)
	{
		
		scanf("%d",&a[i]);
		tree[i]=0;
	}
	constructbitree(a,tree,n);
	printf("enter the index for sum \n");
	scanf("%d",&j);
	while(j!=0)
	{
	if(j>n)
	{
		k=getsum(tree,n);
	}
	else
	{
	k=getsum(tree,j);
}
	printf("%d\n",k);
	printf("enter the index for sum \n");
	scanf("%d",&j);
	}
	return 0;

}
void constructbitree(int a[],int tree[],int n)
{
	int i,index;
	for(i=1;i<n+1;i++)
	{
		index=i;
		while(index<n+1)
		{
			tree[index] +=a[i];
			index +=index & (-index);
		}
	}
}
int getsum(int tree[],int index)
{
	int sum =0;
	while(index>0)
	{
		sum+=tree[index];
		index-=index & (-index);
	}
	return sum;
}