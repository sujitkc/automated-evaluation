#include<stdio.h>
#include<stdlib.h>

struct node
{
	int key;
	int rank;
	struct node *left;
	struct node *right;
	int height;
};
int max(int a, int b);
int height(struct node *N)
{
	if (N == NULL)
		return 0;
	return N->height;
}
int max(int a, int b)
{
	return (a > b)? a : b;
}
struct node* newNode(int key)
{
	struct node* node = (struct node*)malloc(sizeof(struct node));
	node->key = key;
	node->rank = 0;
	node->left = NULL;
	node->right = NULL;
	node->height = 1;
	return(node);
}

int search(struct node *n, int val) {
	if(n==NULL) return 0;
	else if(val==n->key) return 1;
	else if(val < n->key)
		search(n->left, val);
	else
		search(n->right, val);
}

int nofnodes(struct node *n) {
	if(n==NULL) return 0;
	else
		return(1+ nofnodes(n->left) + nofnodes(n->right));
}

int Rank(struct node *n,int val) {
	if(n == NULL) return 0;
	if(val < n->key) {
		return 1+ nofnodes(n->right) + Rank(n->left,val);
	}
	else if(val > n->key) {
		return Rank(n->right,val);
	}
	else if(val == n->key) {
		return 1 + nofnodes(n->right);
	}
}

int final_rank(struct node *n, int val) {
	if(search(n, val)==1)
		return Rank(n, val);
	else if(search(n, val)==0)
		return Rank(n, val) + 1;
}

struct node *rightRotate(struct node *y)
{
	struct node *x = y->left;
	struct node *T2 = x->right;
	x->right = y;
	y->left = T2;
	y->height = max(height(y->left), height(y->right))+1;
	x->height = max(height(x->left), height(x->right))+1;
	return x;
}
struct node *leftRotate(struct node *x)
{
	struct node *y = x->right;
	struct node *T2 = y->left;
	y->left = x;
	x->right = T2;
	x->height = max(height(x->left), height(x->right))+1;
	y->height = max(height(y->left), height(y->right))+1;
	return y;
}

int getBalance(struct node *N)
{
	if (N == NULL)
		return 0;
	return height(N->left) - height(N->right);
}


struct node* insert(struct node* node, int key)
{
	if (node == NULL)
		return(newNode(key));
	if (key < node->key)
		node->left = insert(node->left, key);
	else
		node->right = insert(node->right, key);
	node->height = max(height(node->left), height(node->right)) + 1;
	int balance = getBalance(node);
	// Left Left Case
	if (balance > 1 && key < node->left->key)
		return rightRotate(node);
	// Right Right Case
	if (balance < -1 && key > node->right->key)
		return leftRotate(node);
	// Left Right Case
	if (balance > 1 && key > node->left->key)
	{
		node->left = leftRotate(node->left);
		return rightRotate(node);
	}
	// Right Left Case
	if (balance < -1 && key < node->right->key)
	{
		node->right = rightRotate(node->right);
		return leftRotate(node);
	}
	return node;
}

struct node * minValueNode(struct node* node)
{
	struct node* current = node;
	while (current->left != NULL)
		current = current->left;
	return current;
}

struct node* deleteNode(struct node* root, int key)
{
	
	if (root == NULL)
		return root;
	if ( key < root->key )
		root->left = deleteNode(root->left, key);
	else if( key > root->key )
		root->right = deleteNode(root->right, key);
	else
	{
		// node with only one child or no child
		if( (root->left == NULL) || (root->right == NULL) )
		{
			struct node *temp = root->left ? root->left : root->right;
			// No child case
			if(temp == NULL)
			{
				temp = root;
				root = NULL;
			}
			else // One child case
			*root = *temp; 
			free(temp);
		}
		else
		{
			struct node* temp = minValueNode(root->right);
			root->key = temp->key;
			root->right = deleteNode(root->right, temp->key);
		}
	}
	if (root == NULL)
		return root;
	root->height = max(height(root->left), height(root->right)) + 1;
	int balance = getBalance(root);
	// Left Left Case
	if (balance > 1 && getBalance(root->left) >= 0)
		return rightRotate(root);
	// Left Right Case
	if (balance > 1 && getBalance(root->left) < 0)
	{
		root->left = leftRotate(root->left);
		return rightRotate(root);
	}
	// Right Right Case
	if (balance < -1 && getBalance(root->right) <= 0)
		return leftRotate(root);
	// Right Left Case
	if (balance < -1 && getBalance(root->right) > 0)
	{
		root->right = rightRotate(root->right);
		return leftRotate(root);
	}
	return root;
}

void preOrder(struct node *root)
{
	if(root != NULL)
	{
		printf("--> %d ", root->key);
		preOrder(root->left);
		preOrder(root->right);
	}
}

int main()
{
	struct node *root = NULL;
	root = insert(root, 1);
	root = insert(root, 2);
	root = insert(root, 3);
	root = insert(root, 0);
	root = insert(root, -2);
	root = insert(root, -3);
	root = insert(root, -1);
	printf("Constructed AVL tree in preordered fashion is \n");
	preOrder(root);
	root = deleteNode(root, 0);
	printf("\nPre order traversal after deletion of 0 \n");
	preOrder(root);
	printf("\n");
	printf("rank of 2 is : %d\n", final_rank(root, 2));
  printf("rank of 3 is : %d\n", final_rank(root, 3));
	
	return 0;
}
