#include<stdio.h>
#include<string.h>
#include<math.h>
void findstring(char text[],char pattern[]);
int findhash(char str[],int n);
int prime=101;
int main()
{
	char text[]="abcabcabc";
	char pattern[]="bca";
	findstring(text,pattern);
}
void findstring(char text[],char pattern[])
{
	int n,m,t,p,h=1,i,j;
	n=strlen(text);
	m=strlen(pattern);
	p=findhash(pattern,m);
	t=findhash(text,m);
	for(i=1;i<m;i++)
	{
		h=h*prime;
	}
	for(i=0;i<n-m;i++)
	{
		if(p==t)
		{
			for(j=0;j<m;j++)
			{
				if(text[i+j]!=pattern[j])
				{
					break;
				}
			}
			if(j==m)
			{
				printf("pattern found at %d\n",i+1);
			}
		}
		t=((t-text[i])/prime)+(text[i+m]*h);
	}

}
int findhash(char str[],int n)
{
	int x=str[n-1],i;
	for(i=1;i<n;i++)
	{
		x=(x*prime)+str[n-i-1];
	}
	return x;
}