#include <stdio.h>
#include <math.h>
#include <limits.h>
int minval(int x,int y)
{
	if(x<y)
	{
		return x;
	}
	return y;
}
int midval(int x,int y)
{
	int z=(x+y)/2;
	return z;
}
int construct_st(int arr[],int start,int end,int tree[],int index)
{
	if(start==end)
	{
		tree[index]=arr[start];
	}
	else
	{
		int mid=(start+end)/2;
		construct_st(arr,start,mid,tree,2*index+1);
		construct_st(arr,mid+1,end,tree,2*index+2);
		tree[index]=minval(tree[2*index+1],tree[2*index+2]);
	}
}
int rangeminquery(int tree[],int qlow,int qhigh,int low ,int high,int index)
{
	int max_value=10000;
	if(qlow<=low && qhigh>=high)
	{
		return tree[index];
	}
	if(qlow>high || qhigh<low)
	{
		return max_value;
	}
	int mid=(low+high)/2;
	int a=rangeminquery(tree,qlow,qhigh,low,mid,2*index+1);
	int b=rangeminquery(tree,qlow,qhigh,mid+1,high,2*index+2);
	return minval(a,b);
}
int main()
{
	int n,i;
	printf("enter the size of array  ");
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	int x=ceil(log2(n));
	int max=2*pow(2,x)-1;
	int tree[max];
	construct_st(a,0,n-1,tree,0);
	printf("%d\n",rangeminquery(tree,0,n-1,0,n-1,0));
}
