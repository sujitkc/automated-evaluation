#include <stdio.h>
#include <stdlib.h>

struct rbtree
{
	int data;
	char clr;
	struct rbtree *left,*right,*parent;
};
struct rbtree* newnode(int d)
{
	struct rbtree *temp= (struct rbtree *)malloc(sizeof(struct rbtree));
	temp->data=d;
	temp->left=temp->right=temp->parent=NULL;
	return temp;
}
void rightrotate(struct rbtree **root,struct rbtree *node,int flag)
{
	struct rbtree *temp=node->left;
	node->left=temp->right;

	if(temp->right)
	temp->right->parent=node;

	temp->parent=node->parent;

	if(temp->parent==NULL)
	*root=temp;
	else if(node->parent->left==node)
	node->parent->left=temp;
	else
	node->parent->right=temp;

	temp->right=node;
	node->parent=temp;
	if(flag)
	{
		temp->clr='B';
		node->clr='R';
	}
}
void leftrotate(struct rbtree **root,struct rbtree *node,int flag)
{
	struct rbtree *temp=node->right;
	node->right=temp->left;
	temp->parent=node->parent;

	if(temp->left)
	temp->left->parent=node;
	if(node->parent==NULL)
	(*root)=temp;
	else if(node->parent->left==node)
	node->parent->left=temp;
	else
	node->parent->right=temp;
	temp->left=node;
	node->parent=temp;
	if(flag)
	{
		temp->clr='B';
		node->clr='R';
	}
}
void check(struct rbtree **root,struct rbtree *z)
{

	while(z!=(*root)&&z->parent->clr=='R')
	{
		struct redblack *y=NULL;
		if(z->parent==z->parent->parent->left)
		y=z->parent->parent->right;
		else
		y=z->parent->parent->left;

		if(y&&y->clr=='R')
		{
			y->clr='B';
			z->parent->clr='B';
			z->parent->parent->clr='R';
			z=z->parent->parent;
		}
		else
		{
			if(z->parent==z->parent->parent->left&&z==z->parent->left)
			{
				rightrotate(root,z->parent->parent,1);
			}
			else if(z->parent==z->parent->parent->left&&z==z->parent->right)
			{
				leftrotate(root,z->parent,0);
				rightrotate(root,z->parent,1);
			}
			else if(z->parent==z->parent->parent->right&&z==z->parent->right)
			{
				leftrotate(root,z->parent->parent,1);
			}
			else if(z->parent==z->parent->parent->right&&z==z->parent->left)
			{
				rightrotate(root,z->parent,0);
				leftrotate(root,z->parent,1);
			}
		}
	}
	(*root)->clr='B';
}
void insert(struct rbtree **root,int d)
{
	struct rbtree *temp=newnode(d),*pre,*pro;
	if(*root==NULL)
	{
		temp->clr='B';
		*root=temp;
		return;
	}
	temp->clr='R';
	pre=NULL;
	pro=*root;
	while(pro)
	{
		pre=pro;
		if(pro->data>d)
		pro=pro->left;
		else
		pro=pro->right;
	}
	if(pre->data>d)
	pre->left=temp;
	else
	pre->right=temp;
	temp->parent=pre;
	check(root,temp);
}
void inorder(struct rbtree *root)
{
	if(root==NULL)
	return ;
	inorder(root->left);
    printf("%d-%c ", root->data, root->clr);
	inorder(root->right);
}
int main()
{
	int i,j,n;
	struct rbtree *root=NULL;

	insert(&root,10);
	insert(&root,5);
	insert(&root,3);
	insert(&root,8);
	insert(&root,2);
	insert(&root,7);
	insert(&root,9);
	insert(&root,1);
	insert(&root,4);

	printf("Inoreder redblack tree traversal: \n");
	inorder(root);

	return 0;
}
