#include<stdio.h>
#include<math.h>

void doublecheck(int *t,int *p,int n,int m){
	int i,j;
	for(i=0;i<n-m;i++){
		for(j=0;j<m;j++){
			if(p[j]!=t[i+j]) break;
		}
		if(j==m) printf("string matched at %d",i);
	}
}

int main(){
	int n,m,i,j;	
	scanf("%d%d",&n,&m);
	int t[n],p[m];
	for(i=0;i<n;i++){
		scanf("%d",t[i]);
	}
	for(i=0;i<m;i++){
		scanf("%d",p[i]);
	}
	int x=0,y=0;
	int h=pow(2,(m-1));
	for(j=0;j<=m-1;j++){
		x=((2*x)+p[j])*13;
		y=((2*x)+t[j])*13;
	}
	for(i=0;i<n-m;i++){
		if(x==y){
			doublecheck(t,p,n,m);  
		}	
		else{
			y=2*(y-h*t[i])+t[m+i];
		}
	}
}
