#include<stdio.h>
#include<stdlib.h>
#include<math.h>


int min(int x,int y)
{
	if(x<y)
	{
		return x;
	}
	else
	{
		return y;
	}
	
}

int mid(int f,int l) //first and last
{ 
	return f+(l-f)/2;
}

int buildTree(int arra[],int f, int l,int arrb[],int index)
{
	int mid=mid(f,l);	
	if(f==l)
	{
		arrb[index]= arra[f];
	}
	else
	{
		arrb[index]=min(buildTree(arra,f,mid,arrb,2*index+1),buildTree(arra,mid+1,l,arrb,2*index+2));
	}
	return arrb[index];
}

int RMQ(int *arrb,int f,int l,int s,int e,int index)
// Range Minimum Query s,e are start and end of query interval
{
	int mid = mid(f, l);
	if(s>e)
	{
		printf("Invalid Query");
		return -1;
	}
	else
	{
		if (s <= f && e >= l)
       			 return arrb[index];
    		if (e < s || s > e)
        		return -1;
 		else
		 {
			return min(RMQ(arrb,f, mid, s, e, 2*index+1),RMQ(arrb, mid+1, l, s, e, 2*index+2));
		}
	}
}

int main(){
	int n,i;
	scanf("%d",&n);
	int h=(int)ceil(log2(n));
	int size=2*(int)pow(2,h)-1;
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	int b[size];
	int t;
	t=buildTree(a,0,n-1,b,0);
	printf("%d",t);
	int s,e;
	scanf("%d%d",&s,&e);
	printf("RMQ[%d, %d] is = %d\n",qs, qe, RMQ(b,0,n-1,s, e,0));
}
