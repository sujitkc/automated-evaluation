#include<stdio.h>
#include<stdlib.h>

int b[30];

int update(int i,int *a,int x,int n)
{ 
int j,sum=0;
while(i<=n){
sum=sum+a[i];
j=i & -i;
i=i+j;
b[i]=b[i]+sum;
}
}
int main()
{
int i,n;
scanf("%d",&n);
int a[n];
for(i=1;i<=n;i++){
	scanf("%d",&a[i]);	
	update(i,a,a[i],n);
}

for(i=1;i<=n;i++){
	printf("%d\n",b[i]);	
}
}
 
