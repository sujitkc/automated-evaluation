#include<stdio.h>
#include<stdlib.h>
struct node{
	int key;
	struct node *lc;
	struct node *rc;
};
int search(int val,struct node *root){
	while(root){
		if(root->key==val){
			return 1;
		}
		else if(root->key>val){
			root=root->lc;
		}
		else{
			root=root->rc;
		}
	}
	return 0;	
}
void insert(int val,struct node **root){
	struct node *new,*prev,*curr;
	new=malloc(sizeof(struct node));
	new->key=val;
	new->lc=NULL;
	new->rc=NULL;
	if(*root==NULL){
		*root=new;
	}
	else{
		prev=NULL;
		curr=*root;
		while(curr){
			if(curr->key==val){
				printf("key already present\n");
				return;
			}		
			else if(curr->key>val){
				prev=curr;
				curr=curr->lc;
			}
			else{
				prev=curr;
				curr=curr->rc;
			}
		}
		if(val>prev->key){
			prev->rc=new;
		}
		else if(val<prev->key){
			prev->lc=new;
		}
	}
}
int inordpre(struct node *head){
	struct node *prev;
	prev=head;
	head=head->lc;
	while(head){
		prev=head;
		head=head->rc;
	}
	return prev->key;
}
void delete(int val,struct node **root){
	struct node *prev,*curr;
	prev=NULL;
	curr=*root;
	if(*root==NULL){
		printf("Tree is empty\n");
		return;
	}
	if(search(val,*root)==0){
		printf("key not in tree\n");
		return;
	}
	while(curr){
		if(curr->key==val){
			break;	
		}
		else if(curr->key>val){
			prev=curr;
			curr=curr->lc;
		}
		else{
			prev=curr;
			curr=curr->rc;
		}
	}
	if(prev==NULL){
		if(curr->lc&&curr->rc){
			int x;
			x=inordpre(curr);
			delete(x,root);
			curr->key=x;
		}
		else{
			if(curr->lc){
				*root=curr->lc;
				free(curr);
			}
			else if(curr->rc){
				*root=curr->rc;
				free(curr);
			}
		}
	}
	else{
		if(curr->lc==NULL||curr->rc==NULL){
			if(prev->lc==curr){
				if(curr->lc)
					prev->lc=curr->lc;
				else
					prev->lc=curr->lc;
				free(curr);
			}
			else if(prev->rc==curr){
				if(curr->lc)
					prev->rc=curr->lc;
				else
					prev->rc=curr->lc;
				free(curr);
			}
		}	
		else{
			int x;
			x=inordpre(curr);
			delete(x,root);
			curr->key=x;
		}
	}
}
void inorder(struct node *root)
{
	if(root!=NULL){
	inorder(root->lc);		
	printf("%d\n",root->key);
	inorder(root->rc);
	}
}
int main(){
	struct node *root;
	root=malloc(sizeof(struct node));
	root=NULL;
	printf("%d\n",search(10,root));
	insert(10,&root);
	printf("%d\n",search(10,root));
	insert(7,&root);
	insert(5,&root);
	insert(20,&root);
	insert(1,&root);
	insert(15,&root);
	insert(6,&root);
	printf("%d\n",search(15,root));
	//delete(15,&root);
	printf("%d\n",search(15,root));
	printf("%d\n\n",root->key);
	inorder(root);
}
