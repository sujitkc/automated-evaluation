/*This program deals with add,update and RMS of binary indext trees*/
#include<stdio.h>
#include<stdlib.h>
//int T[1000];

int Prefix_sum(int i,int n,int * T)
{
	//write code for finding prefix sum and next write code for update.
	int sum,j;
	sum=0;
	//j=0;
	while(i>0)
	{
		sum+=* (T+i);
		j=i & (-i);
	}
	return sum;


}

int Update(int i,int X, int n, int *T)
{
	while(i<n)
	{
		*(T+i)+=X;
		int j;
		j=i & (-i);
		i+=j;
	}
	return *(T+i);
}

int Compute_t(int *A, int n, int index)
{
	int ele_of_T;
	ele_of_T=0;
	int no_of_shift;
	//ele_of_A=*(A+index);
	no_of_shift=((index+1) & (-(index+1)));
	printf("The j for index, %d id %d\n",index,no_of_shift);
	int i;
	i=0;
	while(i<no_of_shift)
	{
		ele_of_T+=*(A+index-i);
		i++;

	}
	return ele_of_T;
}

int main()
{
	int A[]={2,1,4,5,2,1,3,8};
	int T[1000];
	int n,i;
	n=8;
	for(i=0;i<n;i++)
		T[i]=Compute_t(A,n,i);
	for(i=0;i<n;i++)
		printf("%d ",T[i]);
	printf("\n");

}