#include<stdio.h>
#include<stdlib.h>
struct node {
   int data;   
   struct node *leftChild;
   struct node *rightChild;
}*root=NULL,*parent;
void insert(int data) {
   struct node *tempNode = (struct node*) malloc(sizeof(struct node));
   struct node *current;
   struct node *parent;

   tempNode->data = data;
   tempNode->leftChild = NULL;
   tempNode->rightChild = NULL;

   if(root == NULL) {
      root = tempNode;
   } 
   else 
   {
      current = root;
      parent = NULL;

      while(1) {                
         parent = current;
         if(data < parent->data)
		  {
            current = current->leftChild;              				
            if(current == NULL) 
			{
               parent->leftChild = tempNode;
               break;
            }
         }
         else {
            current = current->rightChild;
            if(current == NULL) {
               parent->rightChild = tempNode;
               break;
            }
         }
      }            
   }
}  
void postorder(struct node* node)
{
     if (node == NULL)
        return;
     postorder(node->leftChild);
     postorder(node->rightChild);
     printf("%d ", node->data);
}
 
void inorder(struct node* node)
{
     if (node == NULL)
          return;
 
     inorder(node->leftChild);
     printf("%d ", node->data);  
     inorder(node->rightChild);
}
void preorder(struct node* node){
   if(node==NULL)
      return;
   printf("%d ",node->data);
   preorder(node->leftChild);
   preorder(node->rightChild);
}
int height(struct node* node)
{
   if (node==NULL)
       return 0;
   else
   {
     int lheight = height(node->leftChild);
     int rheight = height(node->rightChild);
  
     if (lheight > rheight)
         return(lheight+1);
     else
        return(rheight+1);
   }
}

/* Print nodes at a given level */
void printLevel(struct node* root, int level)
{
    if(root == NULL)
        return;
    if(level == 1)
        printf("%d ", root->data);
    else if (level > 1)
    {
        printLevel(root->leftChild, level-1);
        printLevel(root->rightChild, level-1);
    }
}
void LevelOrder(struct node* root)
{
    int h = height(root);
    int i;
    for(i=1; i<=h; i++)
        printLevel(root, i);
}  
int search(int data){
  parent=root;
  while(parent!=NULL){
    if(data==parent->data)
      return 1;
    else if(data<parent->data)
      parent=parent->leftChild;
    else
      parent=parent->rightChild;
  }
  return 0;

}  
  
int main(){
int n,i,j,k,x;
scanf("%d",&n);
for(i=0;i<n;i++){
   scanf("%d",&x);
   insert(x);
}
preorder(root);
printf("\n");
postorder(root);
printf("\n");
inorder(root);
printf("\n");
LevelOrder(root);
printf("\n%d",height(root));
scanf("%d",&k);
x=search(k);
printf("\n%d",x);
return 0;
}
