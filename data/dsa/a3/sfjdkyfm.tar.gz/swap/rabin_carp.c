#include<stdio.h>
#include<math.h>

void rabin_karp(int t[],int p[],int n,int m)
{
	int x=0,y=0,prime=937;
	int j,i,h;
	for(j=0;j<m;j++)
	{
		x=(2*x+p[j])%prime;
		y=(2*y+t[j])%prime;
		h=pow(2,j);
			
	}
	for(i=0;i<=n-m;i++)
	{
			if(x==y)
				{
					for(j=0;j<m;j++)
					{
						if(p[j]==t[i+j])
						printf("match found !! at:%d\n",i);
						break;
					}
				}
			y=(2*(y-h*t[i])+t[i+m])%prime;	
	}	
		
}


void main()
{
	int n,i,m;
	scanf("%d",&n);
	int t[n];
	scanf("%d",&m);
	int p[m];
	for(i=0;i<n;i++)
		scanf("%d",&t[i]);
	
	for(i=0;i<m;i++)
		scanf("%d",&p[i]);
	
	// rabin karp algorithm
	
	rabin_karp(t,p,n,m);
			
}
