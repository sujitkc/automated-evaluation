#include<stdio.h>
#include<math.h>

int min(int x,int y)
{
	if(x<y)
		return x;
	else
		return y;	
}
void construct(int a[],int seg[],int low,int high,int pos)
{
	if(low==high)
	{
		seg[pos]=a[low];
			return;
	}
	int mid=(low+high)/2;
	construct(a,seg,low,mid,2*pos+1);
	construct(a,seg,mid+1,high,2*pos+2);
	seg[pos]=min(seg[2*pos+1],seg[2*pos+2]);
}

void main()
{
	int i,n,m;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	for(i=0;i<n;i++)
	{
			
	if(n==pow(2,i))
		{
		m=2*n-1;
		break;
	}
	
	else
		{
		
		
			if(pow(2,i)>n)
				{
					m=2*pow(2,i)-1;
					break;
					}	
		}
	}
		int seg[m];
	for(i=0;i<m;i++)
		seg[i]=0;
		construct(a,seg,0,n-1,0);
		
		for(i=0;i<m;i++)
		{
			printf("%d ",seg[i]);
		}
				

}
