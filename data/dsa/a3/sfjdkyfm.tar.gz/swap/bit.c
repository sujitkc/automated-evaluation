#include<stdio.h>
#include<stdlib.h>
int sum(int a[],int i)
{
	int s=0;
	while(i>0){
		s+=a[i];
		i-=i&-i;
	}
	return s;
}
int add(int a[],int i,int val,int n){
	while(i<n+1){
		a[i]+=val;
		i+=i&-i;
	}
}
int main()
{
	int n,i,x,k;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n+1;i++){
		a[i]=0;
	}
	a[0]=0;
	for(i=1;i<n+1;i++){
		scanf("%d",&x);
		add(a,i,x,n);
	}
	for(i=0;i<n+1;i++){
		printf("%d ",a[i]);
	}
	k=sum(a,4);
	printf("\n%d",k);
	return 0;
}
