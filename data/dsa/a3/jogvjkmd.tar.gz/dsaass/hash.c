#include<stdio.h>
#include<stdlib.h>
struct node{
	int data;
	struct node*next;
}*np,*latest,*new,*tri;
struct node*a[1000]={0};
int hash_generator(int num,int tot_num){
		int i;
		i=num%tot_num;
		return i;
		}
void insert(int n){
	int k;
		np=(struct node *)malloc(sizeof(struct node));
		scanf("%d",&np->data);
        np->next=0;
        k=hash_generator(np->data,n);
        if(a[k]==0){
        	a[k]=np;
        }
        else{
            latest=a[k];
            while(1){
                if(latest->next==0){
                    latest->next=np;
                    break;
                }
                latest=latest->next;
            }
        }
}
int search(int d,int n){
	int p=hash_generator(d,n);
	new=a[p];
	while(new!=0){
		if(new->data==d)
				return 1;
		else{
			new=new->next;
			}
	}
	if(new==0)
		return 0;
}
void display(int n){
	int i;
	for(i=0;i<n;i++){
		tri=a[i];
		while(tri!=0){
			printf("%d ",tri->data);
			tri=tri->next;
		}
		printf("\n");
	}
}
int main(){
	int i,j,k,l,n;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		insert(n);
}
display(n);
printf("%d",search(9,n));
return 0;
}