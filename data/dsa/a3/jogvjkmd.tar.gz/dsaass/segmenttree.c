#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int min(int x,int y){
	if(x>y)
		return y;
	else
		return x;
		}
void constructtree(int a[],int b[],int l,int r,int pos){
	if(l==r){
		b[pos]=a[l];
		return;
	}
	int mid=(l+r)/2;
	constructtree(a,b,l,mid,2*pos+1);
	constructtree(a,b,mid+1,r,2*pos+2);
	b[pos]=min(b[2*pos+1],b[2*pos+2]);
} 
int range_min_query(int b[],int p,int q,int l,int r,int pos){
	if(p<=l&&q>=r){//total overlap
		return b[pos];
	}
	if(p>r||q<l){
		//no overlap
		return 1000;
	}
	int mid=(l+r)/2;
	return min(range_min_query(b,p,q,l,mid,2*pos+1),range_min_query(b,p,q,mid+1,r,2*pos+2));
}

int main(){
	int i,j,k,m,n;
	scanf("%d",&n);
	int a[n];
	int x=n/2;
	m=pow(2,n/2+1)-1;
	int b[m];
	for (i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
	constructtree(a,b,0,n,0);
	k=range_min_query(b,1,4,0,n,0);
	printf("%d",k);
}