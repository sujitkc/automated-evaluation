#include<stdio.h>
#include<string.h>
#include<math.h>
int p=37;
int hash2(char str[],int oldidx,int newidx,int oldhash,int patlen){
	int newhash=oldhash-str[oldidx];
	newhash=newhash/p;
	newhash+=str[newidx]*pow(p,patlen-1);
	return newhash;
}
int hash1(char str[],int end){
	int h=0,i;
	for(i=0;i<=end;i++){
		h+=str[i]*pow(p,i);
	}
	return h;
}
int equality(char str1[],int start1,int end1,char str2[],int start2,int end2){
	if(end1-start1 !=end2-start2){
		return 0;
	}
	while(start1<=end1&&start2<=end2){
		if(str1[start1]!=str2[start2]){
			return 0;
		}
		start1++;
		start2++;
	}
	return 1; 
}
int search(char pat[], char txt[])
{
 int n=strlen(txt);
 int m=strlen(pat),i;
 printf("%d %d",n,m);
 int pathash=hash1(pat,m-1);
 printf("%d\n",pathash);
 int txthash=hash1(txt,m-1);
 printf("%d\n",txthash);
 for(i=0;i<n;i++){
 	if(pathash==txthash && equality(txt,i,i+m-1,pat,0,m-1)==1){
 			return 1;
 	}
 	if(i<n-m+1){
 		txthash=hash2(txt,i,i+m,txthash,m);
 		printf("%d\n",txthash);
 	}
 }
 return 0;
}
 
int main(){
	char str1[100],str2[100];
	int k;
	scanf("%s",str1);
	scanf("%s",str2);
	k=search(str2,str1);
	printf("%d",k);
	return 0;
}
