#include<stdio.h>
#include<stdlib.h>
void print(int *a,int n)
{
  int i;
  for(i=0;i<n;i++)
    printf("%d ",a[i]);
  printf("\n");
}
int getSum(int *fw,int i)
{
   int sum=0;
   i++;

   while(i>0)
   {
      sum=sum+fw[i];
      i=i-(i & (-i));
   }
   return sum;
}
void updateBIT(int *bittree,int n,int index,int val)
{
  index++;
  while(index<=n)
  {
    bittree[index]=bittree[index]+val;
    index=index+(index & (-index));
  }
}
void *constructBITree(int *arr,int n,int *bittree)
{
  int i;
  for(i=0;i<=n;i++)
    bittree[i]=0;
  //print(bittree,n);
  for(i=0;i<n;i++)
    updateBIT(bittree,n,i,arr[i]);
  //return bittree;
}
int main()
{
  int n=8;
  int arr[8]={1,2,3,4,5,6,7,8};
  printf("Original array is:\n");
  print(arr,8);
  int bittree[n+1];
  constructBITree(arr,n,bittree);
  printf("BIT Tree is:\n");
  print(bittree,n+1);

  int idx;
  printf("Sum of elements till index given is:\n");
  scanf("%d",&idx);
  int s=getSum(bittree,idx);
  printf("%d\n",s);

}
