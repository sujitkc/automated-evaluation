#include<stdio.h>
#include<stdlib.h>

struct bstnode
{
  int data;
  struct bstnode *left;
  struct bstnode *right;
};

struct bstnode* get_new_node(int data)
{
  struct bstnode* new_node=(struct bstnode*)(malloc(sizeof(struct bstnode)));
  new_node->data=data;
  new_node->left=new_node->right=NULL;
}

struct bstnode* Insert(struct bstnode* rootptr,int data)
{
  if(rootptr==NULL)
  {
    rootptr=get_new_node(data);
  }
  else if(data<=rootptr->data)
  {
    rootptr->left=Insert(rootptr->left,data);
  }
  else
  {
    rootptr->right=Insert(rootptr->right,data);
  }
  return rootptr;
}

int Search_Iterative(struct bstnode* rootptr,int num)
{
  while(rootptr!=NULL && rootptr->data!=num)
  {
    if(rootptr->data>num)
    {
      rootptr=rootptr->left;
    }
    else
    {
      rootptr=rootptr->right;
    }
  }


  if(rootptr==NULL) return 0;

  if(rootptr->data==num) return 1;

}

int main()
{
  struct bstnode *root=NULL;
  root=Insert(root,5);
  root=Insert(root,3);
  root=Insert(root,2);
  root=Insert(root,5);
  root=Insert(root,4);
  root=Insert(root,10);
  root=Insert(root,7);
  root=Insert(root,11);

  printf("Enter '-1' to exit:\n");
  while(1)
  {
    int num;
    printf("Enter value to be searched:\n");
    scanf("%d",&num);
    if(num==-1)
    {
      break;
    }
    if(Search_Iterative(root,num)==1)
    {
      printf("Found\n");
    }
    else
    {
      printf("Not found\n");
    }
  }
}
