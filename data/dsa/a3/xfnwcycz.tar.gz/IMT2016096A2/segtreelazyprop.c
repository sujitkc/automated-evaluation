//Segment tree storing sum of elements . Lazy Propagation.
#include<stdio.h>

int power(int a,int b)
{
  int i,answer=1;
  for(i=1;i<b;i++)
  {
    answer=answer*a;
  }
  return answer;
}

void print_segment_tree(int *arr,int n)
{
  int i;
  for(i=1;i<n;i++)
  {
      if(arr[i]!=-999)
        printf("%d ",arr[i]);
  }
  printf("\n");
}

void build(int *input,int *segment_tree,int start,int end,int node)
{
  //printf("Inside Build %d, %d, %d\n", start, end, node);
  int mid=(start+end)/2;
  if(start==end)
  {
    segment_tree[node]=input[start];
  }
  else
  {
    build(input,segment_tree,start,mid,2*node);
    build(input,segment_tree,mid+1,end,2*node+1);
    segment_tree[node]=segment_tree[2*node]+segment_tree[2*node+1];
  }
}

void update_lazy_propagation(int *input,int *segment_tree,int *lazy,int node,int start,int end,int l,int r,int val)
{
  if(lazy[node]!=0)
  {
    segment_tree[node]=segment_tree[node]+(end-start+1)*lazy[node];

    if(start!=end)
    {
      lazy[node*2]=lazy[node*2]+lazy[node];
      lazy[node*2+1]=lazy[node*2+1]+lazy[node];
    }
    lazy[node]=0;
  }

  if(start>end || start>r || end<l)
  {
    return;
  }

  if(start>=l && end<=r)
  {
    segment_tree[node]=segment_tree[node]+(end - start + 1)*val;
    if(start!=end)
    {
      lazy[node*2]=lazy[node*2]+val;
      lazy[node*2+1]=lazy[node*2+1]*val;
    }
    return;
  }
  int mid = (start + end) / 2;
  update_lazy_propagation(input,segment_tree,lazy,node*2, start, mid, l, r, val);
  update_lazy_propagation(input,segment_tree,lazy,node*2 + 1, mid + 1, end, l, r, val);
  segment_tree[node]=segment_tree[node*2]+segment_tree[node*2+1];
}

int queryRange(int *input,int *segment_tree,int *lazy,int node,int start,int end,int l,int r)
{
    if(start>end || start>r || end<l)
        return 0;
    if(lazy[node]!=0)
    {
        segment_tree[node]=segment_tree[node]+(end - start + 1)*lazy[node];
        if(start!=end)
        {
            lazy[node*2]=lazy[node*2]+lazy[node];
            lazy[node*2+1]=lazy[node*2+1]+lazy[node];
        }
        lazy[node]=0;
    }
    if(start>=l && end<=r)
        return segment_tree[node];
    int mid=(start + end)/2;
    int p1=queryRange(input,segment_tree,lazy,node*2, start, mid, l, r);
    int p2=queryRange(input,segment_tree,lazy,node*2 + 1, mid + 1, end, l, r);
    return (p1 + p2);
}

int main()
{
  printf("*The segment tree stores sum.\n\n");
  int n;
  printf("*Enter number of elements to be stored in array:\n");
  scanf("%d",&n);
  int input[n];
  int i;

  printf("*Original array is:\n");

  for(i=0;i<n;i++)
  scanf("%d",&input[i]);

  int p;
  p=n/2;

  int size_of_segtree=(power(2,p+1)*2);

  int segment_tree[size_of_segtree];

  int lazy[size_of_segtree];

  for(i=0;i<size_of_segtree;i++)
    segment_tree[i]=-999;

  for(i=0;i<size_of_segtree;i++)
    lazy[i]=0;

  build(input,segment_tree,0,n-1,1);//Indexing in segment tree starts from 1.

  printf("*Segment tree formed is:\n");

  print_segment_tree(segment_tree,size_of_segtree);

  printf("Enter range you want to update:\n");

  int left,right;
  scanf("%d %d",&left,&right);

  printf("Enter the value with which you want to update:\n");
  int value;
  scanf("%d",&value);

  update_lazy_propagation(input,segment_tree,lazy,1,0,n-1,left-1,right-1,value);

  int lq,rq,query_answer;

  printf("Enter range to query:\n");
  scanf("%d %d",&lq,&rq);

  query_answer=queryRange(input,segment_tree,lazy,1,0,n-1,lq-1,rq-1);

  printf("*The answer to the query is : %d\n",query_answer);

  printf("\n");

}
