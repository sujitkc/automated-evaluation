//Segment tree storing sum of elements
#include<stdio.h>

void print_segment_tree(int *arr,int n)
{
  int i;
  for(i=1;i<n;i++)
  {
      if(arr[i]!=-999)
        printf("%d ",arr[i]);
  }
  printf("\n");
}

void build(int *input,int *segment_tree,int start,int end,int node)
{
  //printf("Inside Build %d, %d, %d\n", start, end, node);
  int mid=(start+end)/2;
  if(start==end)
  {
    segment_tree[node]=input[start];
  }
  else
  {
    build(input,segment_tree,start,mid,2*node);
    build(input,segment_tree,mid+1,end,2*node+1);
    segment_tree[node]=segment_tree[2*node]+segment_tree[2*node+1];
  }
}

void update(int *input,int *segment_tree,int node,int start,int end,int idx,int val)
{
  if(start==end)
  {
    input[idx]=input[idx]+val;
    segment_tree[idx]=segment_tree[idx]+val;
  }
  else
  {
    int mid=(start+end)/2;
    if(start<=idx && idx<=mid)
    {
      update(input,segment_tree,2*node,start,mid,idx,val);
    }
    else
    {
      update(input,segment_tree,2*node+1,mid+1,end,idx,val);
    }

    segment_tree[node]=segment_tree[2*node]+segment_tree[2*node+1];
  }
}

int power(int a,int b)
{
  int i,answer=1;
  for(i=1;i<b;i++)
  {
    answer=answer*a;
  }
  return answer;
}

int Query(int *input,int *segment_tree,int node,int start,int end, int l,int r)
{
  if(r<start || l>end)
  {
    return 0;
  }

  if(l<=start && r>=end)
  {
    return segment_tree[node];
  }

  int mid=(start+end)/2;

  int p1=Query(input,segment_tree,2*node,start,mid,l,r);
  int p2=Query(input,segment_tree,2*node+1,mid+1,end,l,r);

  return (p1 + p2);
}

int main()
{
  printf("*The segment tree stores sum.\n\n");
  int n;
  printf("*Enter number of elements to be stored in array:\n");
  scanf("%d",&n);
  int input[n];
  int i;

  printf("*Original array is:\n");

  for(i=0;i<n;i++)
  scanf("%d",&input[i]);

  int p;
  p=n/2;

  int size_of_segtree=(power(2,p+1)*2);

  int segment_tree[size_of_segtree];

  for(i=0;i<size_of_segtree;i++)
    segment_tree[i]=-999;

  build(input,segment_tree,0,n-1,1);//Indexing in segment tree starts from 1.

  printf("*Segment tree formed is:\n");

  print_segment_tree(segment_tree,size_of_segtree);

  int idx_,idx;
  int val;

  printf("*Enter index and val with which to update:\n");
  scanf("%d %d",&idx_,&val);

  printf("\n");

  idx=idx_-1;

  update(input,segment_tree,1,0,n-1,idx,val);

  printf("*The original array after update:\n");
  for(i=0;i<n;i++)
  printf("%d ",input[i]);

  printf("\n");

  int left,right,query_answer;
  printf("*Enter the range whose sum you have to find:\n");
  scanf("%d %d",&left,&right);

  printf("\n");

  query_answer=Query(input,segment_tree,1,0,n-1,left-1,right-1);
  printf("*The answer to the query is : %d\n",query_answer);

  printf("\n");
}
