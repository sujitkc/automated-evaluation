#include <iostream>
#include <algorithm>
#include <stdio.h>

struct Node{
    int data;
    int number;
    int height;
    Node* left;
    Node* right;
};

using namespace std;

Node* newNode(int value);
Node* rightRotate(Node* root);
Node* leftRotate(Node* root);
Node* insert(int value, Node** root);
Node* deleteNode(Node* root, int data);
Node * minValueNode(Node* node);
int num(Node *node);
int Rank(int x, Node* root);
Node* FindRank(int k, Node* root);

void inorder(struct Node *tree){
	if(tree!=NULL){
		inorder(tree->left);
		printf("%d ",tree->data);
		inorder(tree->right);
	}
}

int main()
{
    struct Node *root = NULL;
	int arr[] = {9,1,10,0,5,11,-1,2,6};
	int n = 9;
	for(int i = 0; i < n; i++)
		root = insert(arr[i], &root);

	inorder(root);
    printf("\n");
    printf("Rank 0: %d\n",Rank(0,root));
    if(FindRank(9,root))
        printf("Element with rank 9: %d\n",(FindRank(9,root))->data);
    else
        printf("No such element exists\n");
    root = deleteNode(root,10);
    inorder(root);
    printf("\n");
    printf("Rank 0: %d\n",Rank(0,root));
    printf("Element with rank 3: %d\n",(FindRank(3,root))->data);
}

int height(Node* root)
{
    if(root == NULL)
        return -1;
    return max(height(root->left), height(root->right));
}

Node* newNode(int value)
{
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = value;
    newNode->number = 1;
    newNode->right = NULL;
    newNode->left = NULL;
    return newNode;
}

Node* rightRotate(Node* root)
{
    Node* newRoot = root->left;
    if(root != NULL)
        newRoot->number = root->number;

    root->left = newRoot->right;
    newRoot->right = root;
    root->height = height(root);
    newRoot->height = height(newRoot);
    root->number = num(root->left)+num(root->right) +  1;
    return newRoot;
}

Node* leftRotate(Node* root)
{
    Node* newRoot = root->right;
    if(root != NULL)
        newRoot->number = root->number;
    root->right = newRoot->left;
    newRoot->left = root;
    root->height = height(root);
    newRoot->height = height(root);
    root->number = num(root->left)+num(root->right) + 1;
    return newRoot;
}

int getNumber(Node* node){
    if(node->right != NULL && node->left != NULL)
        return 1 + node->right->number + node->left->number;
    if(node->left == NULL && node->right != NULL)
        return 1 + node->right->number;
    if(node->left != NULL && node->right == NULL)
        return 1 + node->left->number;
    if(node->left == NULL && node->right == NULL)
        return 1;
}

int getBalance(Node *N)
{
    if (N == NULL)
        return 0;
    return height(N->left) - height(N->right);
}

Node* insert(int value, Node** root)
{
    if(*root != NULL)
        (*root)->number += 1;
    if(*root == NULL)
        return newNode(value);

    if(value > (*root)->data){
        (*root)->right = insert(value, &((*root)->right));
        (*root)->right->number = getNumber((*root)->right);
    }
    else if(value < (*root)->data){
        (*root)->left = insert(value, &((*root)->left));
        (*root)->left->number = getNumber((*root)->left);
    }
    
    int difference = height((*root)->left) - height((*root)->right);

    if(difference > 1)
    {
        if(height((*root)->left->left) >= height((*root)->left->right))
            return rightRotate((*root));
        else
        {
            (*root)->left = leftRotate((*root)->left);
            return rightRotate(*root);
        }
    }
    else if(difference < -1)
    {
        if(height((*root)->right->right) > height((*root)->right->left))
            return leftRotate((*root));
        else
        {
            (*root)->right = rightRotate((*root)->right);
            return leftRotate(*root);
        }
    }
    (*root)->height = 1 + max(height((*root)->left), height((*root)->right));
    return (*root);
    
}


Node* deleteNode(Node* root, int data)
{   if(root!=NULL)
        root->number-=1;

 
    if (root == NULL)
        return root;
 
    if ( data < root->data )
        root->left = deleteNode(root->left, data);

    else if( data > root->data )
        root->right = deleteNode(root->right, data);

    else
    {
        if( (root->left == NULL) || (root->right == NULL) )
        {
            Node *temp = root->left ? root->left :
                                             root->right;
 
            if (temp == NULL)
            {
                temp = root;
                root = NULL;
            }
            else 
             *root = *temp; 
            free(temp);
        }
        else
        {
            Node* temp = minValueNode(root->right);
 
            root->data = temp->data;
 
            root->right = deleteNode(root->right, temp->data);
        }
    }
 
    if (root == NULL)
      return root;
 
    root->height = 1 + max(height(root->left),
                           height(root->right));
 
    int balance = getBalance(root);
 
    if (balance > 1 && getBalance(root->left) >= 0)
        return rightRotate(root);

    if (balance > 1 && getBalance(root->left) < 0)
    {
        root->left =  leftRotate(root->left);
        return rightRotate(root);
    }

    if (balance < -1 && getBalance(root->right) <= 0)
        return leftRotate(root);

    if (balance < -1 && getBalance(root->right) > 0)
    {
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }
 
    return root;
}


Node * minValueNode(Node* node)
{
    Node* current = node;
    while (current->left != NULL)
        current = current->left;
    return current;
}

int num(Node* node){
    if(node==NULL)
        return 0;
    return node->number;
}

int Rank(int x, Node* root){
    int r = 1;
    Node* current = root;

    while(current){
        if(current->data == x){
            r + num(current->right);
        }
        if(current->data > x){
            r = r + 1 + num(current->right);
            current = current->left;
        }
        else
            return r + num(current->right);
    }
    return r;
}


Node* FindRank(int k, Node* root){
    Node* current = root;
    if(current == NULL)
        return NULL;
    
    while(k){
        if(current == NULL)
            return NULL;
        if(k == 1 + num(current->right))
            return current;
        else if(k > 1 + num(current->right)){
            k = k - 1 -num(current->right);
            current = current->left;
        }
        else    
            current = current->right;
    }

    return current;
}




