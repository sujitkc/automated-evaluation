#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>

#define bool int

void buildSegTree (int arr[], int left, int right, int node);
void Update (int arr[], int tree[], int left, int right, int node, int i, int x);
int RMQ (int tree[], int lq, int rq, int left, int right, int node);
void DisplayArr (int arr[], int size);
void DisplayTree (int tree[], int tree_size);
int sizeSegTree (int n);
int min (int x, int y);
bool isPowerOfTwo (int n);

int tree[] = {};
int tree_size;

void main()
{
    int size;
    printf ("\n\nEnter the size of the array: ");
    scanf("%d", &size);

    int arr[size];
    printf ("\n\nFeed the array with the elements: ");
    for (int i = 0; i < size; i++)
        scanf ("%d", &arr[i]);

    buildSegTree(arr, 0, size-1, 0);
    sizeSegTree (size);
    printf ("\n\nSize of SegTree Array: %d", tree_size);
    printf ("\n\nThe Segment Tree: ");
    for (int j = 0; j < tree_size; j++)
        printf ("%d ", tree[j]);
    
    int option, i, x, lq, rq;
    while (1)
    {
        printf ("\n\n\n\t\t\t\t1. Update\n\t\t\t\t2. Range Minimum Query\n\t\t\t\t3. Display SegTree\n\t\t\t\t4. Exit\n");
        printf ("\nEnter any of the above option: ");
		scanf ("%d", &option); 
        switch (option)
        {
            case 1:
            {
                conti : printf ("\nEnter the position to be updated: ");
                scanf ("%d", &i);
                if (i < 0 || i > size-1)
                {
                    printf ("\n\nError! Enter position between '0' to '%d'!", size-1);
                    goto conti;
                }
                
                printf ("\nEnter the value: ");
                scanf ("%d", &x);
                Update (arr, tree, 0, tree_size-1, 0, i, x);
                
                printf ("\n\nValue succesfully updated!");
                break;
            }

            case 2:
            {
                printf ("\nEnter the left boundary between (0, %d): ", size-1);
                scanf ("%d", &lq);
                printf ("\nEnter the right boundary between (0, %d): ", size-1);
                scanf ("%d", &rq);

                int range_min = RMQ (tree, lq, rq, 0, tree_size-1, 0);
                printf ("\nThe minimum value in the range (%d, %d) is: %d", lq, rq, range_min);
                break;
            }

            case 3:
            {
                printf ("\n\n\t\t\tDisplaying Array...\n\n");
                DisplayArr (arr, size);

                printf ("\n\n\t\t\tDisplaying Segment Tree...\n\n");
                DisplayTree(tree, tree_size);

                break;
            }

            case 4:
                exit(0);

            default: printf ("\n\nError! Enter options between 1-4!");
        }
    }
}

void buildSegTree (int arr[], int left, int right, int node)
{
    if (left == right)
    {
        tree[node] = arr[left];
        return;
    }

    int mid = left + ((right - left) / 2);
    buildSegTree (arr, left, mid, 2*node+1);
    buildSegTree (arr, mid + 1, right, 2*node+2);

    tree[node] = min (tree[2*node+1], tree[2*node+2]);
}

int sizeSegTree (int n)
{   
    return isPowerOfTwo(n) ? tree_size = (2 * n) - 1 : (tree_size = (2 * (pow (2, ceil (log(n)/ log(2))))) - 1);
}

int min (int x, int y)
{
    return x < y ? x : y;
}

bool isPowerOfTwo (int n)
{
    if (n == 0)
        return 0;
    while (n != 1)
    {
        if (n%2 != 0)
            return 0;
        n = n/2;
    }
    return 1;
}

void Update (int arr[], int tree[], int left, int right, int node, int i, int x)
{
    if (left == right)
    {
        arr[i] = x;
        tree[node] = x;
        return;
    }

    if (i >= left && i <= right)
    {
        int mid = left + ((right - left) / 2);
        Update (arr, tree, left, mid, 2*node+1, i, x);
        Update (arr, tree, mid+1, right, 2*node+2, i, x);
        tree[node] = min (tree[2*node+1], tree[2*node+2]);
    }
    return;
}

int RMQ (int tree[], int lq, int rq, int left, int right, int node)
{
    if (lq <= left && rq >= right)
        return tree[node];
    if (lq > right || rq < left)
        return INT_MAX;
    
    int mid = left + ((right - left) / 2);
    return min (RMQ(tree, lq, rq, left, mid, 2*node+1), RMQ(tree, lq, rq, mid+1, right, 2*node+2));
}

void DisplayArr (int arr[], int size)
{
    for (int i = 0; i < size; i++)
        printf ("%d ", arr[i]);
}

void DisplayTree (int tree[], int tree_size)
{
    for (int j = 0; j < tree_size; j++)
        printf ("%d ", tree[j]);
}