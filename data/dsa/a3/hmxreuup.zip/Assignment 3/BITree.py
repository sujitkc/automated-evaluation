#Binary Indexed Tree

def total(BITree,i):
    
    sum = 0 

    i = i+1
 
    while i > 0:
        
        sum += BITree[i]
 
        i -= i & (-i)
    
    return sum
 
def reconstruct(BITree , n , i ,v):
 
    i += 1
 
    while i <= n:
        
        BITree[i] += v

        i += i & (-i)
 
 def build(arr, size):
 
    BITree = [0]*(size+1)
 
   for i in range(size):
        reconstruct(BITree, size, i, arr[i])
 
    return BITree
 

freq = [5, 7, 1, 3, 0, 4, 12, 9, 6, 7, 13, 9]
BITree = build(freq,len(freq))

print("Sum of elements in arr[0..6] is " + str(total(BITree,6)))

freq[3] += 6
reconstruct(BITree, len(freq), 3, 6)

print("Sum of elements in arr[0..6] is " + str(total(BITree,6)))
 
