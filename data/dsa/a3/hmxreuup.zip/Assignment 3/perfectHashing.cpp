#include <stdio.h>
#include <stdlib.h>

struct prim
{
    int a;
    int b;
    int m; 
    int* arr;
};

struct item
{
    int key;
    int val;
};

int n;
int p = 101; 

int hash1(int x);
int hash2(int x, int a, int b, int m);

int main()
{
    scanf("%d", &n);
    item arrayofitems[n];

    int index_count[2*n] = {0};
    prim prim_array[2*n];

    int k, v;

    for(int i = 0; i < 2*n; i++)
        prim_array[i].m = 0;

    for(int i = 0; i < n; i++)
    {
        scanf("%d %d", &k, &v);
        arrayofitems[i].key = k;
        arrayofitems[i].val = v;
        prim_array[hash1(k)].m += 1;
    }

    int fig;

    for(int i = 0; i < 2*n; i++)
    {
        fig = (prim_array[i].m)*(prim_array[i].m);
        prim_array[i].arr = (int*)malloc(fig * sizeof(int));
        prim_array[i].a = rand()%100;
        prim_array[i].b= rand()%100;

    }

    for(int i = 0; i < n; i++)
    {
        if(prim_array[hash1(arrayofitems[i].key)].m > 0)
        {
            *(prim_array[hash1(arrayofitems[i].key)].arr +  hash2(arrayofitems[i].key, prim_array[hash1(arrayofitems[i].key)].a, prim_array[hash1(arrayofitems[i].key)].b, prim_array[hash1(arrayofitems[i].key)].m))= arrayofitems[i].val;
        }
    }

    int q;

    printf("Enter the query : ");

    while(true)
    {
        scanf("%d", &q);

        if(prim_array[hash1(q)].m > 0)
            printf("%d\n", *(prim_array[hash1(q)].arr+hash2(q, prim_array[hash1(q)].a, prim_array[hash1(q)].b, prim_array[hash1(q)].m)));
        else
            printf("Error! Doesn't exist\n");
    }   
}

int hash1(int x){
    return ((3*x + 42)%p)%(2*n);
}

int hash2(int x, int a, int b, int m){
    return ((a*x + b)%p)%(m*m);
}