#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    int height;
    int nos;
    struct node *l;
    struct node *r;
};
int max(int a,int b){
    if(a>b){
        return a;
    }
    return b;
}
void pre_order(struct node *root){
    if(root!=NULL){
        printf("%d ",root->data);
        pre_order(root->l);

        pre_order(root->r);
    }

}
struct node* right_rotate(struct node *y){
    struct node *x=y->l;
    struct node *Temp=x->r;
    x->r=y;
    y->l=Temp;
    y->height=1+max(height(y->l),height(y->r));
    x->height=1+max(height(x->l),height(x->r));
    return x;

}
struct node* left_rotate(struct node *x){
    struct node *y=x->r;
    struct node *Temp=y->l;
    y->l=x;
    x->r=Temp;
    x->height=1+max(height(x->l),height(x->r));
    y->height=1+max(height(y->l),height(y->r));

    return y;

}
struct node *get_min(struct node *temp){
    if(temp==NULL){
        return temp;
    }
    while(temp->l!=NULL){
        temp=temp->l;
    }
    return temp;
}
int height(struct node *root){
    if(root==NULL){
        return 0;
    }
    return root->height;
}
int cur;
int findnos(struct node *root){
    if(root!=NULL){
        int k1=0,k2=0;
        if(root->l!=NULL){
            k1=findnos(root->l);
        }
        if(root->r!=NULL){
            k2=findnos(root->r);
        }
        return k1+k2+1;
    }
    else{
        return 0;
    }


}
int rank(struct node *root,int data,int temp){
    int k=findnos(root);
    //printf("%d\n",k);
    if(data==root->data){
        int rank=1;
        return temp+findnos(root->r);
    }
    if(data>root->data){
        return rank(root->r,data,temp);
    }
    if(data<root->data){
        return rank(root->l,data,findnos(root->r)+1);
    }

}
int findrank(struct node *root,int no){
    if(no==1+findnos(root->r)){
        return root->data;
    }
    else if(no<1+findnos(root->r)){
        return findrank(root->r,no);
    }
    else{
        return findrank(root->l,no);
    }
}
struct node* insert(struct node *root,int data){
    puts("yo");
    if(root==NULL){

        struct node *roo=malloc(sizeof(struct node));
        roo->data=data;
        roo->l=NULL;
        roo->r=NULL;
        cur=data;
        roo->height=1;
        roo->nos=1;
        return roo;
    }
    else if(root->data<data){
        root->r=insert(root->r,data);
    }
    else if(root->data>data){
        root->l=insert(root->l,data);
    }
    else{
        return root;
    }
    root->height=1+max(height(root->l),height(root->r));

    puts("hello");
    cur=root->data;
    int diff=height(root->l)-height(root->r);
    printf("%d \n",root->nos);
    if(diff>1 && data<root->l->data){
        return right_rotate(root);
    }
    else if(diff<-1 && data>root->r->data){
        puts("yess");
        printf("this %d %d %d\n",root->data,root->height,root->r->height);
        return left_rotate(root);
    }
    else if(diff>1 && data>root->l->data){
        root->l= left_rotate(root->l);


        return right_rotate(root);
    }
    else if(diff<-1 && data<root->r->data){
        root->r=right_rotate(root->r);
        pre_order(root);
        puts("here");
        return left_rotate(root);

    }
    return root;
}
int main(){
    struct node *root=NULL;
    root=insert(root,10);
    //printf("%d ",root==NULL);
    pre_order(root);
    puts("");
    root=insert(root,20);
    pre_order(root);
    puts("");
    root=insert(root,30);
    pre_order(root);
    puts("");
    root=insert(root,40);
    pre_order(root);
    puts("");
    root=insert(root,50);
    pre_order(root);
    puts("");
    root=insert(root,25);
    pre_order(root);
    puts("");
    printf("%d %d\n",root->nos,root->l->nos);
    //pre_order(root);
    printf("%d %d\n",rank(root,50,0)+1,findrank(root,3));
    return 0;
}

