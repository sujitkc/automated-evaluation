#include<stdio.h>
#include<math.h>
#include<string.h>
int check_prime(int n){
    int a=sqrt(n);
    int i;
    for(i=2;i<=a;i++){
        if(i%n==0){
            return 0;
        }
    }
    return 1;
}
int find_prime(int m){
    int n1,n2;
    n1=6*m+1;
    n2=6*m-1;
    if(check_prime(n1)){
        return n1;
    }
    return n2;
}
int main(){
    char pattern[100000];
    char string[100000];
    scanf("%s",string);
    scanf("%s",pattern);
    int n=strlen(string);
    int m=strlen(pattern);
    int i,j,x=0,y=0,h=1;
    int prime=find_prime(n);

    for(i=0;i<m;i++){
        x=(2*x+pattern[i])%prime;
        y=(2*y+string[i])%prime;
        h=(h*2)%prime;
    }
    int temp=0;
    for(i=0;i<n-m;i++){
        if(x==y){
            temp=0;
            for(j=i;j<i+m;j++){
                if(pattern[j-i]!=string[j]){
                    temp=1;
                    break;
                }
            }
            if(temp==0){
                puts("match found!!!");
            }

        }
        y=(2*(y-h*string[i])+string[i+m])%prime;
        if(y<0){
            y+=prime;
        }

    }
    return 0;
}
