#include<stdio.h>
#include<stdlib.h>
int SUM(int *arr,int *root,int i,int n){
    int s=0;
    int j;
    while(i>0){
        s=s+root[i];
        j=i&(-i);
        i=i-j;
    }
    return s;
}
void update(int i,int n,int *root,int x){
    int j;
    while(i<n+1){
        root[i]=root[i]+x;
        j=i&(-i);
        i=i+j;
    }
}
int main(){
    int n;
    scanf("%d",&n);
    int i;
    int arr[n];
    int *root=malloc((n+1)*sizeof(int));
	for(i=0;i<n;i++){
        scanf("%d",&arr[i]);
        root[i+1]=0;
    }
    for(i=0;i<n;i++){
        update(i+1,n,root,arr[i]);
    }
    for(i=1;i<n+1;i++){
        printf("%d ",root[i]);
    }
    return 0;
}

