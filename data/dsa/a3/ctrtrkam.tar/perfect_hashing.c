#include<stdio.h>
#include<stdlib.h>
#include"math.h"
struct hashpara
{
	long long int n,m,p,a,b;
};
struct hash1
{
	long long int count,*table;
	struct hashpara *para;
};
int check_prime(long long int n)
{
	long long int a=sqrt(n),i=2;
	for(;i<=a;i++)
	if(n%i==0)
	return 0;
	return 1;
}
long long int find_prime(long long int n)
{
	long long int m1=6*n-1;
	long long int m2=m1+2;
	if(check_prime(m1))
	return m1;
	else
	return m2;
}
struct hashpara* find_para(long long int len,int s)//s=0 then m=2*n,or m=n^2
{
	struct hashpara *n=malloc(sizeof(struct hashpara));
	n->n=len;
	if(s=0)
	n->m=2*len;
	else 
	n->m=len*len;
	n->p=find_prime(n->m);
	n->a=sqrt(n->p);
	n->b=n->p/n->a;
	return n;
}

long long int hash(long long int x,struct hashpara *s)
{
	return ((s->a*x+s->b)%s->p)%s->m;
}

void main()
{
	long long int n;
	scanf("%lld",&n);
	long long int arr[n];
	
	struct hashpara *a=find_para(n,0);
	struct hash1 ma[a->m];
	
	for(long long int i=0;i<a->m;i++)
	{
		ma[i].count=0;
		ma[i].para=NULL;
		ma[i].table=NULL;
	}
	
	for(long long int i=0;i<n;i++)
	{
	scanf("%lld",&arr[i]);
	ma[hash(arr[i],a)].count++;
	}
	
	for(long long int i=0;i<a->m;i++)
	{
		if(ma[i].count!=0)
		{
			ma[i].para=find_para(ma[i].count,1);
			ma[i].table=(long long int *)malloc(sizeof(long long int) * ma[i].para->m);
			for(int j=0;j<ma[i].count;j++)
			ma[i].table[j]=-1;
		}
	}
	for(long long int i=0;i<n;i++)
	{
		long long int k=hash(arr[i],a);
		struct hash1 t=ma[k];
		t.table[hash(arr[i],t.para)]=arr[i];
	}
	for(long long int i=0;i<a->m;i++)
	{
		if(ma[i].count!=0)
		{
			for(int j=0;j<ma[i].count;j++)
			printf("%lld ",ma[i].table[j]);
			
			printf("\n");
		}
	}
	
	
}
