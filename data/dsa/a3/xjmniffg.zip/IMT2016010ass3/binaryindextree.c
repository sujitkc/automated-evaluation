#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
void update(int i,int x,int n,int arf[])
{
    int j;
    while(i<n&&i>0)
    {
        arf[i]=arf[i]+x;
        j=i&(-i);
        i=i+j;
    }
}
int prefixSum(int i,int arf[])
{
    int j,s=0;
    while(i>0)
    {
        s=s+arf[i];
        j=i&(-i);
        i=i-j;
    }
    return s;
}
void main()
{
    int arr[]={0,1,4,6,3,7,2};
    int size=7;//sizeof(arr)/sizeof(int);
    int arf[7]={0};
    int i,ans;
    for(i=0;i<size;i++)
    {
        update(i,arr[i],size,arf);
    }
    //for(i=1;i<size;i++)
        //printf("%d\n",arf[i]);
    ans=prefixSum(3,arf)-prefixSum(1,arf);
    printf("%d",ans);
}

