//it is maximum segment tree
#include<stdio.h>
#include<math.h>
#include<limits.h>
#include<stdlib.h>
#define left(x)(2*(x)+1)
#define right(x)(2*(x)+2)
#define parent(x)(((x)-1)/2)
int min(int a,int b)
{
    if(a<b)
        return a;
    else
        return b;
}
typedef struct
{
	int *tree,leaf,size;
}SegTree;
void update(int node,int start,int end,int index,int n,SegTree *s)
{
    if(start==end)
    {
        s->tree[index]+=n;
        s->tree[node]+=n;
    }
    else
    {
        int mid=(start+end)/2;
        if(start<=index&&index<=mid)
            update(2*node,start,mid,index,n,s);
        else
            update(2*node+1,mid+1,end,index,n,s);
        s->tree[node]=s->tree[2*node]+s->tree[2*node+1];
    }
}
void build(SegTree *s,int *arr,int st,int ed,int curr)
{
	if(st+1==ed)
    {
		s->tree[curr]=(st<s->size)?arr[st]:INT_MAX;//vahi bhi check karna ha har baar
		return;
	}
	int mid=(st+ed)/2;
	build(s,arr,st,mid,left(curr));
	build(s,arr,mid,ed,right(curr));
	s->tree[curr]=min(s->tree[left(curr)],s->tree[right(curr)]);//>>>>>>>>>>>>>>>>>MAIN FUNTION OF MAKING TREE<<<<<<<<<<<<<<<<<<<<<<
}
void initialize(SegTree *s,int *arr,int n)
{
	s->size=n;
	s->leaf=pow(2,ceil(log2(s->size)));
	s->tree=(int*)malloc(sizeof(int)*(2*(s->leaf)-1));
	build(s,arr,0,s->leaf,0);
}
/*
int getsum(int node,int first,int last,SegTree s)//ya nahi chal raha check it first
{
    if(node<=first&&node>=last)
        return s.tree[node];
    else if(node>last||node<first)
        return 0;
    else
    {
        int mid=(first+last)/2;
        return getsum(2*node+1,first,mid,s)+getsum(2*node+2,mid+1,last,s);
    }
}

int getSumUtil(int *st, int ss, int se, int qs, int qe, int si)
{
    // If segment of this node is a part of given range, then return
    // the sum of the segment
    if (qs <= ss && qe >= se)
        return st.tree[si];

    // If segment of this node is outside the given range
    if (se < qs || ss > qe)
        return 0;

    // If a part of this segment overlaps with the given range
    int mid=(ss+se)/2;
    return getSumUtil(st, ss, mid, qs, qe, 2*si+1) +
           getSumUtil(st, mid+1, se, qs, qe, 2*si+2);
}
int getSum(int *st, int n, int qs, int qe)
{
    if (qs < 0 || qe > n-1 || qs > qe)
    {
        printf("Invalid Input");
        return -1;
    }

    return getSumUtil(st, 0, n-1, qs, qe, 0);
}*/
int rangeMin(int qStart,int qEnd,int start,int end,int pos,SegTree s)
{
    if(qStart<=start&&qEnd>=end)
        return s.tree[pos];
    if(qStart>end||qEnd<start)
        return INT_MAX;
    int mid=(end+start)/2;
    return min(rangeMin(qStart,qEnd,start,mid,2*pos+1,s),(rangeMin(qStart,qEnd,mid+1,end,2*pos+2,s)));
}
int main()
{
	int arr[]={1,3,7,2,11,3,0,13};
	int size=sizeof(arr)/sizeof(int);
	SegTree s;
	initialize(&s,arr,size);
	int val=4,index=3,end=s.size,i;
	//printf("%d\n\n",end);
	for(i=0;i<2*(s.leaf)- 1;i++)
		printf("%d ", s.tree[i]);
    printf("\n");
	int ans,qStart=4,qEnd=7,start=0,pos;
	ans=rangeMin(qStart,qEnd,start,end-1,0,s);
	//ans=getSum(arr,end,qStart,qEnd);
	printf("\n\n%d",ans);
	return 0;
}
