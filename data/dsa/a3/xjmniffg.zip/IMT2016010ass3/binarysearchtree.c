//binary search tree
#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *lc,*rc;
};

typedef struct node bTree;
bTree *maxValueNode(bTree *node)
{
    bTree *temp=node;
    while (temp->rc!=NULL)
        temp=temp->rc;
    return temp;
}
bTree *deleteNode(bTree *root, int n)//it is not sir style delete but it works
{
    if (root==NULL)
        return root;
    if(n<root->data)
        root->lc=deleteNode(root->lc,n);
    else if (n>root->data)
        root->rc=deleteNode(root->rc,n);
    else
    {
        if (root->lc==NULL)
        {
            bTree *temp=root->rc;
            free(root);
            return temp;
        }
        else if (root->rc==NULL)
        {
            bTree *temp=root->lc;
            free(root);
            return temp;
        }
        bTree *temp=maxValueNode(root->lc);//if both child exists >> it is inorder deletion
        root->data=temp->data;
        root->lc=deleteNode(root->lc,temp->data);
    }
    return root;
}
void printInorder(bTree *tree)
{
     if (tree==NULL)
          return;
     printInorder(tree->lc);
     printf("%d ",tree->data);
     printInorder(tree->rc);

}

bTree *insert(bTree *t,int n)
{
    bTree *temp;
    if(t==NULL)
    {
        t=malloc(sizeof(bTree));
        t->data=n;
        t->lc=t->rc=NULL;
		return t;
    }
    else if(t->data>n)
        t->lc=insert(t->lc,n);
    else if(t->data<n)
        t->rc=insert(t->rc,n);
    return t;
}

int main()
{
    int arr[]={1,4,6,3,7,2};
    bTree *t = NULL;
    int size=sizeof(arr)/sizeof(int);
    int i;
    for(i=0;i<size;i++)
    {
        t=insert(t,arr[i]);
    }
    printInorder(t);
	t=deleteNode(t,4);
	//printInorder(t);
	return 0;
}
