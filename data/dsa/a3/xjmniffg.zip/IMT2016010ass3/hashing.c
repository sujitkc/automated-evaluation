//making hash tables
//we can even use a key for getting index in a better way by passing key ti hashIndex function rather than sending the number itself
#include<stdio.h>
#include<stdlib.h>
#define SIZE 4//in this case >>>>check it for each edited program
struct table
{
    int data;
    struct table  *nptr;
};
typedef struct table Node;

int hashIndex(int n)//it contains the algorithm for getting index
{
    int ans;
    ans=n%4;
    return ans;
}
void insert(int n,Node *hTable[])
{

    int index;
    index=hashIndex(n);
    Node *temp,*buff,*temp2;
    temp=malloc(sizeof(Node));
    temp->data=n;
    temp->nptr=NULL;
    temp2=buff=hTable[index];
    if(buff==NULL)
    {
        //printf("ab tak sahi ha");
        buff=temp;
        //printf("ab tak sahi ha");
        buff->nptr=NULL;
        hTable[index]=buff;
    }
    else
    {
        while(buff->nptr!=NULL)//this function can be edited to put the new node in specific sequence in linked list eg put it sorted
            buff=buff->nptr;
        buff->nptr=temp;
        hTable[index]=temp2;
    }
    //free(temp);
}
void print(Node *hTable[])
{
    int i;
    for(i=0;i<SIZE;i++)
    {
        Node *temp;
        temp=hTable[i];
        if(temp==NULL)
        {
            printf("NOT element\n");
            continue;
        }
        while(temp!=NULL)
        {
            printf("%d ",temp->data);
            temp=temp->nptr;
        }
        printf("\n");
    }
}
void udade(int n,Node *hTable[])
{
    int index;
    index=hashIndex(n);
    Node *temp,*buff,*temp2;
    temp2=buff=hTable[index];
    if(hTable[index]==NULL)
    {
        printf("NO such element exist\n");
        return;
    }
    if(hTable[index]->nptr==NULL)
    {
        if(hTable[index]->data==n)
        {
            //printf("bra");
            temp=hTable[index]->nptr;
            free(hTable[index]);
            hTable[index]=temp;
            free(temp);
            return;
        }
        else
            printf("NO such element exist\n");
    }
    if(hTable[index]->data==n)
    {
        temp=buff->nptr;
        free(buff);
        hTable[index]=temp;
        return;
    }
    else
    {

        while((buff->nptr->data!=n)&&(buff->nptr!=NULL))
            buff=buff->nptr;

        if(buff->nptr->data==n)
        {
            //while(1)
                //printf("%d\n",buff->data);
            //printf("pussy");
            temp=buff->nptr;
            buff->nptr=temp->nptr;
            free(temp);
            hTable[index]=temp2;
            return;
        }
        if(buff->nptr==NULL)
        {
            printf("NO such element exist\n");
            return;
        }
    }
}
void main()
{
    int arr[]={1,3,4,2,8,12,16,20};
    int i,size;
    size=sizeof(arr)/sizeof(int);
    Node *hTable[size];
    for(i=0;i<size;i++)
        hTable[i]=NULL;
    for(i=0;i<size;i++)
        insert(arr[i],hTable);
    print(hTable);
    //printf("maal gaya\n");
    udade(20,hTable);//delete function>>>>delete is reserved word
    printf("\n");
    print(hTable);
}
