#include <stdio.h>
#include <stdlib.h>

struct node
{
	int data;
	int height;
	int num;//no. of elements in that sub tree
	struct node* left;
	struct node* right;
};

typedef struct node node;

//0child->0,lchild->1,rchild->2,both->3
int number_of_children(node* place)
{
	int count = 0;
	if(place->left != NULL)
		count += 1;
	if(place->right != NULL)
		count += 2;
	return count;
}

void visit(node* place)//what actions to be done when visit this node
{
	printf("(%d,%d) ",place->data,place->height);
}

void inorder(node* root)
{
	if(root == NULL)
		return;
	inorder(root->left);
	visit(root);
	inorder(root->right);
}

int get_height(node* place)
{
	if(place == NULL)
		return -1;
	else
		return place -> height;
}

int get_num(node* place)
{
	if(place == NULL)
		return 0;
	else
		return place -> num;
}

int max(int a,int b)
{
	return a>b?a:b;
}

node* make_node(int val)
{
	node* place = (node *)malloc(sizeof(node));
	if(place == NULL)
		printf("memory error\n");
	place -> data   = val;
	place -> left   = NULL;
	place -> right  = NULL;
	place -> height = 0;
	place -> num = 1;
	return place;
}

void update_height(node* lc,node* rc,node* p)//since they need to be updated in the correct order
{
	lc->height = max(get_height(lc->left),get_height(lc->right)) + 1;	
	rc->height = max(get_height(rc->left),get_height(rc->right)) + 1;
	p->height = max(get_height(p->left),get_height(p->right)) + 1;
}

void update_num(node* lc,node* rc,node* p)//since they need to be updated in the correct order
{
	lc->num = get_num(lc->left)+get_num(lc->right)+1;
	rc->num = get_num(rc->left)+get_num(rc->right)+1;
	p->num = get_num(p->left)+get_num(p->right)+1;
}

node* rotate(node* cur,int a,int b)
{
	int flag1 = 0,flag2 = 0;
	node *z = cur,*y = NULL,*x = NULL;
	if(b > a)
	{
		flag1 = 1;//1 for right,0 for left
		y = cur->right;
	}
	else
		y = cur->left;

	a = get_height(y->left);
	b = get_height(y->right);
	if(b > a)
	{
		flag2 = 1;
		x = y->right;
	}
	else
		x = y->left;

	//left left
	if(flag1 == 0 && flag2 == 0)
	{
		z -> left = y -> right;
		y -> right = z;

		update_height(x,z,y);
		update_num(x,z,y);
		return y;
	}

	//left right
	if(flag1 == 0 && flag2 == 1)
	{
		y->right = x->left;
		z->left = x->right;
		x->left = y;
		x->right = z;
		update_height(x,z,y);
		update_num(x,z,y);
		return x;
	}

	//right left
	if(flag1 == 1 && flag2 == 0)
	{
		z->right = x->left;
		y->left = x->right;
		x->left = z;
		x->right = y;
		update_height(x,z,y);
		update_num(x,z,y);
		return x;	
	}

	//right right
	if(flag1 == 1 && flag2 == 1)
	{
		z->right = y->left;
		y->left = z;
		update_height(x,z,y);
		update_num(x,z,y);
		return y;

	}
}

node* insert(node** root,node* ins,node* cur)//check before passing.don't want repeats 
{
	if(cur != NULL && cur->data < ins->data)
		cur->right = insert(root,ins,cur->right);
	else if(cur != NULL && cur->data > ins->data)
		cur->left = insert(root,ins,cur->left);	
	if(*root == NULL)
	{
		*root = ins;
		return *root;
	}
	else if(cur == NULL)
	{
		return ins;
	}
	int a = get_height(cur->left),b = get_height(cur->right);
	//update on path
	cur->height = max(a,b)+1;
	cur->num = get_num(cur->left)+get_num(cur->right)+1;
	if(abs(b-a) > 1)//cur is the node where rotation needs to happen
	{
		return rotate(cur,a,b);
	}
	return cur;//so that nothing changes
}

node* delete(node** root,int val,node* cur)
{
	if(cur != NULL && cur->data == val)
	{
		int count = number_of_children(cur);
		if(count == 0)//no children
		{
			free(cur);
			return NULL;
		}
		else if(count == 1)//only left child
		{
			node* temp = cur->left;
			free(cur);
			return temp;
		}
		else if(count == 2)//only right child
		{
			node* temp = cur->right;
			free(cur);
			return temp;	
		}
		else
		{
			int pred = 0;
			node* to_find = cur->left;
			while(to_find->right != NULL)
				to_find = to_find->right;
			pred = to_find->data;
			cur->data = pred;//change this to the pred and now delete the predecesor->will this create problems when try to back track??
			cur->left = delete(root,pred,cur->left);//last parameter in each frame helps give pointer to current node i am in.reciving pointer takes address of where it came from
		}
	}
	else if(cur != NULL && cur->data < val)
		cur->right = delete(root,val,cur->right);
	else if(cur != NULL && cur->data > val)
		cur->left = delete(root,val,cur->left);	
	if(*root == NULL)
	{
		return *root;
	}
	//not dealing with case where node doesn't exist.check that before entering
	//come here means need to check heights now, not going further or not returning


	int a = get_height(cur->left),b = get_height(cur->right);
	cur->height = max(a,b)+1;
	cur->num = get_num(cur->left)+get_num(cur->right)+1;
	if(abs(b-a) > 1)//cur is the node where rotation needs to happen
	{
		return rotate(cur,a,b);
	}
	return cur;//so that nothing changes
}

int search(node* root,int val)
{
	node* cur = root;
	while(cur != NULL)
	{
		if(cur -> data == val)
			return 1;
		else if(cur -> data < val)//means go right
			cur = cur -> right;
		else
			cur = cur -> left;
	}
	return 0;
}

int find_rank_given_number(node* root,int val)
{
	node* cur = root;
	int rank = 1;
	while(cur != NULL)
	{
		if(cur -> data == val)
			return rank + get_num(cur->right);
		else if(cur -> data < val)//means go right
			cur = cur -> right;
		else
		{
			rank += get_num(cur->right)+1;
			cur = cur -> left;
		}
	}
	return -1;//if element not found
}

int find_number_given_rank(node* root,int val)//assumes that a valid rank is asked
{
	node* cur = root,*temp = NULL;
	int cur_rank = get_num(cur->right) + 1;
	while(cur != NULL)
	{
		//printf("%d\n",cur->data);
		//printf("rank:%d\n",cur_rank);
		if(cur_rank == val)
			return cur->data;
		else if(cur_rank > val)//means go right since need a bigger number than cur
		{
			//printf("Went right\n");
			temp = cur -> right;
			cur_rank -= (get_num(temp->left)+1);//since the root is also ignored
			cur = cur -> right;
		}
		else
		{
			//printf("Went left\n");
			temp = cur -> left;
			cur_rank += get_num(temp->right)+1;
			cur = cur -> left;
		}
		//printf("\n");
	}
	return 256;
}

int main()
{
	//can't add repeating values to the tree->not needed anymore
	node* root = NULL;
	root = insert(&root,make_node(2),root);
	root = insert(&root,make_node(3),root);
	root = insert(&root,make_node(1),root);
	root = insert(&root,make_node(4),root);
	root = insert(&root,make_node(5),root);
	root = insert(&root,make_node(6),root);
	root = insert(&root,make_node(0),root);
	root = insert(&root,make_node(7),root);
	inorder(root);
	printf("\n");
	int n = 0;
	//scanf("%d",&n);
	//printf("%d\n",find_rank_given_number(root,n));
	scanf("%d",&n);
	printf("%d\n",find_number_given_rank(root,n));
}