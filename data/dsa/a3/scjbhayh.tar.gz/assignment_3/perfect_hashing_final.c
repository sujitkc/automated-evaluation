#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

struct row
{
	int a;
	int b;
	int p;
	int n;//no. of numbers to be hashed.Size of table = n*n
	int m;//m = n*n
	int last_index;
	int *storage;//used before hashing the numbers
	int *arr;
};

typedef struct row row;

row* make_row(int n)
{
	row* temp = (row *)malloc(sizeof(row));
	temp->n = n;
	temp->a = 0;
	temp->b = 0;
	temp->p = 0;
	temp->m = 0;
	temp->last_index = 0;//need this to fill up temp
	temp->m = n*n;
	if(n == 0)
	{
		temp->storage = NULL;
		temp->arr = NULL;
	}
	else
	{
		temp->storage = (int *)calloc(n,sizeof(int));
		temp->arr = (int *)calloc(n*n,sizeof(int));
	}
	return temp;
}

int closest_greater_prime(int n)
{
	int m = n+1,end,i;//in case n is a prime
	while(1)
	{
		i = 0;
		end = sqrt(m);//to avoid recomputation
		end += 1;
		for( i = 2 ; i < end ; i++)
		{
			if(m%i == 0)
				break;
		}
		if(i == end)
			return m;
		m++;
	}
}

void generate_perfect_hash_function(int arr[],int n,int m,int type,int final_val[])//since m = 2n || m = n^2
{
	int a,b,p = m,hashed_val;
	int flag = 0;
	int *check_arr = (int *)calloc(m,sizeof(int));
	while(flag == 0)
	{
		int num = rand()%10+1;//so that num is never 0
		for(int i = 0 ; i < num ; i++)//so that don't always pick next prime->predictable
		{
			p = closest_greater_prime(p);
		}
		a = rand()%p+1;//zero here will ruin it
		b = rand()%p;
		flag = 1;
		if(type == 2)//secondary hash function
		{	
			for(int i = 0 ; i < n ; i++)//all these numbers are in this hash table
			{
				hashed_val = ((a*arr[i] + b)%p)%m;
				if(check_arr[hashed_val] == 1)
				{
					printf("collision at:%d %d %d\n",i,arr[i],check_arr[i]);
					flag = 0;
					break;
				}
				else
					check_arr[hashed_val] = 1;
			}
			for(int i = 0 ; i < m ; i++)
				check_arr[i] = 0;
		}
		else
		{
			for(int i = 0 ; i < n ; i++)
			{
				hashed_val = ((a*arr[i] + b)%p)%m;
				check_arr[hashed_val] += 1;
			}
			int sum = 0;
			for(int i = 0 ; i < m ; i++)
			{
				sum += (check_arr[i]*check_arr[i]);
				if(sum > 2*n)
				{
					flag = 0;
					break;
				}
			}
			for(int i = 0 ; i < m ; i++)
				check_arr[i] = 0;
		}
	}
	final_val[0] = a;
	final_val[1] = b;
	final_val[2] = p;
	free(check_arr);
}

int search(row* final_table[],int val,int a,int b,int p,int m)
{
	int hash1 = ((a*val + b)%p)%m;
	a = final_table[hash1]->a;
	b = final_table[hash1]->b;
	p = final_table[hash1]->p;
	m = final_table[hash1]->m;
	if(a == 0 && b == 0 && p == 0 && m == 0)//this is when it goes to an empty row.then get a floating point exception
		return 0;
	int hash2 = ((a*val + b)%p)%m;
	if(final_table[hash1]->arr[hash2] == val)
		return 1;
	return 0;
}

int main()
{
	int arr[10] = {1,2,3,4,5,6,7,8,9,10},n = 10,m = 20,final[3];
	m = 2*n;
	time_t t;   

	srand((unsigned) time(&t));

	generate_perfect_hash_function(arr,10,20,1,final);
	int a = final[0],b = final[1],p = final[2];
	
	int temp[m];//this will store number of elements in each hash row
	row* final_table[m];
	for(int i = 0 ; i < m ; i++)//initialise to zero
	{
		temp[i] = 0;
	}

	for(int i = 0 ; i < n ; i++)//get count of number of numbers in every row 
	{
		temp[((a*arr[i] + b)%p)%m] += 1;
	}

	for(int i = 0 ; i < m ; i++)//make the rows of the table now that sizes are known
	{
		final_table[i] = make_row(temp[i]);
	}	

	for(int i = 0 ; i < n ; i++)//fill the table now(without doing a secondary hash)
	{
		int location = ((a*arr[i] + b)%p)%m;
		int num = final_table[location]->last_index;
		
		final_table[location]->last_index++;

		final_table[location]->storage[num] = arr[i];
	}

	int temp_final[3];

	for(int i = 0 ; i < m ; i++)//these many secondary hash functions
	{
		int s = final_table[i]->n;//s for size
		if(s != 0)
		{
			generate_perfect_hash_function(final_table[i]->storage,s,s*s,2,temp_final);
			final_table[i]->a = temp_final[0];
			final_table[i]->b = temp_final[1];
			final_table[i]->p = temp_final[2];
			int a = final_table[i]->a,b = final_table[i]->b,p = final_table[i]->p;

			for(int j = 0 ; j < s ;j++)//putting the numbers into the final hash table
			{
				int hval = ((a*(final_table[i]->storage[j]) + b)%p)%(s*s);
				final_table[i]->arr[hval] = final_table[i]->storage[j];
			}
		}
	}
	printf("Table starts here:\n\n");
	for(int i = 0 ; i < m ; i++)
	{
		for(int j = 0 ; j < final_table[i]->m ; j++)
			printf("%d ",final_table[i]->arr[j]);
		printf("\n");
	}
	printf("Search results:\n");
	printf("%d\n",search(final_table,8,a,b,p,m));
	printf("%d\n",search(final_table,4,a,b,p,m));
	printf("%d\n",search(final_table,127,a,b,p,m));
	//printf("%d\n",search(final_table,-1,a,b,p,m));//can't search for -ve or 0, getting a floating point exception
	printf("%d\n",search(final_table,10,a,b,p,m));
}