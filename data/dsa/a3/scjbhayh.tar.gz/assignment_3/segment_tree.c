#include <stdio.h>
#include <stdlib.h>
#include <math.h>

//segment tree will ony have indices

void print_arr(int arr[],int n)
{
	for(int i = 0 ; i < n ; i++)
	{
		printf("%d ",arr[i]);
	}
	printf("\n");
}

void make_segment_tree(int arr[],int n,int seg_tree[],int m,int k)//calculate for k outside
{
	int dummy_val = 0;
	int start = pow(2,k)-1;
	for(int i = 0 ; i < n ; i++)//filling up base level first
		seg_tree[start+i] = i;
	for(int i = n ; i < m ; i++)
		seg_tree[start+i] = dummy_val;//can fill it with any value since the query will never go there
	int pos = m-1;
	while(pos > 0)//> and not >=
	{
		seg_tree[(pos-1)/2] = arr[seg_tree[pos]] < arr[seg_tree[pos-1]]?seg_tree[pos]:seg_tree[pos-1];
		pos -= 2;
	}
}

void update(int arr[],int n,int seg_tree[],int m,int i,int x)
{
	arr[i] = x;
	int pos = m-1,parent,left,right;
	while(seg_tree[pos] != i)
		pos--;
	while(pos > 0)
	{
		parent = (pos-1)/2;
		left = 2*parent + 1;
		right = left + 1;
		seg_tree[parent] = arr[seg_tree[left]] < arr[seg_tree[right]]?seg_tree[left]:seg_tree[right];
		pos = parent;
	}
}

int range_minimum_query(int arr[],int seg_tree[],int i_query,int j_query,int pos,int i,int j)//i,j is the query i want to make
{
	if(i_query == i && j_query == j)
		return seg_tree[pos];
	int t = (i+j)/2;
	if(t < i_query)//move right
		return range_minimum_query(arr,seg_tree,i_query,j_query,2*pos+2,t+1,j);
	else if(t >= j_query)//move left
		return range_minimum_query(arr,seg_tree,i_query,j_query,2*pos+1,i,t);
	else//t lies in between 
	{
		int l,r;
		l = range_minimum_query(arr,seg_tree,i_query,t,2*pos+1,i,t);
		r = range_minimum_query(arr,seg_tree,t+1,j_query,2*pos+2,t+1,j);
		return arr[l] < arr[r]?l:r;
	}
}

int main()
{
	int k,arr[] = {6,4,12,43,1,5,21,93},n = 8;
	//             0,1,2, 3, 4,5,6, 7
	k = log(n)/log(2);
	printf("%d\n",k);
	int *seg_tree,m = (2*pow(2,k))-1;
	seg_tree = (int *)calloc(m,sizeof(int));
	make_segment_tree(arr,n,seg_tree,m,k);
	print_arr(seg_tree,m);
	update(arr,n,seg_tree,m,0,3);
	print_arr(seg_tree,m);
	printf("%d\n",arr[range_minimum_query(arr,seg_tree,0,3,0,0,n-1)]);
}