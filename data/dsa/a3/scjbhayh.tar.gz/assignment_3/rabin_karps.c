#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

int closest_greater_prime(int n)
{
	int m = n+1,end,i;//in case n is a prime
	while(1)
	{
		i = 0;
		end = sqrt(m);//to avoid recomputation
		end += 1;
		for( i = 2 ; i < end ; i++)
		{
			if(m%i == 0)
				break;
		}
		if(i == end)
			return m;
		m++;
	}
}

int rabin_karp(char st[],char pattern[],int n,int m)
{
	int p = m;
	int num = rand()%10+1;//so that num is never 0
	
	time_t t;   
	srand((unsigned) time(&t));
	
	for(int i = 0 ; i < num ; i++)
		p = closest_greater_prime(p);

	printf("p = %d\n",p);

	int base = 26;//no of lower case char.directly use the ascii value to hash

	int x = 0 ,y = 0, power = 1;
	for(int i = 0 ; i < m ; i++)
	{
		x = (base*x + pattern[i])%p;
		y = (base*y + st[i])%p;
		if(i != 0)
			power = (base*power)%p;
	}
	printf("%d\n",power);
	printf("x = %d\n",x);
	for(int i = 0 ; i < n-m ; i++)
	{
		printf("%c %d\n",st[i],y);
		if(x == y)
		{
			printf("matching hash value found\n");
			int j;
			for( j = 0 ; j < m ; j++)
				if(st[i+j] != pattern[j])
					{
						printf("mismatch because of %c\n",st[i+j]);
					break;
					}

			if( j == m )
				return i;//returning first match
		}
		y = (base*(y - power*st[i]) + st[m+i])%p;
		if(y < 0) y += p;
	}
	return -1;//string not found
}

int main()
{
	char st[] = "this is a trial string",pattern[] = "stringgg";
	int n = strlen(st), m = strlen(pattern);
	printf("%d %d\n",n,m);
	int val = rabin_karp(st,pattern,n,m);
	if(val == -1)
		printf("String not found\n");
	else
		printf("Match found at index %d\n",val);
}