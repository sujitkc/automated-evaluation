#include <stdio.h>

//start indexing of the tree from 1

void update(int arr[],int tree[],int n,int i,int x)//updates i by x
{
	arr[i] += x;
	int j = 0;
	while(i <= n)
	{
		tree[i] = tree[i] + x;
		j = i & -i;
		i = i + j;
	}	
}

int prefix_sum(int tree[],int i)
{
	int sum = 0 , j = 0;
	while(i > 0)
	{
		sum = sum + tree[i];
		j = i & -i;
		i = i - j;
	}
	return sum;
}

int range_sum_query(int tree[],int i,int j)//this query is exclusive of i i.e. (i,j]
{
	return prefix_sum(tree,j) - prefix_sum(tree,i);
}

void make_tree(int arr[],int tree[],int n)
{
	for(int i = 0 ; i <= n ; i++)
		tree[i] = 0;
	for(int i = 1 ; i <= n ; i++)
	{
		update(arr,tree,n,i,arr[i]);
	}
}

int main()
{
	int arr[] = {0,1,2,3,4,5,6,7,8,9,10},tree[11],n = 10;
	tree[0] = 0;
	make_tree(arr,tree,n);
	for(int i = 0 ; i <= 10 ; i++)
		printf("%d ",tree[i]);
	printf("\n");
	int i,j;
	//update(arr,tree,n,5,5);
	while(1)
	{
		scanf("%d %d",&i,&j);
		printf("%d\n",range_sum_query(tree,i,j));
	}
}