#include<stdio.h>
#include<math.h>
#include<stdlib.h>
struct point{
    int a,b,prime,n;
    int *arr;
};
int check_prime(int n){
    int a=sqrt(n);
    int i;
    for(i=2;i<=a;i++){
        if(i%n==0){
            return 0;
        }
    }
    return 1;
}
int find_prime(int m){
    int n1,n2;
    n1=6*m+1;
    n2=6*m-1;
    if(check_prime(n1)){
        return n1;
    }
    return n2;
}
int find_a(int prime){
    return sqrt(prime);
}
int find_b(int a,int prime){
    return prime/a;
}
int main(){
    int n;
    scanf("%d",&n);
    int *main_arr;
    main_arr=malloc(sizeof(int)*n);
    int i;
    for(i=0;i<n;i++){
        scanf("%d",&main_arr[i]);
    }
    struct point *arr[2*n];
    for(i=0;i<2*n;i++){
        arr[i]=NULL;
    }
    int prime=find_prime(2*n);
    int a=find_a(prime);
    int b=find_b(a,prime);
    int m=2*n;
    int k;
    for(i=0;i<n;i++){
        k=((main_arr[i]*a+b)%prime)%m;
        if(arr[((main_arr[i]*a+b)%prime)%m]==NULL){

            arr[k]=malloc(sizeof(struct point));
            arr[k]->n=1;
        }
        else{
            arr[k]->n++;
        }
    }
    int j;
    for(i=0;i<m;i++){
        if(arr[i]!=NULL){
            arr[i]->prime=find_prime(2*(arr[i]->n));
            arr[i]->a=find_a(arr[i]->prime);
            arr[i]->b=find_b(arr[i]->a,arr[i]->prime);
            arr[i]->arr=malloc(sizeof(int)*2*(arr[i]->n));
            for(j=0;j<2*arr[i]->n;j++){
                arr[i]->arr[j]=-1;
            }
        }
    }
    int temp;
    for(i=0;i<n;i++){
        k=((main_arr[i]*a+b)%prime)%m;
        temp=((main_arr[i]*(arr[k]->a)+arr[k]->b)%arr[k]->prime)%(arr[k]->n*2);
        if(arr[k]->arr[temp]!=-1){
            arr[k]->a++;
            i=0;
            for(j=0;j<2*arr[k]->n;j++){
                arr[k]->arr[j]=-1;

            }

            continue;
        }
        arr[k]->arr[temp]=main_arr[i];
    }
    for(i=0;i<m;i++){
        if(arr[i]!=NULL){
            for(j=0;j<(arr[i]->n)*2;j++){
                printf("%d ",arr[i]->arr[j]);
            }puts("");
        }
    }
    return 0;
}
