#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int main()
{
	int n,arr[10000],tree[10000],sum,choice,c,d,i,l,e;
	printf("Enter the number of nodes for tree : ");
	scanf("%d",&n);
	printf("Enter the value of nodes : ");
	for(i=0;i<n;i++){
		scanf("%d",&arr[i]);
	}
	for(i=1;i<n;i++)
	{
		int add = arr[i];
		int j = i;
		while(j<n)
		{
			tree[j] = tree[j] + add;
			j = j + (j&(-j));
		}
	}
	printf("Binary index tree is : ");
	for(i=0;i<n;i++)
	{
		printf("%d ",tree[i]);
	}
printf("\nPress 1 to calculate the sum\n");
printf("Press 2 to update the value\n");
{
scanf("%d",&choice);
switch(choice)
{
case 1:
    // To calculate the sum;
	printf("Enter the location till which sum has to calculate : ");
	scanf("%d",&c);
	sum = 0;
	while(c>0)
	{
		sum = sum + tree[c];
		c = c - (c&(-c));
	}
	printf("%d\n",sum);
	break;

case 2:
	// To update the tree;
	printf("Enter the index and new updated value \n");
	scanf("%d%d",&l,&d);
	e = d - tree[l]; 
	while(l<n)
	{
		tree[l] = tree[l] + e;
		l = l + (l&(-l));
	}
	printf("New binary index tree is : ");
	for(i=0;i<n;i++)
	{
		printf("%d ",tree[i]);
	}
	printf("\n");
	break;
}}
return 0;
}