#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

int main()
{
	int i,l,m,x=0,y=0,c=1,j,p=9103;
	char a[1000000],b[100000];
	printf("Enter the string : ");
	scanf("%s",a);
	l = strlen(a);
	printf("Enter the string to be checked : ");
	scanf("%s",b);
	m = strlen(b);
	for(i=0;i<m;i++)
	{
		x = ((2*x + (b[i]-48))%p);
		y = ((2*y + (a[i]-48))%p);
		c = c*2;
	}
	c = c/2;
	for(j=0;j<l-m+1;j++)
	{
		if(x == y)
		{
			for(i=0;i<m;i++)
			{
				if(b[i] != a[j+i])
				{
					break;
				}
				else
				{
					continue;
				}
			}
			printf("Match at %d\n",j);
		}
	    if(j< l-m)
		{
			y = ((2*(y-(c*(a[j]-48))) + (a[j+m]-48))%p);
			
		}	
		
	}

return 0;
}	