#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int power(int n);
int min(int x,int y);
void construct_tree(int arr[],int tree[],int low,int high,int pos);
int range_min_query(int tree[],int qlow,int qhigh,int low,int high,int pos);

int power(int n)
{
	return (pow(2,ceil(log2(n)))*2-1);
}

int min(int x,int y)
{
	if(x>=y)
		return y;
	else
		return x;
}

void construct_tree(int arr[],int tree[],int low,int high,int pos)
{
	if(low == high)
	{
		tree[pos] = arr[low];
		return;
	}
	int mid = (low + high)/2;
	construct_tree(arr, tree, low, mid, (2*pos)+1);
	construct_tree(arr, tree, mid+1, high, (2*pos)+2);
	tree[pos] = min(tree[(2*pos) + 1],tree[(2*pos) + 2]);
}

int range_min_query(int tree[],int qlow,int qhigh,int low,int high,int pos)
{
	/*Total overlap*/
	if(qlow<=low && qhigh>=high)
	{
		return tree[pos];
	}
	/*No overlap*/
	if(qlow>high || qhigh<low)
	{
		return 10000;
	}
	/*partial overlap*/
	int mid = (low + high)/2;
	return min(range_min_query(tree, qlow, qhigh, low, mid, (2*pos)+1),
		range_min_query(tree, qlow, qhigh, mid+1, high, (2*pos)+2));
}


int main()
{
	int arr[100000],tree[100000],i,count=0,g,h,n;
	printf("Enter the size of aray : ");
	scanf("%d",&n);
	printf("Enter the elements : ");
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	int m = power(n);
	construct_tree(arr, tree, 0, n-1, 0);
	printf("Required segment tree is : ");
	for(i=0;i<m;i++){
		printf("%d ",tree[i]);
	}
	puts("");
	printf("Enter the range for RMQ : ");
	scanf("%d %d",&g,&h);
	int z = range_min_query(tree, g, h, 0, n-1, 0);
	printf("Range min query is : ");
	printf("%d\n",z);
	return 0;
}