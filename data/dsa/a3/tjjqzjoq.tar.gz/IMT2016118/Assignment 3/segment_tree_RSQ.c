#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int power(int n);
void construct_tree(int arr[],int tree[],int low,int high,int pos);
int sum_range_query(int tree[],int qlow,int qhigh,int low,int high,int pos);
void update_tree(int arr[], int tree[], int low, int high, int index, int value);
void update_value(int tree[], int low, int high, int index, int diff, int pos);

int power(int n)
{
	return (pow(2,ceil(log2(n)))*2-1);
}

void construct_tree(int arr[],int tree[],int low,int high,int pos)
{
	if(low == high)
	{
		tree[pos] = arr[low];
		return;
	}
	int mid = (low + high)/2;
	construct_tree(arr, tree, low, mid, (2*pos)+1);
	construct_tree(arr, tree, mid+1, high, (2*pos)+2);
	tree[pos] = (tree[(2*pos) + 1] + tree[(2*pos) + 2]);
}

int sum_range_query(int tree[], int qlow, int qhigh, int low, int high, int pos)
{
	/*Total overlap*/
	if(qlow<=low && qhigh>=high)
	{
		return tree[pos];
	}
	/*No overlap*/
	if(qlow>high || qhigh<low)
	{
		return 0;
	}
	/*partial overlap*/
	int mid = (low + high)/2;
	return (sum_range_query(tree, qlow, qhigh, low, mid, (2*pos)+1) +
		sum_range_query(tree, qlow, qhigh, mid+1, high, (2*pos)+2));
}

void update_tree(int arr[], int tree[], int low, int high, int index, int value)
{
	int diff = value - arr[index];
	arr[index] = value;
	update_tree(tree, 0, high-1, index, diff, 0);
}

void update_value(int tree[], int low, int high, int index, int diff, int pos)
{
	if (index < low || index > high)
        return;
	tree[pos] = tree[pos] + diff;
	int mid = (low + high)/2;
	if(low != high)
	{
		update_tree(tree, low, mid, index, diff, 2*pos + 1);
		update_tree(tree, mid + 1, high, index, diff, 2*pos + 2);
	}
}

int main()
{
	int arr[100000],tree[100000],i,g,h,n,index,value;
	printf("Enter the size of aray : ");
	scanf("%d",&n);
	printf("Enter the elements : ");
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	int m = power(n);
	construct_tree(arr, tree, 0, n-1, 0);
	printf("Required segment tree is : ");
	for(i=0;i<m;i++){
		printf("%d ",tree[i]);
	}
	puts("");
	printf("Enter the range for RSQ : ");
	scanf("%d %d",&g,&h);
	int z = sum_range_query(tree, g, h, 0, n-1, 0);
	printf("Range sum query is : ");
	printf("%d\n",z);
	printf("Update key and value is : ");
	scanf("%d %d",&index,&value);
	int add = value - arr[index]; 
	uptill(arr, tree, 0, n-1, index, value);
	printf("New tree is : ");
	for(i=0;i<m-1;i++){
		printf("%d ",tree[i]);
	}
	puts("");
	return 0;
}