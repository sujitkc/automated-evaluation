#include<stdio.h>
#include<stdlib.h>
int SUM(int *arr,int *BIT,int i,int n){
    int s=0;
    int j;
    while(i>0){
        s=s+BIT[i];
        j=i&(-i);
        i=i-j;
    }
    return s;
}
void update(int i,int n,int *BIT,int x){
    int j;
    while(i<n+1){
        BIT[i]=BIT[i]+x;
        j=i&(-i);
        i=i+j;
    }
}
int main(){
    int n;
    scanf("%d",&n);
    int i;
    int arr[n];
    for(i=0;i<n;i++){
        scanf("%d",&arr[i]);
    }
    int *BIT;
    BIT=calloc(n+1,sizeof(int));
    for(i=0;i<n;i++){
        update(i+1,n,BIT,arr[i]);
    }
    for(i=1;i<n+1;i++){
        printf("%d ",BIT[i]);
    }
    puts("");
    return 0;
}

