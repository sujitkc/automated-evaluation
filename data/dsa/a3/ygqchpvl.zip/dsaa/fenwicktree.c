#include <stdio.h>
#include <stdlib.h>
int i, x, bit[30], a[30];
void createbitarray(int i , int data){
    for(; i<=10; i+=i+(-i)){
        bit[i]+=data;
        printf("%d", bit[i]);
    }
}
int rangeminquery(int index){
    int finalsum = 0;
    for(; index>0; index-=index&(-index)){
        finalsum+=bit[index];
    }
    return finalsum;
}
void main(){
    int start, end;
    printf("enter the array elements\n");
    for(x=0; x<=10; x++){
        scanf("%d", &a[x]);
        createbitarray(x, a[x]);
    }
    printf("enter the range for which you wanna find the minimum query\n");
    scanf("%d", &start);
    scanf("%d", &end);
    printf("the sum in the given range is %d", rangeminquery(end)-rangeminquery(start));
}
