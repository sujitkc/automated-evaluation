#include <stdio.h>
#include <math.h>
#include <string.h>

int prime_num(int a){
	for(int i = a+1; ; i++){
		int prime = 1;	
		for(int j = 2; j < sqrt(i); j++){
			if(i % j == 0)
				prime = 0;
		}
		if(prime)
			return i;
	}
}

int main(){
	const int n = 13, m = 6;
	int t[] = { 1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 0, 0, 0};
	int p[] = {0, 1 , 1, 0, 0, 1};
	int radix = 2, prime = prime_num(n);
	printf("Prime = %d\n", prime);
	int x = 0, y = 0, h = 1;
	for(int i = 0;i < m; i++){
		x = (radix * x + p[i]) % prime;
		y = (radix * y + t[i]) % prime;
	}
	h = pow(2, m-1);
	h = h % prime;
	for(int i = 0; i < n - m; i++){
		int j;
		if(x == y){
			for(j = 0; j < m; j++){
				if(p[j]	!= t[i+j])	break;
			}
		}
		if(j == m){
			printf("Match at %d\n", i);
			break;
		}	
		y = ((2 * (y - (t[i] * h))) + t[i + m]) % prime;
		if(y < 0)	y = y + prime;
	}
	return 0;
}