#include <stdio.h>
#include <stdlib.h>
#define MAX 10000;
int minimum(int a, int b){
    if (a>b){
        return b;
    }
    else{
        return a;
    }
}
//segment tree construction function.
void segmenttreemaker(int array[], int segmentarray[], int low, int high, int curr){
    if (low == high){
        segmentarray[curr] = array[low];
        return ;
    }
    int mid = (low + high)/2;
    segmenttreemaker(array, segmentarray, low, mid, 2*curr+1);
    segmenttreemaker(array, segmentarray, mid+1, high, 2*curr+2);
    segmentarray[curr] = minimum(segmentarray[2*curr+1], segmentarray[2*curr+2]);
}
//range minimum query function.
int minimunfinder(int segmentarray, int low, int high, int start, int end, int curr){
    segmenttreemaker(array, segmentarray, low, high, 0);
    if (low>=start && high=<end){
        return segmentarray[curr];
    }
    else{
        return MAX;
    }
    int mid = (low + high)/2;
    return minimum(minimunfinder(segmentarray, low, mid, start, end, 2*curr+1),
    minimunfinder(segmentarray, low, mid, start, end, 2*curr+2));
}

int main(){
    int start, end, i, low=0, high, array[50]={-1, 6, 5, 4, 3, 8}, segmentarray[100];
    segmenttreemaker(array, segmentarray, 0, 5, 0);
    for(i=0; i<14; i++){
        printf("%d\n", segmentarray[i]);
    }
    printf("enter the size of array\n");
    scanf("%d", &high);
    printf("enter the complete array\n");
    for(i=0; i<high; i++){
        scanf("%d", &array[i]);
    printf("enter the starting and the ending range of the query\n");
    scanf("%d", &start);
    scanf("%d", &end);
    minimunfinder(segmentarray, low, mid, start, end, 0));
    printf("the minimum in the given range is - %d", min);
}
}
