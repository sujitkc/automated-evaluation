#include <stdio.h>
#include <strings.h>

void search(char *ptrn, char *str, int q)
{
	int d=256;
	int m = strlen(ptrn);
	int n = strlen(str);
	int i, j;
	int p = 0; 
	int t = 0; 
	int h = 1;
 
	for (i = 0; i < m-1; i++)
		h = (h*d)%q;
 
	for (i = 0; i < m; i++)
	{
		p = (d*p + ptrn[i])%q;
		t = (d*t + str[i])%q;
	}
 
	for (i = 0; i < n - m; i++)
	{	
		if ( p == t )
		{
			for (j = 0; j < m; j++)
			{
				if (str[i+j] != ptrn[j])
					break;
			}
			if (j == m)
				printf("Pattern matched at %dth index\n", i);
		}
		t = (d*(t - str[i]*h) + str[i+m])%q;
		if (t < 0)
			t = (t + q);
	}
}
 
int main()
{
	char str[] = "acbcdbcd";
	char ptrn[] = "bc";
	int q = 11;
	search(ptrn, str, q);
	return 0;
}