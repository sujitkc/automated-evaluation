#include <stdio.h>
#include <math.h>
#include <limits.h>

int min(int a, int b)
{	
	if(a < b) return a;
	else return b;
}

int build_segTree(int *arr, int *inp, int l, int r, int index)
{
	if(l == r)
	{
		arr[index] = inp[l];
		return arr[index];
	}
	
	int mid = (l + r)/2;
	arr[index] = min(build_segTree(arr, inp, l, mid, 2*index + 1), build_segTree(arr, inp, mid + 1, r, 2*index + 2));
	return arr[index];
}

int rmq(int *arr, int ql, int qr, int l, int r, int pos)
{
	if(ql <= l && qr >= r)
		return arr[pos];
	
	if(ql > r || l > qr)
		return INT_MAX;

	int mid = (l + r)/2;
	int val = min(rmq(arr, ql, qr, l, mid, 2*pos + 1), rmq(arr, ql, qr, mid+1, r, 2*pos + 2));
	return val;
}

void update(int *arr, int l, int r, int treeIndex, int i, int val)
{	
	if(l == r)
	{
		arr[treeIndex] += val;
		return;
	}
	int mid = (l+r)/2;
	if(i<=mid)
		update(arr, l, mid, 2*treeIndex+1, i, val);
	if(i>mid)
		update(arr, mid+1, r, 2*treeIndex+2, i, val);
	arr[treeIndex] = min(arr[2*treeIndex+1], arr[2*treeIndex+2]);
}

int main()
{	
	int inp[] = {6, 4, 12, 3, 1, 5, 21, 93};
	int n = sizeof(inp)/sizeof(int);
	
	int size = 2 * pow(2, ceil(log2(n))) - 1;
	int arr[size];

	build_segTree(arr, inp, 0, n-1, 0);
	for(int i=0;i<size;i++)
		printf("%d\t", arr[i]);
	printf("\n");
	
	printf("RMQ(2,6) = %d\n", rmq(arr, 2, 6, 0, n-1, 0));

	printf("Enter the index to be updated and by how much: \n");
	int pos, val;
	scanf("%d%d", &pos, &val);
	update(arr, 0, n-1, 0, pos, val);
	for(int i=0;i<size;i++)
		printf("%d\t", arr[i]);
	printf("\n");
	printf("RMQ(2,6) = %d\n", rmq(arr, 2, 6, 0, n-1, 0));
}
