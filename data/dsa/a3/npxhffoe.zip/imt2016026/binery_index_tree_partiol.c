#include<stdio.h>

int main()

{
void update(int *t,int n,int i,int value);
int rsq(int *a,int i,int j);
int prefix_sum(int *t,int i);
int a[]={5,2,8,1,6,7,3,4};
int n=8,A[8],i;

for(i=0;i<n;i++){A[i]=0;}

for(i=0;i<n;i++){update(A,n,i,a[i]);}
for(i=0;i<n;i++){printf("%d ",A[i]);}

printf("\n%d\n",rsq(A,2,5));



return 0;
}




int prefix_sum(int *t,int i){

int s=0,j;

while(i>=0){

s+=t[i];
j=(i+1)&(-i-1);
i-=j;

}
return s;
}


int rsq(int *a,int i,int j){
return prefix_sum(a,j)-prefix_sum(a,i-1);
}



void update(int *t,int n,int i,int value){
int j;
while(i+1<=n){
t[i]+=value;
j=(i+1)&(-i-1);
i+=j;
}
}











