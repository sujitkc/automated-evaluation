#include<stdio.h>
#include<stdlib.h>

int main()
{

void update(int *st,int s,int *a,int n,int i,int value);
int rmq(int *arr, int l,int r,int *a,int i,int j,int idx);


int arr[]={5,8,1,3,2,6,7,4};
int n=8,s=1,i,j;
int a[]={0,0,0,0,0,0,0,0};


while(s<n){s*=2;}
s*=2;
s-=1;
printf("%d \n",s);


int st[s];

for(i=0;i<s/2;i++){st[i]=0;}

for(i=s/2;i<s;i++){st[i]=i-s/2;}
for(i=0;i<s;i++){printf("%d ",st[i]);}
printf("\n");




for(i=(s-2)/2;i>=0;i--)
{
st[i]=st[2*i+1];
}
for(j=0;j<s;j++){printf("%d ",st[j]);}
printf("\n\n\n");



for(i=0;i<n;i++){

update(st,s,a,n,i,arr[i]);

}
for(j=0;j<s;j++){printf("%d ",st[j]);}

printf("\n\n"); 


printf("%d\n",rmq(st,2,3,arr,0,n-1,0));

return 0;
}







void update(int *st,int s,int *a,int n,int i,int value)
{

a[i]=value;
int c1,c2,p;

c1=s/2+i;
p=(c1-1)/2;
c1=2*p+1;
c2=2*p+2;



while (c1!=1){

if (a[st[c1]]<a[st[c2]])
	
	{
	if(st[p]!=st[c1]){st[p]=st[c1];}
	}

else{
	if(st[p]!=st[c2]){st[p]=st[c2];}
	}

c1=p;
p=(c1-1)/2;
c1=2*p+1;
c2=2*p+2;
}

if(a[st[2]]>a[st[1]]){st[0]=st[1];}
else{st[0]=st[2];}






}










int rmq(int *arr,int l,int r,int *a,int i,int j,int idx){
int x,y;
if(l==i && r==j)
	{return arr[idx];}

else if (r<=(i+j)/2){return rmq(arr,l,r,a,i,(i+j)/2,2*idx+1);}
	

else if (l>=(i+j)/2){return rmq(arr,l,r,a,(i+j)/2+1,j,2*idx+2);}


else{

x=rmq(arr,l,(i+j)/2,a,i,(i+j)/2,2*idx+1);
y=rmq(arr,(i+j)/2,r,a,(i+j)/2+1,j,2*idx+2);

if(a[x]>a[y]){return y;}
else{return x;}

}

}