#include<stdio.h>
#include<stdlib.h>
#include<math.h>


int min_element(int x,int y){
	return (x < y)? x: y;
}

int mid_element(int s,int e){ // s->start,e->end
	return s+(e-s)/2;
}

int build(int a[],int s, int e,int b[],int ind){
	int mid=mid_element(s,e);	
	if(s==e){
		b[ind]= a[s];
	}
	else{
		b[ind]=min_element(build(a,s,mid,b,2*ind+1),build(a,mid+1,e,b,2*ind+2));
	}
	return b[ind];
}

int RMQ(int *b,int s,int e,int qs,int qe,int ind){
	int mid = mid_element(s, e);
	if(qs>qe){
		printf("Invalid");
		return -1;
	}
	else{
		if (qs <= s && qe >= e)
       			 return b[ind];
    		if (e < qs || s > qe)
        		return -1;
 		else{
	return min_element(RMQ(b,s, mid, qs, qe, 2*ind+1),RMQ(b, mid+1, e, qs, qe, 2*ind+2));
		}
	}
}

int main(){
	int n,i;
	scanf("%d",&n);
	int h=(int)ceil(log2(n));
	int size=2*(int)pow(2,h)-1;
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	int b[size];
	int g;
	g=build(a,0,n-1,b,0);
	printf("%d",g);
	int qs,qe;
	scanf("%d%d",&qs,&qe);
	printf("Minimum of values in range [%d, %d] is = %d\n",qs, qe, RMQ(b,0,n-1,qs, qe,0));
}
