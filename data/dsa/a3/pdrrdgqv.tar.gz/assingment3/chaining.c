#include<stdio.h>
#include<stdlib.h>
struct node * b[13];
struct node{
	int data;
	struct node * next;
};
int hashfunction(int data)
{
	return data%20;
}
void insert(int x)
{
	int hash_index=hashfunction(x);
	if(b[hash_index]==NULL)
	{
		arr[hash_index]=malloc(sizeof(struct node));
		arr[hash_index]->data=x;
	}
	else
	{
		struct node * ptr;
		ptr=(struct node *)malloc(sizeof(struct node));
		struct node * ptr1;
		ptr1=(struct node *)malloc(sizeof(struct node));
		ptr=b[hash_index];
		ptr1->data=x;
		ptr1->next=NULL;	
		while(ptr->next!=NULL)
			ptr=ptr->next;
		ptr->next=ptr1;
	}
}
void search(int x)
{
	int hash_index=hashfunction(x);
	struct node * ptr;
	ptr=(struct node *)malloc(sizeof(struct node));
	ptr=b[hash_index];
	while(ptr!=NULL)
	{
		if(ptr->data==x)
		{
			printf("Element found at %d th location\n",hash_index);
			break;
		}
		ptr=ptr->next;
	}
	if(ptr==NULL)
		printf("Element not found");
}
void delete(int x)
{
	int hash_index=hashfunction(x);
	struct node * ptr;
	ptr=(struct node *)malloc(sizeof(struct node));
	ptr=b[hash_index];
	if(ptr->data==x)
		b[hash_index]=ptr->next;
	while(ptr->next!=NULL)
	{
		if(ptr->next->data==x)
		{
			ptr->next=ptr->next->next;
			break;
		}
		ptr=ptr->next;
	}
}
int main()
{
	int n,x,i;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&x);
		insert(x);
	}
	int choice=0;
	while(choice!=4)
	{
		printf("1.Insert\n2.Search\n3.Delete\n4.Exit\n");
		scanf("%d",&choice);
		if(choice==1)
		{
			scanf("%d",&x);
			insert(x);
			struct node * ptr;
			ptr=malloc(sizeof(struct node));
			ptr=b[0];
			for(i=0;i<20;i++)
			{
				ptr=arr[i];
				if(ptr==NULL)
					printf("0");
				while(ptr!=NULL)
				{
					printf("%d ",ptr->data);
					ptr=ptr->next;
				}	
				printf("\n");
			}
		}
		else if(choice==2)
		{
			scanf("%d",&x);
			search(x);
		}
		else if(choice==3)
		{
			scanf("%d",&x);
			delete(x);
			struct node * ptr;
			ptr=malloc(sizeof(struct node));
			ptr=arr[0];
			for(i=0;i<20;i++)
			{
				ptr=arr[i];
				if(ptr==NULL)
					printf("0");
				while(ptr!=NULL)
				{
					printf("%d ",ptr->data);
					ptr=ptr->next;
				}
				printf("\n");
			}
		}
	}
}		
