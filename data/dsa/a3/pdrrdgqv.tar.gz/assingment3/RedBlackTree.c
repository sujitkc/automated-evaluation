#include <stdio.h>
#include <stdlib.h>

struct redblack{
	int data;
	char color;
	struct redblack *left,*right,*parent;
};
struct redblack* newnode(int d)
{
	struct redblack *temp= (struct redblack *)malloc(sizeof(struct redblack));
	temp->data=d;
	temp->left=temp->right=temp->parent=NULL;
	return temp;
}
void rightrotate(struct redblack **root,struct redblack *node,int flag)
{
	struct redblack *temp=node->left;
	node->left=temp->right;

	if(temp->right)
	temp->right->parent=node;

	temp->parent=node->parent;

	if(temp->parent==NULL)
	*root=temp;
	else if(node->parent->left==node)
	node->parent->left=temp;
	else
	node->parent->right=temp;

	temp->right=node;
	node->parent=temp;
	if(flag)
	{
		temp->color='B';
		node->color='R';
	}
}
void leftrotate(struct redblack **root,struct redblack *node,int flag)
{
	struct redblack *temp=node->right;
	node->right=temp->left;
	temp->parent=node->parent;

	if(temp->left)
	temp->left->parent=node;
	if(node->parent==NULL)
	(*root)=temp;
	else if(node->parent->left==node)
	node->parent->left=temp;
	else
	node->parent->right=temp;
	temp->left=node;
	node->parent=temp;
	if(flag)
	{
		temp->color='B';
		node->color='R';
	}
}
void check(struct redblack **root,struct redblack *z)
{

	while(z!=(*root)&&z->parent->color=='R')
	{
		struct redblack *y=NULL;
		if(z->parent==z->parent->parent->left)
		y=z->parent->parent->right;
		else
		y=z->parent->parent->left;

		if(y&&y->color=='R')
		{
			y->color='B';
			z->parent->color='B';
			z->parent->parent->color='R';
			z=z->parent->parent;
		}
		else
		{
			if(z->parent==z->parent->parent->left&&z==z->parent->left)
			{
				rightrotate(root,z->parent->parent,1);
			}
			else if(z->parent==z->parent->parent->left&&z==z->parent->right)
			{
				leftrotate(root,z->parent,0);
				//redblack *x=z->parent->parent;
				rightrotate(root,z->parent,1);
			}
			else if(z->parent==z->parent->parent->right&&z==z->parent->right)
			{
				leftrotate(root,z->parent->parent,1);
			}
			else if(z->parent==z->parent->parent->right&&z==z->parent->left)
			{
				rightrotate(root,z->parent,0);
				//redblack *x=z->parent->parent;
				leftrotate(root,z->parent,1);
			}
		}
	}
	(*root)->color='B';
}
void insert(struct redblack **root,int d)
{
	struct redblack *temp=newnode(d),*pre,*pro;
	if(*root==NULL)
	{
		temp->color='B';
		*root=temp;
		return;
	}
	temp->color='R';
	pre=NULL;
	pro=*root;
	while(pro)
	{
		pre=pro;
		if(pro->data>d)
		pro=pro->left;
		else
		pro=pro->right;
	}
	if(pre->data>d)
	pre->left=temp;
	else
	pre->right=temp;
	temp->parent=pre;
	check(root,temp);
}
void inorder(struct redblack *root)
{
	if(root==NULL)
	return ;
	inorder(root->left);
    printf("%d-%c ", root->data, root->color);
	inorder(root->right);
}
int main()
{
	int i,j,n;
	struct redblack *root=NULL;

	insert(&root,7);
	insert(&root,4);
	insert(&root,3);
	insert(&root,5);
	insert(&root,6);
	insert(&root,9);
	insert(&root,2);
	insert(&root,1);
	insert(&root,8);

	printf("Inoreder RBT: ");
	inorder(root);

	return 0;
}
