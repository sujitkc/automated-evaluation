#include<stdio.h>
#include<stdlib.h>

int hash_code(int key){
	return key%13;
}


int b[13];

void insert(int p){ // p-> key 
	int i;
	int hash_index;
	hash_index=hash_code(p);
	while(b[hash_index] != 0 && b[hash_index]!= -1 ){
		hash_index++;
		hash_index %= 13;
	}
	b[hash_index]=p;
}

void delete(int p){ // p-> key 
	int hash_index;
	hash_index=hash_code(p);
	while(b[hash_index] != 0){
		if(b[hash_index]==p){
			b[hash_index]= -1;
		}
	hash_index++;	
	hash_index %= 13;
	}
}

void search(int p){ // p-> key 
	int hash_index;
	hash_index=hash_code(p);
	while(b[hash_index] != 0){
		if(b[hash_index]==p){
			printf("%d",b[hash_index]);
		}
	hash_index++;	
	hash_index %= 13;
	}
}

int main(){
	int i;
	int n;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
	for(i=0;i<(2*n);i++){
		b[i]=0;
	}
	for(i=0;i<n;i++){
		insert(a[i]);
	}
	printf("choose any one:\n 1.search\n 2.insert\n 3.delete\n");
	int key,ch;	
	scanf("%d",&ch);
	printf("Enter the key:");
	scanf("%d",&key);
	if(ch<=3 && ch>=1){		
		switch(ch){
	 	case 1: 
			search(key);
			break;
	 	case 2: printf("hi");
			insert(key);
			break;
		case 3:
			delete(key);
			break;
		}
	}
	for(i=0;i<13;i++){
		printf("%d\n",b[i]);
	}
}
		
