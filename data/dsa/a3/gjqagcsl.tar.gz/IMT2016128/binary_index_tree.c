#include <stdio.h>
#include <stdlib.h>

int n=11;

int prefix_sum(int *bit,int x){
	x++;
	int sum=0;
	while(x!=0){
		sum=sum+bit[x];
		x=x-(x&(-x));
	}
	return sum;
}

int rsq(int *bit,int c,int d){
	return prefix_sum(bit,d)-prefix_sum(bit,c);
}

int *update(int *bit,int *a,int i,int key){
	int diff=key-a[i];
	i++;
	while(i<n){
		bit[i]=bit[i]+diff;
		i=i+(i&(-i));
	}
	return bit;
}

int *build(int *a,int *bit){
	int p=0,t=0,j=1,sum=0;
	for(j=1;j<n+1;j++){
		sum=0;
		p=j&(-j);
		for(t=j-p;t<j;t++)
				sum=sum+a[t];
		bit[j]=sum;
	}
	return bit;
}

void main(){
	int a[]={3,2,-1,6,5,4,-3,3,7,2,3};
	int bit[n+1];
	int i=0;
	bit[0]=0;
	bit[n+1]=build(a,bit);
	for(i=0;i<=n;i++)
		printf("%d ",bit[i]);
	printf("\n");
	printf("%d\n",rsq(bit,4,7));
	bit[n+1]=update(bit,a,3,9);
	for(i=0;i<=n;i++)
		printf("%d ",bit[i]);
	printf("\n");
}