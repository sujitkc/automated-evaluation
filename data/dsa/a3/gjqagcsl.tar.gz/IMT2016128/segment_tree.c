#include <stdio.h>
#include <stdlib.h>

int maxm = 1000; // infinite
int k=15;

int minm(int x,int y){
	if(x<=y)
		return x;
	else
		return y;
}

int *pushup(int *st,int index){
	int temp;
	if(index==0)
		return st;
	else if(index%2==1){
		if(st[index/2]<=st[index])
			return st;
		else{
			temp=st[index];
			st[index]=st[index/2];
			st[index/2]=temp;
			return st;
			}
		}
	else{
		if(st[(index/2)-1]<=st[index])
			return st;
		else{
			temp=st[index];
			st[index]=st[(index/2)-1];
			st[(index/2)-1]=temp;
			return st;
			}
		}
	}

int *update(int *st,int x,int index){
	st[index]=x;
	st[k]=pushup(st,index);
	return st;
}

int rmq(int *st,int r,int s,int p,int q,int index){
	if(p<=r && s<=q)
		return st[index];
	else if(p>s || r>q)
		return 1000;
	else
		return minm(rmq(st,r,(s+r)/2,p,q,(index*2)+1),rmq(st,((s+r)/2)+1,s,p,q,(index*2)+2));
}

int *build(int *a,int *st,int k){
	int i=(k/2),j=0;
	while(i!=k){
		st[i]=a[j];
		i++;
		j++;
	}
	i=k-1;
	while(i>0){
		if(st[i]>st[i-1])
			st[(i/2)-1]=st[i-1];
		else
			st[(i/2)-1]=st[i];
		i=i-2;
	}
	return st;
}

void main(){
	int i;
	int a[] = {6,4,12,43,78,5,21,93};
	int st[k];
	st[k]= build(a,st,k);
	for(i=0;i<k;i++)
		printf("%d ",st[i]);
	printf("\n");
	printf("%d\n",rmq(st,0,7,2,6,0));
}