#include <stdio.h>
#include <stdlib.h>

int n=7;
int m=3;
int p=101;

int pwr(int x,int y){
	int pro=1,l;
	for(l=0;l<y;l++)
		pro=pro*x;
	return pro;
}

int hash(char *str,int i,int prev){
	int k=0,j;
	if(i==0){
		for(j=0;j<m;j++)
			k=k+((str[j])*pwr(p,j));
		}
	else
		k=((prev-str[i-1])/p)+((str[i+2])*pwr(p,m-1));
	return k;
} 

void main(){
	char ptrn[]="abc";
	char txt[]="abedabc";
	int a=hash(ptrn,0,0),i,prev=0,check=0,k=0,j=0;
	for(i=0;i<=n-m;i++){
		k=0;
		if(hash(txt,i,prev)==a){
			check=1;
			for(j=i;j<i+m;j++){
				if(txt[j]!=ptrn[k])
					check=0;
				k++;
			}
		}
		prev=hash(txt,i,prev);
		if(check==1){
			printf("match found at %d\n",i);
			return;
		}
	} 
}