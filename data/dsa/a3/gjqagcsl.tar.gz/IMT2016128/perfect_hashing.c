#include <stdio.h>
#include <stdlib.h>

int n=10;
int p=23;

struct node{
	int a;
	int b;
	int m;
	int *ar;
};

int hash(int x,int a,int b,int m){
	return (((a*x)+b)%p)%m;
}

int geta(){
	return (rand()%21)+1;
}

int getb(){
	return (rand()%22);
}

void main(){
	int i,j,k;

	int a[]={1,2,6,9,7,19,14,12,16,20};
	int b[2*n];

	for(i=0;i<2*n;i++)
		b[i]=0;
	
	for(i=0;i<n;i++)
		b[hash(a[i],10,5,7)]++;
	
	struct node arr[2*n];
	
	for(i=0;i<2*n;i++){
		arr[i].m=b[i]*b[i];
		arr[i].ar=(int*)malloc((arr[i].m)*sizeof(int));
		for(j=0;j<arr[i].m;j++)
			arr[i].ar[j]=0;
	}

	for(i=0;i<n;i++){
		j=hash(a[i],10,5,7);
		k=hash(a[i],geta(),getb(),arr[j].m);
		if(arr[j].ar[k]!=0)
			i--;
		else
			arr[j].ar[k]=a[i];
	}

	for(i=0;i<2*n;i++){
		for(j=0;j<arr[i].m;j++)
			printf("%d  ",arr[i].ar[j]);
		printf("\n");
	}
}