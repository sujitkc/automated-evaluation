#include<stdio.h>
int prefix_sum(int arr[],int i);
int rsq(int arr[],int i,int j);
void update(int arr[],int i,int x,int n);//indexing starts from 1
int t[1000];//t is the array in which sum is stored till before least significant 1
void main()
{
	int a[1000],i,n,arr[1000];//a is initial givennarray and arr is updated array
	scanf("%d",&n);
	for(i=1;i<n+1;i++)
		arr[i]=0;
	for(i=1;i<n+1;i++)
		scanf("%d",&a[i]);
	for(i=1;i<n+1;i++)
		t[i] = 0;
	for(i=1;i<n+1;i++)
		update(arr,i,a[i],n);
	update(arr,5,3,n);
	update(arr,1,3,n);
	printf("modified array:");
	for(i=1;i<n+1;i++)
		printf("%d\t",arr[i]);	
	printf("\nprefix sum:");
	for(i=1;i<n+1;i++)
		printf("%d\t",prefix_sum(arr,i));	
	printf("\n");
	printf("%d\n",rsq(arr,3,5));
}
int prefix_sum(int arr[],int i)
{
	int s = 0;
	int j;
	while(i>0)
	{
		s=s+t[i];
		j = i&-i;
		i=i-j;
	}
	return s;
}
int rsq(int arr[],int i,int j)//sum of nos of an array frm i to j
{
	return (prefix_sum(arr,j)-prefix_sum(arr,i-1));
}
void update(int arr[],int i,int x,int n)
{
	int j;
	arr[i]=arr[i]+x;
	while(i<n+1)
	{
		t[i]=t[i]+x;
		j=i&-i;
		i=i+j;
	}
}
