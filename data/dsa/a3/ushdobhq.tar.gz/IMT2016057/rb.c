#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
struct node
{
	int colour,data; // black -> 1 , red -> 0 ,double black -> 2
	struct node *parent;
	struct node *rc;
	struct node *lc;
};
void insert(struct node **root,int n);
void rec_in(struct node *root);
void rec_pre(struct node *root);
void double_red(struct node **root,struct node *x);
void right_zigzag(struct node **root,struct node *ptr);
void right_zigzig(struct node **root,struct node *ptr);
void left_zigzag(struct node **root,struct node *ptr);
void left_zigzig(struct node **root,struct node *ptr);
void left_inverse_zigzig(struct node **root,struct node *ptr);
void right_inverse_zigzig(struct node **root,struct node *ptr);
void delete(struct node **root,int n);
void del(struct node **root , struct node *cur);
void double_black(struct node **root,struct node *x);
void  main()
{
	struct node *root = NULL;
	insert(&root,31);
	insert(&root,2);
	insert(&root,36);
	insert(&root,30);
	insert(&root,20);
	insert(&root,100);
	insert(&root,1);
	insert(&root,32);
	delete(&root,1);
	rec_in(root);
	printf("\n");
	rec_pre(root);
}
void insert(struct node **root,int n)
{
	struct node *new;
	new = malloc(sizeof(struct node));
	new -> data = n;
	new->lc = NULL;
	new->rc = NULL;
	if((*root) == NULL)
	{
		new -> colour = 1;
		(*root) = new;
	}
	else
	{
		new -> colour = 0;
		struct node *cur = *root;
		while(1)
		{
			if(cur->data < n)
			{
				if(cur->rc == NULL)break;
				else cur = cur -> rc;
			}
			else
			{
				if(cur->lc == NULL)break;
				else cur = cur -> lc;
			}
		}
		if(n>cur->data)cur->rc = new;
		else cur-> lc = new;
		new -> parent = cur;
		if((new -> parent)->colour == 0)//double red problem
		{
			double_red(root,new);	
		}
	}
}
void delete(struct node **root,int n)
{
	struct node *cur=(*root);
	while(1)
	{
		if(cur->data==n) break;
		else if(n>cur->data) cur=cur->rc;
		else cur=cur->lc;
	}
	if(cur!=NULL)
		del(root,cur);
}
void del(struct node **root , struct node *cur)
{
	if(cur->lc == NULL && cur -> rc == NULL)//cur is a leaf node
	{
		if(cur->parent == NULL)
			(*root) = NULL;
		else if((cur->parent)->lc == cur && (cur->parent)->rc != NULL)
		{
			if((cur->parent)->lc == cur)
				(cur->parent)->lc = NULL;
			else
				(cur->parent)->rc = NULL;
		}
		else if((cur->parent)->rc == cur && (cur->parent)->lc != NULL)
		{
			if((cur->parent)->lc == cur)
				(cur->parent)->lc = NULL;
			else
				(cur->parent)->rc = NULL;
		}
		else
		{
			if((cur->parent)->lc == cur)
			{
				(cur->parent)->colour = (cur->parent)->colour +cur->colour; 
				(cur->parent)->lc = NULL;
			}
			else
			{
				(cur->parent)->colour = (cur->parent)->colour + cur->colour	;			
				(cur->parent)->rc = NULL;
			}
			if((cur->parent)->colour == 2)
				double_black(root,cur->parent);
		}
		free(cur);
	}
	else if(cur->rc == NULL) // cur has only left child 
	{
		(cur->lc) -> parent = cur -> parent;
		(cur->lc) -> colour = (cur->lc)->colour + cur->colour;
		if((cur->parent)->lc == cur)
			(cur->parent)->lc = cur -> lc;
		else
			(cur->parent)->rc = cur -> lc;
		if((cur->lc)->colour == 2)
			double_black(root,cur->lc);
		free(cur);
	}
	else if(cur->lc == NULL) // cur has only right child 
	{
		(cur->rc) -> parent = cur -> parent;
		(cur->rc) -> colour = (cur->rc)->colour + cur->colour;
		if((cur->parent)->lc == cur)
			(cur->parent)->lc = cur -> rc;
		else
			(cur->parent)->rc = cur -> rc;
		if((cur->rc)->colour == 2)
			double_black(root,cur->rc);
		free(cur);
	}
	else//cur has 2 children
	{
		struct node *inpre=cur->lc;
		while(inpre->rc!=NULL)
		{
			inpre=inpre->rc;
	    }
    	cur->data=inpre->data;
   		del(root,inpre);
	}
}
void double_red(struct node **root,struct node *x)
{
	struct node *p,*g,*u;
	p = x -> parent;
	g = p -> parent;
	if(g->lc == p) u = g -> rc;
	else u = g->lc;
	if(u == NULL)
	{
		if(x == p->rc && p == g->lc)
			left_zigzag(root,g);
		else if(x == p->lc && p == g->rc)
			right_zigzag(root,g);
		else if(x == p->lc && p == g->lc)
			left_zigzig(root,g);
		else if(x == p->rc && p == g->rc)
			right_zigzig(root,g);
	}
	else
	{
		while(1)
		{
			p = x -> parent;
			g = p -> parent;
			if(g->lc == p) u = g -> rc;
			else u = g->lc;
			if(x -> colour == 0 && p->colour == 0)
			{
				if(u -> colour == 0)
				{	
					p->colour = 1;
					u->colour = 1;
					if(g == (*root)) break;
					else
					{
						g->colour = 0;	
						x = g;
					}
				}
				else
				{
					if(x == p->rc && p == g->lc)
						left_zigzag(root,g);
					else if(x == p->lc && p == g->rc)
						right_zigzag(root,g);
					else if(x == p->lc && p == g->lc)
						left_zigzig(root,g);
					else if(x == p->rc && p == g->rc)
						right_zigzig(root,g);
					break;
				}
			}
			else
				break;
		}
	}
}
void double_black(struct node **root,struct node *x)
{
	struct node *p ,*u ,*cur;
	cur = x;
	while(1)
	{
		if(cur == (*root))
		{
			cur -> colour = 1;
			break;
		}
		p = cur -> parent;
		if(p->rc == cur)
			u = p->lc;
		else
			u = p->rc;
		if(u ==  NULL)
		{
			p -> colour = p->colour + 1;
			if(p->colour == 2)
				cur = p;
			else
				break;
		}
		else if(u->colour == 0)
		{
			if(cur == p->lc)
				left_inverse_zigzig(root,cur);
			else
				right_inverse_zigzig(root,cur);
			p->colour = 0;
			u->colour = 1;
		}
		else
		{
			if((u->rc == NULL || (u->rc)->colour == 1) && (u->lc == NULL || (u->lc)->colour == 1))
			{
				cur->colour = 1;
				u->colour = 0;
				p ->colour = 1+p->colour;
				if(p->colour==2)
					cur = p;
				else
					break;
			}
			else
			{
				if(cur == p->lc)
				{
					if((u->rc)->colour == 1)
					{
						p->rc = u->lc;
						(u->lc)->parent = p;
						(u->lc) = (p->rc)->rc;
						((p->rc)->rc)->parent = u;
						(p->rc)->rc = u;
						u->parent = p->rc;
						u->colour = 0;
						(p->rc)->colour = 1;
						u = p->rc;
					}
					left_inverse_zigzig(root,cur);
					(u->rc)->colour = 1+(u->rc)->colour;
				}  
				else
				{
					if((u->lc)->colour == 1)
					{
						p->lc = u->rc;
						(u->rc)->parent = p;
						u->rc = (p->lc)->lc;
						((p->lc)->lc)->parent = u;
						(p->lc)->lc = u;
						u->parent = p->lc;
						u->colour = 0;
						(p->lc)->colour = 1;
						u = p->lc;
					}
					right_inverse_zigzig(root,cur);
					(u->lc)->colour = 1+(u->lc)->colour;
				}
				u->colour = p->colour;
				p->colour = 1;
				break;
			}
		}
	}
}
void right_zigzag(struct node **root,struct node *ptr)
{
      struct node *z,*x,*y,*r=ptr->parent;
      z=ptr;
      y=z->rc;
      x=z->rc->lc;
      z->colour = 0;
      x->colour = 1;
      z->rc=x->lc;
      if(x->lc!=NULL) x->lc->parent=z;
      y->lc=x->rc;
      if(x->rc!=NULL) x->rc->parent=y;
      x->rc=y;
      y->parent=x;
      x->lc=z;
      z->parent=x;
      if(r!=NULL){
        if(r->lc==ptr) r->lc=x;
        else r->rc=x;
      }
      else{
        x->parent=NULL;
        (*root)=x;
      }
     // x->parent = r;
}
void right_zigzig(struct node **root,struct node *ptr)
{
      struct node *z,*x,*y,*r=ptr->parent;
      z=ptr;
      y=z->rc;
      x=z->rc->rc;
      z->colour = 0;
      y->colour = 1;
      y->parent=r;
      z->rc=y->lc;
      if(y->lc !=NULL) y->lc->parent=z;
      y->rc=x;
      x->parent=y;
      y->lc=z ;
      z->parent=y;
      if(r!=NULL){
        if(r->lc==ptr) r->lc=y;
        else r->rc=y;
      }
      else{
        (*root)=y;
        y->parent=NULL;
      }
      //y->parent = r;
}
void left_zigzag(struct node **root,struct node *ptr)
{
      struct node *z,*x,*y,*r=ptr->parent;
      z=ptr;
      y=z->lc;
      x=z->lc->rc;
      z->colour = 0;
      x->colour = 1;
      z->lc=x->rc;
      if(x->rc!=NULL) x->rc->parent=z;
      y->rc=x->lc;
      if(x->lc!=NULL) x->lc->parent=y;
      x->lc=y;
      y->parent=x;
      x->rc=z;
      z->parent=x;
      if(r!=NULL){
        if(r->lc==ptr) r->lc=x;
        else r->rc=x;
        x->parent=ptr->parent;
      }
      else{
        x->parent=NULL;
        (*root)=x;
      }
     // x->parent = r;
}
void left_zigzig(struct node **root,struct node *ptr)
{
      struct node *z,*x,*y,*r=ptr->parent;
      z=ptr;
      y=z->lc;
      x=z->lc->lc;
      z->colour = 0;
      y->colour = 1;
      y->parent=r;
      z->lc=y->rc;
      if(y->rc !=NULL) y->rc->parent=z;
      y->lc=x;
      x->parent=y;
      y->rc=z ;
      z->parent=y;
      if(r!=NULL){
        if(r->lc==ptr) r->lc=y;
        else r->rc=y;
      }
      else{
        (*root)=y;
        y->parent=NULL;
      }
      //y->parent = r;
}
void left_inverse_zigzig(struct node **root,struct node *ptr)
{
	struct node *x,*p,*u;
	x = ptr;
	p = x->parent;
	u = p->rc;
	if((ptr->parent)==(*root))
		*root = u;
	p->rc = u -> lc;
	(u->lc)->parent = p;
	u->parent = p->parent;
	if (p->parent == NULL)
	{
	}
	else if(p == (p->parent)->lc)
		(p->parent)->lc = u;
	else
		(p->parent)->rc = u;
	p->parent = u;
	u->lc = p;
}
void right_inverse_zigzig(struct node **root,struct node *ptr)
{
	struct node *x,*p,*u;
	x = ptr;
	p = x->parent;
	u = p->lc;
	if((ptr->parent)==(*root))
		*root = u;
	p->lc = u->rc;
	(u->rc)->parent = p;
	u->parent = p->parent;
	if (p->parent == NULL)
	{
	}
	else if(p == (p->parent)->lc)
		(p->parent)->lc = u;
	else
		(p->parent)->rc = u;
	p->parent = u;
	u->rc = p;	
}
void rec_in(struct node *root)
{
	if(root!=NULL)
	{
		rec_in(root->lc);
		printf("%d\t%d\n",root->data,root->colour);
		rec_in(root->rc);
 	}
}
void rec_pre(struct node *root)
{
	if(root!=NULL)
	{
		printf("%d\t%d\n",root->data,root->colour);
		rec_pre(root->lc);
		rec_pre(root->rc);
	}
}
	
				
