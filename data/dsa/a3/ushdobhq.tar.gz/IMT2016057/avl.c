#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>

struct tree{
  int data,height;
  int num;
  struct tree *parent;
  struct tree *lc;
  struct tree *rc;
};

void insert(struct tree **root,int n);
int height(struct tree *root);
void delete(struct tree **root,struct tree *ptr);
void right_rotate(struct tree **root,struct tree *ptr);
void left_rotate(struct tree **root,struct tree *ptr);
int abs(int a);
int rank_of_node(struct tree *root,struct tree *x);
int find_rank(struct tree *root,int k);
void rec_in(struct tree *root);
void rec_pre(struct tree *root);
void avl_convert(struct tree **root,struct tree *ptr);
void del(struct tree **root,int n);
int maxi(int a,int b);
int main(){
    struct tree *root=malloc(sizeof(struct tree));
    root->data=1;
    root->height=0;
    root->num=1;
    root->lc=NULL;
    root->rc=NULL;
    root->parent=NULL;
    insert(&root,2);
		insert(&root,3);
		insert(&root,4);
    insert(&root,5);
    insert(&root,6);
		insert(&root,7);
		insert(&root,8);
    insert(&root,9);
    del(&root,7);
    del(&root,3);
		del(&root,4);
		del(&root,9);
		del(&root,8);
    rec_in(root);
		printf("\n");
		rec_pre(root);
}
void insert(struct tree **root,int n){
  struct tree *cur=*root,*new,*prev;
  int h=1;bool violated=false;
  new=malloc(sizeof(struct tree));
  new->data=n;
  new->lc=NULL;new->rc=NULL;
  new->height=0;
  new->num=1;
  while(1){
  cur->num++;
    if(n>cur->data){
      if(cur->rc==NULL) break;
      else cur=cur->rc;
    }
    else{
      if(cur->lc==NULL) break;
      else cur=cur->lc;
    }
  }
  if(n>cur->data) cur->rc=new;
  else cur->lc=new;
  new->parent=cur;
  while(cur->height<h){
    cur->height++;
    h++;
    if(abs(height(cur->rc)-height(cur->lc))>1){
      violated=true;break;
    }
    if(cur->parent==NULL) break;
    prev=cur;
    cur=cur->parent;
  }
  if(violated){
    if(prev=cur->rc) right_rotate(root,cur);
    else left_rotate(root,cur);
  }
}
void delete(struct tree **root,struct tree *cur){
    struct tree *prev=cur->parent,*inpre;
    if(cur==*(root) && cur->rc==NULL &&cur->lc==NULL){
      (*root)=NULL;
    }
    else if(cur->lc==NULL || cur->rc==NULL){
      if(cur->rc==NULL){
        if(prev->rc==cur) prev->rc=cur->lc;
        else prev->lc=cur->lc;
        if(cur->lc!=NULL)cur->lc->parent=prev;
      }
      else{
        if(prev->rc==cur) prev->rc=cur->rc;
        else prev->lc=cur->rc;
        if(cur->rc!=NULL) cur->rc->parent=prev;
      }
       avl_convert(root,cur);
    }
    else{
      struct tree *inpre=cur->lc;
      while(inpre->rc!=NULL){
        inpre=inpre->rc;
      }
      cur->data=inpre->data;
      delete(root,inpre);
      }

}
void right_rotate(struct tree **root,struct tree *ptr){
  struct tree *z,*x,*y,*r=ptr->parent;
  int h;
    z=ptr;
    h=z->height;
if(height(z->rc->lc)==h-2){
      y=z->rc;
      x=z->rc->lc;
      z->rc=x->lc;
      x->height=h-1;
      y->height=h-2;
      z->height=h-2;
      y->num=no(y->rc)+no(x->rc)+1;
      z->num=no(z->lc)+no(x->lc)+1;
      x->num=no(y)+no(z)+1;
      if(x->lc!=NULL) x->lc->parent=z;
      y->lc=x->rc;
      if(x->rc!=NULL) x->rc->parent=y;
      x->rc=y;
      y->parent=x;
      x->lc=z;
      z->parent=x;
      if(r!=NULL){
        if(r->lc==ptr) r->lc=x;
        else r->rc=x;
      }
      else{
        x->parent=NULL;
        (*root)=x;
      }
      x->parent = r;
    }
    else{
      y=z->rc;
      x=z->rc->rc;
      y->parent=r;
      z->rc=y->lc;
      y->height=h-1;
      x->height=h-2;
      z->height=h-2;
      z->num=no(y->lc)+no(z->lc)+1;
      y->num=no(x)+no(z)+1;
      if(y->lc !=NULL) y->lc->parent=z;
      y->rc=x;
      x->parent=y;
      y->lc=z ;
      z->parent=y;

      if(r!=NULL){
        if(r->lc==ptr) r->lc=y;
        else r->rc=y;
      }
      else{
        (*root)=y;
        y->parent=NULL;
      }
      y->parent = r;
  }
}
void left_rotate(struct tree **root,struct tree *ptr){
  struct tree *z,*x,*y,*r=ptr->parent;
  int h;
    z=ptr;
    h=z->height;
    if(height(z->lc->rc)==h-2){
      y=z->lc;
      x=z->lc->rc;
      x->height=h-1;
      y->height=h-2;
      z->height=h-2;
      y->num=no(y->lc)+no(x->lc)+1;
      z->num=no(z->rc)+no(x->rc)+1;
      x->num=no(y)+no(z)+1;
      z->lc=x->rc;
      if(x->rc!=NULL) x->rc->parent=z;
      y->rc=x->lc;
      if(x->lc!=NULL) x->lc->parent=y;
      x->lc=y;
      y->parent=x;
      x->rc=z;
      z->parent=x;
      if(r!=NULL){
        if(r->lc==ptr) r->lc=x;
        else r->rc=x;
        x->parent=ptr->parent;
      }
      else{
        x->parent=NULL;
        (*root)=x;
      }
      x->parent = r;
    }
    else{
      y=z->lc;
      x=z->lc->lc;
      y->height=h-1;
      x->height=h-2;
      z->height=h-2;
      z->num=no(y->rc)+no(z->rc)+1;
      y->num=no(x)+no(z)+1;
      y->parent=r;
      z->lc=y->rc;
      if(y->rc !=NULL) y->rc->parent=z;
      y->lc=x;
      x->parent=y;
      y->rc=z ;
      z->parent=y;
      if(r!=NULL){
        if(r->lc==ptr) r->lc=y;
        else r->rc=y;
      }
      else{
        (*root)=y;
        y->parent=NULL;
      }
      y->parent = r;
  }
}
void del(struct tree **root,int n){
  struct tree *cur=(*root);
  while(1){
  	cur->num--;
    if(cur->data==n) break;
    else if(n>cur->data) cur=cur->rc;
    else cur=cur->lc;
  }
  if(cur!=NULL)
  	delete(root,cur);
}
int height(struct tree *root){
  if(root==NULL) return -1;
  else return root->height;
}
int abs(int a){
  if(a<0) return -a;
  else return a;
}
void rec_in(struct tree *root){
  if(root!=NULL){
    rec_in(root->lc);
    printf("%d\n",root->data);
    rec_in(root->rc);
  }
}
void rec_pre(struct tree *root){
  if(root!=NULL){
    printf("%d %d\n",root->data,root->num);
    rec_pre(root->lc);
    rec_pre(root->rc);
  }
}
void avl_convert(struct tree **root,struct tree *ptr){
    struct tree *parent=ptr->parent;
    int h;
    while(parent!=NULL){
      if(parent->height==1+maxi(height(parent->lc),height(parent->rc))){
       if(abs(height(parent->lc)-height(parent->rc))<=1) break;
       else if(height(parent->rc)<height(parent->lc))left_rotate(root,parent);
       else right_rotate(root,parent);
      }
      else
        parent->height--;
      parent=parent->parent;
    }
}
int maxi(int a,int b){
  if(a>b) return a;
  else return b;
}
int rank_of_node(struct tree *root,struct tree *x)
{
	int r = 1;
	struct tree *cur = root;
	while(cur!=NULL)
	{
		if(x->data==cur->data)
			return r+no(cur->rc);
		else if(x->data<cur->data)
		{
			r=r+1+no(cur->rc);
			cur=cur->lc;
		}
		else
			cur=cur->rc;
	}
}
int no(struct tree *ptr){
  if(ptr==NULL) return 0;
  else return ptr->num;
}
int find_rank(struct tree *root,int k)
{
	struct tree *cur = root;
	while(k)
	{
		if(k==1+no(cur->rc))
			return cur->data;
		else if(k>1+no(cur->rc))
		{
			k = k -1 - no(cur->rc);
			cur=cur->lc;
		}
		else
			cur=cur->rc;
	}
	return -1;
}
