#include<stdio.h>
int create_tree(int arr1[],int arr2[],int n);
int min(int a,int b);
int rmq(int arr1[],int arr2[],int i,int s,int e,int a,int b);
void update(int arr1[],int arr2[],int in,int num,int n);
void main()
{
	int arr1[100],arr2[100],n=6,i,k,p,lb,ub;
	for(i=0;i<n;i++)
		scanf("%d",&arr1[i]);
	p = create_tree(arr1,arr2,n);
	update(arr1,arr2,5,0,p);
	scanf("%d",&lb);
	scanf("%d",&ub);
	printf("%d\n",rmq(arr1,arr2,0,lb,ub,0,p-1));
}
int create_tree(int arr1[],int arr2[],int no)//arr 2 represents tree and arr1 represents given arrayand n is no of nos in arr1
{
	int i,m,n=no,mini;//pow of 2 close to n(just greater than n)
	while(1)
	{
		i = n&-n;
		if(n == i)
			break;
		else
			n++;
	}
	for(i=no;i<n;i++)
		arr1[i] = -1;
	m = 2*n-1;//size of the 2nd array which is tree
	for(i=0;i<m;i++)
		arr2[i] = 0;
	for(i=m-n;i<m;i++)
		arr2[i] = i-(m-n);
	for(i=m-n-1;i>=0;i--)
	{
		mini = min(arr1[arr2[2*i+1]],arr1[arr2[2*i+2]]);
		if(mini == arr1[arr2[2*i+1]])
			arr2[i] = arr2[2*i+1];
		else
			arr2[i] = arr2[2*i+2];
	}
	return n;
}
int rmq(int arr1[],int arr2[],int i,int s,int e,int a,int b)//a and b are boundaries of that node and i is the index of no in arr
{
	if(s<=arr2[i] && arr2[i]<=e)
		return arr1[arr2[i]];
	else
	{
		if(e<=(a+b)/2)
			rmq(arr1,arr2,(2*i+1),s,e,a,(a+b)/2);
		else if(s>=((a+b)/2+1))
			rmq(arr1,arr2,(2*i+2),s,e,(a+b)/2+1,b);
		else
			min(rmq(arr1,arr2,(2*i+1),s,(a+b)/2,a,(a+b)/2),rmq(arr1,arr2,(2*i+2),(a+b)/2+1,e,((a+b)/2+1),b));
	}
}
void update(int arr1[],int arr2[],int in,int num,int n)//in is the index to be changed and num is new no and n is the no which is closest 2 power
{
	arr1[in] = num;
	int i = n-1+in;
	int mini;
	int p;
	while(i>0)
	{
		p = (i-1)/2;
		mini = min(arr1[arr2[2*p+1]],arr1[arr2[2*p+2]]);
		if(arr1[arr2[p]]>mini)
		{
			if(mini == arr1[arr2[2*p+1]])
				arr2[p] = arr2[2*p+1];
			else
				arr2[p] = arr2[2*p+2];
		}
		else
			break;
		i = (i-1)/2;
	}
}
int min(int a,int b)
{
	int m = b;
	if(a<b)
		m = a;
	else if(m==-1)
		m = a;
	if(m==-1)
		m = b;
	return m;
}
	
