#include<stdio.h>
#include<stdlib.h>

int main()
{

int s1[7]={1,0,1,0,1,1,0};
int s2[4]={1,1,0,1};
int l1=7,l2=4,temp=1,x=0,y=0,i,j,sup=0,p=67;



for(i=0;i<l2;i++){

	x=2*x+s2[i];
	x=x%p;
	y=2*y+s1[i];
	y=y%p;
	temp*=2;
	}
temp/=2;  
for(i=0;i<l1-l2;i++){

if(x==y){
for(j=0;j<l2;j++)
{
if(s1[l1-i+j]!=s2[j]){break;}}
sup=1;
}

y=2*(y-temp*s1[i])+s1[i+l2];
y=y%p;
}

if(x==y){
for(j=0;j<l2;j++)
{
if(s1[l1-i+j]==s2[j]){break;}}
sup=1;
}


if(sup==1){printf("MATCH FOUND\n");}
else{printf("NO MATCH\n");}
}
