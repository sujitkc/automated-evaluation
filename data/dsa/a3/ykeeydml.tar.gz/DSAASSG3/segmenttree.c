#include <stdio.h>
int min(int a,int b)
{
	if(a<b)
	{
		return a;
	}
	else
	{
		return b;
	}
}
int rangeminq(int b[],int i,int j)
{
	int minm=999999;
	i=i+15;
	j=j+15;
	while(i<j)
	{
		if((i-1)/2==(j-1)/2)
		{
			minm=min(minm,b[(i-1)/2]);
		}
		if (i%2==0)
		{
			printf("min is :%d\n",minm );
			minm=min(minm,b[i]);
			printf("min is :%d\n",minm );
			i=i+1;
		}
		if(j%2==1)
		{
			printf("min is :%d\n",minm );
			minm=min(minm,b[j]);
			printf("min is :%d\n",minm );
			j=j-1;
		}
		i=(i-1)/2;
		j=(j-1)/2;
		if(i==j)
		{
			minm=min(minm,b[i]);
		}
	}
	return minm;

}
int main()
{
	int i,j,q,a,b;
	int arr[10]={4,3,7,9,1,0,5,2,6,8};
	int brr[31];
	for(i=15;i<25;i++)
	{
		brr[i]=arr[i-15];
	}
	for(i=25;i<31;i++)
	{
		brr[i]=99999;
	}
	j=14;
	for(i=14;i>0;i--)
	{
		brr[i]=min(brr[j+15],brr[j+16]);
		j=j-2;
	}
	scanf("%d",&a);
	scanf("%d",&b);
	q=rangeminq(brr,a,b);
	printf("%d\n",q);
}