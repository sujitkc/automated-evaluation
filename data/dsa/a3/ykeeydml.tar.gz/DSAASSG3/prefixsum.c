#include <stdio.h>
int prefixsum(int t[],int i)
{
	
	int j;
	int s=0;
	while(i>0)
	{
		s=s+t[i];
		j=i&-i;
		i=i-j;
		printf("s is :%d\n",s );
	}
	return s;	

}
void update(int t[],int i , int x,int n)
{
	int j;
	while(i<n)
	{
		t[i]=t[i]+x;
		if(i==0)
		{
			i=1;
			j=i&-i;
			i=0;
			i=i+j;
		}
		else
		{
			j=i&-i;
			i=i+j;
		}
	}
}
void create(int t[],int n,int a[])
{
	int i;
	for(i=0;i<n;i++)
	{
		update(t,i,a[i],10);
	}
}
int main()
{
	int h;
	int a[10]={1,2,5,3,7,6,2,6,6,3};
	int t[10];
	for (int i = 0; i < 10; ++i)
	{
		t[i]=0;
	}
	create(t,10,a);
	for(int i=0;i<10;i++)
	{
		printf("%d ",t[i] );
	}
	printf("\n");
	update(t,0,5,10);
	
	
	for(int i=0;i<10;i++)
	{
		printf("%d ",t[i] );
	}
	printf("\n");
	printf("enter sum upto :\n");
	scanf("%d",&h);
	printf("%d\n",prefixsum(t,h));
	
}