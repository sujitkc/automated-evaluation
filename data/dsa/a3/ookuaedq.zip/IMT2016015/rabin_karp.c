#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
	int m,n;
	char P[100],t[100];
	scanf("%s",t);
	scanf("%s",P);
	m=strlen(P);
	n=strlen(t);
	int x=0,y=0,h=1,p=6131;
	for (int i = 0; i < m; ++i)
	{
		x=(2*x+(P[i]-48))%p;
		y=(2*y+(t[i]-48))%p;
			
	}
	for (int i = 0; i < m-1; ++i)
	{
		h=(2*h)%p;
	}
	//printf("x = %d, y = %d, h = %d\n",x,y,h);
	int flag=0;
	for (int i = 0; i < n-m; ++i)
	{
		if (x==y)
			{
				int j;
				for (j = 0; j < m; ++j)
				{
					if(P[j]!=t[i+j])
						break;						
				}
				if(j==m)
					{
						flag=1;
						printf("Match at %d\n",i);
						break;
					}			
			}
		y = (2*(y-h*(t[i]-48))+(t[i+m]-48))%p;
		if(y < 0)
			y+=p;
	}
	if (flag==0)
		printf("No Match\n");
	return 0;
}
 