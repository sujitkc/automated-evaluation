#include <stdio.h>
#include <stdlib.h>

struct node
{
	int key;
	struct node *left, *right;
	int ht;
};

int max(int a, int b)
{
	if(a > b)
		return a;
	else
		return b;
}

int height(struct node *head)
{
	if(head == NULL)
		return 0;
	return head->ht;
}

struct node* search(struct node* root, int k)
{
    if (root == NULL || root->key == k)
       return root;
    if (root->key < k)
       return search(root->right, k);
    return search(root->left, k);
}

struct node *newNode(int item)
{
	struct node *temp = (struct node *)malloc(sizeof(struct node));
	temp->key = item;
	temp->left = temp->right = NULL;
	temp->ht = 1;
	return temp;
}

void inorder(struct node *root)
{
	if (root != NULL)
	{
		inorder(root->left);
		printf("%d \n", root->key);
		inorder(root->right);
	}
}

struct node* RightRotation(struct node *y)
{
	struct node *x = y->left;
	struct node *T2 = x->right;

	x->right = y;
	y->left = T2;

	x->ht = max(height(x->left), height(x->right))+1;
	y->ht = max(height(y->left), height(y->right))+1;
	return x;
}

struct node* LeftRotation(struct node *x)
{
	struct node *y = x->right;
	struct node *T2 = y->left;

	y->left = x;
	x->right = T2;

	x->ht = max(height(x->left), height(x->right))+1;
	y->ht = max(height(y->left), height(y->right))+1;
	return y;
}

int differance(struct node *head)
{
	if(head == NULL)
		return 0;
	return (height(head->left)-height(head->right));
}


struct node* InorderSucc(struct node* head)
{
	struct node* temp = head;
	while(temp->left != NULL)
		temp = temp->left;
	return temp;
}

struct node* insert(struct node* root, int k)
{
	if (root == NULL)
		return newNode(k);
	if (k < root->key)
		root->left = insert(root->left, k);
	else if (k > root->key)
		root->right = insert(root->right, k);
	else
		return root;

	root->ht = max(height(root->left), height(root->right))+1;
	int d = differance(root);

	if(d > 1 && root->left->key > k)
	{
		return RightRotation(root);
	}

	else if(d < -1 && root->right->key < k)
	{
		return LeftRotation(root);
	}

	else if(d > 1 && root->left->key < k)
	{
		root->left = LeftRotation(root->left);
		return RightRotation(root);
	}

	else if(d < -1 && root->right->key > k)
	{
		root->right = RightRotation(root->right);
		return LeftRotation(root);
	}
	return root;
}

struct node* deletion(struct node* root, int k)
{
	if (root == NULL)
		 return newNode(k);
	if (k < root->key)
		root->left = deletion(root->left, k);
	else if (k > root->key)
		root->right = deletion(root->right, k);
	else
	{
		if(root->left == NULL)
        {
			struct node* temp = root->right;
			free(root);
			return temp;
        }
		else if(root->right == NULL)
		{
			struct node* temp = root->left;
			free(root);
			return temp;
		}
		struct node *temp = InorderSucc(root->right);
		root->key = temp->key;
		root->right = deletion(root->right, temp->key);
	}

	root->ht = max(height(root->left), height(root->right))+1;
	int d = differance(root);

	if(d > 1 && root->left->key > k)
	{
		return RightRotation(root);
	}

	else if(d < -1 && root->right->key < k)
	{
		return LeftRotation(root);
	}

	else if(d > 1 && root->left->key < k)
	{
		root->left = LeftRotation(root->left);
		return RightRotation(root);
	}

	else if(d < -1 && root->right->key > k)
	{
		root->right = RightRotation(root->right);
		return LeftRotation(root);
	}
	return root;
}

int main()
{
    struct node *root = NULL;
    root = insert(root, 50);
    root = insert(root, 30);
    root = insert(root, 20);
    root = insert(root, 40);
    root = insert(root, 70);
    root = insert(root, 60);
    root = insert(root, 80);

    printf("Inorder traversal of the given tree \n");
    inorder(root);

    printf("\nDelete 20\n");
    root = deletion(root, 20);
    printf("Inorder traversal of the modified tree \n");
    inorder(root);

    printf("\nDelete 30\n");
    root = deletion(root, 30);
    printf("Inorder traversal of the modified tree \n");
    inorder(root);

    printf("\nDelete 50\n");
    root = deletion(root, 50);
    printf("Inorder traversal of the modified tree \n");
    inorder(root);

    return 0;
}
