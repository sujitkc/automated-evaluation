import random

def PrimaryHash(x):
	return ((a*x+b)%p)%n

class PerfectHash:
 def __init__(self,idx):
  self.idx=idx
  self.set=[]
  self.a=random.randint(1,p)
  self.b=random.randint(0,p)
  self.newset=[]

 def Hash(self):
  size=len(self.set)*len(self.set)
  for i in range(size):
   self.newset.append(-1)
  for i in self.set:
   if self.newset[((self.a*i+self.b)%p)%size]==-1:
    self.newset[((self.a*i+self.b)%p)%size]=i
   else:
    self.Collision()
    break

 def Collision(self):
  self.a=random.randint(1,p)
  self.b=random.randint(0,p)
  self.newset=[]
  self.Hash()

def Search(x):
 idx=PrimaryHash(x)
 u=HashFunctions[idx].a
 v=HashFunctions[idx].b
 size=len(HashFunctions[idx].newset)
 if size==0:
  print "Not Found"
 else:
  if HashFunctions[idx].newset[((u*x+v)%p)%size]==x:
   print "Found"
  else:
   print "Not Found"

l=[1,2,3,4,5,6,7,8,9,32,65,94,19,74,87,12,69,28,42,53]
n=len(l)
p=2654435761
a=random.randint(1,p)
b=random.randint(0,p)
HashFunctions=[]
for i in range(0,n):
 new=PerfectHash(i)
 HashFunctions.append(new)

for i in l:
 if i not in HashFunctions[PrimaryHash(i)].set:
  HashFunctions[PrimaryHash(i)].set.append(i)

for i in HashFunctions:
 i.Hash()
 print i.newset

Search(1)
Search(68)
Search(2)
