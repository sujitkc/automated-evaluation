#include<stdio.h>
#define n 8
 
void Update(int Tree[],int i, int x)
{while(i<=n)
 {Tree[i]+=x;
  i+=i&(-i);
 }
}

int Query(int Tree[],int i)
{int sum=0;
 while(i>0)
 {sum+=Tree[i];
  i-=i&(-i);
 }
 return sum;
}

void main()
{int Tree[n+1];
 for(int i=0;i<=n;i++)
  Tree[i]=0;
 Update(Tree,1,2);
 Update(Tree,2,5);
 Update(Tree,3,4);
 Update(Tree,4,7);
 Update(Tree,5,1);
 Update(Tree,6,8);
 Update(Tree,7,9);
 Update(Tree,8,0);
 for(int i=0;i<=n;i++)
  printf("%d ",Tree[i]);
 printf("\n");
 //To find Sum from i to j...find Sum from 0 to j -sum from 0 to i
 int sumi=Query(Tree,4);
 int sumj=Query(Tree,7);
 printf("%d\n",sumj-sumi);
 Update(Tree,5,6);
 for(int i=0;i<=n;i++)
  printf("%d ",Tree[i]);
 printf("\n");
 sumi=Query(Tree,4);
 sumj=Query(Tree,7);
 printf("%d\n",sumj-sumi);
}
