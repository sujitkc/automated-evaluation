#include<stdio.h>
#define n 8

int A[]={6,4,12,43,78,5,21,93};
int tree[2*n];

int Min(int x,int y)
{if(x<y)return x;
 return y;
}

void build(int node, int start, int end)
{
    if(start == end)
    {
        tree[node] = A[start];
    }
    else
    {
        int mid = (start + end) / 2;
        build(2*node+1, start, mid);
        build(2*node+2, mid+1, end);
        tree[node] = Min (tree[2*node+1] , tree[2*node+2]);
    }
}

void update(int node, int start, int end, int idx, int val)
{
    if(start == end)
    {
        A[idx] = val;
        tree[node] = val;
    }
    else
    {
        int mid = (start + end) / 2;
        if(start <= idx && idx <= mid)
        {
            update(2*node+1, start, mid, idx, val);
        }
        else
        {
            update(2*node+2, mid+1, end, idx, val);
        }
        tree[node] = Min (tree[2*node+1] , tree[2*node+2]);
    }
}

int query(int node, int start, int end, int l, int r)
{
    if(r < start || end < l)
    {
        return 2147483647;
    }
    if(l <= start && end <= r)
    {
        return tree[node];
    }
    int mid = (start + end) / 2;
    int p1 = query(2*node+1, start, mid, l, r);
    int p2 = query(2*node+2, mid+1, end, l, r);
    return Min(p1 , p2);
}

void main()
{build(0,0,n-1);
 for(int i=0;i<2*n;i++)
  printf("%d ",tree[i]);
 printf("\n");
 printf("%d\n",query(0,0,n-1,2,6));
 update(0,0,n-1,3,3);
 for(int i=0;i<2*n;i++)
  printf("%d ",tree[i]);
 printf("\n");
 printf("%d\n",query(0,0,n-1,0,7));
}
