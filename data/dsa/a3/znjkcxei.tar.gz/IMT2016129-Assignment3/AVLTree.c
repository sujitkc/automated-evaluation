// C program to delete a node from AVL Tree
#include<stdio.h>
#include<stdlib.h>
#define INT_MAX 2147483647
 
// An AVL tree node
struct Node
{
    int key;
    struct Node *left;
    struct Node *right;
    int height;
    int num;
    int min;
    int max;
    int mingap;
    int sum;
};
 
// A utility function to get maximum of two integers
int max(int a, int b);

int Min(int a,int b,int c,int d)
{int min=a;
 if(b<min)
  min=b;
 if(c<min)
  min=c;
 if(d<min)
  min=d;
 return min;
}

// A utility function to get height of the tree
int height(struct Node *N)
{
    if (N == NULL)
        return 0;
    return N->height;
}
 
// A utility function to get maximum of two integers
int max(int a, int b)
{
    return (a > b)? a : b;
}
 
/* Helper function that allocates a new node with the given key and
    NULL left and right pointers. */
struct Node* newNode(int key)
{
    struct Node* node = (struct Node*)
                        malloc(sizeof(struct Node));
    node->key   = key;
    node->left   = NULL;
    node->right  = NULL;
    node->height = 1;  // new node is initially added at leaf
    node->num = 1;
    node->max=node->key;
    node->min=node->key;
    node->mingap=INT_MAX;
    node->sum=node->key;
    return(node);
}
 
// A utility function to right rotate subtree rooted with y
// See the diagram given above.
struct Node *rightRotate(struct Node *y)
{
    struct Node *x = y->left;
    struct Node *T2 = x->right;
 
    // Perform rotation
    x->right = y;
    y->left = T2;
 
    // Update heights
    y->height = max(height(y->left), height(y->right))+1;
    x->height = max(height(x->left), height(x->right))+1;

    // Update number of nodes on that subtree
    x->num=1;
    y->num=1;
    x->sum=x->key;
    y->sum=y->key;
    if(x->right!=NULL)
     {x->num+=x->right->num;
      x->max=x->right->max;
      x->sum+=x->right->sum;
     }
    else
     x->max=x->key;
    if(x->left!=NULL)
     {x->num+=x->left->num;
      x->min=x->left->min;
      x->sum+=x->left->sum;
     }
    else
     x->min=x->key;
    if(y->right!=NULL)
     {y->num+=y->right->num;
      y->max=y->right->max;
      y->sum+=y->right->sum;
     }
    else
     y->max=y->key;
    if(y->left!=NULL)
     {y->num+=y->left->num;
      y->min=y->left->min;
      y->sum+=y->left->sum;
     }
    else
     y->min=y->key;

    //Update mingap
    if(x->right==NULL && x->left==NULL)
     x->mingap=INT_MAX;
    if(x->right!=NULL && x->left==NULL)
     x->mingap=Min(x->right->mingap,x->right->min-x->key,x->right->mingap,x->right->min-x->key);
    if(x->right==NULL && x->left!=NULL)
     x->mingap=Min(x->left->mingap,x->key-x->left->max,x->left->mingap,x->key-x->left->max);
    if(x->right!=NULL && x->left!=NULL)
     x->mingap=(x->left->mingap,x->key-x->left->max,x->right->mingap,x->right->min-x->key);

    if(y->right==NULL && y->left==NULL)
     y->mingap=INT_MAX;
    if(y->right!=NULL && y->left==NULL)
     y->mingap=Min(y->right->mingap,y->right->min-y->key,y->right->mingap,y->right->min-y->key);
    if(y->right==NULL && y->left!=NULL)
     y->mingap=Min(y->left->mingap,y->key-y->left->max,y->left->mingap,y->key-y->left->max);
    if(y->right!=NULL && y->left!=NULL)
     y->mingap=(y->left->mingap,y->key-y->left->max,y->right->mingap,y->right->min-y->key);

    // Return new root
    return x;
}
 
// A utility function to left rotate subtree rooted with x
// See the diagram given above.
struct Node *leftRotate(struct Node *x)
{
    struct Node *y = x->right;
    struct Node *T2 = y->left;
 
    // Perform rotation
    y->left = x;
    x->right = T2;
 
    //  Update heights
    x->height = max(height(x->left), height(x->right))+1;
    y->height = max(height(y->left), height(y->right))+1;

    // Update number of nodes on that subtree
    x->num=1;
    y->num=1;
    x->sum=x->key;
    y->sum=y->key;
    if(x->right!=NULL)
     {x->num+=x->right->num;
      x->max=x->right->max;
      x->sum+=x->right->sum;
     }
    else
     x->max=x->key;
    if(x->left!=NULL)
     {x->num+=x->left->num;
      x->min=x->left->min;
      x->sum+=x->left->sum;
     }
    else
     x->min=x->key;
    if(y->right!=NULL)
     {y->num+=y->right->num;
      y->max=y->right->max;
      y->sum+=y->right->sum;
     }
    else
     y->max=y->key;
    if(y->left!=NULL)
     {y->num+=y->left->num;
      y->min=y->left->min;
      y->sum+=y->left->sum;
     }
    else
     y->min=y->key;

    //Update mingap
    if(x->right==NULL && x->left==NULL)
     x->mingap=INT_MAX;
    if(x->right!=NULL && x->left==NULL)
     x->mingap=Min(x->right->mingap,x->right->min-x->key,x->right->mingap,x->right->min-x->key);
    if(x->right==NULL && x->left!=NULL)
     x->mingap=Min(x->left->mingap,x->key-x->left->max,x->left->mingap,x->key-x->left->max);
    if(x->right!=NULL && x->left!=NULL)
     x->mingap=(x->left->mingap,x->key-x->left->max,x->right->mingap,x->right->min-x->key);

    if(y->right==NULL && y->left==NULL)
     y->mingap=INT_MAX;
    if(y->right!=NULL && y->left==NULL)
     y->mingap=Min(y->right->mingap,y->right->min-y->key,y->right->mingap,y->right->min-y->key);
    if(y->right==NULL && y->left!=NULL)
     y->mingap=Min(y->left->mingap,y->key-y->left->max,y->left->mingap,y->key-y->left->max);
    if(y->right!=NULL && y->left!=NULL)
     y->mingap=(y->left->mingap,y->key-y->left->max,y->right->mingap,y->right->min-y->key);
 
    // Return new root
    return y;
}
 
// Get Balance factor of node N
int getBalance(struct Node *N)
{
    if (N == NULL)
        return 0;
    return height(N->left) - height(N->right);
}
 
struct Node* insert(struct Node* node, int key)
{
    /* 1.  Perform the normal BST rotation */
    if (node == NULL)
        return(newNode(key));
 
    if (key < node->key)
        node->left  = insert(node->left, key);
    else if (key > node->key)
        node->right = insert(node->right, key);
    else // Equal keys not allowed
        return node;
 
    /* 2. Update height of this ancestor node */
    node->height = 1 + max(height(node->left),
                           height(node->right));

    node->num=1;
    node->sum=node->key;
    if(node->right!=NULL)
     {node->num+=node->right->num;
      node->max=node->right->max;
      node->sum+=node->right->sum;
     }
    else
     node->max=node->key;
    if(node->left!=NULL)
     {node->num+=node->left->num;
      node->min=node->left->min;
      node->sum+=node->left->sum;
     }
    else
     node->min=node->key;

    if(node->right==NULL && node->left==NULL)
     node->mingap=INT_MAX;
    if(node->right!=NULL && node->left==NULL)
     node->mingap=Min(node->right->mingap,node->right->min-node->key,node->right->mingap,node->right->min-node->key);
    if(node->right==NULL && node->left!=NULL)
     node->mingap=Min(node->left->mingap,node->key-node->left->max,node->left->mingap,node->key-node->left->max);
    if(node->right!=NULL && node->left!=NULL)
     node->mingap=(node->left->mingap,node->key-node->left->max,node->right->mingap,node->right->min-node->key);
 
    /* 3. Get the balance factor of this ancestor
          node to check whether this node became
          unbalanced */
    int balance = getBalance(node);
 
    // If this node becomes unbalanced, then there are 4 cases
 
    // Left Left Case
    if (balance > 1 && key < node->left->key)
        return rightRotate(node);
 
    // Right Right Case
    if (balance < -1 && key > node->right->key)
        return leftRotate(node);
 
    // Left Right Case
    if (balance > 1 && key > node->left->key)
    {
        node->left =  leftRotate(node->left);
        return rightRotate(node);
    }
 
    // Right Left Case
    if (balance < -1 && key < node->right->key)
    {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }
 
    /* return the (unchanged) node pointer */
    return node;
}
 
/* Given a non-empty binary search tree, return the
   node with minimum key value found in that tree.
   Note that the entire tree does not need to be
   searched. */
struct Node * minValueNode(struct Node* node)
{
    struct Node* current = node;
 
    /* loop down to find the leftmost leaf */
    while (current->left != NULL)
        current = current->left;
 
    return current;
}
 
// Recursive function to delete a node with given key
// from subtree with given root. It returns root of
// the modified subtree.
struct Node* deleteNode(struct Node* root, int key)
{
    // STEP 1: PERFORM STANDARD BST DELETE
 
    if (root == NULL)
        return root;
 
    // If the key to be deleted is smaller than the
    // root's key, then it lies in left subtree
    if ( key < root->key )
        root->left = deleteNode(root->left, key);
 
    // If the key to be deleted is greater than the
    // root's key, then it lies in right subtree
    else if( key > root->key )
        root->right = deleteNode(root->right, key);
 
    // if key is same as root's key, then This is
    // the node to be deleted
    else
    {
        // node with only one child or no child
        if( (root->left == NULL) || (root->right == NULL) )
        {
            struct Node *temp = root->left ? root->left :
                                             root->right;
 
            // No child case
            if (temp == NULL)
            {
                temp = root;
                root = NULL;
            }
            else // One child case
             *root = *temp; // Copy the contents of
                            // the non-empty child
            free(temp);
        }
        else
        {
            // node with two children: Get the inorder
            // successor (smallest in the right subtree)
            struct Node* temp = minValueNode(root->right);
 
            // Copy the inorder successor's data to this node
            root->key = temp->key;
 
            // Delete the inorder successor
            root->right = deleteNode(root->right, temp->key);
        }
    }
 
    // If the tree had only one node then return
    if (root == NULL)
      return root;
 
    // STEP 2: UPDATE HEIGHT OF THE CURRENT NODE
    root->height = 1 + max(height(root->left),
                           height(root->right));

    root->num=1;
    root->sum=root->key;
    if(root->left!=NULL)
     {root->num+=root->left->num;
      root->min=root->left->min;
      root->sum+=root->left->sum;
     }
    else
     root->min=root->key;
    if(root->right!=NULL)
     {root->num+=root->right->num;
      root->max=root->right->max;
      root->sum+=root->right->sum;
     }
    else
     root->max=root->key;

    if(root->right==NULL && root->left==NULL)
     root->mingap=INT_MAX;
    if(root->right!=NULL && root->left==NULL)
     root->mingap=Min(root->right->mingap,root->right->min-root->key,root->right->mingap,root->right->min-root->key);
    if(root->right==NULL && root->left!=NULL)
     root->mingap=Min(root->left->mingap,root->key-root->left->max,root->left->mingap,root->key-root->left->max);
    if(root->right!=NULL && root->left!=NULL)
     root->mingap=(root->left->mingap,root->key-root->left->max,root->right->mingap,root->right->min-root->key);
 
    // STEP 3: GET THE BALANCE FACTOR OF THIS NODE (to
    // check whether this node became unbalanced)
    int balance = getBalance(root);
 
    // If this node becomes unbalanced, then there are 4 cases
 
    // Left Left Case
    if (balance > 1 && getBalance(root->left) >= 0)
        return rightRotate(root);
 
    // Left Right Case
    if (balance > 1 && getBalance(root->left) < 0)
    {
        root->left =  leftRotate(root->left);
        return rightRotate(root);
    }
 
    // Right Right Case
    if (balance < -1 && getBalance(root->right) <= 0)
        return leftRotate(root);
 
    // Right Left Case
    if (balance < -1 && getBalance(root->right) > 0)
    {
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }
 
    return root;
}

void Search(struct Node *node,int key)
{struct Node *current=node;
 while(current!=NULL)
 {if(key<current->key)
   current=current->left;
  else if(key>current->key)
   current=current->right;
  else
  {printf("%d Found\n",key);
   break;
  }
 }
 if(current==NULL)
  printf("%d Not Found\n",key);
}

int Rank(struct Node *node,int key)
{int r=1;
 struct Node *T=node;
 while(T!=NULL)
 {if(T->key==key)
  {if(T->right!=NULL)
    return r+T->right->num;
   return r;
  }
  if(T->key>key)
  {if(T->right!=NULL)
    r+=1+T->right->num;
   else
    r+=1;
   T=T->left;
  }
  else
   T=T->right;
 }
 return r;
}

struct Node* FindRank(struct Node *node,int k)
{struct Node *T=node;
 while(k!=0)
 {if(T->right!=NULL)
  {if(k==1+T->right->num)
    return T;
  }
  else
  {if(k==1)
    return T;
  }
  if(T->right!=NULL)
  {if(k>1+T->right->num)
   {k=k-1-T->right->num;
    T=T->left;
   }
   else
    T=T->right;
  }
 }
 return T;
}

int MaxGap(struct Node *node)
{return node->max-node->min;
}

int MinGap(struct Node *root)
{return Min(root->left->mingap,root->key-root->left->max,root->right->mingap,root->right->min-root->key);
}

//Utility function to calculate sum from 0 to a number(excluding that number)
int Sum(struct Node *node,int key)
{int sum=0;
 struct Node *T=node;
 while(T!=NULL)
 {if(T->key==key)
  {if(T->left!=NULL)
    return sum+T->left->sum;
   return sum;
  }
  if(T->key<key)
  {sum+=T->key;
   if(T->left!=NULL)
    sum+=T->left->sum;
   T=T->right;
  }
  else
   T=T->left;
 }
 return sum;
}
 
// A utility function to print preorder traversal of
// the tree.
// The function also prints height of every node
void preOrder(struct Node *root)
{
    if(root != NULL)
    {
        printf("%d ", root->key);
        preOrder(root->left);
        preOrder(root->right);
    }
}
 
/* Drier program to test above function*/
int main()
{
  struct Node *root = NULL;
 
  /* Constructing tree given in the above figure */
  root = insert(root, 9);
  root = insert(root, 6);
  root = insert(root, 4);
  root = insert(root, 7);
  preOrder(root);
  printf("\n");
  printf("Max Gap: %d\n",MaxGap(root));
  printf("Min Gap: %d\n",MinGap(root));
  root = insert(root, 3);
  root = insert(root, 5);
  root = insert(root, 10);
  root = insert(root, 2);
  root = insert(root, 1);
  preOrder(root);
  printf("\n");
  printf("Sum till 7: %d\n",Sum(root, 7));      //Sum from a to b include a and excludes b
  printf("Sum till 10: %d\n",Sum(root, 10));
  printf("Sum till 8: %d\n",Sum(root, 8));
  printf("Sum till 4: %d\n",Sum(root, 4));
  printf("Sum from 4 to 8: %d\n",Sum(root, 8)-Sum(root, 4));
  printf("Max Gap: %d\n",MaxGap(root));
  printf("Min Gap: %d\n",MinGap(root));
  printf("Rank of 6: %d\n",Rank(root,6));
  printf("Element with rank 4: %d\n",FindRank(root,4)->key);
  printf("Rank of 4: %d\n",Rank(root,4));
  printf("Element with rank 6: %d\n",FindRank(root,6)->key);
  printf("Rank of 1: %d\n",Rank(root,1));
  printf("Element with rank 9: %d\n",FindRank(root,9)->key);
  printf("Rank of 10: %d\n",Rank(root,10));
  printf("Element with rank 1: %d\n",FindRank(root,1)->key);
    root = deleteNode(root, 10);
    preOrder(root);
  printf("\n");
    root = deleteNode(root, 5);
    preOrder(root);
  printf("\n");
    root = deleteNode(root, 2);
    preOrder(root);
  printf("\n");
  printf("Max Gap: %d\n",MaxGap(root));
  printf("Min Gap: %d\n",MinGap(root));
  printf("Rank of 6: %d\n",Rank(root,6));
    root = deleteNode(root, 6);
    preOrder(root);
  printf("\n");
  printf("Rank of 4: %d\n",Rank(root,4));
  printf("Element with rank 3: %d\n",FindRank(root,3)->key);
  printf("Rank of 1: %d\n",Rank(root,1));
  printf("Element with rank 5: %d\n",FindRank(root,5)->key);
  printf("Max Gap: %d\n",MaxGap(root));
  printf("Min Gap: %d\n",MinGap(root));
    root = deleteNode(root, 9);
    preOrder(root);
  printf("\n");
  printf("Max Gap: %d\n",MaxGap(root));
  printf("Min Gap: %d\n",MinGap(root));
    root = deleteNode(root, 4);
    preOrder(root);
  printf("\n");
  printf("Max Gap: %d\n",MaxGap(root));
  printf("Min Gap: %d\n",MinGap(root));
  Search(root, 3);
  Search(root, 9);
  Search(root, 10);
}
