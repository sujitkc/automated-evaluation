#include<stdio.h>
int prefix_sum(int c[],int i)
{
	int s=0,j;
	//j=(i)&(-(i));
	while(i>0)
	{
		s=s+c[i-1];
		j=(i)&(-(i));
		i=i-j;
		//j=j-k;
	}
	return s;
}
int make_arr_c(int b[],int c[],int i)
{
	int s=0;
	int k=(i+1)&(-(i+1));// only these many previous number + that number's sum is needed 
	k--;
	int t;
	i=i-1;
	while(k>0)
	{
		s=s+c[i];
		t=(i+1)&(-(i+1));
		k=k-t;
		i=i-t;
	}
	return s;
}
void update(int i, int x,int n,int c[])
{
	int j;
while(i<n)
{
	c[i]=c[i]+x;
	j=(i+1)&(-(i+1));
	i=i+j;
}
}
int main()
{
	int b[]={2,1,4,5,2,1,3,8};
	int n=sizeof(b)/sizeof(b[0]);
	int c[n];
	int i;
	c[0]=b[0];
	for(i=1;i<n;i++)
	{
		c[i]=b[i]+make_arr_c(b,c,i);
	}
	for(i=0;i<n;i++)
	{
		printf("%d ",c[i]);
	}
	printf("%d",prefix_sum(c,5));
	update(0,5,n,c);
	for(i=0;i<n;i++)
	{
		printf(" %d ",c[i]);
	}
}