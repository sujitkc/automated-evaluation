#include<stdio.h>
int l,t=1;
int x=1000;
int min(int b[],int a,int c)
{
	if(b[a]<b[c])
		{
		return a;
		}
	else
		{
		return c;
		}
}
int min2(int b[],int a,int c)
{
	if(b[b[a]]<b[b[c]])
		{
		return b[a];
		}
	else
		{
		return b[c];
		}
}
int call(int b[],int i,int j)
{
	int f=j;
	int k;
	if(t==1)
	{
	for(k=0;k<((j-i)/2)+1;k++)
    	{
    	//printf("**%d",min(b,f,f-1));
	    b[l]=min(b,f,f-1);
	    f=f-2;
	    l--;
	    t++;
	    }
	}
	else
	{
	    for(k=0;k<((j-i)/2)+1;k++)
	    {
	    b[l]=min2(b,f,f-1);
	    f=f-2;
	    l--;
	    }
	}
	return 0;
}

// checking if both the i and j are in the same half sections.
// p is the size of the section.
// l and m are the section of array needed to be checked.

void same_section_check(int arr[],int i, int j,int l, int m)
{
	 if(i==l && j==m)
	{
		while(1)
		{
			//printf("//%d %d %d %d//",i,j,l,m);
			i=(i-1)/2;
			j=((j-1)/2);
			
			if(i==j)
			{
				//printf("'''%d'''",arr[arr[i]]);
				if(arr[arr[i]]<x)
				{
					x=arr[arr[i]];
				//printf("'''%d'''",arr[arr[i]]);
				}
				break;
			}
		}
	}
	else if(i==j)
	{
		if(arr[i]<x)
		{
			printf("'''%d'''",arr[arr[i]]);
			x=arr[i];
		}
	}
	
	// if both i and j are in the same sub section.
	else if(i<=(m+l)/2 && j<=(m+l)/2)
	{
		//printf("(a%d %da)",i,j);
		same_section_check(arr,i,j,l,(l+m)/2);
	}
	else if(i>(m+l)/2 && j>(m+l)/2)
	{
		//printf("(b%d %db)",i,j);
		same_section_check(arr,i,j,((l+m)/2)+1,m);
	}
	// if both i and j are not in the same sub section
	
	else
	{
		//printf("(c%d %dc)",i,j);
		same_section_check(arr,i,(l+m)/2,l,(l+m)/2);
		//printf("(d%d %dd)",i,j);
		same_section_check(arr,((l+m)/2)+1,j,((l+m)/2)+1,m);
	}

}
int main()
{
	int i;
	int arr[16]={1,7,9,12,13,15,27,6,5,9,12,16,33,8,4,3};
	int n=sizeof(arr)/sizeof(arr[0]);
	int m=1;
	while(1)
	{
		if(m<n)
		{
		m=m*2;
		}
		else
		{
		break;
		}
	}
	int b[2*m-1];
	for(i=0;i<n;i++)
		{
		b[i+m-1]=arr[i];
		}	
	for(i=n;i<m;i++)
		{
		b[i+m-1]=-1;
		}
	l=m-2;	
	int x=m;
	while(l!=-1)
	{
	call(b,l+1,l+x);
	x=x/2;
	}
	for(i=0;i<2*m-1;i++)
	{
	printf("%d ",b[i]);
	}
	printf("\n");
	same_section_check(b,17,27,15,30);
	//printf("%d",x);
	
}