#include <stdio.h>
#include <stdlib.h>
#include <math.h>
struct node{
	int data;
	struct node *parent,*lc,*rc;
	int height;
}*head = NULL;

void pre_order_traversal(struct node *ptr)
{
    if(ptr!=NULL)
    {
        printf("%d ",ptr->data);
        pre_order_traversal(ptr->lc);
        pre_order_traversal(ptr->rc);
        
    }
}
void in_order_traversal(struct node *ptr)
{
    if(ptr!=NULL)
    {
        in_order_traversal(ptr->lc);
        printf("%d ",ptr->data);
        in_order_traversal(ptr->rc);
        
    }
}
void zig_zag1(struct node *temp,struct node *temp2,struct node *temp3)
{
struct node *temp4;
int h=temp->height;
temp4=temp->parent;
temp->rc=temp3->lc;
temp2->lc=temp3->rc;
temp3->lc=temp;
temp3->rc=temp2;
temp->parent=temp3;
temp2->parent=temp3;
temp->height=h-2;
temp2->height=h-2;
temp3->height=h-1;
if(temp4!=NULL)
{
	temp3->parent=temp4;
	if(temp4->rc==temp)
	{
		temp4->rc=temp3;
	}
	else
	{
		temp4->lc=temp3;
	}
}
else
{
	head=temp3;
	head->parent=NULL;
}
}
void zig_zag2(struct node *temp,struct node *temp2,struct node *temp3)
{
struct node *temp4;
int h=temp->height;
temp4=temp->parent;
temp->rc=temp3->lc;
temp2->lc=temp3->rc;
temp3->lc=temp;
temp3->rc=temp2;
temp->parent=temp3;
temp2->parent=temp3;
temp->height=h-2;
temp2->height=h-2;
temp3->height=h-1;
if(temp4!=NULL)
{
	temp3->parent=temp4;
	if(temp4->rc==temp)
	{
		temp4->rc=temp3;
	}
	else
	{
		temp4->lc=temp3;
	}
}
else
{
	head=temp3;
	head->parent=NULL;
}
}
void zig_zig1(struct node *temp,struct node *temp2,struct node *temp3)
{
struct node *temp4;
int h=temp->height;
temp4=temp->parent;
temp->rc=temp2->lc;
temp2->lc=temp;
temp->parent=temp2;
temp3->parent=temp2;
temp->height=h-2;
temp2->height=h-1;
temp3->height=h-2;
if(temp4!=NULL)
{
	temp2->parent=temp4;
if(temp4->rc==temp)
	{
		temp4->rc=temp2;
	}
else
	{
		temp4->lc=temp2;
	}
}
else
{
	head=temp2;
	head->parent=NULL;
}
}
void zig_zig2(struct node *temp,struct node *temp2,struct node *temp3)
{
struct node *temp4;
int h=temp->height;
temp4=temp->parent;
temp->lc=temp2->rc;
temp2->rc=temp;
temp->parent=temp2;
temp3->parent=temp2;
temp->height=h-2;
temp2->height=h-1;
temp3->height=h-2;
if(temp4!=NULL)
{
temp2->parent=temp4;
if(temp4->rc==temp)
	{
		temp4->rc=temp2;
	}
else
	{
		temp4->lc=temp2;
	}
}
else
{
	head=temp2;
	head->parent=NULL;
}
}

int max(int a,int b)
{
	if(a>b)
	{
		return a;
	}
	else
	{
		return b;
	}
}
void avl_property(struct node *temp,struct node *temp2,struct node *temp3)
{
		if((temp->rc)==temp2)
					{
						if(temp3==(temp2->lc))
						{
							zig_zag1(temp,temp2,temp3);
						}
						else
						{
							zig_zig1(temp,temp2,temp3);
						}
					}
					else
					{
						if(temp3==(temp2->rc))
						{
							zig_zag2(temp,temp2,temp3);
						}
						else
						{
							zig_zig2(temp,temp2,temp3);
						}
					}	

}
void insertion(struct node **root,int k)
{
struct node *temp;
temp=*root;
if((head)==NULL)
	{
		(head)=(struct node*)malloc(sizeof(struct node));
		(head)->data=k;
		(head)->height=0;
		(head)->lc=NULL;
		(head)->rc=NULL;
		(head)->parent=NULL;
	}
else
	{
	struct node *temp2; 
	temp2=(struct node*)malloc(sizeof(struct node));
	temp2->data=k;	
	temp2->height=0;
	temp2->lc=NULL;
	temp2->rc=NULL;	
	while(1)
		{
			if(temp->data>k && temp->lc==NULL)
			{
				temp->lc=temp2;
				temp2->parent=temp;
				break;	
			}
			else if(temp->data<k && temp->rc==NULL)
			{
				temp->rc=temp2;
				temp2->parent=temp;
				break;	
			}
			else if(temp->data>k)
			{
				temp=temp->lc;
			}
			else
			{
				temp=temp->rc;
			}
		}
		int m,n;
		if(temp->rc==NULL || temp->lc==NULL)
		{
		struct node *temp3;
		temp3=temp2;
		temp2=temp;
		temp2->height=1;
		if(temp!=NULL)
		{	
		if(temp2->parent!=NULL)
		{
			temp=temp->parent;
			if(temp->lc==NULL || temp->rc==NULL)
			{
				temp->height=(temp2->height)+1;
				avl_property(temp,temp2,temp3);
			}
			else
			{	
			while(1)
			{
			m=(temp->lc)->height;
			n=(temp->rc)->height;
			if(m==n) //if both the heights of the children 
				 //are same after insertion=>avl property will
				 //be satisfied in the above part of the trees
				{
					break;		
				}
			else if(abs(m-n)==1 && temp->parent!=NULL)// avl property is satisfied thus move the temp up
				{
				temp->height=max(m,n)+1;
				temp3=temp2;
				temp2=temp;
				temp=temp->parent;
				}
			else if(abs(m-n)==1 && temp->parent==NULL)
				{
					temp->height=max(m,n)+1;
					break;
				}
			else
				{
				//if(m-n>1 || n-m>1),avl property is not satisfied
					avl_property(temp,temp2,temp3);
					break;
				}
			}
		}
		}
		}
	}
	}
}
	
void deletion()
int main()
{
insertion(&head,50);
insertion(&head,25);
insertion(&head,23);
insertion(&head,100);
insertion(&head,200);
pre_order_traversal(head);
printf("\n");
in_order_traversal(head);
}