#include<stdio.h>
#include<math.h>
int min(int x,int y)
{
	if(x<=y)
		return x;
	else
		return y;
}
void build(int seg[],int arr[],int N,int n)
{
	int i,max=32734,size=2*n-1;
	for(i=0;i<size;i++)
		seg[i]=max;
	int x=1;
	for(i=size-(n-N)-1;i>size-(n-N)-1-N;i--)
	{
		seg[i]=arr[N-x];
		x++;
	}
	for(i=size-n-1;i>=0;i--)
	{
		int lc,rc;
		lc=2*i+1;
		rc=lc+1;
		seg[i]=min(seg[lc],seg[rc]);
	}
}
int RMQ(int seg[],int l,int r,int node,int segl,int segr,int max)
{
	if(segl>=l && segr<=r)
		return seg[node];
	else if(segr<l || segl>r)
		return max;
	else
	{
		int lc=2*node+1,rc=lc+1;
    	int left,right;
    	left=RMQ(seg,l,r,lc,segl,segl+(segr-segl)/2,max);
    	right=RMQ(seg,l,r,rc,segl+(segr-segl)/2+1,segr,max);
		return min(left,right);
	}
}
void update(int seg[],int i,int value)
{
	int p=(i-1)/2,lc,sib;
	seg[i]=value;
	while(p>0)
	{
		p=(i-1)/2;
		lc=2*p+1;
		if(lc==i)
			sib=i+1;
		else
			sib=i-1;
		printf("%d %d\n",seg[i],seg[sib]);
		seg[p]=min(seg[i],seg[sib]);
		i=p;
	}
}
int main()
{
	int N,size,n,i;
	scanf("%d",&N);
	int arr[N],max;
	for(i=0;i<N;i++)
    	scanf("%d",&arr[i]);
	for(i=1;i<N;i=i*2)
	{
	}
	n=i;
	size=2*n-1;
  	int seg[size];
	printf("n=%d\nsize=%d\n",n,size);
  	build(seg,arr,N,n);
  	for(i=0;i<size;i++)
		printf("%d ",seg[i]);
	printf("\n");
	int l,r,ind,val;
	scanf("%d%d",&l,&r);
	printf("%d\n",RMQ(seg,l,r,0,0,n-1,max));
	scanf("%d%d",&ind,&val);
	update(seg,ind+n-1,val);
	for(i=0;i<size;i++)
		printf("%d ",seg[i]);
}
