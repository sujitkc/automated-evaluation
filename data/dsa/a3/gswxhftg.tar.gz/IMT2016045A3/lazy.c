#include<stdio.h>
void BuildTree(int tree[],int arr[],int left,int right,int ind)
{
	if(left==right){
		tree[ind]=arr[left];
	}
	else{
		int mid,lc,rc;
		mid=(left+right)/2;
		lc=2*ind+1;
		rc=lc+1;
		BuildTree(tree,arr,left,mid,lc);
		BuildTree(tree,arr,mid+1,right,rc);
		tree[ind]=tree[lc]+tree[rc];
	}
}
void UpdateRange(int tree[],int lazy[],int ul,int ur,int val,int nl,int nr,int node)
{
	int mid,lc,rc;
	mid=(nl+nr)/2;
	lc=2*node+1;
	rc=lc+1;
	if(lazy[node]!=0){
		tree[node]+=(nr-nl+1)*lazy[node];
		if(nl!=nr){
			lazy[lc]+=lazy[node];
			lazy[rc]+=lazy[node];
		}
		lazy[node]=0;
	}
	if(ur<nl || ul>nr){
		return;
	}
	else{
		if(nl==nr){
			tree[node]+=val;
			return;
		}
		else if(nl>=ul && nr<=ur){
			tree[node]+=val*(nr-nl+1);
			lazy[lc]+=val;
			lazy[rc]+=val;
		}
		else{
			UpdateRange(tree,lazy,ul,ur,val,nl,mid,lc);
			UpdateRange(tree,lazy,ul,ur,val,mid+1,nr,rc);
			tree[node]=tree[lc]+tree[rc];
		}
	}
}
int rsq(int tree[],int lazy[],int ql,int qr,int nl,int nr,int node)
{
	int mid,lc,rc;
	mid=(nl+nr)/2;
	lc=2*node+1;
	rc=lc+1;
	if(lazy[node]!=0){
		tree[node]+=(nr-nl+1)*lazy[node];
		if(nl!=nr){
			lazy[lc]+=lazy[node];
			lazy[rc]+=lazy[node];
		}
		lazy[node]=0;
	}
	if(ql>nr || qr<nl){
		return 0;
	}
	else if(ql<=nl && qr>=nr){
		return tree[node];
	}
	else{
		return rsq(tree,lazy,ql,qr,nl,mid,lc)+rsq(tree,lazy,ql,qr,mid+1,nr,rc);
	}
}
int main(){
	int n,size;
	scanf("%d",&n);
	size=2*n-1;
	int arr[n],tree[size],lazy[size],i;
	for(i=0;i<n;i++){
		scanf("%d",&arr[i]);
	}
	for(i=0;i<size;i++){
		lazy[i]=0;
	}
	BuildTree(tree,arr,0,n-1,0);
	for(i=0;i<size;i++){
		printf("%d ",tree[i]);
	}
	printf("\n");
	int ul,ur,val;
	scanf("%d%d%d",&ul,&ur,&val);
	UpdateRange(tree,lazy,ul,ur,val,0,n-1,0);
	for(i=0;i<size;i++){
		printf("%d ",tree[i]);
	}
	printf("\n");
	scanf("%d%d%d",&ul,&ur,&val);
	UpdateRange(tree,lazy,ul,ur,val,0,n-1,0);
	int ql,qr,ans;
	scanf("%d%d",&ql,&qr);
	ans=rsq(tree,lazy,ql,qr,0,n-1,0);
	printf("%d\n",ans);
}
