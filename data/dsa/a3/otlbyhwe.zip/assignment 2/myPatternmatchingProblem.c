#include<stdio.h>
#include<string.h>
int q = 101;
void detectPatternmatch(char P[1000], char T[1000])
{
    int M = strlen(P);
    int N = strlen(T);
    int i, j;
    int p = 0,t = 0,h = 1;
    for (i = 0; i < M-1; i++)
        h = (2*h)%q;
    for (i = 0; i < M; i++)
    {
        p = (2*p + P[i])%q;
        t = (2*t + T[i])%q;
    }
    printf("%d\t%d\t%d\n",p,t,h);
    for (i = 0; i <= N - M; i++)
    {
        if ( p == t )
        {
            for (j = 0; j < M; j++)
            {
                if (T[i+j] != P[j])
                    break;
            }
            if (j == M)
                printf("Pattern match at index %d \n", i);
        }
        if ( i < N-M )
        {
            t = (2*(t - T[i]*h) + T[i+M])%q;
            if (t < 0)
            t = (t + q);
        }
    }
}
 
int main()
{
    char T[] =  "1001011001000";
    char P[] =  "011001";
    detectPatternmatch(P,T);
    return 0;
}
