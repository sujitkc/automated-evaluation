#include <stdio.h>
#include <stdlib.h>
struct rbNode {
    int data; 
	int color;
    struct rbNode *left;
    struct rbNode *right;
};
  
enum nodeColor {
    RED,
    BLACK
};

struct rbNode *root = NULL;

struct rbNode * createNode(int data) {
    struct rbNode *newnode;
    newnode = (struct rbNode *)malloc(sizeof(struct rbNode));
    newnode->data = data;
    newnode->color = RED;
    newnode->left = newnode->right = NULL;
    return newnode;
}

void insertion (int data) {
    struct rbNode *stack[98], *ptr, *newnode, *xPtr, *yPtr;
    int dir[98], ht = 0, index;
    ptr = root;
    if (!root) {
        root = createNode(data);
        return;
    }
    stack[ht] = root;
    dir[ht++] = 0;
    while (ptr != NULL) {
    	if (ptr->data == data) {
            printf("Duplicates Not Allowed!!\n");
            return;
        }
        stack[ht] = ptr;
        if(data>ptr->data){
            index=1;
		}
		if(data<ptr->data){
			index=0;
		}
		if(index==0){
			ptr = ptr->left;
		}
		if(index==1){
			ptr = ptr->right;
		}
        dir[ht++] = index;
	}
    if(index==0){
        stack[ht - 1]->left = newnode = createNode(data);
	}
	if(index==1){
		stack[ht - 1]->right = newnode = createNode(data);	
	}
    while ((ht >= 3) && (stack[ht - 1]->color == RED)) {
        if (dir[ht - 2] == 0) {
            yPtr = stack[ht - 2]->right;
            if (yPtr != NULL && yPtr->color == RED) {
                stack[ht - 2]->color = RED;
                stack[ht - 1]->color = yPtr->color = BLACK;
                ht = ht -2;
            } 
			else {
            	if (dir[ht - 1] == 0) {
                    yPtr = stack[ht - 1];
                } 
				else{
                    xPtr = stack[ht - 1];
                    yPtr = xPtr->right;
                    xPtr->right = yPtr->left;
                    yPtr->left = xPtr;
                    stack[ht - 2]->left = yPtr;
                }
                xPtr = stack[ht - 2];
                xPtr->color = RED;
                yPtr->color = BLACK;
                xPtr->left = yPtr->right;
                yPtr->right = xPtr;
                if (xPtr == root) {
                    root = yPtr;
                }
				else{
                    if(dir[ht - 3]==0){
                        stack[ht - 3]->left = yPtr;
					}
					else if(dir[ht - 3]==1){
						stack[ht - 3]->right = yPtr;	
					}
                }
                break;
            }
        } 
		else{
            yPtr = stack[ht - 2]->left;
            if ((yPtr != NULL) && (yPtr->color == RED)) {
                stack[ht - 2]->color = RED;
                stack[ht - 1]->color = yPtr->color = BLACK;
                ht = ht - 2;
                } 
			else{
                if (dir[ht - 1] == 1) {
                	yPtr = stack[ht - 1];
                }
				else {
                    xPtr = stack[ht - 1];
                    yPtr = xPtr->left;
                    xPtr->left = yPtr->right;
                    yPtr->right = xPtr;
                    stack[ht - 2]->right = yPtr;
                }
                xPtr = stack[ht - 2];
                yPtr->color = BLACK;
                xPtr->color = RED;
                xPtr->right = yPtr->left;
                yPtr->left = xPtr;
                if (xPtr == root) {
                    root = yPtr;
                }
				else{
                    if(dir[ht - 3]==0){
                        stack[ht - 3]->left = yPtr;
					}
					else if(dir[ht - 3]==1){
						stack[ht - 3]->right = yPtr;	
                    }
                    break;
                }
        	} 
		}
    }
    root->color = BLACK;
}

void deletion(int data) {
    struct rbNode *stack[98], *ptr, *xPtr, *yPtr;
    struct rbNode *pPtr, *qPtr, *rPtr;
    int dir[98], ht = 0, index, i;
    enum nodeColor color;
	if (!root) {
        printf("Tree not available\n");
        return;
    }
    ptr = root;
    while (ptr != NULL) {
        if ((data - ptr->data) == 0)
            break;
        	stack[ht] = ptr;
            if(data>ptr->data){
                index=1;
			}
			if(data<ptr->data){
				index=0;
			}
			if(index==0){
				ptr = ptr->left;
			}
			if(index==1){
				ptr = ptr->right;
			}
            dir[ht++] = index;
    }
	if (ptr->right == NULL) {
        if ((ptr == root) && (ptr->left == NULL)) {
            free(ptr);
            root = NULL;
        } 
		else if (ptr == root) {
            root = ptr->left;
            free(ptr);
        } 
		else {
            if(dir[ht - 1]==0){
        		stack[ht - 1]->left = ptr->left;
			}	
			else if(dir[ht - 1]==1){
				stack[ht - 1]->right = ptr->left;	
			}
    	}
    } 
	else {
        xPtr = ptr->right;
        if (xPtr->left == NULL) {
            xPtr->left = ptr->left;
            color = xPtr->color;
            xPtr->color = ptr->color;
            ptr->color = color;
			if (ptr == root){
                root = xPtr;
            } 
			else {
                if(dir[ht - 1]==0){
                    stack[ht - 1]->left = xPtr;
				}
				else if(dir[ht - 1]==1){
					stack[ht - 1]->right = xPtr;	
				}
            }
			dir[ht] = 1;
            stack[ht++] = xPtr;
        } 
		else {
            i = ht++;
            while (1) {
                dir[ht] = 0;
                stack[ht++] = xPtr;
                yPtr = xPtr->left;
                if (!yPtr->left)
                    break;
                xPtr = yPtr;
            }
			dir[i] = 1;
            stack[i] = yPtr;
            if (i > 0){
                if(dir[ht - 1]==0){
                    stack[ht - 1]->left = yPtr;
				}
				else if(dir[ht - 1]==1){
					stack[ht - 1]->right = yPtr;	
				}
			}
            yPtr->left = ptr->left;
            xPtr->left = yPtr->right;
            yPtr->right = ptr->right;
			if (ptr == root) {
                root = yPtr;
            }
			color = yPtr->color;
            yPtr->color = ptr->color;
            ptr->color = color;
        }
    }
    if (ht < 1)
		return;
    if (ptr->color == BLACK) {
        while (1) {
            if(dir[ht - 1]==0){
            	pPtr = stack[ht - 1]->left;
			}
			else if(dir[ht - 1]==1){
				pPtr = stack[ht - 1]->right;	
			}
            if (pPtr && pPtr->color == RED) {
                pPtr->color = BLACK;
                break;
            }
            if (ht < 2)
                break;
            if (dir[ht - 2] == 0) {
                rPtr = stack[ht - 1]->right;
            if (!rPtr)
                break;
            if (rPtr->color == RED) {
                stack[ht - 1]->color = RED;
                rPtr->color = BLACK;
                stack[ht - 1]->right = rPtr->left;
                rPtr->left = stack[ht - 1];
            	if (stack[ht - 1] == root) {
                	root = rPtr;
            	}
				else {
                	if(dir[ht - 2]==0){
                    	stack[ht - 2]->left=rPtr;
					}
					else if(dir[ht - 2]==1){
						stack[ht - 2]->right=rPtr;	
					}
                }
                dir[ht] = 0;
                stack[ht] = stack[ht - 1];
                stack[ht - 1] = rPtr;
                ht++;
                rPtr = stack[ht - 1]->right;
            }
            if ( (!rPtr->left || rPtr->left->color == BLACK) &&(!rPtr->right || rPtr->right->color == BLACK)){
                rPtr->color = RED;
            }
			else {
                if (!rPtr->right || rPtr->right->color == BLACK) {
                    qPtr = rPtr->left;
                    rPtr->color = RED;
                    qPtr->color = BLACK;
                    rPtr->left = qPtr->right;
                	qPtr->right = rPtr;
                    rPtr = stack[ht - 1]->right = qPtr;
                	rPtr->color = stack[ht - 1]->color;
                	stack[ht - 1]->color = BLACK;
                	rPtr->right->color = BLACK;
                	stack[ht - 1]->right = rPtr->left;
                	rPtr->left = stack[ht - 1];
                	if (stack[ht - 1] == root) {
                    	root = rPtr;
                	} 
					else {
                    	if(dir[ht - 2]==0){
                        	stack[ht - 2]->left=rPtr;
						}
						else if(dir[ht - 2]==1){
							stack[ht - 2]->right=rPtr;	
						}
                	}
                	break;
            	}
        	}
        }
		else {
            rPtr = stack[ht - 1]->left;
            if (!rPtr)
                break;
            if (rPtr->color == RED) {
                stack[ht - 1]->color = RED;
                rPtr->color = BLACK;
                stack[ht - 1]->left = rPtr->right;
                rPtr->right = stack[ht - 1];
        	}
            if (stack[ht - 1] == root) {
                root = rPtr;
            } 
			else {
                if(dir[ht - 2]==0){
                    stack[ht - 2]->left=rPtr;
				}
				else if(dir[ht - 2]==1){
					stack[ht - 2]->right=rPtr;	
				}
            }
            dir[ht] = 1;
            stack[ht] = stack[ht - 1];
            stack[ht - 1] = rPtr;
            ht++;
            rPtr = stack[ht - 1]->left;
        }
        if ( (!rPtr->left || rPtr->left->color == BLACK) &&(!rPtr->right || rPtr->right->color == BLACK)){
            rPtr->color = RED;
        } 
		else {
            if (!rPtr->left || rPtr->left->color == BLACK) {
                qPtr = rPtr->right;
                rPtr->color = RED;
                qPtr->color = BLACK;
            	rPtr->right = qPtr->left;
            	qPtr->left = rPtr;
                rPtr = stack[ht - 1]->left = qPtr;
            	rPtr->color = stack[ht - 1]->color;
            	stack[ht - 1]->color = BLACK;
            	rPtr->left->color = BLACK;
            	stack[ht - 1]->left = rPtr->right;
            	rPtr->right = stack[ht - 1];
            	if (stack[ht - 1] == root) {
                	root = rPtr;
            	} 
				else {
                	if(dir[ht - 2]==0){
                    	stack[ht - 2]->left=rPtr;
					}
					else if(dir[ht - 2]==1){
						stack[ht - 2]->right=rPtr;	
					}
            	}
            	break;
        		}
    		}
    		ht--;
		}
	}
}

void searchElement(int data) {
    struct rbNode *temp = root;
    int diff;
	while (temp != NULL) {
    	diff = data - temp->data;
        if (diff > 0) {
            temp = temp->right;
        } 
		else if (diff < 0) {
            temp = temp->left;
        } 
		else {
            printf("Search Element Found!!\n");
            return;
        }
    }
    printf("Given Data Not Found in RB Tree!!\n");
    return;
}

void inorderTraversal(struct rbNode *node) {
    if (node) {
        inorderTraversal(node->left);
        printf("%d  ", node->data);
        inorderTraversal(node->right);
    }
    return;
}

void preorderTraversal(struct rbNode *T)
{
    if(T!=NULL)
    {
        printf("%d->",T->data);
        preorderTraversal(T->left);
        preorderTraversal(T->right);
    }
    return;
}

int main() {
    int ch, data;
    insertion(10);
    insertion(-10);
    insertion(20);
    insertion(-20);
    insertion(6);
    insertion(15);
    insertion(30);
    insertion(1);
    insertion(9);
    while (1) {
        printf("\n1. Insertion\t2. Deletion\n");
        printf("3. Searching\t4. Traverse\n\t5. Exit\nEnter your choice:");
        scanf("%d", &ch);
    	switch (ch) {
            case 1:
                printf("Enter the data to insert:");
                scanf("%d", &data);
                insertion(data);
                break;
            case 2:
                printf("Enter the data to delete:");
            	scanf("%d", &data);
                deletion(data);
                break;
            case 3:
                printf("Enter the search element:");
                scanf("%d", &data);
                searchElement(data);
                break;
            case 4:
            	printf("INORDER:(ascending Order)\n");
                inorderTraversal(root);
                printf("\n");
                printf("PREORDER:(actual Order)\n");
                preorderTraversal(root);
                printf("NULL\n");
                break;
            case 5:
                exit(0);
            default:
                printf("You have entered wrong option!!\n");
                break;
        }
        printf("\n");
    }
    return 0;
}
