#include<stdio.h>
#include<stdlib.h>
 
typedef struct node{
    int data;
    struct node *left,*right;
    int ht;
}node;

int height(node *T){
    int lh,rh;
    if(T==NULL)
        return(0);
    if(T->left==NULL)
        lh=0;
    else
        lh=1+T->left->ht;
    if(T->right==NULL)
        rh=0;
    else
        rh=1+T->right->ht;
    if(lh>rh)
        return(lh);
    return(rh);
}
 
node * rotateright(node *x){
    node *y;
    y=x->left;
    x->left=y->right;
    y->right=x;
    x->ht=height(x);
    y->ht=height(y);
    return(y);
}
 
node * rotateleft(node *x){
    node *y;
    y=x->right;
    x->right=y->left;
    y->left=x;
    x->ht=height(x);
    y->ht=height(y);
    
    return(y);
}

node *ZigZig(int i,node *T){
	if(i==0){
		T=rotateright(T);
    	return(T);	
	}
	if(i==1){
		T=rotateleft(T);
    	return(T);	
	}
}

node *ZigZag(int i,node *T){
	if(i==0){
		T->left=rotateleft(T->left);
    	T=rotateright(T);
    	return(T);	
	}
	if(i==1){
		T->right=rotateright(T->right);
    	T=rotateleft(T);
    	return(T);	
	}
}
 
int BF(node *T){
    int lh,rh;
    if(T==NULL)
        return(0);
 
    if(T->left==NULL)
        lh=0;
    else
        lh=1+T->left->ht;
 
    if(T->right==NULL)
        rh=0;
    else
        rh=1+T->right->ht;
 
    return(lh-rh);
}
 
node * insert(node *T,int x){
    if(T==NULL){
        T=(node*)malloc(sizeof(node));
        T->data=x;
        T->left=NULL;
        T->right=NULL;
    }
    else
        if(x > T->data){
            T->right=insert(T->right,x);
            if(BF(T)==-2){
                if(x>T->right->data){
                	T=ZigZig(1,T);
				}
                else{
                	T=ZigZag(1,T);
				}
			}
        }
        if(x<T->data){
            T->left=insert(T->left,x);
            if(BF(T)==2){
                if(x < T->left->data){
                    T=ZigZig(0,T);	
				}
                else{
                    T=ZigZag(0,T);
				}
			}
        }
        T->ht=height(T);
        return(T);
}
 
node * Delete(node *T,int x){
    node *p;
    if(T==NULL){
        return NULL;
    }
    else
        if(x > T->data){
            T->right=Delete(T->right,x);
            if(BF(T)==2)
                if(BF(T->left)>=0){
                	T=ZigZig(0,T);
				}
                else{
                	T=ZigZag(0,T);
				}
        }
        else
            if(x<T->data){
                T->left=Delete(T->left,x);
                if(BF(T)==-2)  
                    if(BF(T->right)<=0){
                    	T=ZigZig(1,T);
					}
                    else{
                    	T=ZigZag(1,T);
					}
            }
            else{
                if(T->right!=NULL){  
                    p=T->right;
                    while(p->left!= NULL)
                        p=p->left;
                    
                    T->data=p->data;
                    T->right=Delete(T->right,p->data);
                    
                    if(BF(T)==2)
                        if(BF(T->left)>=0){
                        	 T=ZigZig(0,T);
						}  
                        else{
                        	 T=ZigZag(0,T);
						}     
                }
                else
                    return(T->left);
            }
    T->ht=height(T);
    return(T);
}
  
void preorder(node *T){
    if(T!=NULL){
        printf("%d(BF=%d)->",T->data,BF(T));
        preorder(T->left);
        preorder(T->right);
    }
}
 
void inorder(node *T){
    if(T!=NULL){
        inorder(T->left);
        printf("%d(BF=%d)->",T->data,BF(T));
        inorder(T->right);
    }
}

int main(){
    node *root=NULL;
    int x,n,i,p=0;
    root=insert(root,20);
    root=insert(root,10);
    root=insert(root,30);
    root=insert(root,5);
    root=insert(root,25);
    root=insert(root,35);
    root=insert(root,40);
    root=insert(root,45);
    root=insert(root,34);
    printf("\nPreorder sequence:\n");
    preorder(root);
    printf("NULL\n\n");
    while(p!=5){
    	printf("AVL TREE ::::::>\n");
        printf("1)Create:\t2)Insert:\n3)Delete:\t4)Display:\n\t5)Quit:\nEnter Your Choice:");
        scanf("%d",&p);
        if(p==1){
			printf("\nEnter no. of elements:");
            scanf("%d",&n);
            printf("\nEnter tree data:");
            root=NULL;
            for(i=0;i<n;i++){
                scanf("%d",&x);
                root=insert(root,x);
            }
        }    
        if(p==2){
        	printf("\nEnter a data:");
            scanf("%d",&x);
            root=insert(root,x);
		}            
        if(p==3){
            printf("\nEnter a data:");
            scanf("%d",&x);
            root=Delete(root,x);	
		}
        if(p==4){
            printf("\nPreorder sequence:\n");
            preorder(root);
            printf("NULL\n");
            printf("\n\nInorder sequence:\n");
            inorder(root);
            printf("NULL\n\n");	
		}           
    }
    return 0;
}
