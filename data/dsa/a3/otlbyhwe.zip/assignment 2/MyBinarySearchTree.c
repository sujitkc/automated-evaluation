#include<stdio.h>
#include<stdlib.h>

struct BstNode{
	int data;
	int count;
	struct BstNode *left;
	struct BstNode *right;
};

struct BstNode *getnewNode(int data){
	struct BstNode *newNode=(struct BstNode *)malloc(sizeof(struct BstNode));
	newNode->data=data;
	newNode->count=0;
	newNode->left=newNode->right=NULL;
}

struct BstNode *FindMin(struct BstNode *node)
{
    if(node==NULL){      
    	return NULL;
    }
    if(node->left)
        return FindMin(node->left);
    else 
        return node;
}

struct BstNode *FindMax(struct BstNode *node)
{
    if(node==NULL){
        return NULL;
    }
    if(node->right) 
        FindMax(node->right);
    else 
        return node;
}

int MAX(struct BstNode *root){
	return FindMax(root)->data;
}

int MIN(struct BstNode *root){
	return FindMin(root)->data;
}

struct BstNode *Insert(struct BstNode *root,int data){
   	if(root==NULL){
   		root=getnewNode(data);
	   }
	else if(data <= root->data){
		root->left=Insert(root->left,data);
	}
	else{
		root->right=Insert(root->right,data);
	}
	return root;	
}

struct BstNode *Delete(struct BstNode *node, int data)
{
    struct BstNode *temp;
    if(node==NULL){
        printf("Element Not Found");
    }
    else if(data < node->data){
        node->left = Delete(node->left, data);
    }
    else if(data > node->data){
        node->right = Delete(node->right, data);
    }
    else{
        if(node->right && node->left){
            temp = FindMin(node->right);
            node -> data = temp->data; 
            node -> right = Delete(node->right,temp->data);
        }
        else{
            temp = node;
            if(node->left == NULL)
                node = node->right;
            else if(node->right == NULL)
                node = node->left;
            free(temp); 
        }
    }
    return node;
}


int Search(struct BstNode *root,int data){
	if(root==NULL) return 0;
	else if(root->data==data) return 1;
	else if(data <= root->data) Search(root->left,data);
	else Search(root->right,data);
}

void Display(struct BstNode  *node){
    if(node==NULL){
        return;
    }
    Display(node->left);
    printf("%d->",node->data);
    Display(node->right);
}
int num(struct BstNode *Node)
{
    if(!Node){
        return 0;
    }
    else{
        return(1+num(Node->left)+num(Node->right));
    }
}

int Rank(int data,struct BstNode *root){
	int r=0;
	struct BstNode *temp=root;
	while(temp){
		if(data>temp->data){
			temp=temp->right;
		}
		else if(data<temp->data){
			r=r+1+num(temp->right);
			temp=temp->left;
		}
		else{
			return r+num(temp->right)+1;
		}
	}
}

int Numberofelements(struct BstNode *root,int a,int b){
	return Rank(a,root)-Rank(b,root);
}

int s=0;
void prefixSUM(struct BstNode  *node,int b){
    if(node==NULL){
        return;
    }
    prefixSUM(node->left,b);
    if(node->data<b){
    	s=s+node->data;   	
	}
    prefixSUM(node->right,b);
}

int SUM(struct BstNode *root,int a,int b){
	s=0;
	prefixSUM(root,b);
	int k=s;
	s=0;
	prefixSUM(root,a);
	int j=s;
	return k-j;
}

int Average(struct BstNode *root,int a,int b){
	return SUM(root,a,b)/(Rank(a,root)-Rank(b,root));
}

int MAXGAP(struct BstNode *root){
	return MAX(root)-MIN(root);
}

int min(int a,int b){
	if(a<b){
		return a;
	}
	else{
		return b;
	}
}

int MINGAP(struct BstNode *root){
	struct BstNode *temp=root;
	if(root==NULL){
        return 0;
    }
	int y=min((root->data-MAX(root->left)),(MIN(root->right)-root->data));
	int t1=1000000,t2=1000000;
	int g;
	while(root!=NULL){
		if(root->left!=NULL && root->right!=NULL){
			g=min((root->data-MAX(root->left)),(MIN(root->right)-root->data));
			if(g<t1){
				t1=g;
			}
		}
		root=root->left;
	}
	while(temp!=NULL){
		if(temp->left!=NULL && temp->right!=NULL){
			g=min((temp->data-MAX(temp->left)),(MIN(temp->right)-temp->data));
			if(g<t2){
				t2=g;
			}
		}
		temp=temp->right;
	}
	int k=min(t1,t2);
	return min(k,y);
}

int Median(struct BstNode *root,int a,int b){
	int i;
	i=(Rank(a,root)-Rank(b,root))/2;
	return i;
}

struct BstNode *FindRank(struct BstNode *root,int k){
	struct BstNode *T=root;
	printf("%d\n",num(T->left));
	while(k!=0){
		if(T->right!=NULL){
			if(k=num(T->right)){
				return T;	
			}
			else{
				if(k>num(T->right)){
					k=k-num(T->right);
					T=T->left;
				}
				else{
					T=T->right;
				}
			}
		}
	}
}
int main(){
	struct BstNode *root;
	root=NULL;
	root=Insert(root,50);
	root=Insert(root,25);
	root=Insert(root,75);
    root=Insert(root,10);	
	root=Insert(root,35);
	root=Insert(root,5);
	root=Insert(root,85);
	root=Insert(root,65);
	root=Insert(root,90);
	root=Insert(root,45);
	root=Delete(root,65);
	root=Insert(root,65);
	int Num;
	Num=35;
	Display(root);
	printf("NULL\n");
	printf("Rank of 25 is %d\n",Rank(25,root));
	struct BstNode *temp=FindRank(root,8);
	printf("Given rank is 8 and Number is %d\n",temp->left->data);
	printf("NUMBER of elements between 50 and 85 is %d\n",Numberofelements(root,50,85)-1);
	if(Search(root,Num)==1){
		printf("\nFound the value\n");
	}
	else{
		printf("\nNot Found\n");
	}
	printf("%d\n",root->left->data);
	printf("Median of 5,35 is %d\n",Median(root,5,35));
	prefixSUM(root,35);
	printf("prefixSum of the no 35 is %d\n",s);
	printf("SUM of nos from 5 to 35 is %d\n",SUM(root,5,35));
	printf("Average of nos from 5 to 35 is %d\n",Average(root,5,35));
	printf("MINGAP is %d\n",MINGAP(root));
	printf("MAXGAP is %d\n",MAXGAP(root));	
}
