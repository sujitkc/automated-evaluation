#include<stdio.h>
#include<stdlib.h>

int T[1000];
int Prefixsum(int i){
	int s=0,j;
	while(i>0){
		s=s+T[i];
		j=i&(-i);
		i=i-j;
	}
	return s;
}

void Update(int i,int x,int n){
	int j;
	while(i<n+1){
		T[i]=T[i]+x;
		j=i&(-i);
		i=i+j;
	}
}

int RSQ(int arr[1000],int i,int j){
	int a=Prefixsum(j)-Prefixsum(i-1);
	return a;
}

void constructTree(int arr[1000], int n)
{
	int i;
    for (i=1; i<=n; i++){
        T[i] = 0;
    }
    for (i=0; i<n; i++){
        Update(i+1,arr[i],n);
    }
    printf("The cummilative sum array is\n");
    for(i=1;i<=n;i++){
    	printf("%d\t",T[i]);
	}
	printf("\n");
    
}

int main(){
	int arr[]={ 3,2,-1,6,5,4,-3,3,7,2,3};
	int n = sizeof(arr)/sizeof(arr[0]);
	printf("Original array is \n");
	int i;
	for(i=0;i<n;i++){
		printf("%d\t",arr[i]);
	}
	printf("\n");
	constructTree(arr,n);
	int a=Prefixsum(3);
	printf("prefix sum of 3 is %d\n",a);
	printf("Range Sum query of index 2,5 is %d\n",RSQ(arr,2,5));
}
