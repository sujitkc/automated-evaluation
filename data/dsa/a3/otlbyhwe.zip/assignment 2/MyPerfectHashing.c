#include<stdio.h>
#include<stdlib.h>
#include<time.h>

struct hash{
	int value;
	int a;
	int b;
	int mj;
};
struct hash arr[100][100];
int p=101;
int a,b,m;
int outerhash(int k,int size){
   	srand(time(NULL));
   	a=rand()%100;
   	b=rand()%100;
   	m=size;
   	return (((a*k)+b)%p)%m;
}

int innerhash(int k){
	int aj,bj;
   	srand(time(NULL));
   	aj=rand()%100;
   	bj=rand()%100;
   	int i=(((a*k)+b)%p)%m;
   	int mj=sizeof(arr[i])/sizeof(arr[0][0]);
   	int j=(((aj*k)+bj)%p)%mj;
   	arr[i][j].a=a;
   	arr[i][j].b=b;
   	arr[i][j].mj=mj;
   	return (((aj*k)+bj)%p)%mj;
}



void insert(int data,int size){
	int m=size;
	int i,j;
	i=outerhash(data,size);
    j=innerhash(data);
    arr[i][j].value=data;
    printf("i=%d\tj=%d\n",i,j);
    printf("Inserted %d\n",arr[i][j].value);
}

void search(int data){
	int i,j;
	i=outerhash(data,m);
    j=innerhash(data);
	if(arr[i][j].value==-1000){
		printf("Value not found\n\n");
	}
	if(arr[i][j].value==data){
		printf("Found value=%d at i=%d and j=%d\n\n",data,i,j);
	}
}

void Display(){
	int i,j;
	for(i=0;i<m;i++){
		printf("%d->",i);
		for(j=0;j<100;j++){
			if(arr[i][j].value==-1000){
				printf("");
			}
			else{
				printf("%d ",arr[i][j].value);	
			}
		}
		printf("\n");
	}
}
int main(){
	int i,j;
	for (i=0;i<9;i++){
		for(j=0;j<100;j++){
			arr[i][j].value=-1000;
		}	
	}
	insert(10,9);
	insert(22,9);
	insert(37,9);
	insert(40,9);
	insert(60,9);
	insert(70,9);
	insert(75,9);
	search(22);
	Display();
}
