#include<stdio.h>
#include<stdlib.h>

int min(int a,int b){
	if(a<b){
		return a;
	}
	else{
		return b;
	}
}
void constructTree(int arr[1000],int segment[1000],int low,int high,int i){
	if(low==high){
		segment[i]=arr[low];
		return;
	}
	int mid=(low+high)/2;
	constructTree(arr,segment,low,mid,(2*i)+1);
	constructTree(arr,segment,mid+1,high,(2*i)+2);
	segment[i]=min(segment[(2*i)+1],segment[(2*i)+2]);
}
int RMQ(int segment[1000],int qlow,int qhigh,int low,int high,int i){
	if(low>=qlow && high<=qhigh){
		return segment[i];
	}
	if(qlow>high || qhigh<low){
		return 10000;
	}
	int mid=(low+high)/2;
	return min(RMQ(segment,qlow,qhigh,low,mid,(2*i)+1),RMQ(segment,qlow,qhigh,mid+1,high,(2*i)+2));
	
}
void update(int arr[1000],int segment[1000],int value,int i,int n){
	if(i<0 || i>n){
		return;
	}
	arr[i]=value;
}
int main(){
	int i=0,j;
	int segment[1000];
	int arr[]= { -1,2,4,0};
	int len=sizeof(arr)/sizeof(int);
	printf("%d\n",len);
	for(j=0;j<(2*len)-1;j++){
		segment[j]=10000;
	}
	printf("GivenArray is\n");
	for(j=0;j<len;j++){
		printf("%d\t",arr[j]);
	}
	printf("\n");
	constructTree(arr,segment,0,len-1,i);
	for(j=0;j<(2*len)-1;j++){
		printf("%d\t",segment[j]);
	}
	int a,b;
	printf("\nEnter the range:\n");
	scanf("%d%d",&a,&b);
	int RangeMinimum=RMQ(segment,a,b,0,len-1,0);
	printf("RangeMinimum in  is %d\n",RangeMinimum);
	update(arr,segment,9,0,len-1);
	printf("After Updating -1 to 9\n");
	for(j=0;j<len;j++){
		printf("%d\t",arr[j]);
	}
	printf("\n");
	constructTree(arr,segment,0,len-1,i);
	for(j=0;j<(2*len)-1;j++){
		printf("%d\t",segment[j]);
	}
}
