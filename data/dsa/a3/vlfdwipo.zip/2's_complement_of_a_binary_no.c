#include<stdio.h>

int main(){
int size;
scanf("%d",&size);
char binary[size+1],onecom[size+1],twocom[size+1];
gets(binary);
int i,carry=1;
// to find one's complement
for(i=0;i<size,i++){ 
	if(binary[i]=='1'){
		onecom[i]=='0';
		}
	else if(binary[i]=='0'){
		onecom[i]=='1';
		}
	}
onecom[size]='\0';

//to find 2's complement = 1's complement + 1

for(i=size-1;i<=0;i--){
	if(onecom[i]=='1' && carry=='1'){
		twocom[i]='0';
		}
	else if(onecom[i]=='0' && carry=='1'){
		twocom[i]='1';
		carry = '0';
		}
	else{
		twocom[i]=onecom[i];
		}
	}
twocom[size]='\0';
printf("Original binary = %s\n", binary);
printf("Ones complement = %s\n", onesComp);
printf("Twos complement = %s\n", twosComp); 
return 0;
}
