#include<stdio.h>
#include<stdlib.h>

struct arr* b[100];

struct arr{  // let the fn be of type ax+b where a=0,b=0 and p=13
	int data;
	struct arr* next;
};

int hashfn1(int x){
	return x%13;
}

int hashfn2(int x,int ni){
	return ((x)%13)%ni;
}

int main(){
	

}
