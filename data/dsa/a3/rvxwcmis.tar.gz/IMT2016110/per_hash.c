#include <stdio.h>
#include<stdlib.h>
#include<stdbool.h>

struct hash_table{
  long long int a,b,p,n;
  long long int *arr[1000];
};

void insert(struct hash_table *table[],long long int k,long long int m);
void table_insert(struct hash_table *table,long long int n);
void build_new(struct hash_table *table[],long long int k,long long int m);
long long int prime_generator();
long long int a,b,p,ni;

int main(){
  a=rand();b=rand();
  p=rand();ni=0;
  long long int m=200000,i,j,k=0,r=((a*k+b)%p)%m;
  struct hash_table *table1[m];
  for(i=0;i<m;i++){
    table1[i]=malloc(sizeof(struct hash_table));
    table1[i]->n=0;
    table1[i]->a=rand();
    table1[i]->b=rand();
    table1[i]->p=rand();
    for(j=0;j<1000;j++){
      (table1[i]->arr)[j]=NULL;
    }
  }
  for(j=1;j<100000;j++){
    insert(table1,j,m);
    i=48;
    r=((a*i+b)%p)%m;
    if(((table1[r]->arr)[(((table1[r]->a)*i+(table1[r]->b))%(table1[r]->p))%(1+((table1[r]->n)*(table1[r]->n)))])==NULL && j>48){
      printf("%lld\n",j);
      break;
    }
  }

for(i=1;i<100000;i++){
  r=((a*i+b)%p)%m;
  if(((table1[r]->arr)[(((table1[r]->a)*i+(table1[r]->b))%(table1[r]->p))%(1+((table1[r]->n)*(table1[r]->n)))])==NULL){
    //printf("%lld\n",i);
  }
}
  //build_new(table1,122,m);
}

void insert(struct hash_table *table[],long long int k,long long int m){
  long long int h1,h=((a*k+b)%p)%m,i,j;
  ni-=(table[h]->n*table[h]->n);
  (table[h]->n)++;
  ni+=(table[h]->n*table[h]->n);
  if(ni<=2*m){
    if(k==25713) puts("1");
    table_insert(table[h],k);
  }
  else{
    build_new(table,k,m);
  }
}
void build_new(struct hash_table *table[],long long int k,long long int m){
  puts("hii");
  bool done;long long int i,j;
  a=rand();b=rand();p=rand();ni=0;done=true;
  struct hash_table *table1[m];
  while(1){
    for(i=0;i<m;i++){
      table1[i]=malloc(sizeof(struct hash_table));
      table1[i]->n=0;
      table1[i]->a=rand();
      table1[i]->b=rand();
      table1[i]->p=rand();
      for(j=0;j<1000;j++){
        (table1[i]->arr)[j]=NULL;
      }
    }
    for(i=0;i<m;i++){
      for(j=0;j<1000;j++){
        if((table[i]->arr)[j]!=NULL){
          long long int h1,h=((a*(*(table[i]->arr)[j])+b)%p)%m,i,j;
          ni-=(table[h]->n*table[h]->n);
          table[h]->n++;
          ni+=(table[h]->n*table[h]->n);
          if(ni<=2*m){
            table[h]->n--;
            table_insert(table1[h],k);
          }
          else{
            done=false;break;break;
          }
        }
      }
    }
    if(done) break;
  }
  for(i=0;i<m;i++){
    table[i]=table1[i];
  }

}
void table_insert(struct hash_table *table,long long int k){
  long long int h1,h=(((table->a)*k+(table->b))%(table->p))%(1+((table->n)*(table->n))),i;
  if(table->arr[h] != NULL){
    while(1){
      long long int *arr1[1000];bool done=true;
      for(i=0;i<1000;i++) arr1[i]=NULL;
      table->a=rand();
      table->b=rand();
      table->p=rand();
      table->n=1;
      h=(((table->a)*k+(table->b))%(table->p))%(1+((table->n)*(table->n)));
      arr1[h]=malloc(sizeof(long long int));
      *arr1[h]=k;

      for(i=0;i<1000;i++){
        if((table->arr)[i]!=NULL){
          h1=((table->a*(*(table->arr)[i])+table->b)%table->p)%(1+((table->n)*(table->n)));
          if(arr1[h1]!=NULL){
            arr1[h1]=malloc(sizeof(int));
            *arr1[h1]=*((table->arr)[i]);
            table->n++;
          }
          else done=false;
        }
      }

      if(done){
        for(i=0;i<1000;i++){
          free(table->arr[i]);
          table->arr[i]=NULL;
          if(arr1[i]!=NULL){
            table->arr[i]=malloc(sizeof(int));
            *((table->arr)[i])=*arr1[i];
            }
          }
          break;
        }
      }

  }
  else{
    ((table->arr)[h])=malloc(sizeof(long long int));
    *((table->arr)[h])=k;
    k=48;
    h=(((table->a)*k+(table->b))%(table->p))%(1+((table->n)*(table->n)));
    if(table->arr[h] != NULL)  printf("rrrr%lld\n",h);
  }
}
