#include<stdio.h>

void build_tree(int arr[],int len);
void update(int arr[],int i);
int rmq(int arr[],int i,int j,int start,int end,int index);
int min(int a,int b);

int main(){
int len=7,k=1;
while(k<len){
  k=k*2;
}
k=k*2;
int arr[k];
for(int i=len;i<=2*len-1;i++) scanf("%d",&arr[i]);
build_tree(arr,len);
puts("");
for(int i=0;i<=2*len-2;i++) printf("%d\n",arr[i]);
printf("min %d\n",rmq(arr,4,5,0,7,0));
}
void build_tree(int arr[],int len){
  int i,k=(len-1)/2,j=2*len-2;
  if(len%2==0){
    i=len-1;
    j=2*len-2;
  }
  else{
    i=len;
    j=2*len-1;
  }
  while(i>0){
    k=i;
    while(i<=j){
      if(i!=j){
        if(arr[i]<arr[i+1]) arr[(i-1)/2]=arr[i];
        else arr[(i-1)/2]=arr[i+1];
      }
      else arr[(i-1)/2]=arr[i];
      i+=2;
    }
    i=(k-1)/2;
    j=(j-1)/2;
  }
}
int rmq(int arr[],int i,int j,int start,int end,int index){
  if(i==start || j==end) return arr[index];
  else if(i>start || j<end){
    if(i>(start+end)/2) return rmq(arr,i,j,((start+end)/2)+1,end,2*index+2);
    else if(j<=(start+end)/2) return rmq(arr,i,j,start,((start+end)/2),2*index+1);
    else return min(rmq(arr,i,j,((start+end)/2)+1,end,2*index+2),rmq(arr,i,j,start,((start+end)/2),2*index+1));
  }
  else return arr[index];
/*  else if(j>end && i>start){
    if(i>(start+end)/2) return rmq(arr,i,j,((start+end)/2)+1,end,2*index+2);
    else return min(rmq(arr,i,j,((start+end)/2)+1,end,2*index+2),rmq(arr,i,j,start,((start+end)/2),2*index+1));
  }
  else if(i<start && j<end){
    if(j<=(start+end)/2) return rmq(arr,i,j,start,((start+end)/2),2*index+1);
    else return min(rmq(arr,i,j,((start+end)/2)+1,end,2*index+2),rmq(arr,i,j,start,((start+end)/2),2*index+1));
  }
  else return arr[index];*/

}
void update(int arr[],int k,int n){
  int i,j;
  if(len%2==0){
    i=len-1;
    j=2*len-2;
  }
  else{
    i=len;
    j=2*len-1;
  }

    for(;i<j;i++) if(arr[i]==k) break;
    if(i%2==0) i--;

    while(i>0){
      if(arr[i]<arr[i+1]) arr[(i-1)/2]=arr[i];
      else arr[(i-1)/2]=arr[i+1];
      i=(i-1)/2;
    }
}
int min(int a,int b){
  if(a>b)return a;
  else return b;
}
