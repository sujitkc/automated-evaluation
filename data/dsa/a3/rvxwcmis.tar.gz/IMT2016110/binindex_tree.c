#include<stdio.h>

int prefix_sum(int arr[],int i);
int rsq(int arr[],int i,int j);
void update(int a[],int i,int x,int len);
void build(int arr[],int len);
int main(){
  int arr[]={1,2,3,4,5},i;
  build(arr,5);
  for(i=0;i<5;i++) printf("%d\n",arr[i]);
}
int prefix_sum(int arr[],int i){
  int s=0,j;i++;
  while(i>0){
    s+=arr[i-1];
    j=i&(-i);
    i-=j;
  }
}
int rsq(int arr[],int i,int j){
  return prefix_sum(arr,j)-prefix_sum(arr,i);
}
void update(int a[],int i,int x,int len){
  int j;i++;
  while(i<=len){
    a[i-1]+=x;
    j=i&(-1*i);
    i+=j;
  }
}
void build(int arr[],int len){
  int arr1[len],i;
  for(i=0;i<len;i++) arr1[i]=0;
  for(i=0;i<len;i++) update(arr1,i,arr[i],len);
  for(i=0;i<len;i++) arr[i]=arr1[i];
}
