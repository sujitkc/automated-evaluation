#include<stdio.h>
#include<stdlib.h>
void rabinkarp(char t[],char p[],int n,int m,int d);
int main(){
  int d=2;
  char *t=malloc(100*sizeof(char)),*p=malloc(100*sizeof(char));
  t="1010";
  p="1101001011101";
  rabinkarp(t,p,13,4,d);
}
void rabinkarp(char t[],char p[],int n,int m,int d){
  int x=0,y=0,h=1,i,j,pr=11;

  for(j=0;j<m;j++){
    x=((d*x)+p[j])%pr;
    y=((d*y)+t[j])%pr;
    h=(d*h)%pr;

    for(i=0;i<n-m;i++){
      if(x==y){
        for(j=0;j<m;j++){
          if(p[j]!=t[i+j]) break;
          else if(j==m) printf("match at %d\n",i);
        }
      }
      y=(d*(y-h*t[i])+t[i+m])%pr;
      if(y<0) y=y+pr;
    }
  }
}
