#include <stdio.h>
#include <math.h>
#include <limits.h>

int min(int a, int b){	
	if(a < b)
		return a;
	else
		return b;
}

void print(int a[], int size){
	for(int i=0;i<size;i++)
		printf("%d ", a[i]);
	printf("\n");
}

int rmq(int t[], int ql, int qr, const int size){	//Computes min([ql, qr))
	int l = ql + size;
	int r = qr + size;
	int minimum = INT_MAX;
	while(l<r){
		if(l%2 == 1){
			minimum = min(minimum, t[l]);
			l = l+1;
		}
		if(r%2 == 1){
			r = r-1;
			minimum = min(minimum, t[r]);
		}
		l = l/2;
		r = r/2;
	}
	return minimum;
}

void update(int t[], int size, int index, int val){
	index = index + size;
	t[index] = val;
	while(index > 1){
		index = index/2;
		t[index] = min(t[2*index], t[2*index+1]);
	}
}

void build(int input[], const int size, int t[]){
	int size_tree = 2*size;
	for(int i=size;i<size_tree;i++)
		t[i] = input[i-size];
	for(int i=size-1;i>=0;i--)						//neglect t[0]
		t[i] = min(t[2*i], t[2*i+1]);				//left-child = 2*i, right child = 2*i+1
}

int main(){
	int input[] = {6, 4, 12, 3, 1, 5, 21, 93};
	int size = sizeof(input)/sizeof(int);
	const int size_tree = 2*size;
	int t[size_tree]; 
	build(input, size, t);
	print(t, size_tree);
	update(t, size, 4, 99);
	print(t, size_tree);
	printf("rmq = %d\n", rmq(t, 5, size, size));
	return 0;
}
/*
int build(int a[], int input[], int l, int r, int pos){
	
	if(l == r){
		a[pos] = input[l];
		return a[pos];
	}
	
	int mid = (l + r)/2;
	a[pos] = min(build(a, input, l, mid, 2*pos + 1), build(a, input, mid + 1, r, 2*pos + 2));
	return a[pos];
}

void update(int a[], int l, int r, int treeIndex, int i, int val){	
	if(l == r){
		a[treeIndex] += val;
		return;
	}
	int mid = (l+r)/2;
	if(i<=mid)
		update(a, l, mid, 2*treeIndex+1, i, val);
	if(i>mid)
		update(a, mid+1, r, 2*treeIndex+2, i, val);
	a[treeIndex] = min(a[2*treeIndex+1], a[2*treeIndex+2]);
}

int rmq(int a[], int ql, int qr, int l, int r, int pos){
	
	if(ql <= l && qr >= r)
		return a[pos];
	
	if(ql > r || l > qr)
		return INT_MAX;

	int mid = (l + r)/2;
	int val = min(rmq(a, ql, qr, l, mid, 2*pos + 1), rmq(a, ql, qr, mid+1, r, 2*pos + 2));
	return val;
}

int main(){
	
	int input[] = {6, 4, 12, 3, 1, 5, 21, 93};
	int n = sizeof(input)/sizeof(int);
	int k = ceil(log2(n));
	
	const int size = 2 * pow(2, k) - 1;
	int a[size];
	build(a, input, 0, n-1, 0);
	print(a, size);
	
	printf("RMQ(3, 7) = %d\n", rmq(a, 3, 7, 0, n-1, 0));
	printf("Enter the index to be updated and by how much: \n");
	int pos, val;
	scanf("%d%d", &pos, &val);
	update(a, 0, n-1, 0, pos, val);
	print(a, size);
	return 0;
}
*/