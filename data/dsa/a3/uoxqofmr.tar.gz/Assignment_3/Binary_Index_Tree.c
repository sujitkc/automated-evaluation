#include <stdio.h>

int prefix_sum(int t[], int i){
	int s = 0, j;
	while(i > 0){
		s = t[i] + s;
		j = i & (-i);
		i = i - j;
	}
	return s;
}

void update(int t[], int n, int i, int x){
	int j;
	while(i < n){
		t[i] = t[i] + x;
		j = i & (-i);
		i = i + j;		
	}
}

int rsq(int i, int j, int t[]){
	return (prefix_sum(t, j) - prefix_sum(t, i - 1));
}

int main(){
	int a[] = {-1, 2, 1, 4, 5, 2, 1, 3, 8};
	const int size = sizeof(a)/sizeof(int);
	int t[size];
	for(int i = 1;i < size; i++)
		update(t, size, i, a[i]);
	printf("RSQ = %d\n", rsq(1, size-1, t));
	return 0;
}