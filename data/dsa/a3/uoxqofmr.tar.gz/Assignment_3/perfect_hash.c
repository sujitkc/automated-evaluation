#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int prime_num(int a){
	for(int i=a+1; ; i++){
		int prime = 1;	
		for(int j=2; j<=sqrt(i); j++){
			if(i%j == 0)
				prime = 0;
		}
		if(prime)
			return i;
	}
}

int hashfun(int k, int rprime, int size){
	return ((k*2)%rprime)%size;
}

struct secondaryhashtable{
	int n;
	int size;
	int prime;
	int *hashtable;
};

struct secondaryhashtable hashtable2(int a[], int n){
	struct secondaryhashtable obj;
	if(n != 0){
		obj.n = n;
		obj.size = n*n;
		obj.hashtable = malloc(sizeof(int[obj.size]));
		obj.prime = prime_num(obj.size);
		int i;
		do{
			for(int j=0;j<obj.size;j++)
				obj.hashtable[j] = 0;
			for(i=0;i<obj.n;i++){
				int index = hashfun(a[i], obj.prime, obj.size);
				if(obj.hashtable[index] != 0){
					obj.prime = prime_num(obj.prime);
					break;
				}
				else
					obj.hashtable[index] = a[i];
			}
		}while(i != n);
	}
	return obj;
}

int secondary_search(struct secondaryhashtable *ptr, int key){
	if(ptr->hashtable[hashfun(key, ptr->prime, ptr->size)] == key)
		return 1;
	return 0;
}

int gen_primary_hash(int a[], const int n){

	const int size = 2*n;
	int collisiontable[size];
	int sum = 0, rprime;
	rprime = prime_num(size);

	do{
		for(int i=0;i<size;i++)
			collisiontable[i] = 0;
		for(int i=0;i<n;i++)
			collisiontable[hashfun(a[i], rprime, size)]++;
		for(int i=0;i<size;i++)
			sum+=collisiontable[i]*collisiontable[i];
		rprime = prime_num(rprime);
	}while(sum > 2*n);
	
	int *hashedElements[size];
	for(int i=0;i<size;i++){
		hashedElements[i] = malloc(sizeof(collisiontable[i]));
	}

	int indexList[size];
	for(int i=0;i<size;i++)
		indexList[i] = 0;
	for(int i=0;i<n;i++){
		int index = hashfun(a[i], rprime, size);
		hashedElements[index][indexList[i]++] = a[i];
	}

	struct secondaryhashtable *arr[size];
	struct secondaryhashtable obj[size];
	for(int i=0;i<size;i++){
		obj[i] = hashtable2(hashedElements[i], collisiontable[i]);
		arr[i] = &obj[i];
	}
	printf("Enter the search key : ");
	int key;
	scanf("%d", &key);
	if(secondary_search(arr[hashfun(key, rprime, size)], key))
		printf("Element Found\n");
	else
		printf("Not Found\n");

}

int main(){
	int a[] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
	const int n = sizeof(a)/sizeof(int);
	gen_primary_hash(a, n);
	return 0;
}