#include<stdio.h>
#include<stdlib.h>
struct node{
	int data;
	node *left;
	node *right;
	int height;
	int m;
}*root=0;
int childnodes(struct node* t){
	if(t==0){
		return 0;
	}
	return childnodes(t->left)+childnodes(t->right)+1;
}
int max(int a,int b){
	return (a>b)?a:b;
}
int height(struct node* t){
	if(t==0){
		return 0;
	}
	return max(height(t->right),height(t->left))+1;
}
struct node* newnode(int value){
	struct node* newnode;
	newnode=(struct node*)malloc(sizeof(struct node));
	newnode->data=value;
	newnode->left=0;
	newnode->right=0;
	newnode->height=1;
	newnode->m=1;
	return newnode;
}
int getbalance(struct node* t){
	if(t==0){
		return 0;
	}
	return height(t->left)-height(t->right);
}
struct node* leftcase(struct node* t){
	struct node *t1,*t2;
	t1=t->left;
	t2=t1->right;
	t1->right=t;
	t->left=t2;
	t1->height=height(t1);
	t->height=height(t);
	t1->m=childnodes(t1);
	t->m=childnodes(t);
	return t1;
}
struct node* rightcase(struct node* t){
	struct node *t1,*t2;
	t1=t->right;
	t2=t1->left;
	t1->left=t;
	t->right=t2;
	t1->height=height(t1);
	t->height=height(t);
	t1->m=childnodes(t1);
	t->m=childnodes(t);
	return t1;
}
struct node* balancefun(struct node* start){
	
}
struct node* insert(struct node* start,int value){
	if(start==0){
		return newnode(value);
	}
	else if(value>start->data){
		start->m++;
		start->right=insert(start->right,value);
	}
	else if(value<start->data){
		start->m++;
		start->left=insert(start->left,value);
	}
	else{
		return start;
	}
	start->height=height(start);
	int balance=getbalance(start);
	if(balance>1 && value<start->left->data){// left left case
		return leftcase(start);
	}
	if(balance<-1 && value>start->right->data){
		return rightcase(start);
	}
	if(balance>1 && value>start->left->data){
		start->left=rightcase(start->left);
		return leftcase(start);
	}
	if(balance<-1 && value<start->right->data){
		start->right=leftcase(start->right);
		return rightcase(start);
	}
	return start;
}
int rank(int x,struct node *root){
	int r=1;
while(root){
	if(root->data==x){
		return (root->right!=0)? r+root->right->m:r;
	}
	else if(root->data>x){
		r+=(root->left!=0)? root->m-root->left->m:root->m;
		root=root->left;
	}
	else{
		root=root->right;
	}
}
	return -1;
}
int findrank(int k,struct node *root){
	while(k>0 && root!=0){
		if(root->right!=0){
			if(k==1+root->right->m){
					return root->data;
			}
			else if(k>1+root->right->m){
				k-=1+root->right->m;
				root=root->left;
			}
			else{
				root=root->right;
			}
		}
		else{
			if(k==1){
				return root->data;
			}
			else if(k>1){
				k--;
				root=root->left;
			}
			else{
				root=root->right;
			}
		}
	}
	printf("\nNot Found:");
	return 0;
}
struct node* delete1(struct node* root,int x){
	if(root==0){
		return root;
	}
	else if(root->data>x){
		root->left=delete1(root->left,x);
	}
	else if(root->data<x){
		root->right=delete1(root->right,x);
	}
	else{
		if(root->left==0){
			return root->right;
		}
		else if(root->right==0){
			return root->left;
		}
		else{
			struct node* temp=root->right;
			while(temp->left!=0){
				temp=temp->left;
			}
			root->data=temp->data;
			root->right=delete1(root->right,temp->data);
		}
	}
	if(root==0){
		return root;
	}
	root->height=height(root);
	root->m=childnodes(root);
	int balance=getbalance(root);
	if(balance>1 && getbalance(root->left)>=0){
		return leftcase(root);
	}
	if(balance>1 && getbalance(root->left)<0){
		root->left=rightcase(root->left);
		return leftcase(root);
	}
	if(balance<-1 && getbalance(root->right)<=0){
		return rightcase(root);
	}
	if(balance<-1 && getbalance(root->right)>0){
		root->right=leftcase(root->right);
		return rightcase(root);
	}
	return root;
}
void inorder(struct node *t)
{
    if (t == NULL)
    {
        printf("No elements in a tree to display");
        return;
    }
    if (t->left != NULL){
    	inorder(t->left);
    }
    printf("%d :%d -> ", t->data,t->m);
    if (t->right != NULL){
    	       inorder(t->right);
    }
}
int main(){
	root=insert(root,25);
	root=insert(root,50);
	root=insert(root,10);
	root=insert(root,24);
	root=insert(root,35);
	root=insert(root,80);
	root=insert(root,70);
	inorder(root);
	printf("\n%d",height(root));
	printf("\n%d",getbalance(root));
	int k=rank(10,root);
	printf("\n\t%d",k);
	k=findrank(7,root);
	printf("\n\t%d",k);
	root=delete1(root,50);
	printf("\n");
	inorder(root);
	k=rank(10,root);
	printf("\n\t%d",k);
	k=findrank(7,root);
	printf("\n\t%d",k);
}
