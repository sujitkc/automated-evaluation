#include<stdio.h>
void RSQ(int b[],int l,int r,int a[]){
	int x=l,sum1=0,sum2=0;
	l++;
	r++;
	while(l>0){
		sum1+=b[l];
		l-=l&(-l);
	}
	while(r>0){
		sum2+=b[r];
		r-=r&(-r);
	}
	printf("sum1:%d\n",sum1);
	printf("sum2:%d\n",sum2);
	printf("sum:%d",sum2-sum1+a[x]);
	
}

void update(int n,int i,int value,int b[]){
	i++;
	while(i<=n){
		b[i]+=value;
		i+=i&(-i);
	}
}
void constructbit(int a[],int n,int b[]){
	int i;
	for(i=0; i<n+1; i++){
		b[i]=0;
	}
	for(i=0; i<n; i++){
		update(n,i,a[i],b);
	}
}
int main(){
	int n;
	scanf("%d",&n);
	int a[n],i;
	int b[n+1];
	for(i=0; i<n; i++){
		scanf("%d",&a[i]);
	}
	constructbit(a,n,b);
	RSQ(b,2,4,a);
	
}
