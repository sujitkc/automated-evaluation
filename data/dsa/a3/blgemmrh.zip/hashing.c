
#include<stdio.h>
struct student{
	int roll;
	char name[20];
	float grade;
	struct student *nxt;
}a[10];
int hach(int x){
	return (x%10);
}
void main(){
	int l,t,s;
	struct student *temp,*np;
	for(l=0;l<10;l++){
		a[l].nxt=NULL;
	}
	l=0;
	while(l!=3){
		printf("\n1-Enter student's info\n2-Look at student's info\n3-Exit\n");
		scanf("%d",&l);
		if(l==1){
			printf("\nEnter student's roll no.: ");
			scanf("%d",&t);
			temp=&a[hach(t)];
			if(temp->roll==0){
				printf("\nEnter name of student: ");
				scanf("%s",a[hach(t)].name);
				printf("\nEnter student's grade point: ");
				scanf("%f",&a[hach(t)].grade);
				a[hach(t)].roll=t;
			}
			else{
				while(temp->nxt!=NULL){                 
					temp=temp->nxt;
				}
				np=(struct student*)malloc(sizeof(struct student));
				temp->nxt=np;
				temp=temp->nxt;
				printf("\nEnter name of student: ");
				scanf("%s",temp->name);
				printf("\nEnter student's grade point: ");
				scanf("%f",&temp->grade);
				temp->nxt=NULL;
				temp->roll=t;
			}
			system("cls");
		}
		if(l==2){
			printf("\nEnter student's roll no.: ");
			scanf("%d",&t);
			s=0;
			if(a[hach(t)].roll==t){
				printf("\nName: %s",a[hach(t)].name);
				printf("\nRoll number: %d",a[hach(t)].roll);
				printf("\nGrade point: %f",a[hach(t)].grade);
			}
			else{
				temp=&a[hach(t)];
				while(temp!=NULL){
					if(temp->roll==t){
						s=1;
						break;
					}
					temp=temp->nxt;
				}
				if(s==1){
					printf("\nName: %s",temp->name);
					printf("\nRoll number: %d",temp->roll);
					printf("\nGrade point: %f",temp->grade);
				}
				else{
					printf("None");
				}
				
			}
		}
	}
}
