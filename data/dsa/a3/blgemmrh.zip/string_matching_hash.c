#include<stdio.h>
void main(){
	int n,m,h,q=0,j,i,s,t,l;
	printf("Enter length of string\n");
	scanf("%d",&n);
	char str[n];
	printf("\nEnter string\n");
	scanf("%s",str);
	printf("\nEnter length of pattern\n");
	scanf("%d",&m);
	char pt[m];
	printf("\nEnter pattern\n");
	scanf("%s",pt);
	for(i=0; i<m; i++){
		h=h*10+(pt[i]-'0');
	}
	h=h%13;
	for(i=0;i<=n-m;i++){
		for(j=i;j<i+m;j++){
			t=t*10+(str[j]-'0');
		}
		t=t%13;
		if(t==h){
			l=1;
			for(j=i;j<i+m;j++){
				if(str[j]!=pt[j-i]){
					l=0;
					break;
				}
			}
			if(l==1){
				q++;
			}
		}
	}
	printf("\n%d", q);
}
