#include<stdio.h>
int st;
int sum(int *b,int r,int s,int q,int x,int y){
	int l=0;
	if(x==r && y==s){
		st=st+b[q];
		return;
	}
	if(y>(s+r)/2 && x<=(s+r)/2){
		sum(b,r,(s+r)/2,2*q+1,x,s/2);
		sum(b,(s+r)/2+1,s,2*q+2,s/2+1,y);
	}
	else{
		if(y<=(s+r)/2){
			sum(b,r,(s+r)/2,2*q+1,x,y);
		}
		if(x>(s+r)/2){
			sum(b,(s+r)/2+1,s,2*q+2,x,y);
		}
	}
}
void main(){		
	int n,t,i,l,x,y,p;
	printf("Enter no. of elements\n");
	scanf("%d",&n);
	for(i=1;;i++){
		if(pow(2,i)>=n){
			t=pow(2,i);
			break;
		}
	}
	int a[t],b[2*t-1];
	printf("Enter elements in list\n");
	for(i=0;i<t;i++){
		if(i<n){
			scanf("%d",&a[i]);
		}
		else
			a[i]=0;
	}
	for(i=t-1;i<2*t-1;i++){
		b[i]=a[i-t+1];
	}
	for(i=t-1;i>=0;i--){
		b[i]=b[2*i+1]+b[2*i+2];
	}
	while(l!=3){
		printf("\n1-Get sum of range\n2-Update an element\n3-Exit\n");
		scanf("%d",&l);
		if(l==1){
			st=0;
			printf("Enter the range(1-%d)",n);
			scanf("%d",&x);
			scanf("%d",&y);
			sum(b,0,t-1,0,x-1,y-1);
			printf("%d\n",st);
		}
		if(l==2){
			for(i=t-1;i<t+n;i++){
				printf("%d(%d) ",b[i],i-t+2);
			}
			printf("\nEnter index of element you want to update\n");
			scanf("%d",&i);
			printf("Enter new value of index(%d)\n",i);
			scanf("%d",&b[i+t-2]);
			for(i=(i+t-1)/2-1;i>=0;){
				b[i]=b[2*i+1]+b[2*i+2];
				i=(i+1)/2-1;
			}
			for(i=0;i<2*t-1;i++){
				printf("%d ",b[i]);
			}
		}
	}
}
