int sum(int q,int *a){
	int s=0,j;
	j=q;
	while(j>0){
		s=s+a[j];
		j-=j&(-j);
		printf("%d",j);
	}
	return s;
}
void main(){
	int n,i,j,k,x,y,l=1,t;
	printf("Enter length of array\n");
	scanf("%d",&n);
	int b[n],a[n+1];
	printf("Enter elements of array\n");
	for(i=0;i<n;i++){
		scanf("%d",&b[i]);
	}
	for(i=0;i<=n;i++){
		a[i]=0;
	}
	for(i=1;i<=n;i++){
		j=i;
		k=b[i-1];
		while(j<=n){
			a[j]=a[j]+k;
			j+=j&(-j);
		}
	}
	
	while(l!=3){
		printf("\n1-Find sum of range\n2-Update a element\n3-Exit\n");
		scanf("%d",&l);
		if(l==1){
			printf("\nEnter range (1-%d)\n",n);
			scanf("%d %d",&x,&y);
			k=sum(y,a)-sum(x-1,a);
			printf("\n%d",k);
		}
		if(l==2){
			for(i=0;i<n;i++){
				printf("%d(%d) ",b[i],i+1);
			}
			printf("\nEnter index you want to update\n");
			scanf("%d",&k);
			printf("Enter new value of index(%d)",k);
			t=b[k-1];
			scanf("%d",&b[k-1]);
			t=t-b[k-1];
			j=k;
			while(j<=n){
				a[j]=a[j]-t;
				j+=j&(-j);
			}
			
		}
	}	
	
}
