#include <stdio.h>
#include <stdlib.h>

int max(int a, int b){
	if(a > b)
		return a;
	else
		return b;
}

struct node{
	int val;
	struct node *l;
	struct node *r;
	int height;
	int num;
};

int rightNodes(struct node *root);
int leftNodes(struct node *root);

struct node *newnode(int val)
{
	struct node *ptr = malloc(sizeof(struct node));
	ptr->val = val;
	ptr->l = NULL;
	ptr->r = NULL;
	ptr->height = 1;
	return (ptr);
}

int height(struct node *n)
{
	if(n == NULL)
		return 0;
	else
		return n->height;
}

int difBalance(struct node *n)
{
	if(n == NULL)
		return 0;
	else
		return (height(n->l) - height(n->r));
}


struct node *rightRotate(struct node *z)
{
	
	struct node *y  = z->l;
	struct node *T3 = y->r;

	y->r = z;
	z->l = T3;

	z->height = max(height(z->l), height(z->r)) + 1;
	y->height = max(height(y->l), height(y->r)) + 1;

	z->num = rightNodes(z);
	y->num = rightNodes(z);

	return y;	
}

struct node *leftRotate(struct node *z){
	
	struct node *y = z->r;
	struct node *T2 = y->l;

	y->l = z;
	z->r = T2;

	z->height = max(height(z->l), height(z->r)) + 1;
	y->height = max(height(y->l), height(y->r)) + 1;

	z->num = rightNodes(z);
	y->num = rightNodes(z);
	
	return y;
}

struct node *zigzigr(struct node *z){
	return rightRotate(z);
}

struct node *zigzigl(struct node *z)
{
	return leftRotate(z);
}

struct node *zigzagrl(struct node *n)
{
	n->r = zigzigr(n->r);
	return zigzigl(n);
}

struct node *zigzaglr(struct node *n)
{
	n->l = zigzigl(n->l);
	return zigzigr(n);
}

struct node *search(struct node *n, int val)
{
	if(n == NULL)
		return NULL;
	else if(val < n->l->val)
		return search(n->l, val);
	else if(val > n->r->val)
		return search(n->r, val);
	else
		return n;
}

int leftNodes(struct node *root)
{
	struct node *t = root;
	if(t->l == NULL)
		return 0;
	else
		return rightNodes(t->l) + leftNodes(t->l) + 1;
}

int rightNodes(struct node *root)
{
	struct node *t = root;
	if(t->r == NULL)
		return 0;
	else
		return rightNodes(t->r) + leftNodes(t->r) + 1;
}

int rank(int x, struct node *root)
{
	int r = 0;
	struct node *t = root;
	while(t != NULL)
	{
		if(t->val == x)
		{
			r = r + t->num + 1;
			break;
		}
		else if(t->val > x)
		{
			r = r + t->num + 1;
			t = t->l;
		}
		
		else
			t = t->r;
	}
	return r;
}

int findRank(struct node *root, int x)
{
	int add = 0, flag = 0;
	struct node *tmp = root;
	while(tmp)
	{
		if(x == tmp->num + add + 1)

		{
			flag = 1;
			return tmp->val;
		}
		else if(x > tmp->num + add +1)
		{
			add = add + tmp->num + 1;
			tmp = tmp->l;
		}
		else
			tmp = tmp->r;
	}
	if(flag == 0)
		return -1;
}

struct node *insert(struct node *node, int val)
{
	
	if(node == NULL)
		return (newnode(val));
	if(val < node->val)
		node->l = insert(node->l, val);
	else if(val > node->val)
		node->r = insert(node->r, val);
	else
		return node;
	
	node->height = max(height(node->l), height(node->r)) + 1;	

	int balance = difBalance(node);
	
	if (balance > 1 && val < node->l->val)
		return zigzigr(node);

	if (balance < -1 && val > node->r->val)
		return zigzigl(node);

	if (balance > 1 && val > node->l->val)
		return zigzaglr(node);

	if (balance < -1 && val < node->r->val)
		return zigzagrl(node);

 	node->num = rightNodes(node);
    return node;
}

struct node *minValueNode(struct node *ptr)
{
	struct node *tmp = ptr;
	if(tmp == NULL)
		return tmp;
	else{
		while(tmp->l != NULL)
			tmp = tmp->l;
	}
	return tmp;
}

struct node* deleteNode(struct node *root, int key)
{
	if(root == NULL)
		return root;

	if(key < root->val)
		root->l = deleteNode(root->l, key);
	else if(key > root->val)
		root->r = deleteNode(root->r, key);

	else{
		if(root->l == NULL || root->r == NULL){

			struct node *tmp = root->l ? root->l : root->r;		
			
			if(tmp == NULL){									
				tmp = root;
				root = NULL;
			}

			else{												
				*root = *tmp;
			}
			free(tmp);
		}
		else{
			struct node *tmp = minValueNode(root->r);
			root->val = tmp->val;
			root->r = deleteNode(root->r, tmp->val);
		}
	}

	if(root == NULL)
		return root;

	root->height = 1 + max(height(root->l), height(root->r));
	
	int balance = difBalance(root);

	if(balance > 1 && difBalance(root->l) >= 0)
		return zigzigr(root);

	if(balance > 1 && difBalance(root->l) < 0)
		

	if(balance < -1 && difBalance(root->r) <= 0)
        return zigzigl(root);
 
    if(balance < -1 && difBalance(root->r) > 0)
		zigzagrl(root);
	
	root->num = rightNodes(root);

	return root;
}

void visit(struct node *ptr)
{
	printf("%d(num = %d)", ptr->val, ptr->num);
}

void preorder(struct node *ptr)
{
	if(ptr == NULL)
		return;
	else{
		visit(ptr);
		preorder(ptr->l);
		preorder(ptr->r);
	}
}

int main()
{
	
	struct node *root = NULL;
	root = insert(root,1);
	root = insert(root,2);
	root = insert(root,3);
	root = insert(root,4);
	root = insert(root,5);
	root = insert(root,6);
	root = insert(root,7);
	root = insert(root,8);
	root = insert(root,9);
	root = insert(root,10);
	root = deleteNode(root, 4);
	
	preorder(root);
	printf("\n");
	printf("\nRank(10) : %d \nRank(5) : %d \nRank(2) : %d\n",rank(10,root),rank(5,root),rank(2,root));
	printf("findRank(1) : %d \nfindRank(6) : %d \nfindRank(8) : %d\n",findRank(root, 1),findRank(root, 6),findRank(root, 8));
	return 0;
}