T=[0,2,1,4,5,2,1,3,6]           
l=[]
def update(i,x):
    n=len(T)
    while(i<n and i>0):
        l[i]=l[i]+x
        j=i&(-i)
        i=i+j
def prefixSum(i):
    s=0
    while(i>0):
        s=s+l[i]
        j=i&(-i)
        i=i-j
    return s
for i in range(len(T)):
    l.append(0)
for i in range(0,len(T)):
    update(i,T[i])
    
print l
a=prefixSum(3)-prefixSum(1)
print a
