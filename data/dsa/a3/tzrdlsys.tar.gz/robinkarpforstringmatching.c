#include<stdio.h>
#include<string.h>
#include<math.h>
void check(int n,int len,char ss[],char sl[])
{
    int i;
    for(i=0;i<len;i++)
    {
        if(ss[i]!=sl[i+n-1])
            return;
    }
    printf("Same string at index %d\n",(n-len)+1);
    return;
}
void main()
{
    char sl[10000],ss[1000];
    printf("Enter main string\n");
    gets(sl);
    printf("Enter sub string\n");
    gets(ss);
    int lsl,lss;
    lsl=strlen(sl);
    lss=strlen(ss);
    int prime=3,i,sc=0;
    for(i=0;i<lss;i++)
        sc=sc+ss[i]*pow(prime,i);
    int s=0;
    for(i=0;i<lss;i++)
        s=s+sl[i]*pow(prime,i);
    if(s==sc)
        check(i-1,lss,ss,sl);
    for(i=lss;i<lsl;i++)
    {
        s=(s-sl[i-lss])/prime;
        s=s+sl[i]*pow(prime,lss-1);
        if(s==sc)
            check(i,lss,ss,sl);
    }
}
