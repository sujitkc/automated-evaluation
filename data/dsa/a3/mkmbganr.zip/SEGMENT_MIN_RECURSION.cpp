#include<bits/stdc++.h>
#define MAX 120000
using namespace std;

void Tree(int *a , int *seg , int l , int h , int pos)
{
	if(l == h)
	{
		seg[pos] = a[l];
		return ;
	}
	int mid = (l+h)/2;
	
	Tree(a , seg , l , mid , (2*pos)+1);
	Tree(a , seg , mid+1 , h , (2*pos)+2);
	seg[pos] = min(seg[(2*pos)+1] , seg[(2*pos)+2]);
}

int Query(int *seg , int ql , int qh , int l , int h , int pos)
{
	if(ql <= l && qh >= h) return seg[pos];
	
	if(ql > h || qh < l)   return MAX;
	
	int mid = (l+h)/2;
	
	return min(Query(seg , ql , qh , l , mid , (2*pos)+1) , Query(seg , ql , qh , mid+1 , h , (2*pos)+2));
}

int main()
{
	int a[] = {-1 , 2 , 4 , 0};
	int seg[MAX];
	Tree(a , seg , 0 , 3 , 0);
	int MIN = Query(seg , 1 , 2 , 0 , 3 , 0);
	cout<<MIN;
	return 0;
}
