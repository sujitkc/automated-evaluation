#include<bits/stdc++.h>

using namespace std;

// data structure definition ...........
typedef struct node
{
	int key;
	struct node* left;
	struct node* right;
}n;

// creating a newnode ..........
n* newnode(int data)
{
	n* temp = (n*)malloc(sizeof(n));
	temp->key = data;
	temp->left = temp->right = NULL;
	return temp;
}

//search operation in BST ............
n* search(n* root , int data)
{
	if(root == NULL || root->key == data) return root;
	else if(data < root->key){
		search(root->left , data);
	}
	else{
		search(root->right , data);
	}
}

// insertion operation in BST ...........
n* insert(n* root , int data)
{
	n* temp = newnode(data);
	if(root == NULL) return temp;
	
	n* parent = NULL;
	n* current = root;
	
	while(current != NULL){
		parent = current;
		if(current->key < data) current = current->right;
		else{
			current = current->left;
		}
	}
	
	if(parent->key < data) parent->right = temp;
	else{
		parent->left = temp;
	}
	
	return root;
}

// finding minimum in BST .....
n* min(n* root)
{
	while(root->left != NULL){
		root = root->left;
	}
	return root;
}

// finding maximum in BST .......
n* max(n* root)
{
	while(root->right != NULL){
		root = root->right;
	}
	return root;
}

// deleting operation in BST ........
n* delete_node(n* root , int data)
{
	if(root == NULL) return root;
	
	if(root->key > data)
		root->left = delete_node(root->left , data);
	else if(root->key < data){
		root->right = delete_node(root->right , data);
	}
	else
	{
		if (root->left == NULL)
        {
            n* temp = root->right;
            delete(root);
            return temp;
        }
        else if (root->right == NULL)
        {
            n* temp = root->left;
            delete(root);
            return temp;
        }	
        n* temp = min(root->right);
        root->key = temp->key;
        root->right = delete_node(root->right , temp->key);
	}
	return root;
}

// inorder for checking the tree ......
n* inorder(n* root)
{
	if(root == NULL) return root;
	
	else{
		inorder(root->left);
		printf("%d\n",root->key);
		inorder(root->right);
	}
}

int main()
{
    /* Let us create following BST
              50
           /     \
          30      70
         /  \    /  \
       20   40  60   80 */
    n* root = NULL;
    root = insert(root, 50);
    insert(root, 30);
    insert(root, 20);
    insert(root, 40);
    insert(root, 70);
    insert(root, 60);
    insert(root, 80);
    root = delete_node(root , 50);
  
    // print inoder traversal of the BST
    inorder(root);
  
    return 0;
}
