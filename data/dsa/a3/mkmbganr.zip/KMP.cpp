#include<bits/stdc++.h>

using namespace std;

void DFA(char *p , int m , int *dfa)
{
	dfa[0] = 0;
	int j = 0;
	int i = 1;
	
	while(i < m)
	{
		if(p[j] == p[i])
		{
			j++;
			dfa[i] = j;
			i++;
		}
		else
		{
			if(j == 0)
			{
				dfa[i] = 0;
				i++;
			}
			else
			{
				j = dfa[j-1];
			}
		}	
	}
}

void KMP(char *t , char *p)
{
	int n = strlen(t);
	int m = strlen(p);
	
	int dfa[m];
	DFA(p , m , dfa);
	
	int i = 0;
	int j = 0;
	while(i < n)
	{
		if(p[j] == t[i])
		{
			i++;
			j++;
		}
		if(j == m)
		{	
			printf("%d" , i-j);
			j = dfa[j-1];
		}
		else if(i < n && p[j] != t[i])
		{
			if(j == 0)
			{
				i++;
			}
			else
			{
				j = dfa[j-1];
			}
		}
	}
}

int main()
{
	char *txt = "ABXABCABCABY";
    char *pat = "ABCABY";
    KMP(txt , pat);
    return 0;
}
