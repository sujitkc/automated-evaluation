#include<bits/stdc++.h>

using namespace std;

void update(int *tree , int n , int idx , int val)
{
	while(idx <= n)
	{
		tree[idx] += val;
		idx += (idx)&(-idx);
	}
}

void BIT(int *tree , int n , int *a)
{
	int idx = 1;
	for(; idx <= n ; idx++)
		update(tree , n , idx , a[idx-1]);
}

int till_sum(int *tree , int idx)
{
	idx += 1;
	int sum = 0;
	while(idx > 0)
	{
		sum += tree[idx];
		idx -= idx & (-idx);
	}
	return sum;
}

int main()
{
	int a[] = {3 , 4 , 5 , 7 , 10};
	int n = sizeof(a)/sizeof(a[0]);
	int tree[n+1] = {};
	
	BIT(tree , n , a);
	int sum = till_sum(tree , 3);
	printf("%d" , sum);
	return 0;
}
