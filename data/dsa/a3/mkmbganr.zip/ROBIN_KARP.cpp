#include<bits/stdc++.h>
#define d 26

void RK(char *p , char *t , int q)
{
	int n = strlen(t);
	int m = strlen(p);
	
	int h = 1 , x = 0 , y = 0;
	int i,j,w,z;
	for(i = 0 ; i < m-1 ; i++)
	{
		h = (h*d)%q;
	}
	
	for(z = 0 ; z < m ; z++)
	{
		x = (d*x + p[z])%q;     // pattern hash value
		y = (d*y + t[z])%q;
	}
	
	for(w = 0 ; w <= n-m ; w++)
	{
		if(x == y)
		{
			for(j = 0 ; j<m ; j++)
			{
				if(t[w+j] != p[j]) 
					break;
			}
			if(j == m)
				printf("%d\n",w);
		}
		
		if(w < n-m)
		{
			y = (d*(y - t[w]*h) + t[w+m])%q;
			if(y < 0) y += q;
		}
	}	
}

int main()
{
    char *txt = "ABXABCABCABY";
    char *pat = "ABCABY";
    int q = 101; 
    RK(pat , txt , q);
    return 0;
}
