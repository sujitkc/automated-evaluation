#include<stdio.h>
void BuildTree(int tree[],int arr[],int left,int right,int ind)
{
	if(left==right){
		tree[ind]=arr[left];
	}
	else{
		int mid,lc,rc;
		mid=(left+right)/2;
		lc=2*ind+1;
		rc=lc+1;
		BuildTree(tree,arr,left,mid,lc);
		BuildTree(tree,arr,mid+1,right,rc);
		tree[ind]=tree[lc]+tree[rc];
	}
}
int rsq(int tree[],int ql,int qr,int nl,int nr,int node)
{
	if(ql>nr || qr<nl){
		return 0;
	}
	else if(ql<=nl && qr>=nr){
		return tree[node];
	}
	else{
		int mid,lc,rc;
		mid=(nl+nr)/2;
		lc=2*node+1;
		rc=lc+1;
		return rsq(tree,ql,qr,nl,mid,lc)+rsq(tree,ql,qr,mid+1,nr,rc);
	}
}
void update(int tree[],int ind,int val,int nl,int nr,int node)
{
	if(ind<nl || ind>nr){
		return;
	}
	else{
		if(nl==nr){
			tree[node]+=val;
		}
		else{
			int mid,lc,rc;
			mid=(nl+nr)/2;
			lc=2*node+1;
			rc=lc+1;
			update(tree,ind,val,nl,mid,lc);
			update(tree,ind,val,mid+1,nr,rc);
			tree[node]=tree[lc]+tree[rc];
		}
	}
}
int main(){
	int n,size;
	scanf("%d",&n);
	size=2*n-1;
	int arr[n],tree[size],i;
	for(i=0;i<n;i++){
		scanf("%d",&arr[i]);
	}
	BuildTree(tree,arr,0,n-1,0);
	for(i=0;i<size;i++){
		printf("%d ",tree[i]);
	}
	printf("\n");
	int ql,qr,ans;
	scanf("%d%d",&ql,&qr);
	ans=rsq(tree,ql,qr,0,n-1,0);
	printf("%d\n",ans);
	int upd_ind,upd_val;
	scanf("%d%d",&upd_ind,&upd_val);
	int diff=upd_val-arr[upd_ind];
	arr[upd_ind]=upd_val;
	update(tree,upd_ind,diff,0,n-1,0);
	for(i=0;i<size;i++){
		printf("%d ",tree[i]);
	}
}
