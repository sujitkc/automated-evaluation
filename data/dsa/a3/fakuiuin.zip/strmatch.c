#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(){
	char *txt,*pat;
	txt=(char *)malloc(sizeof(char)*100);
	pat=(char *)malloc(sizeof(char)*10);
	scanf("%s%s",txt,pat);
	int i,j,n,m,p=101,x=0,y=0,h=1,d=10;
	n=strlen(txt);
	m=strlen(pat);
	for(i=0;i<m;i++){
		x=(d*x+(pat[i]-'0'))%p;
		y=(d*y+(txt[i]-'0'))%p;
		if(i<m-1)
			h=(d*h)%p;
	}
	for(i=0;i<=n-m;i++){
		if(x==y){
			for(j=0;j<m;j++){
				if(pat[j]!=txt[i+j])
					break;
			}
			if(j==m){
				printf("match at %d\n",i);	
			}
		}
		y=(d*(y-h*(txt[i]-'0'))+(txt[i+m]-'0'))%p;
	}
}
