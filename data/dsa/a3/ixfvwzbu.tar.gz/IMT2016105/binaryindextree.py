def sum(b,i):
   s = 0
   i = i+1
   while i > 0:

       s += b[i]
       i -= i & (-i)
   return s

def update(b, n , i ,v):
   i += 1
   while i <= n:
       b[i] += v
       i += i & (-i)


def construct(arr, n):
   b = [0]*(n+1)
   for i in range(n):
       update(b, n, i, arr[i])

   return b


freq = [2, 1, 1, 3, 2, 3, 4, 5, 6, 7, 8, 9]
b = construct(freq,len(freq))
print sum(b,5)
freq[3] += 6
update(b, len(freq), 3, 6)
print sum(b,5)
