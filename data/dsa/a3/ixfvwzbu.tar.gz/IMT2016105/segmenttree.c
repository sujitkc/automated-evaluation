#include<stdio.h>
int a[]={1,5,3,7,3,9,5,7};
int data[16];
int min(int a,int b){
  if(a<=b){
    return a;
  }
  else{
    return b;
  }
}
void construction(int a[]){
  int i=0;
  for(i=8;i<16;i++){
    data[i]=a[i-8];
  }
  int j=0;
  for(j=7;j>=1;j--){
    data[j]=min(data[2*j],data[(2*j)+1]);
    }
}
void updateValue(int idx,int value){
  idx=idx+8;
  data[idx]=value;
  while(idx>1){
    idx=idx/2;
    data[idx]=min(data[2*idx],data[(2*idx)+1]);
  }
}
int minrange(int l,int r){
  l=l+8;r=r+8;
  int m=100000;//large number
  while(l<r){
    if(l%2!=0){
      m=min(m,data[l]);
      l=l+1;
    }
    if(r%2!=0){

      m=min(m,data[r]);
      r=r-1;

    }
    l=l/2;r=r/2;

  }
  return m;
}
int main(){
  construction(a);
  printf("%d\n",minrange(2,6));
  return 0;
}
