#include<stdio.h>
#include<math.h>
void build(int input[],int tree[],int pos, int low, int high){
	if(low==high){
		tree[pos]=input[low];
		printf("\n %d %d %d",pos,low,input[low]);
	}
	else{
		int mid=(low+high)/2;
		build(input,tree,2*pos+1,low,mid);
		build(input,tree,2*pos+2,mid+1,high);
		tree[pos]=tree[2*pos+1]+tree[2*pos+2];
	}
	}
void update(int input[],int tree[],int low,int high,int pos,int up,int index){
	if(index>=low && index<=high){
		tree[pos]+=up;
		if(low==high){
			return;
		}
	}
	int mid=(low+high)/2;
	if(index>=low && index<=mid){
	update(input,tree,low,mid,2*pos+1,up,index);	
	}
	else{
	update(input,tree,mid+1,high,2*pos+2,up,index);
		}	
}
int query(int input[],int tree[],int low,int high,int pos,int l,int r){
	if(low>r || high<l){
		return 0;
	}
	if(low>=l && high<=r){
		return tree[pos];
	}
	int mid=(low+high)/2;
	int p1=query(input,tree, low,mid,2*pos+1,l,r);
	int p2=query(input,tree,mid+1,high,2*pos+2,l,r);
	return p2+p1;
}
int main(){
	int n,i;
	scanf("%d",&n);
	int a[n];
	for(i=0; i<n; i++){
		scanf("%d",&a[i]);
	}
	double j=log(n)/log(2);
	int k=j+1;
	k=pow(2,k)-1;
	printf("--%d--",k);
	int b[k];
	build(a,b,0,0,n-1);
	int q=query(a,b,0,n-1,0,1,2);
	printf("--%d--",q);
	update(a,b,0,n-1,0,3,2);
	printf("\n");
	for(i=0; i<k; i++){
		printf("%d\t",b[i]);
	}
	
}
