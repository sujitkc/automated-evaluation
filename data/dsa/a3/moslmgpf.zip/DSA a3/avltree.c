#include <stdio.h>
#include <stdlib.h>
struct node
{
    int data;
    int height;
    struct node *l;
    struct node *r;
};
int max(int a,int b)
{
    if(a>b)
    {
        return a;
    }
    return b;
}
void pre_order(struct node *root)
{
    if(root!=NULL)
    {
        printf("%d ",root->data);
        pre_order(root->l);

        pre_order(root->r);
    }

}

int height(struct node *root)
{
    if(root==NULL)
    {
        return 0;
    }
    return root->height;
}
struct node* right_rotate(struct node *y)
{
    struct node *x=y->l;
    struct node *Temp=x->r;
    x->r=y;
    y->l=Temp;
    y->height=1+max(height(y->l),height(y->r));
    x->height=1+max(height(x->l),height(x->r));
    return x;

}
struct node* left_rotate(struct node *x)
{
    struct node *y=x->r;
    struct node *Temp=y->l;
    y->l=x;
    x->r=Temp;
    x->height=1+max(height(x->l),height(x->r));
    y->height=1+max(height(y->l),height(y->r));

    return y;

}
struct node *get_min(struct node *temp)
{
    if(temp==NULL)
    {
        return temp;
    }
    while(temp->l!=NULL)
    {
        temp=temp->l;
    }
    return temp;
}
struct node* delete_node(struct node *root,int value)
{
    if(root==NULL)
    {
        return root;
    }
    if(value>root->data)
    {
        root->r=delete_node(root->r,value);
    }
    else if(value<root->data)
    {
        root->l=delete_node(root->l,value);
    }
    else
    {
        if(root->l==NULL || root->r==NULL)
        {
            struct node *temp=root->l?root->l:root->r;
            if(temp==NULL)
            {
                temp=root;
                root=NULL;
            }
            else
            {
                *root=*temp;
            }
            free(temp);
        }
        else
        {
            struct node *temp=get_min(root->r);
            root->data=temp->data;
            root->r=delete_node(root->r,temp->data);

        }

    }
    if(root==NULL)
    {
        return root;
    }
    root->height=max(height(root->l),height(root->r))+1;
        int diff=height(root->l)-height(root->r);
    if(diff>1 && value<root->l->data)
    {
        return right_rotate(root);
    }
    if(diff<-1 && value>root->r->data)
    {
        //puts("yess");
        //printf("this %d %d %d\n",root->data,root->height,root->r->height);
        return left_rotate(root);
    }
    if(diff>1 && value>root->data)
    {
        root->l= left_rotate(root->l);
        return right_rotate(root);
    }
    if(diff<-1 && value<root->r->data)
    {
        root->r=right_rotate(root->r);
        return left_rotate(root);

    }
    return root;

}

struct node* insert(struct node *root,int data)
{
    if(root==NULL)
    {

        struct node *roo=malloc(sizeof(struct node));
        roo->data=data;
        roo->l=NULL;
        roo->r=NULL;
        roo->height=1;
        return roo;
    }
    else if(root->data<data)
    {
        root->r=insert(root->r,data);
    }
    else if(root->data>data)
    {
        root->l=insert(root->l,data);
    }
    else
    {
        return root;
    }
    root->height=1+max(height(root->l),height(root->r));
    int diff=height(root->l)-height(root->r);
    if(diff>1 && data<root->l->data)
    {
        return right_rotate(root);
    }
    if(diff<-1 && data>root->r->data)
    {
        //puts("yess");
        //printf("this %d %d %d\n",root->data,root->height,root->r->height);
        return left_rotate(root);
    }
    if(diff>1 && data>root->data)
    {
        root->l= left_rotate(root->l);
        return right_rotate(root);
    }
    if(diff<-1 && data<root->r->data)
    {
        root->r=right_rotate(root->r);
        return left_rotate(root);

    }
    return root;
}
int main()
{
    struct node *root=NULL;
    root=insert(root,10);
    //printf("%d ",root==NULL);
    pre_order(root);
    puts("");
    root=insert(root,20);
    pre_order(root);
    puts("");
    root=insert(root,30);
    pre_order(root);
    puts("");
    root=insert(root,40);
    pre_order(root);
    puts("");
    root=insert(root,50);
    pre_order(root);
    puts("");
    root=insert(root,25);
    pre_order(root);
    puts("");
    //pre_order(root);
    return 0;
}