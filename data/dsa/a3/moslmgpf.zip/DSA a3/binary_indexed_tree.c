#include <stdio.h>
#include <stdlib.h>

int *tree;

void update(int num_of_elem, int i, int x)
{
	i++;
	int j;
	while(i<=num_of_elem)
	{
		j = i&(-i);
		tree[i-1] = tree[i-1]+x;
		i = i+j;
	}
}
int RSQ(int *arr, int i, int j)
{
	int k, sum=0;
	j = j+1;
	while(j>i)
	{
		k = j&(-j);
		sum = sum+tree[j-1];
		j = j-k;
	}
	return sum;
}

void main()
{
	int n;
	scanf("%d", &n);
	tree = (int *)malloc(sizeof(int)*n);
	int arr[n], i;
	for(i=0;i<n;i++)
	{
		scanf("%d", &arr[i]);
		tree[i] = 0;
	}
	for(i=0;i<n-1;i++)
	{
		printf("%d ", arr[i]);
	}
	printf("%d\n", arr[n-1]);
	for(i=0;i<n;i++)
	{
		update(n, i, arr[i]);
	}
	for(i=0;i<n-1;i++)
	{
		printf("%d ", tree[i]);
	}
	printf("%d\n%d\n", tree[n-1], RSQ(arr, 0, n-1));
}