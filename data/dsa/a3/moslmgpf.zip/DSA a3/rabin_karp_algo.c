#include <stdio.h>
#include <string.h>

void string_search(char *T, char *P, int d, int q)
{
	int n=strlen(T), m=strlen(P), p=0, t=0, h=1, i, j;
	for(i=0;i<m-1;i++)
	{
		h = (h*d)%q;
	}
	for(i=0;i<m;i++)
	{
		p = ((d*p)+P[i])%q;
		t = ((d*t)+T[i])%q;
	}
	for(i=0;i<=n-m;i++)
	{
		if(p==t)
		{
			for(j=0;j<m;j++)
			{
				if(T[i+j]!=P[j])
				{
					break;
				}
			}
			if(j==m)
			{
				printf("Pattern found at index %d\n", i);
			}
		}
		if(i<n-m)
		{
			t = (d*(t-T[i]*h)+(T[i+m]))%q;
			if(t<0)
			{
				t = t+q;
			}
		}
	}
}

int main()
{
	char txt[] = "My name is Nikhil";
	char pat[] = "Nikhil";
	int q = 101;
	string_search(txt, pat, 256, q);
	return 0;
}