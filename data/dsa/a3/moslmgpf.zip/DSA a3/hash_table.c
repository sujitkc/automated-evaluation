#include <stdio.h>
#include <stdlib.h>

typedef struct Pair
{
	int value;
	int key;
	struct Pair *next;
}pair;

void display(pair *arr, int size)
{
	printf("Key\tValues\n");
	int i;
	for(i=0;i<size;i++)
	{
		pair *ptr;
		ptr = arr[i].next;
		printf("%d\t%d ", arr[i].key, arr[i].value);
		while(ptr!=NULL)
		{
			printf("%d\t", ptr->value);
			ptr = ptr->next;
		}
		printf("\n");
	}
}
/*void search(pair *arr, int size)
{
	int elem;
	scanf("%d", &elem);
	if(arr[elem%size].value==elem)
	{
		printf("Element exist at %d\n", elem%size);
	}
	else
	{
		printf("Element does not exist\n");
	}
}*/
void insert(pair *arr, int size)
{
	int input;
	scanf("%d", &input);
	if(arr[input%size].value==-1)
	{
		arr[input%size].value = input;
	}
	else
	{
		pair *kvpair;
		kvpair = (pair *)malloc(sizeof(pair *));
		kvpair->value = input;
		kvpair->next = NULL;
		arr[input%size].next = kvpair;
	}
}

void main()
{
	int size, i, temp, j=0;
	scanf("%d", &size);
	pair hash_table[size];
	while(j<size)
	{
		hash_table[j].value = -1;
		hash_table[j].next = NULL;
		j++;
	}
	for(i=0;i<size;i++)
	{
		scanf("%d", &temp);
		hash_table[temp%size].value = temp;
		hash_table[temp%size].key = temp%size;
	}
	display(hash_table, size);
	//search(hash_table, size);
	insert(hash_table, size);
	display(hash_table, size);
}