#include <stdio.h>
#include <stdlib.h>

int *tree;

int min(int i, int j)
{
	if(i<j)
	{
		return i;
	}
	else
	{
		return j;
	}
}

void constructTree(int *arr, int i, int j, int pos)
{
	if(i>j)
	{
		return;
	}
	if(i==j)
	{
		tree[pos] = arr[i];
		return;
	}
	int mid = (i+j)/2;
	constructTree(arr, i, mid, (2*pos)+1);
	constructTree(arr, mid+1, j, (2*pos)+2);
	tree[pos] = min(tree[(2*pos)+1], tree[(2*pos)+2]);
}
void update(int *arr, int pos, int x)
{
	arr[pos]+=x;
}
int RMQ(int *arr, int n, int i, int j, int pos)
{
	if(i>n-1 || j<0)
	{
		return 0;
	}
	if(i>=0 && j<=n-1)
	{
		return tree[pos];
	}
	int mid=(i+j)/2;
	int p1=RMQ(arr, n, i, mid, 2*pos+1);
	int p2=RMQ(arr, n, mid+1, j, 2*pos+2);
	return p2+p1;
}

void main()
{
	int arr[]={1, 2, 3, 4}, i;
	tree = (int *)malloc(sizeof(int)*((2*sizeof(arr))-1));
	constructTree(arr, 0, 3, 0);
	for(i=0;i<7;i++)
	{
		printf("%d ", tree[i]);
	}
	printf("\b\n");
	printf("%d\n\n", RMQ(arr, 4, 0, 3, 0));
	update(arr, 0, 7);
	constructTree(arr, 0, 3, 0);
	for(i=0;i<7;i++)
	{
		printf("%d ", tree[i]);
	}
	printf("\b\n");
	printf("%d\n\n", RMQ(arr, 4, 0, 3, 0));
	update(arr, 1, 4);
	constructTree(arr, 0, 3, 0);
	for(i=0;i<7;i++)
	{
		printf("%d ", tree[i]);
	}
	printf("\b\n");
	printf("%d\n\n", RMQ(arr, 4, 0, 3, 0));
	update(arr, 2, 10);
	constructTree(arr, 0, 3, 0);
	for(i=0;i<7;i++)
	{
		printf("%d ", tree[i]);
	}
	printf("\b\n");
	printf("%d\n\n", RMQ(arr, 4, 0, 3, 0));
	update(arr, 3, 3);
	constructTree(arr, 0, 3, 0);
	for(i=0;i<7;i++)
	{
		printf("%d ", tree[i]);
	}
	printf("\b\n");
	printf("%d\n\n", RMQ(arr, 4, 0, 3, 0));
}