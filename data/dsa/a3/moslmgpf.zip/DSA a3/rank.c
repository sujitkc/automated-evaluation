#include <stdio.h>
#include <stdlib.h>

typedef struct treeNode
{
	int data;
	struct treeNode *leftchild, *rightchild, *parent;
}treenode;

int Max(int x, int y)
{
	if(x>=y)
	{
		return x;
	}
	else
	{
		return y;
	}
}
int height(treenode *node)
{
	if(node==NULL)
	{
		return -1;
	}
	else if(node->leftchild==NULL && node->rightchild==NULL)
	{
		return 0;
	}
	else
	{
		return 1+Max(height(node->leftchild), height(node->rightchild));
	}
}
int level(treenode *node)
{
	if(node->parent==NULL)
	{
		return 0;
	}
	else if(node==NULL)
	{
		return -1;
	}
	else
	{
		return 1+level(node->parent);
	}
}

treenode *FindMin(treenode *node)
{
	if(node==NULL)
	{
		return NULL;
	}
	if(node->leftchild)
	{
		return FindMin(node->leftchild);
	}
	else
	{
		return node;
	}
}
treenode *FindMax(treenode *node)
{
	if(node==NULL)
	{
		return NULL;
	}
	if(node->rightchild)
	{
		return FindMax(node->rightchild);
	}
	else
	{
		return node;
	}
}

void complete_link(treenode *node)
{
	if(node==NULL)
	{
		return;
	}
	else
	{
		if(node->leftchild==NULL && node->rightchild==NULL)
		{
			return;
		}
		else if(node->leftchild==NULL && node->rightchild!=NULL)
		{
			node->rightchild->parent = node;
		}
		else if(node->rightchild==NULL && node->leftchild!=NULL)
		{
			node->leftchild->parent = node;
		}
		else
		{
			node->rightchild->parent = node;
			node->leftchild->parent = node;
		}
	}
	complete_link(node->leftchild);
	complete_link(node->rightchild);
}

treenode *insert(treenode *node, int key)
{
	if(node==NULL)
	{
		treenode *temp;
		temp = (treenode *)malloc(sizeof(treenode));
		temp->data = key;
		temp->leftchild = temp->rightchild = NULL;
		return temp;
	}
	if(key>(node->data))
	{
		node->rightchild = insert(node->rightchild, key);
	}
	else if(key<(node->data))
	{
		node->leftchild = insert(node->leftchild, key);
	}
	return node;
}
treenode *delete(treenode *node, int key)
{
	treenode *temp;
	if(node==NULL)
	{
		printf("Element not found");
	}
	else if(key<(node->data))
	{
		node->leftchild = delete(node->leftchild, key);
	}
	else if(key>(node->data))
	{
		node->rightchild = delete(node->rightchild, key);
	}
	else
	{
		if(node->leftchild && node->rightchild)
		{
			temp = FindMin(node->rightchild);
			node->data = temp->data;
			node->rightchild = delete(node->rightchild, temp->data);
		}
		else
		{
			temp = node;
			if(node->leftchild==NULL)
			{
				node = node->rightchild;
			}
			else if(node->rightchild==NULL)
			{
				node = node->leftchild;
			}
			free(temp);
		}
	}
	return node;
}

treenode *Find(treenode *node, int key)
{
	if(node==NULL)
	{
		return NULL;
	}
	if(key>(node->data))
	{
		return Find(node->rightchild, key);
	}
	else if(key<(node->data))
	{
		return Find(node->leftchild, key);
	}
	else
	{
		return node;
	}
}

void PreOrderTraversal(treenode *node)
{
	if(node==NULL)
	{
		return;
	}
	printf("%d ", node->data);
	PreOrderTraversal(node->leftchild);
	PreOrderTraversal(node->rightchild);
}
void InOrderTraversal(treenode *node)
{
	if(node==NULL)
	{
		return;
	}
	InOrderTraversal(node->leftchild);
	printf("%d ", node->data);
	InOrderTraversal(node->rightchild);
}
void PostOrderTraversal(treenode *node)
{
	if (node==NULL)
	{
		return;
	}
	PostOrderTraversal(node->leftchild);
	PostOrderTraversal(node->rightchild);
	printf("%d ", node->data);
}

int rank(int x, treenode *root)
{
	int r=1;
	treenode *t;
	t = root;
	while(t)
	{
		if(t->data>=x)
		{
			r = r+1;
			t = t->leftchild;
		}
		else
		{
			if(t->rightchild!=NULL)
			{
				t = t->rightchild;
			}
			else
			{
				r = r+1;
				break;
			}
		}
	}
	return r;
}
/*int find_rank(int k, treenode *root)
{
	treenode *t;
	t = root;
	while(k)
	{
		if(t->rightchild!=NULL)
		{
			if(k==1+t->rightchild->data)
			{
				return k;
			}
			else
			{
				if(k>1+t->rightchild->data)
				{
					k = k-(1+t->rightchild->data);
					t = t->leftchild;
				}
				else
				{
					t = t->rightchild;
				}
			}
		}
	}
}*/

void main()
{
	treenode *root = NULL;
	root = insert(root, 5);
	root = insert(root, -1);
	root = insert(root, 3);
	root = insert(root, -14);
	root = insert(root, 8);
	root = insert(root, 10);
	root = insert(root, 9);
	root = insert(root, 6);
	complete_link(root);
	printf("Pre-Order Traversal:\n\t");
	PreOrderTraversal(root);
	printf("\n");
	printf("In-Order Traversal:\n\t");
	InOrderTraversal(root);
	printf("\n");
	printf("Post-Order Traversal:\n\t");
	PostOrderTraversal(root);
	printf("\nHeight of tree: %d", height(root));
	//printf("\nMaximum level of tree: %d", level(root));
	printf("\nRank of 8: %d\n\n", rank(8, root));
	root = delete(root,5);
	root = delete(root,-1);
	complete_link(root);
	printf("Pre-Order Traversal:\n\t");
	PreOrderTraversal(root);
	printf("\n");
	printf("In-Order Traversal:\n\t");
	InOrderTraversal(root);
	printf("\n");
	printf("Post-Order Traversal:\n\t");
	PostOrderTraversal(root);
	printf("\nHeight of tree: %d", height(root));
	//printf("\nMaximum level of tree: %d", level(root));
	printf("\nRank of 8: %d\n\n", rank(8, root));
	treenode * temp;
	temp = FindMin(root);
	printf("Minimum element is %d\n",temp->data);
	temp = FindMax(root);
	printf("Maximum element is %d\n",temp->data);
	temp = Find(root,8);
	if(temp==NULL)
	{
		printf("Element 8 not found\n");
	}
	else
	{
		printf("Element 8 Found\n");
	}
	temp = Find(root,2);
	if(temp==NULL)
	{
		printf("Element 2 not found\n");
	}
	else
	{
		printf("Element 6 Found\n");
	}
	printf("Rank of 8: %d\n", rank(8, root));
}