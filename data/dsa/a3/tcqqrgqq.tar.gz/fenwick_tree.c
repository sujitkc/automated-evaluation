#include <stdio.h>
#include <stdlib.h>

int BIT[1000]={0}, a[1000]={0};

void update(int i, int x, int n)
{
	int j;
	i=i+1;
	while(i<=n)
	{
		BIT[i]=BIT[i]+x;
		j=i&(-i);
		i+=j;
	}
}

int prefix_sum(int i)
{
	int sum=0,j;
	while(i>0)
	{
		sum+=BIT[i];
		j=i&(-i);
		i-=j;
	}
	return sum;
}

int main()
{
	int n;
	scanf("%d",&n);
	for (int i = 0; i < n; ++i)
	{
		scanf("%d",a+i);
		update(i,a[i],n);
	}
	int start,end;
	scanf("%d",&start);
	scanf("%d",&end);
	if (start>end||end>n)
	{
		printf("Invalid range\n");
	}
	else
		printf("sum = %d\n",prefix_sum(end)-prefix_sum(start-1));
	return 0;
}