# Binary index Tree
A=[2,1,4,5,2,1,3,6]
def Update(i,X):
    while(i<len(A)):
        T[i]=T[i]+X
        j=i+1&-(i+1)
        i=i+j
def Sum(i):
    s=0
    while(i>=0):
        s=s+T[i]
        j=i+1&-(i+1)
        i=i-j
    return s
T=[]
for i in range(0,len(A)):
    T.append(0)
for i in range(0,len(A)):
    Update(i,A[i])
print T
a=Sum(4)
Update(1,3)
print T
print a

