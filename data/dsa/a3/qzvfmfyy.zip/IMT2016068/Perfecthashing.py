##Perfect hashing
import random
class SEC:
    def __init__(self,a,b):
        self.a=a
        self.b=b
        self.m=0
        self.lis=[]
        self.stack=[]
l=[10,22,37,40,52,60,70,72,75,80,85,90,100,101]
primary=[]
p=121
M=len(l)*2
r=random.randint(1,p-1)
s=random.randint(0,p-1)
def PHash(X):
    global p
    global M
    global r
    global s
    return ((r*X+s)%p)%M

def SHash(X,a,b,m):
    global p
    return ((a*X+b)%p)%(m*m)
for i in range(0,2*len(l)):
    primary.append(0)
    a=random.randint(1,p-1)
    b=random.randint(0,p-1)
    primary[i]=SEC(a,b)

for i in range(0,len(l)):
    primary[PHash(l[i])].m+=1
    primary[PHash(l[i])].stack.append(l[i])

# Inserting values    
for i in range(0,len(primary)):
    if(primary[i].m==0):
        continue
    for j in range(0,(primary[i].m)*(primary[i].m)):
        primary[i].lis.append(0)
    done=0
    while(not done):
        temp=0
        for k in range(0,len(primary[i].stack)-1):
            for z in range(k+1,len(primary[i].stack)):
                if(SHash(primary[i].stack[k],primary[i].a,primary[i].b,primary[i].m)==SHash(primary[i].stack[z],primary[i].a,primary[i].b,primary[i].m)):
                    primary[i].a=random.randint(1,p-1)
                    primary[i].b=random.randint(0,p-1)
                    temp=1
                    break
            if(temp==1):
                break
        if(temp==0):
            done=1

    for j in range(0,len(primary[i].stack)):
        primary[i].lis[SHash(primary[i].stack[j],primary[i].a,primary[i].b,primary[i].m)]=primary[i].stack[j]

#for testing
for i in range(0,len(primary)):
    print primary[i].a,primary[i].b,primary[i].m,primary[i].stack,primary[i].lis
#Search Operation
def Search(X):
    if(primary[PHash(X)].m==0):
        print "Element found"
    elif(primary[PHash(X)].lis[SHash(X,primary[PHash(X)].a,primary[PHash(X)].b,primary[PHash(X)].m)]==X):
        print "Element found"
    else:
        print "Element not found"
#Testing        
Search(70)
Search(80)
Search(90)
Search(100)
Search(101)
Search(35)
