# Segment tree-Range Minimum Query
arr=[1,5,3,7,3,2,5,7]
seg=[]
j=len(arr)-2
def Create():
    global j
    for i in range(0,2*len(arr)-1):
        seg.append(0)
    for i in range(0,len(arr)):
        seg[i+len(arr)-1]=arr[i]
    while(j>=0):
        seg[j]=min(seg[2*j+1],seg[2*j+2])
        j-=1
def Update(idx,value):
    idx=idx+n
    seg[idx]=value
    while(idx>1):
        seg[idx/2]=min(seg[2*j+1],seg[2*j+2])
        idx=idx/2
minimum=93989
def RMQ(left,right):
    global minimum
    left=left+len(arr)
    right=right+len(arr)
    while(left<right):
        if(left%2!=0):
            minimum=min(minimum,seg[left])
            left=left+1
        if(right%2!=0):
            right=right-1
            minimum=min(minimum,seg[right])
        left=left/2
        right=right/2
    return minimum
Create()
print seg
seg.insert(0,0)
print seg
print RMQ(3,4)
