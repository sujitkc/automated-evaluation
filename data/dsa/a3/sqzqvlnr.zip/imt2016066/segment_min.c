#include<stdio.h>
#include<math.h>
int min(int a,int b){
    if(a<b){
        return a;
    }
    else{
        return b;
    }
}
int give_mid(int a,int b){
    return a+(b-a)/2;
}
int build_segment(int *arr,int n,int *seg,int st,int ed,int curr){
    if(st==ed){
        seg[curr]=arr[st];
        return seg[curr];
    }
    int mid=give_mid(st,ed);

    int temp;
    int k1,k2;
    k1=build_segment(arr,n,seg,st,mid,2*curr+1);
    k2=build_segment(arr,n,seg,mid+1,ed,2*curr+2);
    temp=min(k1,k2);
    seg[curr]=temp;
    //printf("%d %d %d %d\n",curr,temp,k1,k2);
    return seg[curr];
}
void update(int *arr,int n,int *seg,int st,int ed,int ind,int val,int cur){
    if(ind>=st && ind<=ed && cur<n){
        if(seg[cur]>val ){
            seg[cur]=val;
        }
        int mid=give_mid(st,ed);
        //puts("helo");
        update(arr,n,seg,st,mid,ind,val,2*cur+1);
        update(arr,n,seg,mid+1,ed,ind,val,2*cur+2);
    }
    else{
        return ;
    }
}
int RMQ(int *seg,int n,int ist,int ied,int st,int ed,int cur){
    if(cur<n){
        if(ist<=st && ied>=ed){
            return seg[cur];
        }
        int mid=give_mid(st,ed);
        int k1=RMQ(seg,n,ist,ied,st,mid,cur*2+1);
        int k2=RMQ(seg,n,ist,ied,mid+1,ed,cur*2+2);
        return min(k1,k2);
    }
}
int main(){
    int n;
    scanf("%d",&n);
    int i;
    int arr[10000],max=-1;
    for(i=0;i<n;i++){
        scanf("%d",&arr[i]);
        if(arr[i]>max){
            max=arr[i];
        }
    }

    int x = (int)(ceil(log2(n)));
    int j;


    int max_size = 2*(int)pow(2, x) - 1;
    for(j=i;j<max_size;j++){
        arr[j]=max+1;
    }
    for(j=0;j<max_size;j++){
        printf("%d ",arr[j]);
    }
    puts("");
    int seg[max_size];
    build_segment(arr,max_size,seg,0,max_size-1,0);
    for(i=0;i<max_size;i++){
        printf("%d ",seg[i]);
    }puts("");
    update(arr,max_size,seg,0,max_size-1,3,0,0);
    for(i=0;i<max_size;i++){
        printf("%d ",seg[i]);
    }puts("");
    printf("this %d ",RMQ(seg,max_size,1,3,0,max_size-1,0));
}
