import random
import math
def prime_no(a):
    m=a
    while True:
        for i in range(2, int(math.sqrt(m))+2):
                   if m%i == 0:
                       x = False
                       break
                   else:
                       x = True
        if x==True :
            return m
        else:
            m=m+1
class hash_table:
    def __init__(self,size):
        random.seed(a=None)
        self.table=map(lambda x:(x*0)-1,range(size))
        self.size=size
        self.p=prime_no(size+1)
        self.a=random.randint(1,self.p)
        self.b=random.randint(1,self.p)
    def insert(self,x):
        index=self.a*x
        index=index+self.b
        index=index%self.p
        index=index%self.size
        self.table[index]=x
    def search(self,x):
        index=self.a*x
        index=index+self.b
        index=index%self.p
        index=index%self.size
        if self.table[index]==-1:
            sub[index].search(x)
    def reveal_var(self):
        l=[self.p,self.a,self.b]
        return l
if __name__ == "__main__" :            
n=input("no of elements u want to give : ")
main=hash_table(2*n)
global sub
sub=map(lambda x:x*0,range(2*n))
for i in range(2*n):
    sub[i]=[]
for i in range(n):
    l=main.reveal_var()
    x=input("element : ")
    index=l[1]*x
    index=index+l[2]
    index=index%l[0]
    index=index%(2*n)
    sub[index].append(x)
for i in range(2*n):
    temp=sub[i]
    sub[i]=hash_table(len(temp)*len(temp))
    for j in temp:
        sub[i].insert(j)
for i in sub:
    print i.table
