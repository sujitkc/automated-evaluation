#include<stdio.h>
long int n;
long int a[200000],dp[200000],s[1000001];
long int minm(long int a,long int b)
{
  if(a>b)
  {
    return b;
  }
  else{return a;}
};
void buildtree()
{
 long int i;
 for(i=n-1;i>0;i--)
 {
  a[i]=minm(a[2*i],a[2*i+1]);
 }
};
 
void update(long int p)
{
 for(p>>=1;p>0;p>>=1)
 {
  a[p]=minm(a[2*p],a[2*p+1]);
 }
};
long int query(long int l,long int r)
{
  long int res=10000000007;
  for(;l<r;l>>=1,r>>=1)
  {
   if(l&1) res=minm(res,a[l++]);
   if(r&1) res=minm(res,a[--r]);
  }
  return res;
};
int main()
{
 long int q,l,r;
 scanf("%ld %ld",&n,&q);
 long int i;
 for(i=n;i<2*n;i++)
 {
    scanf("%ld",&a[i]);
 }
 buildtree();
 char c;
 for(i=0;i<q;i++)
 {
     scanf("\n%c %ld %ld\n",&c,&l,&r);
     if(c=='q')
     {
      printf("%ld\n",query(l+n-1,r+n));
     }
     if(c=='u')
     {
         a[l+n-1]=r;
         update(l+n-1);
     }
 }
 return 0;
}
