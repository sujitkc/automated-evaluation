#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct node
{
	int key;
	struct node *left,*right;
	int height;
	int odd;
}node;

struct node *create(int value);
void inorder(node *temp);
void preorder(node *temp);
void postorder(node *temp);
node* insert(node *root,int value);
node* search(node *root,int value);
void print(node *root);
node *delete(node *root,int value);
node* min(node *root);
int height(node *N);
int max(int a,int b);
int getBalance(node *N);
node *rightRotate(node *y);
node *leftRotate(node *x);
int nnodes(node *root);
int rank(int data,node *root);
int rank1(int data,node *root);
int nnodes1(node *root);
int odd(node* root,int i,int j);
int count(struct node** head);

int main(int argc,char *argv[])
{
	node *a,*b,*c;
	int d,e,f,g,h,i,j;
	b=create(1);
	inorder(b);
	printf("\n");
	//printf("h is %d\n",height(a));
	//printf("h is %d\n",getBalance(a));
	b=insert(b,2);
	inorder(b);
	printf("\n");
	b=insert(b,3);
	b=insert(b,4);
	b=insert(b,5);
	inorder(b);
	preorder(b);
	printf("b is %d\n",b->key);
	printf("\n");
	c=search(b,3);
	print(c);
	d=nnodes(b);
	printf("d is %d\n",d);
	j=count(&b);
	//i=nnodes1(b);
	inorder(b);
	f=5;
	e=rank1(f,b);
	printf("rank of %d  is %d\n",f,e);
	g=3;
	h=rank(g,b);
	printf("rank of %d  is %d\n",g,h);
	i=odd(b,4,5);
	printf("i is %d",i);


	b=delete(b,3);
	//inorder(b);
	b=delete(b,2);
	//inorder(b);
	b=delete(b,1);
	//inorder(b);



	//free(a);
	free(b);
	free(c);
}

struct node *create(int value)
{
	struct node *temp=(struct node*)malloc(sizeof(struct node));
	temp->key=value;
	temp->left=NULL;
	temp->right=NULL;
	temp->height=1;
	return temp;
}

void inorder(node *temp)
{
	if(temp!=NULL)
	{
		inorder(temp->left);
		printf("%d ",temp->odd);
		inorder(temp->right);
	}
	//printf("\n");
	
}


void preorder(node *temp)
{
	if(temp!=NULL)
	{
		printf("%d ",temp->key);
		preorder(temp->left);
		preorder(temp->right);
	}
	//printf("\n");
	
}


void postorder(node *temp)
{
	if(temp!=NULL)
	{
		preorder(temp->left);
		preorder(temp->right);
		printf("%d ",temp->key);
	}
	//printf("\n");
	
}


node* insert(node *root,int value)
{
	if(root==NULL)
	{
		return create(value);
	}
	else
	{
		if(value<root->key)
		{
			root->left=insert(root->left,value);
		}
		else if(value>root->key)
		{
			root->right=insert(root->right,value);
		}

		root->height=max(height(root->left),height(root->right))+1;
		
		int balance=getBalance(root);

		if(balance>1 && value<root->left->key)
		{
			return rightRotate(root);
		}

		if(balance<-1 && value>root->right->key)
		{
			return leftRotate(root);
		}
		
		if(balance>1 && value>root->left->key)
		{
			root->left=leftRotate(root->left);
			return rightRotate(root);
		}
		
		if(balance<-1 && value<root->right->key)
		{
			root->right=rightRotate(root->right);
			return leftRotate(root);
		}

		return root;
	}
}

node* search(node *root,int value)
{
	if(root==NULL || root->key==value)
		return root;
	if(root->key<value)
		return search(root->right,value);
	else
		return search(root->left,value);
}

void print(node *root)
{
	if(root!=NULL)
	{
		printf("%d \n",root->key);
	}
	else
		printf("DOESNT EXIST\n");
}

node* min(node *root)
{
	if(root==NULL)
	{
		return root;
	}
	if(root->left!=NULL)
	{
		return min(root->left);
	}
	else
		return root;
}


node *delete(node *root,int value)
{
	node *temp;
	if(root==NULL)
	{
		printf("element not found");
		return root;

	}
	else if(value<root->key)
	{
		root->left=delete(root->left,value);
	}
	else if(value>root->key)
	{
		root->right=delete(root->right,value);
	}
	else
	{
		if(root->right!=NULL && root->left!=NULL)
		{
			temp=min(root->right);
			root->key=temp->key;
			root->right=delete(root->right,temp->key);
		}
		else
		{
			temp=root;
			if(root->left==NULL)
				root=root->right;
			else if(root->right==NULL)
				root=root->left;
			free(temp);
		}

	}
	if(root==NULL)
	{
		return root;
	}


	root->height=max(height(root->left),height(root->right))+1;

	int balance=getBalance(root);

	if(balance>1 && getBalance(root->left)>=0)
	{
		return rightRotate(root);
	}

	if(balance<-1 && getBalance(root->right)<=0)
	{
		return leftRotate(root);
	}

	if(balance>1 && getBalance(root->left)<0)
	{
		root->left=leftRotate(root->left);
		return rightRotate(root);
	}

	if(balance<-1 && getBalance(root->right)>0)
	{
		root->right=rightRotate(root->right);
		return leftRotate(root);
	}
	return root;
}

int height(node *N)
{
	if(N==NULL)
		return 0;
	return N->height;
}

int max(int a,int b)
{
	if(a>=b)
	{
		return a;
	}
	else
	{
		return b;
	}
}

int getBalance(node *N)
{
	if(N==NULL)
		return 0;
	return height(N->left)-height(N->right);
}

node *rightRotate(node *y)
{
	node *x=y->left;
	node *z=x->right;
	
	x->right=y;
	y->left=z;
	
	y->height=max(height(y->left),height(y->right))+1;
	x->height=max(height(x->left),height(x->right))+1;

	return x;

}

node *leftRotate(node *x)
{
	node *y=x->right;
	node *z=y->left;
	
	y->left=x;
	x->right=z;
	
	y->height=max(height(y->left),height(y->right))+1;
	x->height=max(height(x->left),height(x->right))+1;

	return y;

}

int rank(int data,node *root)
{
	int rank1=0;
	while(root!=NULL)
	{
		if(data<root->key)
		{
			if((root->key)%2==1)
			{
			rank1+=1+nnodes(root->right);
			}
			else
			{
			rank1+=nnodes(root->right);

			}
			root=root->left;
		}
		else if(data>root->key)
		{
			//rank1+=1+nnodes(root->left);
			root=root->right;
		}
		else
		{
			if((root->key)%2==1)
			{
			rank1=1+rank1+nnodes(root->right);
			}
			else
			{
			rank1=rank1+nnodes(root->right);
			}
			return rank1;
		}
	}
	return rank1;
	
}
int nnodes(node *root)
{
	if(root==NULL)
	{
		return 0;
	}
	else
	{
		if((root->key)%2==1)
		{
			return 1+nnodes(root->left)+nnodes(root->right);
		}
		else
		{
			return nnodes(root->left)+nnodes(root->right);
		}
	}
}


int nnodes1(node *root)
{
	if(root==NULL)
	{
		return 0;
	}
	else
	{
		if((root->key)%2==1)
		{
			root->odd= 1+nnodes(root->left)+nnodes(root->right);
		}
		else
		{
			root->odd= nnodes(root->left)+nnodes(root->right);
		}
	}
}


int rank1(int data,node *root)
{
	int rank1=0;
	while(root!=NULL)
	{
		if(data<root->key)
		{
			if((root->key)%2==1)
			{
			rank1+=1+root->right->odd;
			}
			else
			{
			rank1+=root->right->odd;

			}
			root=root->left;
		}
		else if(data>root->key)
		{
			//rank1+=1+nnodes(root->left);
			root=root->right;
		}
		else
		{
			if((root->key)%2==1)
			{
			rank1=1+rank1+(root->right->odd);
			}
			else
			{
			rank1=rank1+(root->right->odd);

			}

			return rank1;
		}
	}
	return rank1;

}

int odd(node* root,int i,int j)
{
	return 1+rank(i,root)-rank(j,root);
}

/*void InitRank(node* root)
{
	if(root==NULL)
	{
		return 0;
	}
	else
	{       root->rank = 1 + NumeberofNodeInTree(Node->LChild);
		InitRank(Node->LChild);
		InitRank(Node->RChild);
	}

}*/

/*int nnodes2(node **root)
{
	struct node *temp=(struct node*)malloc(sizeof(struct node));
	temp=*root;

	if(root!=NULL)
	{
		return 0;
	}
	else
	{
		if((root->key)%2==1)
		{
		root->odd=(1+nnodes2(&(temp->left))+nnodes2(&(temp->right));
		}
		else
		{
		root->odd=nnodes2(&(temp->left))+nnodes2(&(temp->right));
		}

	}
}*/

int count(struct node** head)
{
struct node* head1=*head;
if(head1==NULL)
{
return 0;
}
else
{
int a=0,b=0;
a=count(&(head1->left));
b=count(&(head1->right));
if((head1->key)%2==1)
{
	head1->odd=a+b+1;
}
else
{
	head1->odd=a+b;
}
return head1->odd;

}
}
