#include<stdio.h>
void update(int t[],int i,int x,int n){
	int j;
	while(i<n){
		t[i]=t[i]+x;
		j=(i+1)&(-(i+1));
		i=i+j;
	}
}
int sum(int t[],int i){
	int j;	
	int s=0;
	while(i>=0){
		s+=t[i];
		j=(i+1)&(-(i+1));
		i=i-j;		
	}
	return s;
}
int main(){
	int n,i;
	scanf("%d",&n);
	int arr[n],t[n];
	for(i=0;i<n;i++){
		scanf("%d",&arr[i]);
		t[i]=0;
	}
	for(i=0;i<n;i++){
		update(t,i,arr[i],n);
	}
	int l,r,RSQ;
	scanf("%d%d",&l,&r);
	if(l>0)
		RSQ=sum(t,r)-sum(t,l-1);
	else
		RSQ=sum(t,r);
	printf("%d\n",RSQ);
	//update(t,3,5,n);
	//RSQ=sum(t,r)-sum(t,l-1);
	//printf("%d\n",RSQ);
}
