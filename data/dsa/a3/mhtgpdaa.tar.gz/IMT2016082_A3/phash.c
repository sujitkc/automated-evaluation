#include<stdio.h>
#include<stdlib.h>
#include<time.h>
struct node{
  int a,b,n_j;
  int * st;
};
int search(int key,struct node *pt[],int A,int B,int P,int M){
	int H,h,a_j,b_j,m;
	H=((A*key+B)%P)%M;
	a_j=pt[H]->a;
	b_j=pt[H]->b;
	m=(pt[H]->n_j)*(pt[H]->n_j);
	if(m==0)
		return 0;
	h=((a_j*key+b_j)%P)%m;
	if((pt[H]->st)[h]==key)
		return 1;
	else
		return 0;
}
void func(struct node *pt[],int arr[],int A,int B,int P,int n,int m){
	int i,j;
	for(i=0;i<n;i++){
    int h_k=((A*arr[i]+B)%P)%m;
    if(pt[h_k]->n_j>1){
			int a_j=pt[h_k]->a,b_j=pt[h_k]->b,m_j,x;
			m_j=(pt[h_k]->n_j)*(pt[h_k]->n_j);
    	while(pt[h_k]->a==0){
     		a_j=(rand()%(P));
				b_j=rand()%P;
				pt[h_k]->a=a_j;
      	pt[h_k]->b=b_j;
			}
      x=((a_j*arr[i]+b_j)%P)%m_j;
			if(pt[h_k]->st==NULL){
      	int *t;
				t=(int *)malloc(sizeof(int)*m_j);
      	for(j=0;j<m_j;j++)
        	t[j]=-1;
				pt[h_k]->st=t;
			}
			if(pt[h_k]->st[x]==-1)
      	pt[h_k]->st[x]=arr[i];
			else if(pt[h_k]->st[x]!=-1||pt[h_k]->st[x]!=arr[i]){
				pt[h_k]->st=NULL;
				pt[h_k]->a=0;
				func(pt,arr,A,B,P,n,m);
			}
			
    }
    else if(pt[h_k]->n_j==1){
      int *t;
			t=(int *)malloc(sizeof(int));
			t[0]=arr[i];
      pt[h_k]->st=t;
    }
  }
}
int main(){
  int n=10,m=2*n,P=1193,A=0,B,i=0,j,flag=0;
  int arr[]={1,2,8,4,11,21,3,22,18,15};
  srand((unsigned int)time(NULL));
	for(i=0;i<n;i++){
		//arr[i]=rand()%100;
	}
	//1,2,8,4,11,20,3,22,18,15
  struct node * pt[m];
  while(flag==0){
    for(i=0;i<m;i++){
      struct node * new;
      new=malloc(sizeof(struct node));
      new->a=0;
      new->b=0;
      new->n_j=0;
      new->st=NULL;
      pt[i]=new;
    }
		while(A==0)
    	A=rand()%(P);
    B=rand()%P;
    for(i=0;i<n;i++){
      int h_k=((A*arr[i]+B)%P)%m;
      pt[h_k]->n_j++;
    }
    int sum=0;
    for(i=0;i<m;i++){
      sum+=(pt[i]->n_j)*(pt[i]->n_j);
    }
    if(sum<2*n){
      flag=1;
		}
		else
			A=0;
  }
	printf("%d %d\n",A,B);
	func(pt,arr,A,B,P,n,m);
/*
	for(i=0;i<n;i++){
    int h_k=((A*arr[i]+B)%P)%m;
    if(pt[h_k]->n_j>1){
			int a_j=pt[h_k]->a,b_j=pt[h_k]->b,m_j,x;
			m_j=(pt[h_k]->n_j)*(pt[h_k]->n_j);
    	if(pt[h_k]->a==0){
     		a_j=1+(rand()%(P-1));
				b_j=rand()%P;
				//printf("%d %d\n",a_j,b_j);
      	pt[h_k]->a=a_j;
      	pt[h_k]->b=b_j;
			}
      x=((a_j*arr[i]+b_j)%P)%m_j;
			if(pt[h_k]->st==NULL){
      	int *t;
				t=(int *)malloc(sizeof(int)*m_j);
      	for(j=0;j<m_j;j++)
        	t[j]=-1;
				pt[h_k]->st=t;
			}
			printf("X:%d x:%d %d\n",h_k,x,arr[i]);
			//if(pt[h_k]->st[x]==-1)
      	pt[h_k]->st[x]=arr[i];
			//else if(pt[h_k]->st[x]!=-1||pt[h_k]->st[x]!=arr[i]){
				//pt[h_k]->st=NULL;
				//pt[h_k]->a=0;
				//func(pt,arr,A,B,P,n,m);
			//}
			
    }
    else if(pt[h_k]->n_j==1){
      int *t;
			t=(int *)malloc(sizeof(int));
			t[0]=arr[i];
      pt[h_k]->st=t;
    }
  }*/
  for(i=0;i<m;i++){
    for(j=0;j<pt[i]->n_j*pt[i]->n_j;j++){
      printf("%d ",(pt[i]->st)[j]);
    }
    printf("\n");
	}
	int key;
	//scanf("%d",&key);
	//printf("%d\n",search(key,pt,A,B,P,m));
}
