#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>

struct tree{
  int data;
  bool black;
  struct tree *parent,*lc,*rc;
};

void insert(struct tree **root,int n);
void rotate(struct tree **root,struct tree *g,struct tree *p,struct tree *u,struct tree *x);
void delete_node(struct tree **root,struct tree *cur);
void delete(struct tree **root,int n);
void redblack(struct tree **root,struct tree *prev);
void double_black(struct tree **root,struct tree *x);
bool search(struct tree *root,int n);
void rec_in(struct tree *root);
void rec_pre(struct tree *root);
int main(){
  struct tree *root=NULL;
  insert(&root,11);
  insert(&root,2);
  insert(&root,15);
  insert(&root,1);
  insert(&root,7);
  insert(&root,16);
  insert(&root,5);
  insert(&root,8);
  insert(&root,9);
//  printf("r=%d\n",root->data);
  //rec_in(root);
  //puts("");
  //rec_pre(root);
  for(int i=0;i<1000;i++){
    int k=rand();
    //printf("%d\n",k%1000);
    //if(!search(root,k%1000));
    insert(&root,i);
  }
  for(int i=0;i<5000;i++){
    int k=rand();
    delete(&root,k%1000);
  }
  rec_in(root);
  rec_pre(root);
  /*search(root,926);
  delete(&root,9);
  delete(&root,11);
  delete(&root,2);
  delete(&root,15);
  delete(&root,1);
  delete(&root,5);
  delete(&root,7);
  delete(&root,16);
  delete(&root,8);*/

}
bool search(struct tree *root,int n){
  while(1){
    if(root==NULL){
      return false;
    }
    else if(root->data==n){
      return true;
    }
    else if((root->data)<n){
      root=root->rc;
    }
    else{
      root=root->lc;
    }
  }

}
void insert(struct tree **root,int n){
  struct tree *new=malloc(sizeof(struct tree)),*cur=(*root);
  new->data=n;new->lc=NULL;new->rc=NULL;
  new->black=false;
  if((*root)==NULL){
    new->black=true;
    new->parent=NULL;
    (*root)=new;
  }
  else{
    while(1){
      if(n>cur->data){
        if(cur->rc==NULL) break;
        else cur=cur->rc;
      }
      else{
        if(cur->lc==NULL) break;
        else cur=cur->lc;
      }
    }
  if(n>cur->data) cur->rc=new;
  else cur->lc=new;
  new->parent=cur;
  cur=new;
  if(!cur->parent->black){
    while(1){
      if(cur==(*root)){
        cur->black=true;
        break;
      }
      else if(cur->parent->black) break;
      else{
        struct tree *p,*g,*u;
        p=cur->parent;
        g=p->parent;
        if(g->rc==p) u=g->lc;
        else u=g->rc;
        if(u!=NULL){
          if(!p->black && !u->black){
            p->black=true;
            u->black=true;
            g->black=false;
            cur=g;
          }
          else if(!p->black && u->black){
            rotate(root,g,p,u,cur);
            break;
          }
        }
        else{
          p->black=true;
          g->black=false;
          cur=g;
        }
      }
    }
  }
}}
void rotate(struct tree **root,struct tree *g,struct tree *p,struct tree *u,struct tree *x){
  struct tree *par=g->parent;
  if(g->lc==p){
    if(p->rc==x){
      x->black=true;
      g->black=false;
      g->lc=x->rc;
      if(x->rc!=NULL) x->rc->parent=g;
      p->rc=x->lc;
      if(x->lc!=NULL) x->lc->parent=p;
      x->rc=g;
      g->parent=x;
      x->lc=p;
      p->parent=x;
      if(par==NULL) (*root)=x;
      else if(par->rc==g) par->rc=x;
      else par->lc=x;
      x->parent=par;
    }
    else{
      g->black=false;
      p->black=true;g->lc=p->rc;
      if(p->rc!=NULL) p->rc->parent=g;
      p->rc=g;
      g->parent=p;
      p->lc=x;
      x->parent=p;
      if(par==NULL) (*root)=p;
      else if(par->rc==g) par->rc=p;
      else par->lc=p;
      p->parent=par;
    }
  }
  else{
    if(p->lc==x){
      x->black=true;
      g->black=false;
      g->rc=x->lc;
      if(x->lc!=NULL) x->lc->parent=g;
      p->lc=x->rc;
      if(x->rc!=NULL) x->rc->parent=p;
      x->lc=g;
      g->parent=x;
      x->rc=p;
      p->parent=x;
      if(par==NULL) (*root)=x;
      else if(par->rc==g) par->rc=x;
      else par->lc=x;
      x->parent=par;
    }
    else{
      g->black=false;
      p->black=true;
      g->rc=p->lc;
      if(p->lc!=NULL) p->lc->parent=g;
      p->lc=g;
      g->parent=p;
      p->rc=x;
      x->parent=p;
      if(par==NULL) (*root)=p;
      else if(par->rc==g) par->rc=p;
      else par->lc=p;
      p->parent=par;
    }
  }
}
void delete(struct tree **root,int n){
  struct tree *cur=(*root);
  if(search(*root,n)){
    while(1){
      if(cur->data==n) break;
      else if(cur->data<n) cur=cur->rc;
      else cur=cur->lc;
    }
    delete_node(root,cur);
  }
}

void delete_node(struct tree **root,struct tree *cur){
  struct tree *par=cur->parent,*u;
  if(par!=NULL){
    if(par->lc==cur) u=par->rc;
    else u=par->lc;
  }

  if(cur->rc==NULL && cur->lc==NULL){
    if(par==NULL) (*root)=NULL;
    else{
      if(cur==par->rc) par->rc=NULL;
      else par->lc=NULL;
      if(u==NULL && cur->black){
        if(!par->black) par->black=true;
        else double_black(root,par);
      }
    }
    free(cur);
  }
  else if(cur->rc==NULL){
    struct tree *c=cur->lc;
    if(par==NULL){
      (*root)=cur->lc;
      (*root)->parent=NULL;
      (*root)->black=true;
    }
    else if(cur==par->rc) par->rc=cur->lc;
    else par->lc=cur->lc;
    cur->lc->parent=par;
    if(cur->black){
      if(!c->black) c->black=true;
      else double_black(root,c);
    }
    free(cur);
  }
  else if(cur->lc==NULL){
    struct tree *c=cur->rc;
    if(par==NULL){
      (*root)=cur->rc;
      (*root)->parent=NULL;
      (*root)->black=true;
    }
    else if(cur==par->rc) par->rc=cur->rc;
    else par->lc=cur->rc;
    cur->rc->parent=par;
    if(cur->black){
      if(!c->black) c->black=true;
      else double_black(root,c);
    }
    free(cur);
  }
  else{
    struct tree *inpre=cur->lc;
    while(inpre->rc!=NULL) inpre=inpre->rc;
    cur->data=inpre->data;
    delete_node(root,inpre);
  }
}

void double_black(struct tree **root,struct tree *x){
  struct tree *p=x->parent,*u;
  if(p!=NULL){
    if(p->lc==x) u=p->rc;
    else u=p->lc;

    if(u==NULL){
      if(!p->black) p->black=false;
      else double_black(root,p);
    }
    else if(!u->black){
      if(u==p->rc){
        p->black=true;
        u->black=true;
        if(u->lc != NULL)
        {
        	u->lc->black = false;
        }
        p->rc=u->lc;
        if(u->lc!=NULL) u->lc->parent=p;
        u->lc=p;
        p->parent=u;
      }
      else{
        p->black=false;
        u->black=true;
        p->lc=u->rc;
        if(u->rc!=NULL) u->rc->parent=p;
        u->rc=p;
        p->parent=u;
      }
    }
    else{
      bool red_child=false,right_red=false,p_black=false;
      if(u->rc!=NULL) if(!u->rc->black) red_child=true;
      if(u->lc!=NULL) if(!u->lc->black) red_child=true;
      if(p->black) p_black=true;

      if(!red_child){
        u->black=false;
        p->black=true;
        if(p_black) double_black(root,p);
      }
      else{
        struct tree *par=p->parent;
        if(u==p->rc){
          if(u->rc!=NULL) if(!u->rc->black){
            bool lc_red;
            p->rc=u->lc;
            if(u->lc!=NULL) u->lc->parent=NULL;
            u->black=p->black;
            p->black=true;
            u->rc->black=true;
            if(par==NULL) (*root)=u;
            else if(par->rc==p) par->rc=u;
            else par->lc=u;
            u->parent=par;
          }
          if(u->lc!=NULL) if(!u->lc->black){
            u->black=false;
            x->black=true;
            x=u->lc;
            u->lc=x->rc;
            if(x->rc!=NULL) x->rc->parent=u;
            x->rc=u;
            u->parent=x;
            x->parent=p;
            p->rc=x;

            p->rc=x->lc;
            if(x->lc!=NULL) x->lc->parent=u;
            x->lc=p;
            p->parent=x;
            u->black=true;
            if(par==NULL) (*root)=x;
            else if(par->rc==p) par->rc=x;
            else par->lc=x;
            x->parent=par;
          }
          else{
            if(u->lc!=NULL) if(!u->lc->black){
              bool rc_red;
              p->lc=u->rc;
              if(u->rc!=NULL) u->rc->parent=NULL;
              u->black=p->black;
              p->black=true;
              u->lc->black=true;
              if(par==NULL) (*root)=u;
              else if(par->rc==p) par->rc=u;
              else par->lc=u;
              u->parent=par;
            }
            if(u->rc!=NULL) if(!u->rc->black){
              u->black=false;
              x->black=true;
              x=u->rc;
              u->rc=x->lc;
              if(x->lc!=NULL) x->lc->parent=u;
              x->lc=u;
              u->parent=x;
              x->parent=p;
              p->lc=x;

              p->lc=x->rc;
              if(x->rc!=NULL) x->rc->parent=u;
              x->rc=p;
              p->parent=x;
              u->black=true;
              if(par==NULL) (*root)=x;
              else if(par->rc==p) par->rc=x;
              else par->lc=x;
              x->parent=par;
          }
        }
      }
    }
  }
}
  else{
    (*root)->black=true;
  }
}
void rec_in(struct tree *root){
  if(root!=NULL){
    rec_in(root->lc);
    printf("%d\n",root->data);
    rec_in(root->rc);
  }
}
void rec_pre(struct tree *root){
  if(root!=NULL){
    printf("%d\n",root->data);
    rec_pre(root->lc);
    rec_pre(root->rc);
  }
}
