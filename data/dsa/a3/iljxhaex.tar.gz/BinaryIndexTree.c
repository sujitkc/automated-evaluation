#include<stdio.h>
#include<stdlib.h>

void update(int sum[],int i, int increment,int size)
{
	int j;
	while(i<size)
	{
		sum[i] += increment;
		j = i+1&-(i+1);
		i+=j;
	}
}

int RSQ(int sum[],int i,int j)
{
	i--;
	int sum1 = 0,sum2 = 0,z;
	while(i>0)
	{
		sum2 += sum[i];
		z = (i+1)&-(i+1);
		i -= z;
	}
	while(j>0)
	{
		sum1 += sum[j];
		z = j+1&-(j+1);
		j -= z;
	}
	return sum1- sum2;
}

int main()
{
	int arr[] = {2,34,17,0,45,100,25,8};
	int size = 8;
	int *sum = (int*)calloc(size,sizeof(int));
	update(sum,0,2,size);
	update(sum,1,34,size);
	update(sum,2,17,size);
	update(sum,3,0,size);
	update(sum,4,45,size);
	update(sum,5,100,size);
	update(sum,6,25,size);
	update(sum,7,8,size);
	for(int i = 0; i<size; i++)
	{
		printf("%d ",sum[i]);
	}
	printf("\nSum from 2 to 5 = %d\n",RSQ(sum,2,5));
}
