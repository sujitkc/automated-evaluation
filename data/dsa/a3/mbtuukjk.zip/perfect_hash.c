#include <stdio.h>
#include <math.h>
#include <stdlib.h>

struct secondaryhashtable
{
	int n;
	int size;
	int prime;
	int *hashtable;
};

int prime_num(int a)
{
	for(int i=a+1; ; i++)
	{
		int prime = 1;	
		for(int j=2; j<=sqrt(i); j++)
		{
			if(i%j == 0)
				prime = 0;
		}
		if(prime)
			return i;
	}
}

int hash_func(int k, int rprime, int size)
{
	return ((k*2)%rprime)%size;
}

struct secondaryhashtable hashtable2(int *a, int n)
{
	struct secondaryhashtable table;
	if(n != 0)
	{
		table.n = n;
		table.size = n*n;
		table.hashtable = malloc(sizeof(int[table.size]));
		table.prime = prime_num(table.size);
		int i;
		do
		{
			for(int j=0;j<table.size;j++)
				table.hashtable[j] = 0;
			for(i=0;i<table.n;i++)
			{
				int index = hash_func(a[i], table.prime, table.size);
				if(table.hashtable[index] != 0)
				{
					table.prime = prime_num(table.prime);
					break;
				}
				else
					table.hashtable[index] = a[i];
			}
		}while(i != n);
	}
	return table;
}

int secondary_search(struct secondaryhashtable *ptr, int key)
{
	if(ptr->hashtable[hash_func(key, ptr->prime, ptr->size)] == key)
		return 1;
	return 0;
}

int primary_hash(int *a, const int n)
{
	const int size = 2*n;
	int collisiontable[size];
	int sum = 0, rprime;
	rprime = prime_num(size);

	do
	{
		for(int i=0;i<size;i++)
			collisiontable[i] = 0;
		for(int i=0;i<n;i++)
			collisiontable[hash_func(a[i], rprime, size)]++;
		for(int i=0;i<size;i++)
			sum+=collisiontable[i]*collisiontable[i];
		rprime = prime_num(rprime);
	}while(sum > 2*n);
	


	int *hashedElements[size];
	for(int i=0;i<size;i++)
	{
		hashedElements[i] = malloc(sizeof(collisiontable[i]));
	}

	int indexList[size];
	for(int i=0;i<size;i++)
		indexList[i] = 0;
	for(int i=0;i<n;i++)
	{
		int j = hash_func(a[i], rprime, size);
		hashedElements[j][indexList[i]++] = a[i];
	}

	struct secondaryhashtable *arr[size];
	struct secondaryhashtable table[size];
	for(int i=0;i<size;i++)
	{
		table[i] = hashtable2(hashedElements[i], collisiontable[i]);
		arr[i] = &table[i];
	}

	printf("Enter the search key : ");
	int key;
	scanf("%d", &key);
	if(secondary_search(arr[hash_func(key, rprime, size)], key))
		printf("Found\n");
	else
		printf("Not Found\n");

}

int main()
{
	int a[] = {6, 9, 8, 7, 1};
	int n = sizeof(a)/sizeof(int);
	primary_hash(a, n);
	return 0;
}