#include <stdio.h>

int prefix_sum(int *t, int i)
{
	int sum = 0;
	while(i > 0)
	{
		sum = t[i] + sum;
		i -= i & (-i);
	}
	return sum;
}

int rsq(int i, int j, int *t)
{
	return (prefix_sum(t, j) - prefix_sum(t, i - 1));
}

void update(int *t, int n, int i, int x)
{
	while(i < n)
	{
		t[i] = t[i] + x;
		i += i & (-i);
	}
}

int main()
{
	int a[] = {-1, 2, 1, 4, 5, 2, 1, 3, 8};
	int size = sizeof(a)/sizeof(int);
	int t[size];
	for(int i=0;i<size;i++)
		t[i] = 0;
	for(int i = 1;i < size; i++)
		update(t, size, i, a[i]);
	for(int i=0;i<size;i++)
		printf("%d ", t[i]);
	printf("\nRSQ = %d\n", rsq(2, size-2, t));
	return 0;
}