#include <stdio.h>
#include <stdlib.h>

int max(int a, int b)
{
	if(a > b)
		return a;
	else
		return b;
}

struct tree
{
	int data;
	struct tree *left;
	struct tree *right;
	int height;
	int num;
};

int rightNodes(struct tree *root);
int leftNodes(struct tree *root);

struct tree *newnode(int val)
{
	struct tree *ptr = malloc(sizeof(struct tree));
	ptr->data = val;
	ptr->left = NULL;
	ptr->right = NULL;
	ptr->height = 1;
	return (ptr);
}

int height(struct tree *n)
{
	if(n == NULL)
		return 0;
	else
		return n->height;
}

int heightDiff(struct tree *n)
{
	if(n == NULL)
		return 0;
	else
		return (height(n->left) - height(n->right));
}


struct tree *rightRotate(struct tree *z)
{
	
	struct tree *y  = z->left;
	struct tree *T3 = y->right;

	y->right = z;
	z->left = T3;

	z->height = max(height(z->left), height(z->right)) + 1;
	y->height = max(height(y->left), height(y->right)) + 1;

	z->num = rightNodes(z);
	y->num = rightNodes(z);

	return y;	
}

struct tree *leftRotate(struct tree *z)
{
	
	struct tree *y = z->right;
	struct tree *T2 = y->left;

	y->left = z;
	z->right = T2;

	z->height = max(height(z->left), height(z->right)) + 1;
	y->height = max(height(y->left), height(y->right)) + 1;

	z->num = rightNodes(z);
	y->num = rightNodes(z);
	
	return y;
}

struct tree *zigzigr(struct tree *z)
{
	return rightRotate(z);
}

struct tree *zigzigl(struct tree *z)
{
	return leftRotate(z);
}

struct tree *zigzagrl(struct tree *n)
{	n->right = zigzigr(n->right);
	return zigzigl(n);
}

struct tree *zigzaglr(struct tree *n)
{
	n->left = zigzigl(n->left);
	return zigzigr(n);
}

int leftNodes(struct tree *root)
{
	struct tree *t = root;
	if(t->left == NULL)
		return 0;
	else
		return rightNodes(t->left) + leftNodes(t->left) + 1;
}

int rightNodes(struct tree *root)
{
	struct tree *t = root;
	if(t->right == NULL)
		return 0;
	else
		return rightNodes(t->right) + leftNodes(t->right) + 1;
}

struct tree *search(struct tree *n, int val)
{
	if(n == NULL)
		return NULL;
	else if(val < n->left->data)
		return search(n->left, val);
	else if(val > n->right->data)
		return search(n->right, val);
	else
		return n;
}

int rank(int x, struct tree *root)
{
	int right = 0;
	struct tree *ptr = root;
	while(ptr != NULL)
	{
		if(ptr->data == x)
		{
			right = right + ptr->num + 1;
			break;
		}
		else if(ptr->data > x)
		{
			right = right + ptr->num + 1;
			ptr = ptr->left;
		}
		
		else
			ptr = ptr->right;
	}
	return right;
}

int findRank(struct tree *root, int x)
{
	int add = 0, flag = 0;
	struct tree *tmp = root;
	while(tmp)
	{
		if(x == tmp->num + add + 1)
		{
			flag = 1;
			return tmp->data;
		}
		else if(x > tmp->num + add +1)
		{
			add = add + tmp->num + 1;
			tmp = tmp->left;
		}
		else
			tmp = tmp->right;
	}
	if(flag == 0)
		return -1;
}

struct tree *insert(struct tree *node, int val)
{
	
	if(node == NULL)
		return (newnode(val));
	if(val < node->data)
		node->left = insert(node->left, val);
	else if(val > node->data)
		node->right = insert(node->right, val);
	else
		return node;
	
	node->height = max(height(node->left), height(node->right)) + 1;	

	int balance = heightDiff(node);
	
	if (balance > 1 && val < node->left->data)
		return zigzigr(node);

	if (balance < -1 && val > node->right->data)
		return zigzigl(node);

	if (balance > 1 && val > node->left->data)
		return zigzaglr(node);

	if (balance < -1 && val < node->right->data)
		return zigzagrl(node);

 	node->num = rightNodes(node);
    return node;
}

struct tree *minValueNode(struct tree *ptr)
{
	struct tree *tmp = ptr;
	if(tmp == NULL)
		return tmp;
	else
	{
		while(tmp->left != NULL)
			tmp = tmp->left;
	}
	return tmp;
}

struct tree* delete(struct tree *root, int key)
{
	if(root == NULL)
		return root;

	if(key < root->data)
		root->left = delete(root->left, key);
	else if(key > root->data)
		root->right = delete(root->right, key);

	else
	{
		if(root->left == NULL || root->right == NULL){

			struct tree *tmp = root->left ? root->left : root->right;		
			
			if(tmp == NULL)
			{									
				tmp = root;
				root = NULL;
			}

			else
			{												
				*root = *tmp;
			}
			free(tmp);
		}
		else
		{
			struct tree *tmp = minValueNode(root->right);
			root->data = tmp->data;
			root->right = delete(root->right, tmp->data);
		}
	}

	if(root == NULL)
		return root;

	root->height = 1 + max(height(root->left), height(root->right));
	
	int balance = heightDiff(root);

	if(balance > 1 && heightDiff(root->left) >= 0)
		return zigzigr(root);

	if(balance > 1 && heightDiff(root->left) < 0)
		

	if(balance < -1 && heightDiff(root->right) <= 0)
        return zigzigl(root);
 
    if(balance < -1 && heightDiff(root->right) > 0)
		zigzagrl(root);
	
	root->num = rightNodes(root);

	return root;
}

void preorder(struct tree *ptr)
{
	if(ptr == NULL)
		return;
	else
	{
		printf("%d\t", ptr->data);
		preorder(ptr->left);
		preorder(ptr->right);
	}
}

int main(){
	
	struct tree *root = NULL;
	root = insert(root,1);
	root = insert(root,2);
	root = insert(root,3);
	root = insert(root,4);
	root = insert(root,5);
	root = insert(root,6);
	root = insert(root,7);
	root = insert(root,8);
	root = insert(root,9);
	root = insert(root,10);
	root = delete(root, 4);
	printf("preorder is: \t");
	preorder(root);
	printf("\n");
	printf("Rank(10) : %d \nRank(5) : %d \nRank(2) : %d\n",rank(10,root),rank(5,root),rank(2,root));
	printf("findRank(1) : %d \nfindRank(6) : %d \nfindRank(8) : %d\n",findRank(root, 1),findRank(root, 6),findRank(root, 8));
	return 0;
}