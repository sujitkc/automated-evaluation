#include<stdio.h>
#include<stdlib.h>
struct node{
	int num;
	struct node *left;
	struct node *right;
	struct node *parent;
};
struct node *root=NULL;
void insert(int n)
{
	struct node *t=malloc(sizeof(struct node));
	t->num=n;
	t->left= NULL;
	t->right=NULL;
	t->parent=NULL;
	struct node *sptr=root;
	struct node *current;
	if(root==NULL)
		root=t;
	else
	{
		while(sptr!=NULL)
		{
			current=sptr;
			if(t->num<=sptr->num)
				sptr=sptr->left;
			else
				sptr=sptr->right;
		}
		if(t->num<=current->num)
				current->left=t;
			else
				current->right=t;
		t->parent=current;
	}
}
void delete_node(struct node *t)
{
	if(t->right==NULL&&t->left==NULL)
	{
		if(t==root)
			root=NULL;
		free(t);
	}
	else if(t->right!=NULL&&t->left==NULL)
	{
		if(t==root)
		{
			root=t->right;
			(t->right)->parent=NULL;
		}
		else{
		if((t->parent)->right==t)
			(t->parent)->right=t->right;
		else
			(t->parent)->left=t->right;
		(t->right)->parent=t->parent;
		}
		free(t);
		
	}
	else if(t->right==NULL&&t->left!=NULL)
	{
		if(t==root)
		{
			root=t->left;
			(t->left)->parent=NULL;
		}
		else{
		if((t->parent)->right==t)
			(t->parent)->right=t->left;
		else
			(t->parent)->left=t->left;
		(t->left)->parent=t->parent;
		}
		free(t);
	}
	else
	{
		struct node *l=t->left;
		while(l->right!=NULL)
			l=l->right;
		t->num=l->num;
		delete_node(l);
	}
}
void delete_num(int n)
{
	struct node *sptr=root;
	while(sptr!=NULL)
	{
		if(n<sptr->num)
			sptr=sptr->left;
		else if(n>sptr->num)
			sptr=sptr->right;
		else
			break;
	}
	if(sptr==NULL)
		return;
	else
		delete_node(sptr);
	
}
void print(struct node *sptr)
{
	if(sptr!=NULL)
	{
		print(sptr->left);
		printf("%d\n",sptr->num);
		print(sptr->right);
	}	
}
void main()
{
	insert(5);
	insert(4);
	insert(3);
	insert(2);
	insert(1);
	insert(7);
	insert(9);
	print(root);
	delete_num(5);
	delete_num(7);
	print(root);
}
