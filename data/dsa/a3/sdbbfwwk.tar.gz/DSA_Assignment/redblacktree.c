#include<stdio.h>
#include<stdlib.h>
struct node{
	int num;
	int red;
	struct node *left;
	struct node *right;
	struct node *parent;
};
struct node *root=NULL;
struct node *nil;
void zig_zig(struct node *x, struct node *y, struct node *z)
{
	if(z==root)
	{
		root=y;
		y->parent=nil;
	}
	else
	{
		if((z->parent)->left==z)
		{
			(z->parent)->left=y;
			y->parent=z->parent;
		}
		else
		{
			(z->parent)->right=y;
			y->parent=z->parent;
		}
	}
	struct node *tmp;
	if(y->right==x)
	{
		tmp=y->left;
		y->left=z;
		z->parent=y;
	}
	else
	{
		tmp=y->right;
		y->right=z;
		z->parent=y;
	}
	if(z->right==y)
		z->right=tmp;
	else
		z->left=tmp;
}
void zig_zag(struct node *x, struct node *y, struct node *z)
{
	if(z==root)
	{
		root=x;
		x->parent=nil;
	}
	else
	{
		if((z->parent)->left==z)
		{
			(z->parent)->left=x;
			x->parent=z->parent;
		}
		else
		{
			(z->parent)->right=x;
			x->parent=z->parent;
		}
	}
	struct node *zc, *yc;
	if(y->left==x)
	{
		zc=x->left;
		yc=x->right;
		x->right=y;
		y->parent=x;
		x->left=z;
		z->parent=x;
		y->left=yc;
		z->right=zc;
		
	}
	else
	{
		zc=x->right;
		yc=x->left;
		x->right=z;
		z->parent=x;
		x->left=y;
		y->parent=x;
		y->right=yc;
		z->left=zc;
	}
}
/*void inverse_zig_zig(struct node *n, struct node *p, struct node *s)
{
		if((p->parent)->right==p)
		{
			(p->parent)->right=s;
			s->parent=p->parent;
		}
		else
		{
			(p->parent)->left=s;
			s->parent=p->parent;
		}
		if(p->right==s)
		{
			p->right=s->left;
			p->parent=s;
			s->left=p;
		}
		else
		{
			p->left=s->right;
			p->parent=s;
			s->right=p;
		}
		
	
}*/
void check(struct node *t)
{
	if(root==t)
	{
		root->red=0;
		root->parent=nil;
		return;
	}
	struct node *p=t->parent;
	if(p->red==0)
		return;
	struct node *gp=p->parent;
	struct node *u;
	if(gp->left!=p)
		u=gp->left;
	else
		u=gp->right;
	if(u!=nil&&u->red==1)
	{
		u->red=0;
		p->red=0;
		gp->red=1;
		check(gp);
	}
	else
	{
		if((p->left==t&&gp->left==p)||(p->right==t&&gp->right==p))
		{
			p->red=0;
			gp->red=1;
			zig_zig(t,p,gp);
		}
		else
		{
			t->red=0;
			gp->red=1;
			zig_zag(t,p,gp);
		}
	}
	
	
}
void insert(int n)
{
	struct node *t=malloc(sizeof(struct node));
	t->num=n;
	t->red=1;
	t->left= nil;
	t->right=nil;
	t->parent=nil;
	struct node *sptr=root;
	struct node *current;
	if(root==NULL)
		root=t;
	else
	{
		while(sptr!=nil)
		{
			current=sptr;
			if(t->num<=sptr->num)
				sptr=sptr->left;
			else
				sptr=sptr->right;
		}
		if(t->num<=current->num)
				current->left=t;
			else
				current->right=t;
		t->parent=current;
	}
	check(t);
}
/*void delete_node(struct node *t)
{
	struct node *p, *s, *n;
	n=nil;
	/*else
	{
		if(t->right==nil&&t->left==nil&&t->red==1)
		{
			if(p->right==t)
				p->right=nil;
			else
				p->left=nil;
			free(t);
		}
		else if(t->red==0&&((t->right!=nil&&t->left==nil)||(t->right==nil&&t->left!=nil)))
		{
			if(t->right!=nil)
			{
				if(p->right==t)
					p->right=t->right;
				else
					p->left=nil;
			free(t);
			}
		}
	}*/
	/*p=t->parent;
	if(t->right==nil&&t->left==nil&&t->red==1)
	{
		if(p->right==t)
			p->right=nil;
		else
			p->left=nil;
		free(t);
	}
	else if(t->red==0&&(t->right)->red==1)
	{
		(t->right)->red=0;
		if(p->right==t)
			p->right=t->right;
		else
			p->left=t->right;
		(t->right)->parent=p;
		free(t);
	}
	else if(t->red==0&&(t->left)->red==1)
	{
		(t->left)->red=0;
		if(p->right==t)
			p->right=t->left;
		else
			p->left=t->left;
		(t->left)->parent=p;
		free(t);
	}
	else
	{
		if(t==root)
		{
			root=NULL;
			free(t);
			return;
		}
		int k;
		(t->left)->red=-1;
		if(p->right==t)
		{
			p->right=t->left;
			k=1;
		}
		else
		{
			p->left=t->left;
			k=0;
		}
		free(t);
		if(k=1)
		{
			s=p->left;
			n=p->right;
		}
		else
		{
			s=p->right;
			n=p->left;
		}
		if(p->red==0&&s->red==1)
		{
			s->red=0;
			p->red==1;
			inverse_zig_zig(n,p,s);
			delete_node(n);
		}
		else if(p->red==0&&s->red==0&&(s->left)->red==0&&(s->right)->red==0)
		{
			n->red=0;
			p->red=-1;
			s->red=1;
		}
	}
	
	
}
void delete_num(int n)
{
	struct node *sptr=root;
	while(sptr!=nil)
	{
		if(n<sptr->num)
			sptr=sptr->left;
		else if(n>sptr->num)
			sptr=sptr->right;
		else
			break;
	}
	if(sptr==nil)
		return;
	else if(sptr->left!=nil)
	{
		struct node *ino_pre;
		ino_pre=sptr->left;
		while(ino_pre->right!=nil)
		{
			ino_pre=ino_pre->right;
		}
		sptr->num=ino_pre->num;
		delete_node(ino_pre);
	}
	else
		delete_node(sptr);
	
}*/
void print(struct node *sptr)
{
	if(sptr!=nil)
	{
		print(sptr->left);
		printf("%d, colour= %d\n",sptr->num, sptr->red);
		print(sptr->right);
	}	
}
void main()
{
	nil=malloc(sizeof(struct node));
	nil->num=0;
	nil->red=0;
	nil->left=NULL;
	nil->right=NULL;
	nil->parent=NULL;
	insert(17);
	insert(11);
	insert(15);
	insert(14);
	insert(16);
	insert(18);
	insert(29);
	insert(25);
	insert(30);
	print(root);
	//delete_num(8);
	//delete_num(6);
	//printf("latest\n");
	//print(root);
}
