#include<stdio.h>
#include<stdlib.h>
struct node{
	int key,h;
	struct node *lc;
	struct node *rc;
  struct node *p;
};
int max(int x,int y){
  if(x>=y)
    return x;
  else
    return y;
}
int height(struct node *n){
  if(n==NULL)
    return -1;
  else if(n->lc==NULL&&n->rc==NULL)
    return 0;
  else if(n->lc==NULL){
    return 1+height(n->rc);
  }
  else if(n->rc==NULL){
    return 1+height(n->lc);
  }
  else
    return 1+max(height(n->rc),height(n->lc));
}
int balanced(struct node *n){
  if(abs(height(n->lc)-height(n->rc))<=1)
    return 1;
  else
    return 0;
}
int search(int val,struct node *root){
	while(root){
		if(root->key==val){
			return 1;
		}
		else if(root->key>val){
			root=root->lc;
		}
		else{
			root=root->rc;
		}
	}
	return 0;	
}
void zigzig(struct node **z,struct node **y,struct node **x,struct node **root,int a){
	printf("zigzig %d %d %d\n",(*z)->key,(*y)->key,(*x)->key);
	if(a==1){
		(*z)->rc=(*y)->lc;
		if((*y)->lc){
			(*y)->lc->p=(*z);
		}
		(*y)->lc=*z;
		(*y)->p=(*z)->p;
		(*z)->p=(*y);
	}
	else if(a==0){
		(*z)->lc=(*y)->rc;
		if((*y)->rc){
			(*y)->rc->p=(*z);
		}
		(*y)->rc=*z;
		(*y)->p=(*z)->p;
		(*z)->p=(*y);
	}
	(*z)->h=height(*z);
	(*y)->h=height(*y);
	if(*root==*z){
		*root=*y;
	}
	else{
		if((*y)->p->rc==(*z)){
			(*y)->p->rc=(*y);
		}
		else if((*y)->p->lc==(*y)){
			(*y)->p->lc=(*y);
		}
	}
}
void zigzag(struct node **z,struct node **y,struct node **x,struct node **root,int a){
	printf("zigzag %d %d %d\n",(*z)->key,(*y)->key,(*x)->key);
	if(a==1){
		(*z)->rc=(*x)->lc;
		if((*x)->lc){
			(*x)->lc->p=(*z);
		}
		(*y)->lc=(*x)->rc;
		if((*x)->rc){
			(*x)->rc->p=(*y);
		}
		(*x)->lc=(*z);
		(*x)->rc=(*y);
		(*x)->p=(*z)->p;
		(*z)->p=(*x);
		(*y)->p=(*x);
	}
	else if(a==0){
		(*z)->lc=(*x)->rc;
		if((*x)->rc){
			(*x)->rc->p=(*z);
		}
		(*y)->rc=(*x)->lc;
		if((*x)->lc){
			(*x)->lc->p=(*y);
		}
		(*x)->lc=(*y);
		(*x)->rc=(*z);
		(*x)->p=(*z)->p;
		(*z)->p=(*x);
		(*y)->p=(*x);
	}
	(*z)->h=height(*z);
	(*y)->h=height(*y);
	(*x)->h=height(*x);
	if(*root==*z){
		printf("Root\n");
		*root=*x;
	}
	else{
		if((*x)->p->rc==(*z)){
			(*x)->p->rc=(*x);
		}
		else if((*x)->p->lc==(*z)){
			(*x)->p->lc=(*x);
		}
	}
}
void Balance(struct node **z,struct node **y,struct node **x,struct node **root){
	if((*z)->rc==(*y)){
		if((*y)->rc==(*x)){
			zigzig(z,y,x,root,1);
		}
		else if((*y)->lc==(*x)){
			zigzag(z,y,x,root,1);
		}
	}
	else if((*z)->lc==(*y)){
		if((*y)->lc==(*x)){
			zigzig(z,y,x,root,0);
		}
		else if((*y)->rc==(*x)){
			zigzag(z,y,x,root,0);
		}
	}
}
void insert(int val,struct node **root){
	struct node *new,*prev,*curr;
	new=malloc(sizeof(struct node));
	new->key=val;
  new->h=0;
	new->lc=NULL;
	new->rc=NULL;
  new->p=NULL;
	if(*root==NULL){
		*root=new;
	}
	else{
		prev=NULL;
		curr=*root;
		while(curr){
			if(curr->key==val){
				printf("key already present\n");
				return;
			}		
			else if(curr->key>val){
				prev=curr;
				curr=curr->lc;
			}
			else{
				prev=curr;
				curr=curr->rc;
			}
		}
		if(val>prev->key){
			prev->rc=new;
      new->p=prev;
		}
		else if(val<prev->key){
			prev->lc=new;
      new->p=prev;
		}
    struct node *z,*y,*x;
    z=prev;
    y=new;
    x=NULL;
    while(z){
      if(balanced(z)==0){
				Balance(&z,&y,&x,root);
        break;
      }
      else{
        z->h=height(z);
        x=y;
        y=z;
        z=z->p;
      }
    }
  }
}
int inordpre(struct node *head){
	struct node *prev;
	prev=head;
	head=head->lc;
	while(head){
		prev=head;
		head=head->rc;
	}
	return prev->key;
}
void delete(int val,struct node **root){
	struct node *prev,*curr;
	prev=NULL;
	curr=*root;
	if(*root==NULL){
		printf("Tree is empty\n");
		return;
	}
	if(search(val,*root)==0){
		printf("key not in tree\n");
		return;
	}
	while(curr){
		if(curr->key==val){
			break;	
		}
		else if(curr->key>val){
			prev=curr;
			curr=curr->lc;
		}
		else{
			prev=curr;
			curr=curr->rc;
		}
	}
	if(prev==NULL){
		if(curr->lc&&curr->rc){
			int x;
			x=inordpre(curr);
			delete(x,root);
			curr->key=x;
		}
		else{
			if(curr->lc){
				*root=curr->lc;
        (*root)->h=height(*root);
				free(curr);
			}
			else if(curr->rc){
				*root=curr->rc;
        (*root)->h=height(*root);
				free(curr);
			}
		}
	}
	else{
		if(curr->lc==NULL||curr->rc==NULL){
			if(prev->lc==curr){
				if(curr->lc)
					prev->lc=curr->lc;
				else
					prev->lc=curr->lc;
				free(curr);
      }
			else if(prev->rc==curr){
				if(curr->lc)
					prev->rc=curr->lc;
				else
					prev->rc=curr->lc;
				free(curr);
			}
      prev->h=height(prev);
		}	
		else{
			int x;
			x=inordpre(curr);
			delete(x,root);
			curr->key=x;
      curr->h=height(curr);
		}
    struct node *z,*y,*x;
    z=prev;
    y=NULL;
    x=NULL;
    while(z){
      if(balanced(z)==0){
        if(y==z->lc){
          y=z->rc;
          if(y->lc){
            x=y->lc;        
          }
          else{
            x=y->rc;
          }
        }
        else if(y==z->rc){
          y=z->lc;
          if(y->rc){
            x=y->rc;        
          }
          else{
            x=y->lc;
          }
        }
        Balance(&z,&y,&x,root);
        z=z->p;
      }
      else{
        z->h=height(z);
        y=z;
        z=z->p;
      }
    }
	}
}
void inorder(struct node *root)
{
	if(root!=NULL){
	inorder(root->lc);		
	printf("%d\t%d\n",root->key,root->h);
	inorder(root->rc);
	}
}
int main(){
	struct node *root;
	root=malloc(sizeof(struct node));
	root=NULL;
  insert(10,&root);
	insert(7,&root);
	insert(5,&root);
	insert(20,&root);
	insert(1,&root);
	insert(15,&root);
	insert(6,&root);
	insert(26,&root);
	insert(30,&root);
	inorder(root);
	delete(30,&root);
	delete(10,&root);
	inorder(root);
}
