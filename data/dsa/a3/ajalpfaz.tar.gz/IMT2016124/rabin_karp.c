#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
	int m,n;
	int f=0;
	char C[100],t[100];
	scanf("%s",t);
	scanf("%s",C);
	m=strlen(C);
	n=strlen(t);
	int x=0,y=0,h=1,p=6131;
	for (int i = 0; i < m; i++)
	{
		x=(2*x+(C[i]-48))%p;
		y=(2*y+(t[i]-48))%p;
			
	}
	for (int i = 0; i < m-1; i++)
	{
		h=(2*h)%p;
	}
	
	
	for (int i = 0; i < n-m; i++)
	{
		if (x==y)
			{
				int j;
				for (j = 0; j < m; j++)
				{
					if(C[j]!=t[i+j])
						break;						
				}
				if(j==m)
					{
						f=1;
						printf("Match at %d\n",i);
						break;
					}			
			}
		y = (2*(y-h*(t[i]-48))+(t[i+m]-48))%p;
		if(y < 0)
			y=y+p;
	}
	if (f==0)
		printf("No Match\n");
	return 0;
}
 
