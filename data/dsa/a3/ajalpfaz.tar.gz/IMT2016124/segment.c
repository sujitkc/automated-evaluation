#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>

int n,k=2;

int min(int x,int y)
{
	return (x < y)? x: y; 
}
void swap(int *a,int *b)
{
	int temp=*a;
	*a=*b;
	*b=temp;
}

void update(int i,int x,int *a,int *b)
{
	b[i]=b[i]+x;
	i=k-n+i;
	printf("i=%d",i);
	while(b[a[i]]<b[a[i/2+i%2-1]])
	{
		a[i/2+i%2-1]=a[i];
		i=i/2+i%2-1;
	}
}




void printtree(int *a,int *b)
{
	int i;
	for(i=0;i<k;i++)
	{
		printf("\nsegment tree :%d=%d",a[i],b[a[i]]);
	}
}


void main()
{
	int i,j,m;
	scanf("%d",&n);
	while(k<n)
	{
		k=k*2;
	}
	int *b=(int*)calloc(sizeof(int),k);
	k=k*2-1;
	printf("%d\n",k);
	int *a=(int*)calloc(sizeof(int),k);
	m=k-1;
	for(i=0;i<n;i++)
	{
		scanf("%d",&b[i]);	
	}
	j=n-1;
	for(i=k-1;i>=0;i--)
	{
		if(j>=0)
			{
				a[i]=j;
				j--;
				printf("\ni=%d",i);
			}
		else
		{	
			if(b[a[m]]<b[a[m-1]])	
				a[i]=a[m];
			else
			{
				a[i]=a[m-1];
			}	
			m=m-2;
		}
	}
 	printtree(a,b);
 	int x;
 	printf("\nenter update: ");
 	scanf("%d %d",&i,&x);
 	printf("updated segment tree:\n");
 	update(i,x,a,b);
 	printtree(a,b);
 	printf("%d",rmq(2,6,a,b,0,n-1,0));

}