#include<stdio.h>
#include<math.h>
#include<stdlib.h>

struct point
{
    int a,b,prime,n;
    int *array;
};

int find_prime(int m)
{
    int n1,n2;
    n1=7*m+4;
    n2=7*m-4;
    if(check_prime(n1))
    {
        return n1;
    }
    return n2;
}

int find_a(int prime)
{
    return sqrt(prime);
}

int find_b(int a,int prime)
{
    return rand()%a;
}

int check_prime(int n)
    {
    int a=sqrt(n);
    int i;
    for(i=2;i<=a;i++)
    {
        if(i%n==0)
        {
            return 0;
        }
    }
    return 1;
}


void main()
{
    int n,i;
    scanf("%d",&n);
    int *main_array;
    main_array=malloc(sizeof(int)*n);
    
    for(i=0;i<n;i++)
    {
        scanf("%d",&main_array[i]);
    }
    struct point *array[2*n];
    for(i=0;i<2*n;i++)
    {
        array[i]=NULL;
    }
    int prime=find_prime(2*n);
    int a=find_a(prime);
    int b=find_b(a,prime);
    int m=2*n;
    int k;
    for(i=0;i<n;i++)
    {
        k=((main_array[i]*a+b)%prime)%m;
        if(arr[((main_array[i]*a+b)%prime)%m]==NULL)
        {

            array[k]=malloc(sizeof(struct point));
            array[k]->n=1;
        }
        else
        {
            array[k]->n++;
        }
    }
    int j;
    for(i=0;i<m;i++)
    {
        if(array[i]!=NULL)
        {
            array[i]->prime=find_prime(2*(array[i]->n));
            array[i]->a=find_a(array[i]->prime);
            array[i]->b=find_b(array[i]->a,array[i]->prime);
            array[i]->arr=malloc(sizeof(int)*2*(array[i]->n));
            for(j=0;j<2*array[i]->n;j++)
            {
                array[i]->array[j]=-1;
            }
        }
    }
    int temp;
    for(i=0;i<n;i++)
    {
        k=((main_array[i]*a+b)%prime)%m;
        temp=((main_array[i]*(array[k]->a)+array[k]->b)%array[k]->prime)%(array[k]->n*2);
        arr[k]->arr[temp]=main_arr[i];
    }
    for(i=0;i<m;i++)
    {
        if(array[i]!=NULL)
        {
            for(j=0;j<(array[i]->n)*2;j++)
            {
                printf("%d ",array[i]->array[j]);
            }
            puts("");
        }
    }
}
