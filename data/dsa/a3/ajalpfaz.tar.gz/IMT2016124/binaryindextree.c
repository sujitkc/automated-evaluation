#include <stdio.h>
#include <stdlib.h>


void update(int n,int i,int a,int *b)
{
	i=i+1;
	while (i<=n)
	{
    	b[i]=b[i]+a;
		i=i+(i&(-i));
	}

}



void rangesum(int i,int *b)
{
	int sum=0;
	i=i+1;
	while (i>0)
	{
    	sum = sum+b[i];
		i=i-(i&(-i));
	}
	printf("sum=%d\n",sum);

}

void printbinitree(int *b,int n)
{
	int i;
	for(i=0;i<n+1;i++)
	{
		printf("%d\n",b[i]);
	}
}


void createbintree(int n,int *a,int *b)
{
	int i;
	for(i=0;i<n;i++)
	{
		update(n,i,a[i],b);
	}
}




void main()
{
	int n,i,d;
	scanf("%d",&n);
	int *a=(int *)calloc(sizeof(int),n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	int *b=(int *)calloc(sizeof(int),n+1);
	createbintree(n,a,b);
	printbinitree(b,n);
	scanf("%d",&d);
	rangesum(d,b);
}