#include<iostream>
#include<math.h>
#include<limits.h>
using namespace std;

class BIT{
  int *tree;
  int size;
public:
  BIT(int *A,int n){
    tree=new int[n+1];
    size=n;
    for(int i=0;i<=n;i++)tree[i]=0;
    for(int i=0;i<n;i++)update(i,A[i]);
  }
  void update(int i,int x){
    i++;
    while(i<=size){
      tree[i]+=x;
      i+=i&(-i);
    }
  }
  void view(){
    for(int i=0;i<=size;i++)cout<<tree[i]<<" ";
    cout<<endl;
  }
  int RSQ(int l,int r){
    return SQ(r+1)-SQ(l);
  }
  int SQ(int i){
    int sum=0;
    while (i){
      sum+=tree[i];
      i-=i&(-i);
    }
    return sum;
  }
};

int main(){
  int arr[] = {2,1,4,5,2,1,3,8};
  int n = sizeof(arr)/sizeof(arr[0]);
  BIT BT(arr,n);
  BT.view();
  cout<<BT.RSQ(3,7);
}
