#include<iostream>
using namespace std;

class AVL{
class Node{
public:
  int key;
  Node *left;
  Node *right;
  int value;
  int maxValue;
  int height;
  int nodeCount;
  int sum;
  int minGap;
  static int getHeight(Node *n){
    if (n==NULL)return 0;
    return n->height;
  }
  static int getSum(Node *n){
    if (n==NULL)return 0;
    return n->sum;
  }
  static int getMax(Node *n){
    if (n==NULL)return INT_MIN;
    return n->maxValue;
  }
  static int getNodeCount(Node *n){
    if (n==NULL)return 0;
    return n->nodeCount;
  }
  static int getMinGap(Node *n){
    if (n==NULL)return 100000;
    return n->minGap;
  }

  Node(int key,int value,Node* left=NULL,Node *right=NULL){
    this->key=key;
    this->value=value;
    this->left=left;
    this->right=right;
    update();
  }
  void update(){
    updateHeight();
    updateNodeCount();
    updateSum();
    updateMinGap();
    updateMax();
  }
  Node *maxValueNode(Node *n){
    while(n->right!=NULL)n=n->right;
    return n;
  }
  Node *minValueNode(Node *n){
    while(n->left!=NULL)n=n->left;
    return n;
  }
  void updateSum(){
      sum=getSum(left)+getSum(right)+key;
  }
  void updateMax(){
      maxValue=max(max(getMax(left),getMax(right)),value);
  }
  void updateMinGap(){
      minGap=min(getMinGap(left),getMinGap(right));
      if(left)minGap=min(key-maxValueNode(left)->key  ,minGap);
      if(right)minGap=min(minValueNode(right)->key - key,minGap);
  }
  void updateHeight(){
    height=max(getHeight(left),getHeight(right))+1;
  }
  void updateNodeCount(){
    nodeCount=getNodeCount(left)+getNodeCount(right)+1;
  }
};

Node *root;

Node *zigZagRight(Node *root){
  // cout<<"HIT"<<endl;
  Node *z=root;
  Node *x=root->right->left;
  Node *y=root->right;
  y->left=x->right;
  z->right=x->left;
  x->right=y;
  x->left=z;
  y->update();
  z->update();
  x->update();
  return x;
}
Node *zigZigRight(Node *root){
  // cout<<"HIT"<<endl;
  Node *z=root;
  Node *x=root->right->right;
  Node *y=root->right;

  z->right=y->left;
  y->left=z;
  z->update();
  y->update();
  return y;
}
Node *zigZagLeft(Node *root){
  // cout<<"HIT"<<endl;
  Node *z=root;
  Node *x=root->left->right;
  Node *y=root->left;
  y->right=x->left;
  z->left=x->right;
  x->left=y;
  x->right=z;
  y->update();
  z->update();
  x->update();
  return x;
}
Node *zigZigLeft(Node *root){
  // cout<<"HIT"<<endl;
  Node *z=root;
  Node *x=root->left->left;
  Node *y=root->left;

  z->left=y->right;
  y->right=z;
  z->update();
  y->update();
  return y;
}

Node *insert_r(Node *root,int key,int value){
  if(root==NULL)
    return new Node(key,value);
  if(root->key==key)return root;
  else if(key>root->key)
    root->right=insert_r(root->right,key,value);
  else
    root->left=insert_r(root->left,key,value);

  root->update();
  if(Node::getHeight(root->right)>Node::getHeight(root->left)+1){
    if(Node::getHeight(root->right->left)>Node::getHeight(root->right->right))
      return zigZagRight(root);
    return zigZigRight(root);
  }
  if(Node::getHeight(root->right)<Node::getHeight(root->left)-1){
    if(Node::getHeight(root->left->right)>Node::getHeight(root->left->left))
      return zigZagLeft(root);
    return zigZigLeft(root);
  }
  return root;
}
Node *maxValueNode(Node *n){
  while(n->right!=NULL)n=n->right;
  return n;
}
Node *minValueNode(Node *n){
  while(n->left!=NULL)n=n->left;
  return n;
}

Node *delete_r(Node *root,int key){
  if(root==NULL)
    return NULL;
  if(root->key==key){
    if(root->left==NULL&&root->right==NULL){
      delete root;
      return NULL;
    }
    else if(root->left==NULL){
      delete root;
      return root->right;
    }
    else if(root->right==NULL){
      delete root;
      return root->left;
    }
    else{
      Node *pre = maxValueNode(root->left);
      root->key=pre->key;
      pre->key=key;
      root->left=delete_r(root->left,key);
    }
  }
  else if(key>root->key)
    root->right=delete_r(root->right,key);
  else
    root->left=delete_r(root->left,key);

  root->update();

  if(Node::getHeight(root->right)>Node::getHeight(root->left)+1){
    if(Node::getHeight(root->right->left)>Node::getHeight(root->right->right))
      return zigZagRight(root);
    return zigZigRight(root);
  }
  if(Node::getHeight(root->right)<Node::getHeight(root->left)-1){
    if(Node::getHeight(root->left->right)>Node::getHeight(root->left->left))
      return zigZagLeft(root);
    return zigZigLeft(root);
  }
  return root;
}

bool search_r(Node *n,int key){
  if(!n)return false;
  if(key==n->key)return true;
  if(key>n->key)return search_r(n->right,key);
  return search_r(n->left,key);
}
Node *find_r(Node *n,int key){
  if(!n)return NULL;
  if(key==n->key)return n;
  if(key>n->key)return find_r(n->right,key);
  return find_r(n->left,key);
}

public:


  AVL(){
    root=NULL;
  }

  void insert(int key,int value){
    root=insert_r(root,key,value);
  }
  void deleteKey(int key){
    root=delete_r(root,key);
  }

  bool search(int key){
    return search_r(root,key);
  }

  Node *findNode(int key){
    return find_r(root,key);
  }

  int treeHeight(){
    return Node::getHeight(root);
  }
  int getMinGap(){
    return root->minGap;
  }
  int findRank(int key){
    int r=1;
    Node * temp=root;
    while(temp){
      // cout<<temp->key<<endl;
      if(temp->key>key){
        r+=Node::getNodeCount(temp->right)+1;
        temp=temp->left;
      }
      else if(temp->key<key){
        temp=temp->right;
      }
      else{
        if(temp->right)
          r+=Node::getNodeCount(temp->right);
        return r;
      }
    }
    return r;
  }

  int getRank(int rank){
    Node * temp=root;
    while(rank){
      int rightCount=Node::getNodeCount(temp->right)+1;
      if(rank==rightCount)return temp->key;
      else if(rank>rightCount){
        rank-=rightCount;
        temp=temp->left;
      }
      else{
        temp=temp->right;
      }
    }
    return temp->key;
  }

  int nosInBetween(int b,int a){
    return findRank(b)-findRank(a)+1;
  }
  int sumInBetween(int a,int b){
    return getPrefixSum(b)-getPrefixSum(a)+a;
  }

  void preOrderTraversal(Node *root=NULL){          //O(n)
    if(root==NULL)root=this->root;
    if(root==NULL)return;
    cout<<root->key<<" ";
    if(root->left)preOrderTraversal(root->left);
    if(root->right)preOrderTraversal(root->right);
  }
  void postOrderTraversal(Node *root=NULL){       //O(n)
    if(root==NULL)root=this->root;
    if(root==NULL)return;
    if(root->left)postOrderTraversal(root->left);
    if(root->right)postOrderTraversal(root->right);
    cout<<root->key<<" ";
  }
  void inOrderTraversal(Node *root=NULL){       //O(n)
    if(root==NULL)root=this->root;
    if(root->left)inOrderTraversal(root->left);
    cout<<root->key<<":"<<root->maxValue<<" ";
    if(root->right)inOrderTraversal(root->right);
  }

  int maxInBetween(int l,int r){
    Node *p=root;
    while(p){
      if(p->key>l && p->key>r){
        p=p->left;
      }
      else if(p->key<l && p->key<r){
        p=p->right;
      }
      else break;
    }
    if(p==NULL)return INT_MIN;
    Node *temp=p->left;
    int mx=p->value;
    while(temp){
      if(temp->key==l){
        mx=max(Node::getMax(temp->right),max(mx,temp->value));
        break;
      }
      else if(temp->key>l){
        mx=max(Node::getMax(temp->right),max(mx,temp->value));
        temp=temp->left;
      }
      else {
        temp=temp->right;
      }
    }
    temp=p->right;
    while(temp){
      if(temp->key==r){
        mx=max(Node::getMax(temp->left),max(mx,temp->value));
        break;
      }
      else if(temp->key>r){
        temp=temp->left;
      }
      else {
        mx=max(Node::getMax(temp->left),max(mx,temp->value));
        temp=temp->right;
      }
    }
    return mx;
  }
  int getPrefixSum(int key){
    // Node *n=findNode(key);
    // if(n==NULL)return 0;
    // return key+Node::getSum(n->left);

    Node * temp=root;
    int prefixSum=0;
    while(temp){
    if(temp->key<key){
      prefixSum+=Node::getSum(temp->left)+temp->key;
      temp=temp->right;
    }
    else if (temp->key>key){
      temp=temp->left;
    }
      else {
      prefixSum+=Node::getSum(temp->left);
      return prefixSum+key;
      }
    }
    return prefixSum;
  }
};

int main(){
AVL b1;
b1.insert(1,2);
b1.insert(3,4);
b1.insert(4,6);
b1.insert(7,8);
b1.insert(10,5);
b1.deleteKey(4);
b1.deleteKey(7);
b1.insert(9,7);
// b1.inOrderTraversal();
cout<<b1.maxInBetween(1,10)<<endl;

}
