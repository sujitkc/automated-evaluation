#include<iostream>
#include<math.h>
#include<limits.h>
using namespace std;

class segmentTree{
  int *tree;
  int size;
  int n;
public:
  segmentTree(int *A,int n){
    int h=(int)(ceil(log2(n)));
    this->size=2*(int)pow(2, h) - 1;
    this->n=n;
    tree=new int[this->size];
    for(int i=0;i<this->size;i++)tree[i]=INT_MAX;
    cout<<size<<":"<<n<<endl;
    constructTree(A,0,n-1,0);
    viewTree();
  }
  int constructTree(int *A,int l,int r,int i){
    if(l==r){
      tree[i]=A[l];
      return tree[i];
    }
    int mid=(l+r)/2;
    tree[i]=constructTree(A,l,mid,2*i+1)+constructTree(A,mid+1,r,2*i+2);
    return tree[i];
  }
  int RSQ(int ql,int qr){
    return RSQ_r(ql,qr,0,n-1,0);
  }

  int RSQ_r(int ql,int qr,int l,int r,int i){
    if(ql<=l&&qr>=r)return tree[i];
    if(ql>r||qr<l)return 0;
    int mid=(l+r)/2;
    return RSQ_r(ql,qr,l,mid,2*i+1)+RSQ_r(ql,qr,mid+1,r,2*i+2);
  }

  void update(int i,int val){
    update_r(0,n-1,0,i,val);
    viewTree();
  }
  void update_r(int l,int r,int treeIndex,int i,int val){
    if(l==r){
      tree[treeIndex]+=val;
      return;
    }
    int mid=(l+r)/2;
    if(i<=mid)update_r(l,mid,treeIndex*2+1,i,val);
    if(i>mid)update_r(mid+1,r,treeIndex*2+2,i,val);
    tree[treeIndex]=tree[treeIndex*2+1]+tree[treeIndex*2+2];
  }

  void viewTree(){
      for(int i=0;i<size;i++)
        cout<<tree[i]<<" ";
      cout<<endl;
  }
};

int main(){
  int arr[] = {6, 4, 12, 3, 1, 5, 21, 93};
  int n = sizeof(arr)/sizeof(arr[0]);
  segmentTree ST(arr,n);
  cout<<ST.RSQ(1,5)<<endl;
  ST.update(2,100);
  ST.update(0,10000);
  cout<<ST.RSQ(0,0)<<endl;
}
