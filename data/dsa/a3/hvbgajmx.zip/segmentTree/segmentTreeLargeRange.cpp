#include<iostream>
#include<limits.h>
using namespace std;
class segmentTree{
  class Node{
  public:
    Node *left;
    Node *right;
    long long int  key;
    long long int  childCount;
    long long int  value;
    Node(long long int  v=0,Node *l=NULL,Node *r=NULL){
      if(v)
        childCount=1;
      else
        childCount=0;
      value=v;
      left=l;
      right=r;
    }
    void updateValue(int v){
      value=v;
      if(v)
        childCount=1;
      else
        childCount=0;
    }
    static int getValue(Node *n){
      if(n==NULL)return INT_MIN;
      return n->value;
    }
    static long long int  getChildCount(Node *n){
      if(n==NULL)return 0;
      return n->childCount;
    }
  };
public:
  Node * root;
  long long int  l,r;
  segmentTree(long long int  l,long long int  r){
    this->l=l;
    this->r=r;
    root=NULL;
  }
  void insert(long long int  key,long long int  value){
    root=insert_r(root,l,r,key,value);
  }
  void update(long long int  key,long long int value){
    root=insert_r(root,l,r,key,value);
  }
  void deleteKey(long long int key){
    root=insert_r(root,l,r,key,0);
  }
  Node*insert_r(Node * root,long long int  l,long long int  r,long long int  k,long long int  value){
    if(root==NULL) root=new Node();
    if(l==r){
        root->updateValue(value);
        return root;
    }
    long long int  mid=(l+r)/2;
    if(k>mid)root->right=insert_r(root->right,mid+1,r,k,value);
    else root->left=insert_r(root->left,l,mid,k,value);
    root->value=max(Node::getValue(root->left),Node::getValue(root->right));
    root->childCount=Node::getChildCount(root->left)+Node::getChildCount(root->right);
    return root;
  }

  long long int  search(long long int  key){
    return search_r(root,l,r,key);
  }
  long long int  search_r(Node * root,long long int  l,long long int  r,long long int  k){
    if(root==NULL)return INT_MIN;
      if(l==r){
        return root->value;
      }
      long long int  mid=(l+r)/2;
      if(k>mid)return search_r(root->right,mid+1,r,k);
      else return search_r(root->left,l,mid,k);
      return INT_MIN;
  }
  long long int findElementsBetween(long long int  ql,long long int  qr){
    return findElementsBetween_r(root,l,r,ql,qr);
  }
  long long int  findElementsBetween_r(Node *root,long long int  l,long long int  r,long long int  ql,long long int  qr){
    if(root==NULL)return 0;
    if(ql<=l&&qr>=r)return Node::getChildCount(root);
    if(ql>r||qr<l)return 0;
    long long int  mid=(l+r)/2;
    return findElementsBetween_r(root->left,l,mid,ql,qr)+findElementsBetween_r(root->right,mid+1,r,ql,qr);
  }
  long long int  RMQ(long long int  ql,long long int  qr){
    return RMQ_r(root,l,r,ql,qr);
  }
  long long int  RMQ_r(Node *root,long long int  l,long long int  r,long long int  ql,long long int  qr){
    if(root==NULL)return INT_MIN;
    if(ql<=l&&qr>=r)return Node::getValue(root);
    if(ql>r||qr<l)return INT_MIN;
    long long int  mid=(l+r)/2;
    return max(RMQ_r(root->left,l,mid,ql,qr),RMQ_r(root->right,mid+1,r,ql,qr));
  }
};
int  main(){
  segmentTree ST(0,1000000000000);
  for(long long int  i=0;i<100000;i++)
  ST.insert(i,i);
  for(long long int  i=7;i<10;i++)
  ST.insert(i,0);
  cout<<ST.findElementsBetween(5,100)<<endl;

}
