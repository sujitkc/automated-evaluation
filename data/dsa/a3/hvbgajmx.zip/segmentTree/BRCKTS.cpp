#include<iostream>
#include<math.h>
#include<limits.h>
using namespace std;

int max(int a,int b){
  if(a>b)return a;
  return b;
}
class segmentTree{
  class data{
  public:
    int open;
    int close;
    data(){
      open=0;
      close=0;
    }
      void merge(data left,data right){
        close=left.close;
        open=right.open;
        int t=left.open-right.close;
        if(t>0)open+=t;
        else close-=t;
    }
  };

  data *tree;
  int size;
  int n;

public:
  segmentTree(char *A, int n){
    int h=(int)(ceil(log2(n)));
    this->size=2*(int)pow(2, h) - 1;
    this->n=n;
    tree=new data[this->size];
    constructTree(A,0,n-1,0);
    viewTree();
  }

  void constructTree(char *A,int l,int r,int i){
    if(l==r){
      if(A[i]=='(')tree[i].open=1;
      else tree[i].close=1;
      return;
    }
    int mid=(l+r)/2;
    constructTree(A,l,mid,2*i+1);
    constructTree(A,mid+1,r,2*i+2);
    data left=tree[2*i+1];
    data right=tree[2*i+2];
    tree[i].merge(tree[2*i+1],tree[2*i+2]);

  }

  int query(int ql,int qr){
  data temp=query_r(0,n-1,0,ql,qr);
  return temp.overAllMax;
  }
  data query_r(int l,int r,int i,int ql,int qr){

    if(l>=ql&&r<=qr){
      return tree[i];
    }
    int mid=(l+r)/2;
    data T;
    if(ql>r||qr<l)return T;
    data left=query_r(l, mid,2*i+1,ql, qr);
    data right=query_r(mid+1,r,2*i+2, ql, qr);
    T.leftMax=max(left.leftMax,right.leftMax+left.total);
    T.rightMax=max(right.rightMax,left.rightMax+right.total);
    T.total=left.total+right.total;
    T.overAllMax=max(left.overAllMax,right.overAllMax);
    int temp=max(T.leftMax,T.rightMax);
    T.overAllMax=max(T.overAllMax,temp);
    T.overAllMax=max(T.overAllMax,left.rightMax+right.leftMax);
    return T;

  }
  void viewTree(){
      for(int i=0;i<size;i++)
        cout<<tree[i].close<<" "<<tree[i].open<<endl;
      cout<<endl;
  }
};

int main(){

  while(1){
    int n;
    cin >>n;
    if(n==0)break;
    char word[n+1];
    cin>>word;
    segmentTree ST(word,n);
  }

}
