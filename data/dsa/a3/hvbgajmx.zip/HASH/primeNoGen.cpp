#include<iostream>
using namespace std;
int main(){
  int arr[1000000]={0};
  int n=10000;
  for(int i=2;i<n;i++){
    if(arr[i]==0){
      cout<<i<<",";
      for(int j=i;j<n;j+=i){
        arr[j]=1;
      }
    }
  }
}
