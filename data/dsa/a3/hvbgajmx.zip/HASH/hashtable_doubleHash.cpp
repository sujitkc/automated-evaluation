#include<iostream>
#include<stdlib.h>
#include<time.h>

using namespace std;


class hashTable{

  int *table;
  int randomKey;
  int randomKey2;
  int size;
public:
  hashTable(int size=100){
    this->size=size;
    table=new int[size];
    for(int i=0;i<size;i++)table[i]=0;
    srand(time(0));
    randomKey=rand();
    randomKey2=rand();
  }
  ~hashTable(){
    delete[] table;
  }
  int hashfn(int k){
    return (k*2654435761+randomKey)%size;
  }
  int hashfn2(int k){
    return (k*2654435761+randomKey2)%size;
  }
  void insert(int k){
    int hashedIndex=hashfn(k);
    int hashedIndex2=hashfn2(k);
    int i;

    for(i=0;i<size;i++){
      if(table[(hashedIndex+i*hashedIndex2)%size]<=0){
        table[(hashedIndex+i*hashedIndex2)%size]=k;
        // cout<<k<<" entered successfully\n";
        break;
      }
    }
    if(i==size)cout<<"TABLE FULL!\n";
  }

  bool deleteKey(int k){
    int hashedIndex=hashfn(k);
    int hashedIndex2=hashfn2(k);
    int i;
    for(i=0;i<size;i++){
      if(table[(hashedIndex+i*hashedIndex2)%size]==k){
        table[(hashedIndex+i*hashedIndex2)%size]=-1;
        return true;
      }
      else if(table[(hashedIndex+i*hashedIndex2)%size]==0)return false;
    }
    return false;
  }
  bool search(int k){
    int hashedIndex=hashfn(k);
    int hashedIndex2=hashfn2(k);
    int i;
    for(i=0;i<size;i++){
      if(table[(hashedIndex+i*hashedIndex2)%size]==k){
        return true;
      }
      else if(table[(hashedIndex+i*hashedIndex2)%size]==0)return false;
    }
    return false;
  }
  void viewTable(){
    for(int i=0;i<size;i++)
      cout<<table[i]<<" ";
    cout<<endl;
  }
};


int main(){
  hashTable h1;
  for(int i=1;i<=60;i++)
    h1.insert(i);
  for(int i=30;i<=50;i++)
      h1.deleteKey(i);
  h1.viewTable();

  for(int i=25;i<=75;i++)
    cout<<h1.search(i)<<" ";

}
