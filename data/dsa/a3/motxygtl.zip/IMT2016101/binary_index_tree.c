#include<stdio.h>
#include<stdlib.h>

int b[20];

int update(int i,int *a,int x,int n){ //cummulative sum
int j,sum=0;
while(i<=n){
sum=sum+a[i];
j=i & -i;
i=i+j;
b[i]=b[i]+sum;
}
}
/*
int prefix_sum(int i,int *a,int x,int n){
int sum=0,j;
while(i>0){
sum=sum+update(i,a,a[i],n);
j=i & -i;
i=i-j;
}
return sum;
}
*/
int main(){
int i,n;
scanf("%d",&n);
int a[n];
for(i=1;i<=n;i++){
	scanf("%d",&a[i]);	
	update(i,a,a[i],n);
}

for(i=1;i<=n;i++){
	printf("%d\n",b[i]);	
}
/*printf("The element's position to be updated and the element by the which got updated:");
int x,k;
scanf("%d,%d",&x,&k);
update(int k,int x);
*/
}
 
