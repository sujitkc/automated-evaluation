#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<limits.h>

void updatetree(int BIT[],int i,int x,int n)
{
    while(i<n)
	{
		BIT[i]=BIT[i]+x;
		int j=i+1&(-(i+1));
		i=i+j;
	}
}

void makeTree(int BIT[],int arr[],int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		updatetree(BIT,i,arr[i],n);
	}
}

int FindCumSum(int BIT[],int i)
{
	int s=0;
	while(i>=0)
	{
		s=s+BIT[i];
		int j=i+1&(-(i+1));
		i=i-j;
	}
	return s;
}
int RSQbaba(int BIT[],int start,int end)
{
	return FindCumSum(BIT,end)-FindCumSum(BIT,start-1);
}


int main()
{
	int n,i;
	printf("Please enter the size of the array\n");
	scanf("%d",&n);
	int arr[n],BIT[n];
	printf("Please enter the elements of the array\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",arr+i);
		BIT[i]=0;
	}
	makeTree(BIT,arr,n);
	//MENU
	while(1)
	{
		printf("1. UPDATE\n2. Find RSQ\n3. Print Binary Index tree\n4. Print array\n");
		int choice;
		scanf("%d",&choice);
		if(choice==1)
		{
			printf("Enter index to be updated\n");
			scanf("%d",&i);
			int value;
			printf("Enter value\n");
			scanf("%d",&value);
			arr[i]+=value;
			updatetree(BIT,i,value,n);
			printf("Value updated\n");
		}
		else if(choice == 2)
		{
			printf("Enter start index\n");
			int start;
			scanf("%d",&start);
			printf("Enter end index\n");
			int end;
			scanf("%d",&end);
			printf("RSQ between %d and %d is %d\n",start,end,RSQbaba(BIT,start,end));

		}
		else if(choice==3)
		{
			for(i=0;i<n;i++)
				printf("%d ",BIT[i] );
			printf("\n");
		}
		else if(choice==4)
		{
			for(i=0;i<n;i++)
				printf("%d ",arr[i]);
			printf("\n");
		}
		else
		{
			break;
		}
	}


}

