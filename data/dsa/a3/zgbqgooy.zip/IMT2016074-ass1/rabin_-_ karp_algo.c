#include<stdio.h>
#include<string.h>
#include<math.h>
#include<limits.h>
 
#define d 256
 
void rhash(char pattern[], char text[], int q12)
{
    int M,N,i,j,p,t,h;
	M=strlen(pattern);
    N=strlen(text);
    p=0;
    t=0;
    h=1;
    for(i=0;i<M-1;i++)
    {
    	h=(h*d)%q12;
	}
    for(i=0;i<M;i++)
    {
        p=(d*p+pattern[i])%q12;
        t=(d*t+text[i])%q12;
    }
    for(i=0;i<=N-M;i++)
    {
    	if(p==t)
        {
            for (j=0;j<M;j++)
            {
                if (text[i+j]!=pattern[j])
                {
                	break;
				}
            }
            if(j==M)
            {
            	printf("The required pattern found at index %d \n", i);
			}
        }
        if(i<N-M)
        {
            t=(d*(t-text[i]*h)+text[i+M])%q12;
            if(t<0)
            {
            	t=t+q12;
			}
            
        }
    }
}

int main()
{
	int i,j,qq=101;char c;
	char reqtext[100],reqpattern[100];
	printf("\n Please enter the required text for hashing\n");
	scanf("%s",reqtext);
	printf("\n Please enter the required pattern for hashing\n");
	scanf("%s",reqpattern);
	printf("\n");
    rhash(reqpattern,reqtext,qq);
    return 0;
}
