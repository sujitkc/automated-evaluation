#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<limits.h>

int min(int a,int b)
{
	return (a<b)?a:b;
}

void update_tree(int a[],int st[],int i,int j,int idx,int val,int pos)
{
	if (i==j)
	{
		a[idx]=val;
		st[pos]=val;
		printf("pos=%d\n",pos );
	}
	else
	{
		int mid=(i+j)/2;
		if (i<=idx && idx<=mid)
		{
			update_tree(a,st,i,mid,idx,val,2*pos+1);
		}
		else
		{
			update_tree(a,st,mid+1,j,idx,val,2*pos+2);
		}
		st[pos]=min(st[2*pos+1],st[2*pos+2]);
	}
}

void build_segment_tree(int a[],int st[],int i,int j, int pos)
{
	if (i==j)
	{
		st[pos]=a[i];
		return;
	}
	int mid=i + (j -i)/2;
	build_segment_tree(a,st,i,mid,2*pos+1);
	build_segment_tree(a,st,mid+1,j,2*pos+2);
	st[pos]=min(st[2*pos+1],st[2*pos+2]);
}

int query_for_min_range(int st[],int n,int i,int j,int qi,int qj,int pos)
{
	if (qi<0||qj>n||qi>qj)
	{
		printf("Invalid Input");
		return -1;
	}
	else
	{
		if(qi<=i && qj>=j)
		{
			return st[pos];
		}
		if(j<qi || i>qj)
		{
			return INT_MAX;
		}
		int mid=i+(j-i)/2;
		return min(query_for_min_range(st,n,i,mid,qi,qj,2*pos+1),query_for_min_range(st,n,mid+1,j,qi,qj,2*pos+2));
	}
}

int main(int argc, char const *argv[])
{
	int n,i;
	scanf("%d",&n);
	int a[n];
	for (i=0;i<n;++i)
	{
		scanf("%d",&a[i]);
	}
	int h=ceil(log2(n));
	int max_size=2*pow(2,h)-1;
	int st[max_size];
	build_segment_tree(a,st,0,n-1,0);
	puts("\n");
	int qi,qj;
	printf("Please enter the range for which minimum has to be calculated: ");
	scanf("%d %d",&qi,&qj);
	int rmq=query_for_min_range(st,n,0,n-1,qi,qj,0);
	printf("Minimum for this range: %d\n",rmq );
	puts("");
	update_tree(a,st,0,n-1,1,-10,0);
	int qi1,qj1;
	printf("Please enter Range for which minimum has to be calculated: ");
	scanf("%d %d",&qi1,&qj1);
	int rmq123=query_for_min_range(st,n,0,n-1,qi1,qj1,0);
	printf("The minimum for this range: %d\n",rmq123);
	puts("");
	return 0;
}
