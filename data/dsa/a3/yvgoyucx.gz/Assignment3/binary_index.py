seg = [1,2,3,4,5,6,7,8,9]
def sum(arr,idx):
    result = 0
    idx= idx+1
    while idx:
        result += arr[idx]
        idx -= idx & (-idx)
    return result
def updatetree(bit,n,i,v):
    i +=1
    while i<=n:
        bit[i]= bit[i]+v;
        i+=i & (-i)
def construct(arr,n):
    bit= [0]*(n+1)
    for i in range(n):
        updatetree(bit,n,i,arr[i])

    return bit
def sumindex(arr,i,j):
    a=0
    a=sum(arr,j)-sum(arr,i)
    return a

freq=[1,3,2,5,6,8,9,2,7]
bit=construct(freq,len(freq))
print ("sum from 0,5 :"+ str(sum(bit,8)))
print sumindex(bit,2,5)
