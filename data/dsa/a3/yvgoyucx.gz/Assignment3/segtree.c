#include <stdio.h>
#include <limits.h>
#include<stdlib.h>
int min(int x, int y){
  if (x>y){
    return y;
  }
  else
    return x;
}

void make_segtree(int n[],int segtree[], int low,int high, int pos){
  if(low==high){
    segtree[pos]=n[low]; return ;
  }
    int mid = (low + high)/2;
    make_segtree(n,segtree,low,mid,(2*pos)+1);
    make_segtree(n,segtree,mid+1,high,(2*pos)+2);
    segtree[pos]=min(segtree[(2*pos)+1],segtree[(2*pos)+2]);
}
int RMQ(int segtree[],int l, int h, int low, int high, int pos){
  if (l<=low && h>=high) //perfect overlap
    return segtree[pos];
  if( l>high || h<low){//no overlap
  return INT_MAX;}
  int mid = (low + high)/2;
  return min(RMQ(segtree,l,h,low,mid,(2*pos)+1),RMQ(segtree,l,h,mid+1,high,(2*pos)+2));
}

int main(){
  int n[]={1,4,2,5,6,3};
  int k;
  int size=sizeof(n)/sizeof(int);
  k = 2*4-1;
  int segtree[k];
  int i;
  for(i=0;i<k;i++)segtree[i]=INT_MAX;
  make_segtree(n,segtree,0,size-1,0);

  for(i=0; i<k;i++){
    printf("%d\n",segtree[i] );
  }
  printf("The min is: %d\n",RMQ(segtree,3,4,0,size-1,0));
  return 0;
}
