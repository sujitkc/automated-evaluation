#include <stdio.h>
#include <stdlib.h>
struct node{
	int key;
	struct node *left, *right;

};
struct node *newnode(int x){
	struct node *temp= malloc(sizeof(struct node));
	temp->key= x;
	temp->left=NULL;
	temp->right=NULL;
	return temp;
}
struct node *search(struct node * root, int y){
	if (root ==NULL || root->key==y)
	return root;
	if(y<root->key)
	
	return search(root->left,y);
		
	
	else if(y>root->key)
	
	return search(root->right,y);
			
}
void inorder(struct node *root)
{
	if (root!=NULL)
	{
	inorder (root->left);
	printf("%d ",root->key);
	inorder(root->right);
	}
}

void deletenode(struct node *root,int x){
	struct node *temp= malloc(sizeof(struct node));
	if(x==root->key && root->left==NULL && root->right==NULL)
	{
	free(*root);	
	}
	if(x==root->key && root->left==NULL)
	{
			temp=root->right;
			free(*root);
			root = temp;
	}
	if(x==root->key && root->right==NULL)
	{
			temp=root->left;
			free(*root);
			root = temp;
	}
	if(x==root->key && root->left!=NULL && root->right!=NULL)
	{
		
	}
	
}
struct node *insertnode(struct node * node,int x){
	if(node==NULL)
		{
			return newnode(x);
		}
	if(x<node->key)
		{
			node->left = insertnode(node->left,x);
		}
	else if (x>node->key)
		{
			node->right = insertnode(node->right,x);
		}
		
	return node;
}
int main(){
	struct node *root = NULL;
    root = insertnode(root, 50);
    insertnode(root, 30);
    insertnode(root, 20);
    insertnode(root, 40);
    insertnode(root, 70);
    insertnode(root, 60);
    insertnode(root, 80);
	
	inorder(root);
	if (search(root,70)==NULL)
	printf("\n0");
	else printf("\n1");
	
	return 0;	
}
