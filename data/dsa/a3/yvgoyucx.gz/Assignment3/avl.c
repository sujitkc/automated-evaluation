#include<stdio.h>
#include<stdlib.h>

struct node{
  int key;
  struct node *left;
  struct node *right;
  int height;
};

int max(int a, int b){
  return (a>b)? a : b;
}
int height(struct node *n){
  if(n==NULL)
  return 0;
  else
    return n->height;
}

struct node *newnode(int key){
  struct node *newnode= (struct node*)malloc(sizeof(struct node));
  newnode->key = key;
  newnode->left = NULL;
  newnode->right = NULL;
  newnode->height = 1; // as a new node is added at the leaf position
  return (newnode);
}

struct node *rightrotate(struct node *y){
    struct node *x = y-> left;
    struct node *T2 = x->right;
    x->right = y;
    y->left = T2;
    y->height = max(height(y->left),height(y->right))+1;
    x->height = max(height(x->left),height(x->right))+1;
    return x;
}
struct node *leftrotate(struct node *x){
  struct node *y = x->right;
  struct node *T2 = y->left;
  y->left = x;
  x->right= T2;
  x->height = max(height(x->left),height(x->right))+1;
  y->height = max(height(y->left),height(y->right))+1;
  return y;
}
int getbalance(struct node *n){
  if(n==NULL)
    return 0;
  return height(n->left) - height(n->right);
}

struct node *insertnode(struct node* n, int key){
  if(n==NULL)
    return(newnode(key));

  if(key < n->key)
    n->left = insertnode(n->left,key);
  else if(key > n->key)
    n->right = insertnode(n->right,key);
  else
    return n;
  n->height = 1+ max(height(n->left),height(n->right));

  int bal = getbalance(n);
  if(bal > 1 && key < n->left->key)
    return rightrotate(n);
  if(bal < -1 && key > n->right->key)
    return leftrotate(n);
  if(bal > 1 && key > n->left->key){

    n->left = leftrotate(n->left);
      return rightrotate(n);
  }
  if (bal < -1 && key < n->left->key){
    n->right = rightrotate(n->right);
      return leftrotate(n);
  }
  return n;
}
void preorder(struct node *root){
  if(root != NULL)
  {
    printf("%d\n",root->key);
    preorder(root->left);
    preorder(root->right);
  }
}
struct node* deletenode(struct node *root, int key){
  if(root == NULL)
    return root;
  if (key < root->key)
    root->left = deletenode(root->left,key);
  else if (key> root->key)
    root->right = deletenode(root->right,key);
  else {
    //node with one or no child
    if((root->left = NULL) || (root->right = NULL)){
      struct node *temp = root->left? root->left : root->right;
      if(temp == NULL){
        temp = root;
        root = NULL;
      }
      else
      *root = *temp;
      free(temp);

  }
  else {
    struct node *temp = minvalnode(root->right);
    root->key = temp->key;
    root->right = deletenode(root->right, temp->key);


  }
}
if(root == NULL)
  return root;
  root->height = 1 + max(height(root->left),root->right);
  int bal = getbalance(root);

    // If this node becomes unbalanced, then there are 4 cases

    // Left Left Case
    if (bal > 1 && getbalance(root->left) >= 0)
        return rightrotate(root);

    // Left Right Case
    if (bal > 1 && getbalance(root->left) < 0)
    {
        root->left =  leftrotate(root->left);
        return rightrotate(root);
    }

    // Right Right Case
    if (bal < -1 && getbalance(root->right) <= 0)
        return leftrotate(root);

    // Right Left Case
    if (bal < -1 && getbalance(root->right) > 0)
    {
        root->right = rightrotate(root->right);
        return leftrotate(root);
    }

    return root;
}

int main() {

  struct node *root=NULL;

  root = insertnode(root, 10);
  root = insertnode(root, 20);
  root = insertnode(root, 32);
  root = insertnode(root, 40);
  root = insertnode(root, 50);
  root = insertnode(root, 25);

  preorder(root);
  return 0;
}
