#include<iostream>
#include<string.h>
using namespace std;

long long int  stringMatches(char *str,char *pattern){
  long long int  len1=strlen(str);
  long long int  len2=strlen(pattern);
  long long int  matches=0;
  long long int  x=0;
  long long int  y=0;
  long long int  h=1;
  long long int  p=9967;;
  for(long long int  i=0;i<len2;i++){
    x=pattern[i] +256*x;
    y=str[i] +256*y;
    if(i)h*=256;
    x%=p;
    y%=p;
    h%=p;
  }
  for(long long int  i=len2;i<=len1;i++){
    if(x==y){
      long long int  j;
      for( j=0;j<len2;j++)
        if(pattern[j]!=str[j+i-len2])break;
      if(j==len2)matches++;
    }
    y=((y-h*(str[i-len2])+h*p)*256+str[i])%p;

  }
  return matches;
}

int  main(){
  char str1[]="asasasasasasasasddfsdfjsdkfhkdsfjsdfsdfljasd";
  char pattern[]="jasd";
  cout<<stringMatches(str1,pattern);
}
