#include<iostream>
#include<stdlib.h>
#include<time.h>
using namespace std;


class hashTable2{
  int n;
  int size;
  int a;
  int b;
  int prime;
  int *hashTable;
  int hashfn(int k){
    return ((k*a+b)%prime)%size;
  }
public:
  hashTable2(int *arr,int n){
    prime=463003;
    this->n=n;
    this->size=n*n;
    hashTable=new int[size];
    int i;
    do{
      for(int j=0;j<size;j++)hashTable[j]=0;
      a=rand()%(prime-1)+1;
      b=rand()%prime;
      for(i=0;i<n;i++){
        int index=hashfn(arr[i]);
        if(hashTable[index])break;
        else hashTable[index]=arr[i];
      }
    }while(i!=n );
  }
  bool search(int key){
    if(size==0)return false;
    if(hashTable[hashfn(key)]==key)return true;
    return false;
  }
};

class perfectHashTable{

  int n;
  int size;
  int a;
  int b;
  int prime;
  int hashfn(int k){
    return ((k*a+b)%prime)%size;
  }
  hashTable2** hashTable;
public:
  perfectHashTable(int *arr,int n){
    prime=463003;
    this->n=n;
    size=2*n;

    int HashTableCollisions[size];
    int sigma;
    do{
      sigma=0;
      a=rand()%(prime-1)+1;
      b=rand()%prime;
      for(int i=0;i<size;i++)HashTableCollisions[i]=0;
      for(int i=0;i<n;i++)
        HashTableCollisions[hashfn(arr[i])]++;
      for(int i=0;i<size;i++)
        sigma+=HashTableCollisions[i]*HashTableCollisions[i];
    }while(sigma>2*n);

    for(int i=0;i<size;i++)cout<<HashTableCollisions[i];
    int *hashTableElements[size];

    for(int i=0;i<size;i++)
      hashTableElements[i]=new int[HashTableCollisions[i]];

    int indexList[size];
    for(int i=0;i<size;i++)indexList[i]=0;

    for(int i=0;i<n;i++){
      int index=hashfn(arr[i]);
      hashTableElements[index][indexList[index]++]=arr[i];
    }

    hashTable = new hashTable2*[size];
    for(int i=0;i<size;i++){
      hashTable[i]=new hashTable2(hashTableElements[i],HashTableCollisions[i]);
    }
    for(int i=0;i<size;i++)
      delete[] hashTableElements[i];
  }

  bool search(int key){
    return hashTable[hashfn(key)]->search(key);
  }


};

int main(){
  srand(time(0));
  int arr[1000];
  for(int i=0;i<1000;i++)arr[i]=i+2;

  int n=sizeof(arr)/sizeof(int);

  perfectHashTable PHT(arr,n);
  for(int i=0;i<100;i++)
  cout<<PHT.search(i);



}
