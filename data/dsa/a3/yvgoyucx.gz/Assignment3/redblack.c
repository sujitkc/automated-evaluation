#include<stdio.h>
#include<stdlib.h>


struct node{
  int key;
  struct node *left;
  struct node *right;
  int height;
  int color;
};

int max(int a, int b){
  return (a>b)? a : b;
}
int height(struct node *n){
  if(n==NULL)
  return 0;
  else
    return n->height;
}

struct node *newnode(int key){
  struct node *newnode= (struct node*)malloc(sizeof(struct node));
  newnode->key = key;
  newnode->left = NULL;
  newnode->right = NULL;
  newnode->height = 1; // as a new node is added at the leaf position
  return (newnode);
}

struct node *rightrotate(struct node *y){
    struct node *x = y-> left;
    struct node *T2 = x->right;
    x->right = y;
    y->left = T2;
    y->height = max(height(y->left),height(y->right))+1;
    x->height = max(height(x->left),height(x->right))+1;
    return x;
}
struct node *leftrotate(struct node *x){
  struct node *y = x->right;
  struct node *T2 = y->left;
  y->left = x;
  x->right= T2;
  x->height = max(height(x->left),height(x->right))+1;
  y->height = max(height(y->left),height(y->right))+1;
  return y;
}
int getbalance(struct node *n){
  if(n==NULL)
    return 0;
  return height(n->left) - height(n->right);
}
struct insert(struct node *n, int key){
  
}

int main() {

  struct node *root=NULL;

  root = insertnode(root, 10);
  root = insertnode(root, 20);
  root = insertnode(root, 32);
  root = insertnode(root, 40);
  root = insertnode(root, 50);
  root = insertnode(root, 25);

  preorder(root);
  return 0;
}
