#include "stdio.h"
#include "stdlib.h"

void update(int x,int val,int BIT[],int n){
	
	x=x+1;
	while(x<=n){
		//printf("hiii\n");
		BIT[x]+=val;
		int j=x&(-x);
		x=x+j;
	}
	//printf("hello\n");
}

int prefix_sum(int i,int BIT[]){
	int s=0;
	int j;
	while(i>0){
		s=s+BIT[i];
		j=i&(-i);
		i=i-j;
	}
	return s;
}

int main()
{
	int n;
	scanf("%d",&n);
	int a[n];
	int BIT[n+1];
	for (int i = 0; i < n+1; ++i)
	{
		BIT[i]=0;
	}
	for (int i = 0; i < n; ++i)
	{
		scanf("%d",&a[i]);
		update(i,a[i],BIT,n);
	}
	for (int i = 1; i < n+1; ++i)
	{
		printf("%d\n",BIT[i]);
	}
	int aa,b;
	//printf("%d\n",prefix_sum(3,BIT)-prefix_sum(2,BIT) );
	printf("Enter the range: " );
	scanf("%d %d",&aa,&b);
	printf("\nSUM=%d\n",prefix_sum(b,BIT)-prefix_sum(aa-1,BIT));

	return 0;
}