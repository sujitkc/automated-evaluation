#include<stdio.h>
#include<stdlib.h>
typedef struct node
{
	int data;
	struct node *left,*right;
	int ht;
	int rn,ln;
}node;
 
node *insert(node *,int);
node *Delete(node *,int);
void preorder(node *);
void inorder(node *);
int height( node *);
node *rotateright(node *);
node *rotateleft(node *);
node *RR(node *);
node *LL(node *);
node *LR(node *);
node *RL(node *);
int BF(node *);
int rightnodes(node *);
int leftnodes(node *);
int Rank(int,node *);
int FindRank(int,node*);
 
int main()
{
	node *root=NULL;
	int x,n,i,op;
	root = insert(root,1);
	root = insert(root,2);
	root = insert(root,3);
	root = insert(root,4);
	root = insert(root,5);
	root = insert(root,6);
	root = insert(root,7);
	root = insert(root,8);
	root = insert(root,9);
	root = insert(root,10);
	root = Delete(root,4);
	preorder(root);
	printf("\n");
	inorder(root);
	printf("\n%d %d %d\n",Rank(10,root),Rank(5,root),Rank(2,root));
	printf("%d %d %d\n",FindRank(1,root),FindRank(6,root),FindRank(8,root));
	return 0;
}
 
node * insert(node *T,int x)
{
	if(T==NULL)
	{
		T=(node*)malloc(sizeof(node));
		T->data=x;
		T->left=NULL;
		T->right=NULL;
	}
	else if(x > T->data)        // insert in right subtree
	{
		T->right=insert(T->right,x);
		if(BF(T)==-2)
		{
			if(x>T->right->data)
			{
				T=RR(T);
			}
			else
			{
				T=RL(T);
			}
		}
	}
	else if(x<T->data)
	{
		T->left=insert(T->left,x);
		if(BF(T)==2)
		{	
			if(x < T->left->data)
			{
				T=LL(T);
			}
			else
			{
				T=LR(T);
			}
		}
	}
	T->ht=height(T);
	T->rn = rightnodes(T);
	T->ln = leftnodes(T);
	return(T);
}
 
node * Delete(node *T,int x)
{
	node *p;
	
	if(T==NULL)
	{
		return NULL;
	}
	else if(x > T->data)        // insert in right subtree
	{
		T->right=Delete(T->right,x);
		if(BF(T)==2)
		{
			if(BF(T->left)>=0)
			{
				T=LL(T);
			}
			else
			{
				T=LR(T);
			}
		}
	}
	else if(x<T->data)
	{
		T->left=Delete(T->left,x);
		if(BF(T)==-2)    //Rebalance during windup
		{
			if(BF(T->right)<=0)
			{	
				T=RR(T);
			}
			else
			{	
				T=RL(T);
			}
		}
	}
	else
	{
		//data to be deleted is found
		if(T->right!=NULL)
		{    //delete its inorder succesor
			p=T->right;
			
			while(p->left!= NULL)
			{	
				p=p->left;
			}
			T->data=p->data;
			T->right=Delete(T->right,p->data);
			
			if(BF(T)==2)//Rebalance during windup
			{	
				if(BF(T->left)>=0)
				{	
					T=LL(T);
				}
				else
				{
					T=LR(T);
				}
			}
		}
		else
		{
			return(T->left);
		}
	}
	T->ht=height(T);
	T->rn = rightnodes(T);
	T->ln = leftnodes(T);
	return(T);
}
 
int height(node *T)
{
	int lh,rh;
	if(T==NULL)
	{
		return(0);
	}
	if(T->left==NULL)
	{
		lh=0;
	}
	else
	{	
		lh=1+T->left->ht;
	}	
	if(T->right==NULL)
	{
		rh=0;
	}
	else
	{	
		rh=1+T->right->ht;
	}
	if(lh>rh)
	{
		return(lh);
	}
	return(rh);
}
 
node * rotateright(node *x)
{
	node *y;
	y=x->left;
	x->left=y->right;
	y->right=x;
	x->ht=height(x);
	y->ht=height(y);
	x->rn = rightnodes(x);
	x->ln = leftnodes(x);
	y->rn = rightnodes(y);
	y->ln = leftnodes(y);
	return(y);
}
 
node * rotateleft(node *x)
{
	node *y;
	y=x->right;
	x->right=y->left;
	y->left=x;
	x->ht=height(x);
	y->ht=height(y);
	x->rn = rightnodes(x);
	x->ln = leftnodes(x);
	y->rn = rightnodes(y);
	y->ln = leftnodes(y);
	return(y);
}
 
node * RR(node *T)
{
	T=rotateleft(T);
	return(T);
}
 
node * LL(node *T)
{
	T=rotateright(T);
	return(T);
}
 
node * LR(node *T)
{
	T->left=rotateleft(T->left);
	T=rotateright(T);
	
	return(T);
}
 
node * RL(node *T)
{
	T->right=rotateright(T->right);
	T=rotateleft(T);
	return(T);
}
 
int BF(node *T)
{
	int lh,rh;
	if(T==NULL)
	{	
		return(0);
 	}
	if(T->left==NULL)
	{	
		lh=0;
	}
	else
	{	
		lh=1+T->left->ht;
 	}
	if(T->right==NULL)
	{	
		rh=0;
	}
	else
	{
		rh=1+T->right->ht;
 	}
	return(lh-rh);
}
 
void preorder(node *T)
{
	if(T!=NULL)
	{
		printf("%d(rn = %d,ln = %d)",T->data,T->rn,T->ln);
		preorder(T->left);
		preorder(T->right);
	}
}
 
void inorder(node *T)
{
	if(T!=NULL)
	{
		inorder(T->left);
		printf("%d(rn = %d,ln = %d)",T->data,T->rn,T->ln);
		inorder(T->right);
	}
}
int rightnodes(node *T)
{
	if(T->right == NULL)
	{
		return 0;
	}
	else
	{
		return rightnodes(T->right) + leftnodes(T->right) + 1;
	}
}
int leftnodes(node *T)
{
	if(T->left == NULL)
	{
		return 0;
	}
	else
	{
		return leftnodes(T->left) + rightnodes(T->left) + 1;
	}
}
int Rank(int x, node * T)
{
	int rank = 0,flag = 0;
	while(T != NULL)
	{
		if(T->data == x)
		{
			flag = 1;
			rank += T->rn + 1;
			break;
		}
		else if(T->data > x)
		{
			rank += T->rn + 1;
			T = T->left;
		}
		else
		{
			T = T->right;
		}
	}
	if(flag == 0)
	{
		return -1;
	}
	return rank;
}
int FindRank(int x, node *  T)
{
	int add = 0,flag = 0;
	while(T!=NULL)
	{
		if(x == T->rn + add + 1)
		{
			flag = 1;
			break;
		}
		else if(x > T->rn + add + 1)
		{
			add += T->rn + 1;
			T = T->left;
		}
		else
		{
			T = T->right;	
		}
	}
	if(flag == 0)
	{
		return -1;
	}
	return T->data;
}
