#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
	int m,n;
	char P[10000],T[10000];
	scanf("%s",T);
	scanf("%s",P);
	m=strlen(P);
	n=strlen(T);
	int x=0,y=0,h=1,p=60077;
	for (int i = 0; i < m; ++i)
	{
		x=(2*x+(P[i]-48))%p;
		y=(2*y+(T[i]-48))%p;
		if(i<m-1)
			h=(2*h)%p;
	}
	printf("x = %d, y = %d, h = %d\n",x,y,h);
	int flag=0;
	for (int i = 0; i < n-m; ++i)
	{
		if (x==y)
			{
				int j;
				for (j = 0; j < m; ++j)
				{
					if(P[j]!=T[i+j])
						break;						
				}
				if(j==m)
					{
						flag=1;
						printf("Match at %d\n",i);
						break;
					}			
			}
		y = (2*(y-h*(T[i]-48))+(T[i+m]-48))%p;
		if(y < 0)
			y+=p;
	}
	if (flag==0)
		printf("No Match\n");
	return 0;
}
 