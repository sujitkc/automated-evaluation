#include "stdio.h"
#include "stdlib.h"
#include <math.h>
#include "limits.h"

struct node
{
	int a;
	int b;
    int m;
    int *c;
};

int prime_no[]={3343, 3347, 3359, 3361, 3371, 3373, 3389, 3391, 3407, 3413, 3433, 3449, 3457, 3461, 3463, 3467, 3469, 3491, 3499, 3511, 3517, 3527, 3529, 3533, 3539, 3541, 3547, 3557, 3559, 3571, 3581, 3583, 3593, 3607, 3613, 3617, 3623, 3631, 3637, 3643, 3659, 3671, 3673, 3677, 3691, 3697, 3701, 3709, 3719, 3727};

int hashfunc(int k,int a,int b,int m,int p){
    return ((a*k+b)%p)%m;
}

void hash(int arr[],struct node* hashtable[],int n,int m,int a,int b,int p){   
    int aa[m];
    for (int i = 0; i < m; ++i)
    {
        aa[i]=0;
    }
    for (int i = 0; i < n; ++i)
    {
        aa[hashfunc(arr[i],a,b,m,p)]++;
        //printf("%d ",hashfunc(arr[i],a,b,m,p) );
    }
    //printf("\n");
    /*for (int i = 0; i < n; ++i)
    {
        printf("%d ",aa[i] );
    }*/
    for (int i = 0; i < m; ++i)
    {
        int poww=pow(aa[i],2);
        hashtable[i]=(struct node*)malloc(sizeof(struct node));
        hashtable[i]->m=poww;
        hashtable[i]->a=(rand()%100+1);
        hashtable[i]->b=(rand()%100+1);
        hashtable[i]->c=malloc(sizeof(int)*hashtable[i]->m);
        for(int j=0;j<hashtable[i]->m;j++){
            hashtable[i]->c[j]=INT_MIN;
            printf("%d ",hashtable[i]->c[j] );
        }
        puts("");
    }

    for (int i = 0; i < n; ++i)
    {
        int hf=hashfunc(arr[i],a,b,m,p);
        hashtable[hf]->c[hashfunc(arr[i],hashtable[hf]->a,hashtable[hf]->b,hashtable[hf]->m,p)]=arr[i];
           // int pp=hashtable[hf]->c[hashfunc(arr[i],hashtable[hf]->a,hashtable[hf]->b,hashtable[hf]->m,p)];
           // printf(" %d      %d ",pp,hashfunc(arr[i],hashtable[hf]->a,hashtable[hf]->b,hashtable[hf]->m,p) );    
        
        
    }

    //printf("\n");
}

int search(struct node* hashtable[],int x,int m,int a,int b,int p){
    int hf=hashfunc(x,a,b,m,p);
    if (hashtable[hf]->m!=0)
    {
        if (hashtable[hf]->c[hashfunc(x,hashtable[hf]->a,hashtable[hf]->b,hashtable[hf]->m,p)]==x){
            return 1;
        }        
    }
    return 0;
}

int main()
{
    int n;
    scanf("%d",&n);
    int arr[n];
    for (int i = 0; i < n; ++i)
    {
        scanf("%d",&arr[i]);
    }
    struct node* hashtable[n];
    int m=n;
    int p=prime_no[rand()%50];
    int a=rand()%(p-1)+1;
    int b=rand()%(p-1)+1;
    
    hash(arr,hashtable,n,m,a,b,p);
    int ele;
    printf("Enter element to be searched: ");
    scanf("%d",&ele);
    for (int j = 0; j < m; ++j)
    {
    
        for (int i = 0; i < hashtable[j]->m; ++i)
        {
            printf("%d ",hashtable[j]->c[i] );
        }
        printf("\n");
    }
    
    int ss=search(hashtable,ele,m,a,b,p);
    printf("%d\n",ss );
    return 0;
}
