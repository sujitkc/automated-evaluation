
class Graph:
  def __init__(self):
    self.nodes = set()
    self.edges = {}
    self.distances = {}
    #self.check=False

  def add_node(self, value):
    self.nodes.add(value)
    self.check=False

  def add_edge(self, from_node, to_node, distance):
    #self.edges.append((from_node,weight,to_node))
    if  self.edges[from_node]==None:
      self.edges[from_node]=[]
    self.edges[from_node].append(to_node)
    if  self.edges[to_node]==None:
      self.edges[to_node]=[]
    self.edges[to_node].append(from_node)
    self.distances[(from_node, to_node)] = distance

def check_node(node,graph):
    Dv_1_n,Dp_1_n=dijsktra(graph,1)
    Dv_n_v,Dp_n_v=dijsktra(graph,n)
    if Dv_1_n[n]==Dv_1_n[node]+Dv_n_v[node]:
      graph.add_node.check=True


def dijsktra(graph, initial):
  visited = {initial: 0}
  path = {}

  nodes = set(graph.nodes)

  while nodes: 
    min_node = None
    for node in nodes:
      if node in visited:
        if min_node is None:
          min_node = node
        elif visited[node] < visited[min_node]:
          min_node = node

    if min_node is None:
      break

    nodes.remove(min_node)
    current_weight = visited[min_node]

    for edge in graph.edges[min_node]:
      weight = current_weight + graph.distance[(min_node, edge)]
      if edge not in visited or weight < visited[edge]:
        visited[edge] = weight
        path[edge] = min_node

  return visited, path

def new_dijsktra(graph,intitial):
  visited = {initial: 0}
  path = {}

  nodes = set(graph.nodes)

  #Dv_1_n,Dp_1_n=dijsktra(graph,1)
  #Dv_n_v,Dp_n_v=dijsktra(graph,n)

  while nodes: 
    nodes_s=nodes
    min_node = None
    for node in nodes_s:
      if node in visited:
        check_node(node,graph)
        if min_node is None:
          min_node = node
        elif visited[node] < visited[min_node] and graph.add_node.check==False:
          min_node = node
        elif visited[node] < visited[min_node] and graph.add_node.check==True:
          nodes_s.remove(visited[node])

    if min_node is None:
      break

    nodes.remove(min_node)
    current_weight = visited[min_node]

    for edge in graph.edges[min_node]:
      weight = current_weight + graph.distance[(min_node, edge)]
      if edge not in visited or weight < visited[edge]:
        visited[edge] = weight
        path[edge] = min_node

  return visited, path

graph=Graph()
print "Enter the no. of nodes"
n=input()
print "enter the nodes"
for i in range (0,n):
  node=input()
  graph.add_node(node)
print "enter edges (m)"
m=input()
for i in range (0,m):
  from_node, to_node, distance=input()
  graph.add_edge(from_node,to_node,distance)
Dv_1_n,Dp_1_n=dijsktra(graph,1)
Dv_n_v,Dp_n_v=dijsktra(graph,n)
print "enter s and t"
s=input()
t=input()
if new_dijsktra(graph,s):
  print "possible"
else:
  print "no"