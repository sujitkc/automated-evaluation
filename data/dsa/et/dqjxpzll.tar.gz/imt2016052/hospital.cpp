#include <iostream>
#include <stdio.h>
#include <cstdlib>
#include "heap_functions.h"
#include "graph_c2.h"

using namespace std;


void dijkstras(int s,adjacency_matrix graph,int max[])//max keeps track of the max dist to each node
{
	graph.colour_all_red();

	int n = graph.get_size();
	int dest[n];
	int popped = s,flag = 1,h_label = 0;

	int heap_size = 0;
	heap_node* heap[n];
	heap_node* h_temp = make_heap_node(0,s);

	graph_node* g_temp = NULL;

	int pi[n];
	for(int i = 0 ; i < n ; i++)
		pi[i] = 0;

	pi[s] = s;
	while(flag == 1 || heap_size != 0)//since ds is empty initially
	{
		if(heap_size != 0)//flag is 1 on the first pass.ds is empty on the first pass
		{
			delete_node(heap,&heap_size,h_temp);
			popped = h_temp->graph_node_label;		
		}

		flag = 0;

		g_temp = graph.get_pointer_given_index(popped);
		
		if(h_temp->priority > max[popped])//someones shortest path is longer than the one ive seen till now
			max[popped] = h_temp->priority;

		// printf("Visited node %d.Discovered by %d.Distance is %d.\n",popped,pi[popped],h_temp->priority);
		
		g_temp->change_colour('b');

		graph.all_outgoing_edges(popped,dest);
		int i = 0;
		int val = 0;

		// cout << "a\n";
		while(i < n && dest[i] != -1)
		{
			// cout << "e\n";
			g_temp = graph.get_pointer_given_index(dest[i]);
			// cout << "f\n";
			val = h_temp->priority + graph.get_edge_weight(popped,dest[i]);
			// cout << "d\n";
			if(g_temp->get_colour() == 'r')
			{
				pi[dest[i]] = popped;
				insert_node(heap,&heap_size,val,dest[i]);
				g_temp->change_colour('y');
				// cout << "b\n";
			}

			else if(g_temp->get_colour() == 'y')
			{
				h_label = get_heap_label_given_graph_label(heap,&heap_size,dest[i]);
				if(heap[h_label]->priority > val)
				{
					pi[dest[i]] = popped;
					update_node_priority(heap,&heap_size,h_label,val);
				}
				// cout << "c\n";
			}

			i++;
		}
	}

	for(int j = 0 ; j < n ; j++)
	{
		g_temp = graph.get_pointer_given_index(j);
		if(g_temp->get_colour() == 'r')
			max[j] == 50000;//non-discoverable,so not a hospital
	}
}


int hospital(adjacency_matrix graph)
{
	int n = graph.get_size();
	int pos = 0;
	int max[n];
	for(int i = 0 ; i < n ; i++)
		max[i] = -1;

	while(pos < n)
	{
		dijkstras(pos,graph,max);
		pos++;
	}
	
	int min_index = 0;
	for(int i = 0 ; i < n ; i++)
	{
		if(max[i] < max[min_index])
			min_index = i;
	}
	if(max[min_index] == 50000)
		return -1;
	else
		return min_index;
}

int main()
{
	/*int t = 0;
	int nodes = 0 , edges = 0;
	cin >> t;
	for(int cases = 0 ; cases < t ; cases++)
	{
		cin >> nodes >> edges;
		adjacency_matrix graph(nodes);
		for(int i = 0 ; i < nodes ; i++)
			graph.add_node(i);
		for(int i = 0 ; i < edges ; i++)
		{
			int s,e,w;
			cin >> s,e,w;
			graph.add_edge(s,e,w);
		}

		cout << hospital(graph) << endl;
	}*/

	//nodes are indexed from 0

	adjacency_matrix graph(5);
	graph.add_node(0);
	graph.add_node(1);
	graph.add_node(2);
	graph.add_node(3);
	graph.add_node(4);

	graph.add_edge(0,1,28);
	graph.add_edge(0,2,44);
	graph.add_edge(0,3,37);
	graph.add_edge(1,3,10);
	graph.add_edge(2,0,41);
	graph.add_edge(2,1,23);
	graph.add_edge(3,2,13);
	graph.add_edge(4,0,30);

	cout << hospital(graph) << endl;
}