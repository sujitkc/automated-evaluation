struct heap_node
{
	int priority;
	int graph_node_label;
	//all other data features can be added here
	//remember to change definition in header file too
};

typedef struct heap_node heap_node;

//heap using basics-start
heap_node* make_heap_node(int pri,int g_label);
void add_node_at_end(heap_node* arr[],int pos,int val,int gnode);
int sample_heap(heap_node* arr[]);
void swap(heap_node* arr[],int val1,int val2);
void view_full_heap(heap_node* arr[],int n);
void val_by_val_copy(heap_node* arr[],int val1,int val2);
//heap using basics-end

//node insertion-start
void bottom_up_heapify(heap_node* arr[],int n,int i);//i is from where the heapify will be done
void insert_node(heap_node* arr[],int* n,int val,int gnode);//val is the priority
//node insertion-end

//node deletion-start
void top_down_heapify(heap_node* arr[],int n,int i);//i is from where the heapify will be done
void delete_node(heap_node* arr[],int* n,heap_node* place);//returns priority of the deleted node
//node deletion-end

//update node-start
void update_node_priority(heap_node* arr[],int* n,int place,int pri);
//update node-end

int get_heap_label_given_graph_label(heap_node* arr[],int* n,int g_label);