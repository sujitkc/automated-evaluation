#include <iostream>
#include <stdio.h>
#include <cstdlib>

using namespace std;

class graph_node
{
private:
	char colour;
	int value;//or any other data the node needs to hold
	int label;//its index in the array of nodes
	int discovery_time;
	int finish_time;
public:
	graph_node(int val,int lab);
	void change_colour(char col);
	void assign_dt(int dt);
	void assign_ft(int ft);
	char get_colour();
	int get_label();
	void print_node();
	int get_dt();
	int get_ft();
};

graph_node::graph_node(int val,int lab)
{
	value = val;
	label = lab;
	colour = 'r';
}

void graph_node::change_colour(char col)
{
	colour = col;
	/*
	red = outside data str and not yet visited
	blue = inside data str
	yellow = outside data str and visited
	*/
}

void graph_node::assign_dt(int dt)
{
	discovery_time = dt;
}

void graph_node::assign_ft(int ft)
{
	finish_time = ft;
}

char graph_node::get_colour()
{
	return colour;
}

void graph_node::print_node()
{
	printf("(%d,%c,%d)\n",label,colour,value);
}

int graph_node::get_label()
{
	return label;
}

int graph_node::get_dt()
{
	return discovery_time;
}

int graph_node::get_ft()
{
	return finish_time;
}




class adjacency_matrix
{
private:
	int max_n;
	int last_pos;//last filled index
	int no_of_edges;//updated each time an edge is added.initial val = 0
	graph_node** vertices;//pointers to all the nodes.indexing from 0
	int** arr;
public:
	adjacency_matrix(int num);
	void add_node(int val);//can have max n nodes
	void add_edge(int start,int end,int weight);//edge addition based on labels
	void colour_all_red();
	void print_matrix();
	void all_outgoing_edges(int i,int dest[]);//arr is of size max_n and will store all the nodes to which there is an outgoing edge
	void get_edges(int weight[],int start[],int end[]);//assume all these arrays have correct no of elements
	graph_node* get_pointer_given_index(int i);
	int get_edge_weight(int start,int end);//assuming valid start and end
	int get_size();
	int get_no_of_edges();
};

adjacency_matrix::adjacency_matrix(int num)
{
	max_n = num;
	vertices = (graph_node**)calloc(max_n,sizeof(graph_node*));
	arr = (int**)calloc(max_n,sizeof(int*));

	for(int i = 0 ; i < max_n ; i++)
	{
		// arr[i] = new int[max_n];
		arr[i] = (int*)calloc(max_n,sizeof(int));
	}

	cout << endl;

	last_pos = -1;
	no_of_edges = 0;
	for(int i = 0 ; i < max_n ; i++)
		vertices[i] = NULL;
}

void adjacency_matrix::add_node(int val)
{
	if(last_pos >= max_n-1)
	{
		cout << "graph is already full\n";
		return;
	}
	last_pos++;
	vertices[last_pos] = new graph_node(val,last_pos);
}

void adjacency_matrix::add_edge(int start,int end,int weight)
{
	if(start < max_n && end < max_n && start >= 0 && end >= 0)
	{
		arr[start][end] += weight;
		no_of_edges += 1;
		// arr[end][start] -= weight;//since its a directed graph
	}
	else
	{
		cout << "Invalid node";
	}
}

void adjacency_matrix::colour_all_red()
{
	for(int i = 0 ; i <= last_pos ; i++)
	{
		vertices[i]->change_colour('r');
	}
}

void adjacency_matrix::print_matrix()
{
	for(int i = 0 ; i <= last_pos ; i++)
	{
		for(int j = 0 ; j <= last_pos ; j++)
			cout << arr[i][j] << " ";
		cout << endl;
	}
	cout << endl;
}

void adjacency_matrix::all_outgoing_edges(int i,int dest[])
{
	int k = 0;
	for(int j = 0 ; j < max_n ; j++)
		dest[j] = -1;
	if(i >= max_n)
	{
		cout << "Node error";
		return;
	}
	for(int j = 0 ; j < max_n ; j++)
	{
		if(arr[i][j] != 0)
		{
			dest[k] = j;
			k++;
		}
	}
}

void adjacency_matrix::get_edges(int weight[],int start[],int end[])
{
	int k = 0;
	
	// cout << "the matrix is:\n";
	// for(int i = 0 ; i < max_n ; i++)
	// {
	// 	for(int j = 0 ; j < max_n ; j++)
	// 		cout << arr[i][j] << " ";
	// 	cout << endl;
	// }

	for(int i = 0 ; i < max_n ; i++)
	{
		for(int j = 0 ; j < max_n ; j++)
		{
			if(arr[i][j] != 0)
			{
				weight[k] = arr[i][j];
				start[k] = i;
				end[k] = j; 
				k++;
			}
		}
	}
	printf("k:%d\n",k);
}

graph_node* adjacency_matrix::get_pointer_given_index(int i)
{
	return vertices[i];
}

int adjacency_matrix::get_edge_weight(int start,int end)
{
	return arr[start][end];
}

int adjacency_matrix::get_size()
{
	return max_n;
}

int adjacency_matrix::get_no_of_edges()
{
	return no_of_edges;
}