#include <stdio.h>
#include <cstdlib>

using namespace std;

//basic heap making-start
struct heap_node
{
	int priority;
	int graph_node_label;
	//all other data features can be added here
	//remember to change definition in header file too
};

//typedef struct heap_node heap_node;


heap_node* make_heap_node(int pri,int g_label)
{
	heap_node* temp = (heap_node*)malloc(sizeof(heap_node));
	temp->priority = pri;
	temp->graph_node_label = g_label;
	return temp;
}

void add_node_at_end(heap_node* arr[],int pos,int val,int gnode)
{
	heap_node* temp = NULL;
	temp = (heap_node *)malloc(sizeof(heap_node));
	temp->priority = val;
	temp->graph_node_label = gnode;
	//other data assignments here	
	arr[pos] = temp;
}

//array of heap node pointers//right now of a very large size



//heap using basics-start
void swap(heap_node* arr[],int val1,int val2)
{
	heap_node* t = NULL;
	t = arr[val1];
	arr[val1] = arr[val2];
	arr[val2] = t;
}

void view_full_heap(heap_node* arr[],int n)
{
	int nodes = 1,count = 0;
	for(int j = 0 ; j < n ; j++)
	{
		printf("%d ",arr[j]->priority);
		count += 1;
		if(count == nodes)
		{
			count = 0;
			nodes *= 2;
			printf("\n");
		}
	}
	if(count != 0)//since if it reached the end it would have automatically put a new line without anything else
		printf("\n");
	printf("\n");
}

void val_by_val_copy(heap_node* arr[],int val1,int val2)
{
	arr[val1]->priority = arr[val2]->priority;
	arr[val1]->graph_node_label = arr[val2]->graph_node_label;
}
//heap using basics-end



//node insertion-start
void bottom_up_heapify(heap_node* arr[],int n,int i)//i is from where the heapify will be done
{
	int pos = i,parent = 0;
	while(pos > 0)
	{
		parent = (pos-1)/2;		
		if(arr[parent]->priority > arr[pos]->priority)
		{
			swap(arr,pos,parent);
			pos = parent;
		}
		else break;
	}
}

void insert_node(heap_node* arr[],int* n,int val,int gnode)
{
	add_node_at_end(arr,*n,val,gnode);
	*n += 1;//++ takes priority over *
	bottom_up_heapify(arr,*n,(*n)-1);
}
//node insertion-end



//node deletion-start
void top_down_heapify(heap_node* arr[],int n,int i)//i is from where the heapify will be done
{
	int pos = i,l = 2*i+1,r = 2*i+2,min = 0;
	while(r < n)
	{
		min = (arr[l]->priority)>(arr[r]->priority)?r
												   :l;													  
		if(arr[pos]->priority > arr[min]->priority)//since minimum one will also make a good new parent
		{
			swap(arr,pos,min);
			pos = min;
			l = 2*pos+1;
			r = 2*pos+2;
		}
		else break;//if parent is less than min break out
	}
	//corner case where right child not there but left is there
	l = n-1;
	int parent = (n-2)/2;
	if(n == 1 || n == 0)
		return;
	if(arr[l]->priority < arr[parent]->priority)
	{
		swap(arr,l,parent);
	}
}

void delete_node(heap_node* arr[],int* n,heap_node* place)//returns priority of the deleted node
{
	place->priority = arr[0]->priority;
	place->graph_node_label = arr[0]->graph_node_label;
	val_by_val_copy(arr,0,(*n)-1);
	free(arr[(*n)-1]);
	*n -= 1;
	top_down_heapify(arr,*n,0);
}
//node deletion-end

//update node-start
void update_node_priority(heap_node* arr[],int* n,int place,int pri)
{
	int cur = arr[place]->priority;

	arr[place]->priority = pri;//update
	
	if(pri < cur)//value decreased,then only an upward violation possible
		bottom_up_heapify(arr,*n,place);
	else//value increase,then only a downward violation possible
		top_down_heapify(arr,*n,place);
}
//update node-end

int get_heap_label_given_graph_label(heap_node* arr[],int* n,int g_label)
{
	for(int i = 0 ; i < *n ; i++)
		if(arr[i]->graph_node_label == g_label)
			return i;
	return -1;
}