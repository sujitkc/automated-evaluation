class graph_node
{
private:
	char colour;
	int value;//or any other data the node needs to hold
	int label;//its index in the array of nodes
	int discovery_time;
	int finish_time;
public:
	graph_node(int val,int lab);
	void change_colour(char col);
	void assign_dt(int dt);
	void assign_ft(int ft);
	char get_colour();
	int get_label();
	void print_node();
	int get_dt();
	int get_ft();
};



class adjacency_matrix
{
private:
	int max_n;
	int last_pos;//last filled index
	int no_of_edges;//updated each time an edge is added.initial val = 0
	graph_node** vertices;//pointers to all the nodes.indexing from 0
	int** arr;
public:
	adjacency_matrix(int num);
	void add_node(int val);//can have max n nodes
	void add_edge(int start,int end,int weight);//edge addition based on labels
	void colour_all_red();
	void print_matrix();
	void all_outgoing_edges(int i,int dest[]);//arr is of size max_n and will store all the nodes to which there is an outgoing edge
	void get_edges(int weight[],int start[],int end[]);//assume all these arrays have correct no of elements
	graph_node* get_pointer_given_index(int i);
	int get_edge_weight(int start,int end);//assuming valid start and end
	int get_size();
	int get_no_of_edges();
};