#include <stdio.h>
int main()
{
    int a;
    scanf("%d",&a);
    int arr[a+1];
    arr[0]=0;
    if(a>0)
    {
        arr[1]=1;
        if(a>1)
        {
            for(int i=2;i<a+1;i++)
                
                arr[i]=(arr[i-1]+arr[i-2])%100;
            
        }
    }
    
    printf("%d",arr[a]);
    return 0;
}
//using array to store and add the previous two numbers
