import random
import math
difference = [1,2,3,3,4,5,5,6,6,8,9,9,11,14,15]    #hardcoded
length = int((1 + (1+8*len(difference))**0.5)/2)

print "ascending order difference set ",(difference)

def right(newset,difference,position,max_left,min_right,length):
    if min_right-max_left<=2:

        removed = []
        number =  max(difference)-newset[0]
        for i in newset:
            if i!=-1:
                if abs(number-i) not in difference:
                    difference.extend(removed)
                    difference.sort()
                    return False
                else:
                    difference.remove(abs(number-i))
                    removed.append(abs(number-i))
        newset[position] = number
        return True

    else:

        removed = []
        number =  max(difference)-newset[0]
        for i in newset:
            if i!=-1:
                if abs(number-i) not in difference:
                    difference.extend(removed)
                    difference.sort()
                    return False
                else:
                    difference.remove(abs(number-i))
                    removed.append(abs(number-i))
        newset[position] = number
        if right(newset,difference,min_right-2,max_left,min_right-1,length):
            return True

        elif left(newset,difference,max_left+1,max_left,min_right-1,length):
            return True

        else:
            newset[position] = -1
            difference.extend(removed)
            difference.sort()
            return False


def left(newset,difference,position,max_left,min_right,length):
    if min_right-max_left<=2:
        
        removed = []
        number =  newset[length-1]-max(difference)
        for i in newset:
            if i!=-1:
                if abs(number-i) not in difference:
                    difference.extend(removed)
                    difference.sort()
                    return False
                else:
                    difference.remove(abs(number-i))
                    removed.append(abs(number-i))
        newset[position] = number
        return True

    else:
        print min_right,max_left
        print newset,difference
        removed = []
        number =  newset[length-1]-max(difference)
        for i in newset:
            if i!=-1:
                if abs(number-i) not in difference:
                    difference.extend(removed)
                    difference.sort()
                    return False
                else:
                    difference.remove(abs(number-i))
                    removed.append(abs(number-i))
        newset[position] = number
        if right(newset,difference,min_right-1,max_left+1,min_right,length):
            return True

        elif left(newset,difference,max_left+2,max_left+1,min_right,length):
            return True

        else:
            newset[position] = -1
            difference.extend(removed)
            difference.sort()
            return False



newset = [-1 for i in range(length)]
newset[0]=0
if right(newset,difference,length-1,0,length,length):
    print "set of numbers ",newset
else:
    print newset
    print "not possible"
