#include <stdio.h>
#include <math.h>
void mul(int a[][2],int b[][2])
{
    
    int c[2][2];
    for(int i=0;i<2;i++)
    {
        
        for(int j=0;j<2;j++)
        {
            int sum=0;
            for(int k=0;k<2;k++)
            {
                sum+=a[i][k]*b[k][j];
            }
            c[i][j]=sum;
        }
    }
    for(int i=0;i<2;i++)
        for(int j=0;j<2;j++)
            a[i][j]=c[i][j];
    
}

void power(int arr[][2],int a[],int size)
{
    int i=0,y[][2]={{1,0},{0,1}};
    while(i<size)
    {
        if(a[i]==1)
            mul(y,arr);
        mul(arr,arr);
        
        i++;
    }
    printf("%d\n",y[0][1]%100);  //here we have taken 100 for modular operation
}

void convert(int a,int arr[])
{
    int size=ceil(log(a)/log(2));
    for(int i=0;i<size-1;i++)
    {
        arr[i]=a%2;
        a/=2;
    }
    arr[size-1]=1;
    
}

int main()
{
    int a=10;
    int size=ceil(log(a)/log(2));
    int a1[size];
    convert(a,a1);//inverted binary form of tern n
    int arr[2][2]={{1,1},{1,0}}; // matrix used to multiply
    power(arr,a1,size);
    
}
// using nth power of {{1,1},{1,0}}
