//long inputs following pattern

#include<stdio.h>

int main()
{
    char arr[10000];
    printf("give the input of term in fibonacci\n");
    scanf("%s",arr);
    char a[10000];
    int j=0;
    while(arr[j]!='\0')
    {
        a[j]=arr[j]-'0';
        j++;
        
    }
    
    
    int m;
    printf("give the value of m for finding the modulo\n");
    scanf("%d",&m);
    int z=m;
    
    int x=0,y=1,i=0;
    for(i=2;i<=m*6;i++){
        
        int c= (x+y)%m;
        x=y;
        y=c;
        if(x==0 && y==1)
        {
            i--;
            break;
        }
    }
   
    
    int count =0;
    while(m!=0)     //to count the digits in m
    {
        count++;
        m=m/10;
    }
    
    int rem =0;
    if(j<count)
    {
        for(int i=j;i>=0;i--)
            a[i+count-j]=a[i];
        
        for(int i=0;i<count-j;i++)
            a[i]=0;
    }
    
    if(j>=count)
        for(int l=0;l<j-count+1;l++)
        {
            int num=rem;
            for(int k=0;k<count;k++)
            {
                num = num*10+a[k+l];
                
            }
            rem = num % (i);
            
        }
    else
    {
        int num=rem;
        for(int k=0;k<count;k++)
        {
            num = num*10+a[k];
            
        }
        rem = num % (i);
        
    }
    
    
    
    
    x=0,y=1;
    for(int j=2;j<=rem;j++){
        
        int c= (x+y)%z;
        x=y;
        y=c;
        
    }
    printf("%d",y);
    return 0;
}

