#include<stdio.h>

int partition_array(int a[],int l,int r,int piv)
{
    int left=l;
    int right=r;
    int k=l;
    
    while(k<=right)
    {
        if(a[k]<piv)
        {
            int b;
            b=a[left];
            a[left]=a[k];
            a[k]=b;
            left++;
            k++;
            
        }
        else if(a[k]>piv)
        {
            int b=a[right];
            a[right]=a[k];
            a[k]=b;
            right--;
            
            
            
        }
        else
        {
            k++;
        }
        
    }
    return left;
}

int random_num(int* arr,int l,int r)
{
    int piv=l + ( rand() % ( r - l + 1 ) );
    return arr[piv];
}

void quick(int arr[],int l,int r)
{
    if(r!=l)
    {
        int piv=random_num(arr,l,r);
        int part=partition_array(arr,l,r,piv);
        if(part-1>=l)
            quick(arr, l, part-1);
        if(part+1<=r)
            quick(arr, part+1, r);
    }
    
}

int main()
{
    
    int n;
    printf("enter the size of the array\n");
    scanf("%d",&n);
    int arr[n];
    for(int i=0;i<n;i++)
    {
        int piv=0 + ( rand() % ( 20*n - 0 + 1 ) );
        arr[i]=piv;
    }
    
    for(int i=0;i<n;i++)
        printf("%d\t",arr[i]);
    
    printf("\n");
    quick(arr,0,n-1);
    printf("after sorting\n");
    for(int i=0;i<n;i++)
        printf("%d\t",arr[i]);
    
    return 0;
}
