#include<stdio.h>
int main()
{
    int a;
    scanf("%d",&a);
    int x=0,y=1,c;
    for(int i=1;i<a;i++){
        
        c= (x+y)%100;
        x=y;
        y=c;
        
    }
    printf("%d",c);
    return 0;
}
//using only 3 variables
