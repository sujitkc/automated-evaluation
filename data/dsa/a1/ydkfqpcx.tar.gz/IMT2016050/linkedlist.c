#include<stdio.h>
#include <stdlib.h>
struct node
{
    int data;
    struct node *next;
    struct node *prev;


};

void add(int num, struct node **head)
{
    
    if ((*head)==NULL)
    {
        
        struct node *new = (struct node*)malloc(sizeof(struct node));
        (new)->data=num;
        (new)->next=NULL;
        (new)->prev=NULL;
        (*head) = new;
    }
    else
    {
        struct node *start = *head;
        struct node *new = (struct node*)malloc(sizeof(struct node));
        new->data=num;
        while(start->next!=NULL)
        {
            start=start->next;
        }
        start->next= new;
        new->prev=start;
        new->next=NULL;
    }
    
}

void view(struct node *head)
{
    while(head!=NULL)
    {
        printf("%d,",head->data);
        head=head->next;
    }
    printf("\n");

}

void del_hor(struct node **head)
{

    if(*head!=NULL){
    while((*head)->next!=NULL)
        {
            struct node *start = *head;
            if(start == *head)
                {
                    if(((*head)->data)%2==1 && ((*head)->next->data)%2==0 )
                    {
                        (*head) = ((*head)->next);
                        (*head)->prev=NULL;
                    }
                    else if(((*head)->data)%2==0 && ((*head)->next->data)%2==1)
                    {
                        (*head)->next = (*head)->next->next;
                        if((*head)->next!=NULL)
                            (*head)->next->prev=(*head);
                    
                    }
                    else if(((*head)->data)%2==0 && ((*head)->next->data)%2==0)
                    {
                        if(((*head)->data)>((*head)->next->data))
                        {
                            (*head) = ((*head)->next);
                            (*head)->prev=NULL;
                        }
                        else
                        {
                            (*head)->next = (*head)->next->next;
                            if((*head)->next!=NULL)
                                (*head)->next->prev=(*head);
                        }
                    }
                    else
                    {
                        
                            
                        if(((*head)->data)<((*head)->next->data))
                        {
                            (*head) = ((*head)->next);
                            (*head)->prev=NULL;
                        }
                        else
                        {
                            (*head)->next = (*head)->next->next;
                            if((*head)->next!=NULL)
                                (*head)->next->prev=(*head);
                        }
                    }
                    start=(*head)->next;
                }
                else
                {
                    while((start)->next==NULL)
                    {
                    if(((start)->data)%2==1 && ((start)->next->data)%2==0 )
                    {
                        (start) = (start)->next;
                        (start)->prev=NULL;
                    }
                    else if(((start)->data)%2==0 && ((start)->next->data)%2==1)
                    {
                        (start)->next = (start)->next->next;
                        if((start)->next!=NULL)
                            (start)->next->prev=(start);
                        
                    }
                    else if(((start)->data)%2==0 && ((start)->next->data)%2==0)
                    {
                        if(((start)->data)>((start)->next->data))
                        {
                            (start) = (start)->next;
                            (start)->prev=NULL;
                        }
                        else
                        {
                            (start)->next = (start)->next->next;
                            if((start)->next!=NULL)
                                (start)->next->prev=(start);
                        }
                    }
                    else
                    {
                        if(((start)->data)<((start)->next->data))
                        {
                            (start) = (start)->next;
                            (start)->prev=NULL;
                        }
                        else
                        {
                            start->next = (start)->next->next;
                            if((start)->next!=NULL)
                                (start)->next->prev=(start);
                        }
                    }

                    start=(start)->next;
                }
            }
            
        }
    }
    

}

void del_ver(struct node *array[])
{
    
        int i=0,j=1;
        while(i<=29 && j<=29)
        {
            if(array[i]!=NULL && array[j]!=NULL)
            {
                if(((array[i])->data)%2==1 && (array[j]->data)%2==0 )
                
                {
                    (array[i]) = NULL;
                    i=j;
                    j++;
                    
                }
                else if(((array[i])->data)%2==0 && (array[j]->data)%2==1 )
                {
                    array[j]=NULL;
                    j++;
                    
                }
                else if(((array[i])->data)%2==0 && (array[j]->data)%2==0 )
                {
                    if(array[i]>array[j])
                    {
                        (array[i]) = NULL;
                        i=j;
                        j++;
                        
                    }
                    else
                    {
                        array[j]=NULL;
                        j++;
                        
                    }
                }
                else
                {
                    if(array[i]<array[j])
                    {
                        (array[i]) = NULL;
                        i=j;
                        j++;
                        
                    }
                    else
                    {
                        array[j]=NULL;
                        j++;
                        
                    }

                }
            }
            else if(array[i]!=NULL && array[j]==NULL)
            {
                j++;
                
            }
            else
            {
                i=j;
                j++;
                
            }
            
        }


}

int main()
{

    struct node *array[30];
    for(int i=0;i<30;i++)
    {
        array[i] = NULL;
    }
    
    for(int i=0;i<30;i++)
    {
        int randomnumber;
        randomnumber = rand() % 30;
        int rand_array;
        rand_array = rand() % 30;
        
        add(randomnumber,&array[rand_array]);
    
    }
    
    for(int i=0;i<30;i++){
    
        view(array[i]);
    }
    printf("After Deletion in Linked List......\n");
   
    for(int i=0;i<30;i++)
    {
       del_hor(&array[i]);
       view(array[i]);
       
    }
    printf("After Deletion in Linked List......\n");
    del_ver(array);
    for(int i=0;i<30;i++)
    {
        if(array[i]!=NULL)
            printf("%d\n",array[i]->data);
    }
        

    return 0;
}
