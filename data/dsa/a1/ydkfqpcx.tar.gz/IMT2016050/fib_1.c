#include<stdio.h>
int fib(int num)
{
    if(num==1)
    {
        return 1;
    }
    else if(num==0)
    {
        return 0;
    }
    else
        return (fib(num-1)+fib(num-2))%100;
}

int main()
{
    int a;
    printf("enter the term of fibonacci which you want to see\n");
    scanf("%d",&a);
    printf("%d",fib(a));
    return 0;
}

//using plain fibonacci recursion method
