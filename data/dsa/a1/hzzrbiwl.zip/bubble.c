#include<stdio.h>
void bubble_sort(int *a,int n)
{
int k,j,temp;
for(k=0;k<n;k++)
{
	for(j=0;j<=n-k-1;j++)
	{
		if(a[j]>a[j+1])
		{
			temp=a[j+1];
			a[j+1]=a[j];
			a[j]=temp;
		}
	}
}	
}
int main()
{
int a[5]={1,5,4,2,3};
int i;
bubble_sort(a,5);
for(i=0;i<5;i++)
{
	printf("%d\t",a[i]);
}
return 0;
}
