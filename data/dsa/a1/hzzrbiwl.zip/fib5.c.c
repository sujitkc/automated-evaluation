#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int mod(int a)
{
	return a%2;
}
void print(int *a, int p)
{
	int i;
	for(i=0;i<p;i++)
		printf("%d",a[i]);
}
int divide(int *num, int p)
{
	int i=0,b=0,c=0;
	for(i=0;i<p;i++)
		if(num[i]==0) c++;
	if(c==p)
		return 0;
	for(i=0;i<p;i++)
	{
		if(num[i]<2&&b==0)
		{
			b=b*10+mod(num[i]);
			num[i]=0;
		}
		else
		{
			if(b!=0)
			{
				b=b*10+num[i];
				int k= mod(b);
				num[i]=b/2;
				b=k;
			}
			else
			{
				b=mod(num[i]);
				num[i]=num[i]/2;
			}
		}
	}
	return 1;
}
int divide_bin(int *num, int p)
{
	int i=0,b=0,c=0;
	for(i=0;i<p;i++)
		if(num[i]==0) c++;
	if(c==p)
		return 0;
	for(i=p;i>0;i--)
	{
		num[i]=num[i-1];
	}
	num[i]=0;
	return 1;
}
void mat_mult(int (*a)[2], int b[2][2], int k)
{
	int p1,p2,p3,p4;
	p1=a[0][0]*b[0][0]+a[0][1]*b[1][0];
	p2=a[0][0]*b[0][1]+a[0][1]*b[1][1];
	p3=a[1][0]*b[0][0]+a[1][1]*b[1][0];
	p4=a[1][0]*b[0][1]+a[1][1]*b[1][1];
	a[0][0]=p1%k;
	a[0][1]=p2%k;
	a[1][0]=p3%k;
	a[1][1]=p4%k;
}
int algo_4(int n, int k)
{
	int a[2][2]={{1,1},{1,0}},y[2][2]={{1,0},{0,1}};
	int i=n-1;
	while(i>0)
	{
		if (i%2==1)
		{
			mat_mult(y,a,k);
		}
		mat_mult(a,a,k);
		i=i/2;
		
	}
	return y[1][0];
}
int algo_5(int* arr, int p, int k)
{
	int a[2][2]={{1,1},{1,0}},y[2][2]={{1,0},{0,1}};
	do
	{
		if (mod(arr[p-1])==1)
		{
			mat_mult(y,a,k);
		}
		mat_mult(a,a,k);
	}while(divide(arr,p)==1);
	return y[1][0];
}
int algo_6(int* arr, int p, int k)
{
	int a[2][2]={{1,1},{1,0}},y[2][2]={{1,0},{0,1}};
	do
	{
		if (arr[p-1]==1)
		{
			mat_mult(y,a,k);
		}
		mat_mult(a,a,k);
	}while(divide_bin(arr,p)==1);
	return y[1][0];
}
void input_as_decimal()
{
	int k,n;
	scanf("%d%d",&n,&k);
	printf("%d\n",algo_4(n,k));
}
void input_as_string_decimal()
{
	int k,p;
	printf("Enter number of digits\n");
	scanf("%d",&p);
	char str[p];
	printf("Enter number\n");
	scanf("%s",str);
	printf("Enter k\n");
	scanf("%d",&k);
	int i=0, num[p];
	while(i<p)
	{
		num[i]=str[i]-'0';
		i++;
	}
	printf("%d\n",algo_5(num,p,k));
	
}
void input_as_string_binary()
{
	int k,p;
	printf("Enter number of digits\n");
	scanf("%d",&p);
	char str[p];
	printf("Enter number\n");
	scanf("%s",str);
	printf("Enter k\n");
	scanf("%d",&k);
	int i=0, num[p];
	while(i<p)
	{
		num[i]=str[i]-'0';
		i++;
	}
	printf("%d\n",algo_6(num,p,k));
	
}
void main()
{
	//input_as_decimal();
	input_as_string_decimal();
	input_as_string_binary();
}
