#include<stdio.h>
int Period()
{
	int p;
	int a,b,c;
	a=0;
	b=1;
	c=(a+b)%100;
	a=b;
	b=c;
	p=1;
	while(1)
	{
		if(a==0 && b==1)
			break;
		else
		{
		p++;
		c=(a+b)%100;
		a=b;
		b=c;
		}
	}
	//if(a==0 && b==1)
	printf("Period= %d\n",p);
	return p;
}
int Mod_fib_algo4(int n, int p)
{
	if(n<p)
	{
		if(n<2)
			return n;
		else
		{
			int a,b,c;
			a=0;
			b=1;
			c=n;
			int i;
			for(i=2;i<=n;i++)
			{
				c=(a+b)%100;
				a=b;
				b=c;
			}
		
			return c;
		}

	}
 	else
	{
		while(n>p)
			return Mod_fib_algo4(n%p,p);
	}

}
int main()
{
	int n,i,p;
	scanf("%d",&n);
	p=Period();
	printf("%d\n",Mod_fib_algo4(n,p));
	return 0;
}