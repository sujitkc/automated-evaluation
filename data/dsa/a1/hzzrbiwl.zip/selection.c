#include<stdio.h>
void selection_sort(int *a,int n)
{
int amin,i,j,temp;
for(i=0;i<n;i++)
{
	amin=a[i];
	for(j=i+1;j<n;j++)
	{
		if(a[j]<amin)
		{
			temp=a[j];
			a[j]=amin;
			amin=temp;
		}
	}
	a[i]=amin;
}
}
int main()
{
int a[5]={1,5,4,7,3};
int i;
selection_sort(a,5);
for(i=0;i<5;i++)
{
	printf("%d\t",a[i]);
}
return 0;
}
