#include<stdio.h>
void insertion_sort(int *a,int n)
{
int k,value,hole;
for(k=1;k<n;k++)
{
	value=a[k];
	hole=k;
	while(hole>0&&a[hole-1]>a[hole])
	{
		a[hole]=a[hole-1];
		hole--;
		a[hole]=value;
	}
	a[hole]=value;
}
}
int main()
{
int a[5]={1,7,5,2,3};
int i;
insertion_sort(a,5);
for(i=0;i<5;i++)
{
	printf("%d\t",a[i]);
}
return 0;
}
