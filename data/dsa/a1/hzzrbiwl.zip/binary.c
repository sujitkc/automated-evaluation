#include<stdio.h>
#include<math.h>
int binarytodecimal(long long n)
{
int decimal=0;
int i=0,remainder;
while(n!=0)
{
	remainder=n%10;
	n=n/10;
	decimal=decimal+remainder*pow(2,i);
	i++
}
return decimal;
}
int decimaltobinary(int n)
{
long long binary=0;
int remainder,i=1;
while(n!=0)
{
	remainder=n%2;
	n=n/2;
	binary=binary+(remainder*1);
	i=i*10;
}
return binary;
}

