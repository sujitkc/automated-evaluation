#include<stdio.h>
void multiply(int f[2][2],int m[2][2])
{
int x=f[0][0]*m[0][0]+f[0][1]*m[1][0];
int y=f[0][0]*m[0][1]+f[0][1]*m[1][1];
int z=f[1][0]*m[0][0]+f[1][1]*m[1][0];
int w=f[1][0]*m[0][1]+f[1][1]*m[1][1];
f[0][0]=x%100;
f[0][1]=y%100;
f[1][0]=z%100;
f[1][1]=w%100;
}
void power(int f[2][2],int n)
{
if(n==0||n==1)
	return;
int m[2][2]={{1,1},{1,0}};
power(f,n/2);
multiply(f,f);
if(n%2!=0)
	multiply(f,m);//change it

}
int fib(int n)
{
int f[2][2]={{1,1},{1,0}};
if(n==0)
{
	return 0;
}
power(f,n-1);
return f[0][0];
}
int main()
{
int n;
scanf("%d",&n);
printf("%d\n",fib(n));
return 0;
}
