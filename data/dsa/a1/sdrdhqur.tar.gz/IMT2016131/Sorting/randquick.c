#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <assert.h>
void swap(int *a,int *b)
{
    int temp =*a;
    *a=*b;
    *b=temp;
}

void quicksort(int s,int n, int *a) {
    if(s+1 == n) 
    	return;
    int r=(rand()%(n-s)+s);
    swap(&a[r],&a[s]);
    int pivot=a[s],i,j = s;
    for(i=s;i<n;i++)
        {
        if(pivot>=a[i])
            {
            swap(&a[i],&a[j]);
            j++;
            }
        }
    j--;
    swap(&a[j],&a[s]);   
    if(s< j)
    {
        quicksort(s,j,a);
    }
    if(j+1 < n)
    {
    	quicksort(j+1,n,a);
    }

}
int main(void) {
    int n=100,i;

    int a[100]={70,22,551,94,178,566,181,914,771,185,438,424,783,438,748,50,714,768,971,421,618,266,331,239,201,604,36,919,350,105,836,772,479,739,866,10,305,399,924,77,584,714,853,367,505,601,770,219,722,741,640,692,359,323,284,913,279,320,832,982,777,668,754,257,408,621,267,65,372,543,142,957,610,347,676,115,949,446,686,23,540,678,715,251,1,999,164,632,672,997,614,449,17,369,58,425,342,677,491,714};
    srand((time(NULL)));
    quicksort(0,n,a);

    for(i=0;i<n;i++)
    {
    	printf("%d\n",a[i]);
    }

   
   return 0;
}