#include <stdio.h>
#include <time.h>

int rec(int n)
{
	if(n<2)
	{
		return n;
	}
	else
	{
		return (rec(n-1)+rec(n-2))%100;
	}
}
void main()
{
	int i;
	scanf("%d",&i);
	clock_t start = clock();
	printf("%d\n",rec(i));
	clock_t end = clock();
	double time_taken=((double)end-(double)start)/CLOCKS_PER_SEC;
	printf("%lf\n",time_taken );
}