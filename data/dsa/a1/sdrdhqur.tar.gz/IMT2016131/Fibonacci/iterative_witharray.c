#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int iter(int n)
{
	int i,*a=(int *)malloc(sizeof(int)*n);
	a[0]=0;
	a[1]=1;
	for(i=2;i<=n;i++)
	{
		a[i]=(a[i-1]+a[i-2])%100;
	}
	return a[n];
}
void main()
{
	int i;
	scanf("%d",&i);
	clock_t start = clock();
	
	printf("%d\n",iter(i));
	
	clock_t end = clock();
	double time_taken=((double)end-(double)start)/CLOCKS_PER_SEC;
	printf("%lf\n",time_taken );
}