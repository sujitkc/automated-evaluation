import math

n=input("Enter the length of array of differences: ")
print "Enter n numbers: (after each number press enter)"


def find(d,ol,final,k=1,j=1):
    global temp
    check1=[]
    check2=[]
    count=1
    for i in d:
        check1.append(i)
    for i in final:
        check2.append(i)
    counter=0
    for i in final:
        if(i==None):
            counter=counter+1
    if (counter==0):
        if final not in temp and len(d)==0:
            print "Answer :",final
            temp.append(final)
        return
    x=len(check2)
    y=len(check1)
    check2[x-k-1]=max(check1)

    for i in range(x):
        if check2[i]!=None:
            if i!=x-1-k:
                try:
                    if(check2[x-1-k]-check2[i]>0):
                        check1.remove(check2[x-1-k]-check2[i])
                    else:
                        check1.remove(check2[i]-check2[x-1-k])
                except:
                    count=0
                    break
    if count==1:
        find(check1,ol,check2,k+1,j)
    count=1
    for i in range(len(d)):
        if (d[i]-max(final)>0):
            p=d[i]-max(final)
        else:
            p=max(final)-d[i]
        if p==max(d):
            index=i
            number=d[i]
            break
    try:
        final[j]=number
    except:
        count=0
    if count==1:
        for i in range(len(final)):
            if final[i]!=None:
                if i!=j:
                    try:
                        if(number-final[i]>0):
                            d.remove(number-final[i])
                        else:
                            d.remove(final[i]-number)
                    except:
                        count=0
                        break

    if count==1:
        find(d,ol,final,k,j+1)
d=[input() for i in range(n)]
d.sort()
ol=float((1+math.sqrt(1+8*n))/2.0)
if int(ol)==ol:
    ol=int(ol)
    final=[None]*ol
    final[0]=0
    final[ol-1]=max(d)
    d.remove(max(d))
    temp=[]
    find(d,ol,final)
    if len(temp)==0:
        print "Incorrect Input No Solutions!!!"
else:
    print "Incorrect Input!!"