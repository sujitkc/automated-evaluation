#include <stdio.h>
#include <time.h>
#include <stdlib.h>
int arraysize=40;
struct node{
	int data;
	struct node* next;
};
struct node* start[40];
void insert(int i,int n){
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	temp->data=n;
	if(start[i]==NULL)
	{
		start[i]=temp;
		start[i]->next=NULL;
	}
	else
	{
		temp->next=start[i];
		start[i]=temp;
	}
}
void main(){
	srand(time(NULL));
	int i,index,number;
	for(i=0;i<1000;i++)
	{
		index=rand()%arraysize;
		number=rand()%200+1;
		//printf("%d %d \n",index,number);
		insert(index,number);
	}
	printf("The created random array of linked list is: \n");
	for(i=0;i<arraysize;i++)
	{
		struct node* temp=start[i];
		printf("%d",i);
		while(temp!=NULL)
		{
			printf(" %d",temp->data);
			temp=temp->next;
		}
		printf("\n");
	}
	for(i=0;i<arraysize;i++)
	{
		struct node* temp1=start[i];
		struct node* temp2;
		{
			
		};
		if(temp1==NULL)
		{
			struct node* temp=(struct node*)malloc(sizeof(struct node));
			temp->data=0;
			temp->next=NULL;
			start[i]=temp;
		}
		else
		{
			int final=temp1->data;
			while(temp1!=NULL)
				{
					if(temp1->data%2==0 && temp1->data<final)
						final=temp1->data;
					temp2=temp1;
					temp1=temp1->next;
					free(temp2);
				}
			start[i]->data=final;
			start[i]->next=NULL;
		}
	}
	int final=start[0]->data;

for(i=0;i<arraysize;i++)
	{
		struct node* temp=start[i];
		while(temp!=NULL)
		{
			printf("%d %d \n",i,temp->data);
			temp=temp->next;
		}
	}
	for(i=1;i<arraysize;i++)
	{
		if(final>start[i]->data)
		{
			final=start[i]->data;
		}
	}
	printf("Final answer: %d",final);

}