#include<stdio.h>


void swap(int *a,int *b)
{
 int temp;
 temp = *a;
 *a = *b;
 *b = temp;
}


int main()
{
 int n,i,j,k,l;
 int *arr;
 printf("enter the number of elements in the array:");
 scanf("%d",&n);
 for(i=0;i<n;i++)
 {
  scanf("%d",(arr+i));
 }
 for(j=0;j<n;j++)
{
  for(k=0;k<n-j-1;k++)
  {
   if(*(arr+k) > *(arr+(k+1)))
    {
      swap((arr+k), (arr+(k+1)));
    }

  }
}
for(l=0;l<n;l++)
{
  printf("%d",*(arr+l));
}
}


