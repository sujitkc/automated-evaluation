#include <stdio.h>

int fib(int n)
{
    int a,b,c,i;
    if(n==0)
    {
        return 0;
    }
    if(n==1)
    {
        return 1;
    }
    else
    {
     a=0;
     b=1;
     for(i=2;i<n+1;i++)
     {
         
         
         
         c = (a+b) % 100;
         a=b;
         b=c;
         
     }
    }
    return c;
}
int main()
{
	 int n;
    printf("enter the value of the number");
    scanf("%d",&n);
    fib(n);
    printf("%d",fib(n));
    return 0;
}
