#include<stdio.h>
#include<stdlib.h>

void Merge(int arr[],int a,int b,int c)
{
 int i,j,k,l;
 int r = b-a+1;
 int s = c-b;
 int arr1[r],arr2[s];
 for(i=0;i<r;i++)
 {
  arr1[i] = arr[a+i];
   
 }
 for(j=0;j<s;j++)
 {
  arr2[j] = arr[b+j+1];
   
 } 
 i=0;
 j=0;
 k=a;
 while(i<r && j<s)
 {
  if(arr1[i] <= arr2[j])
  {
   arr[k] = arr1[i];
   i++;
  }
  else
  {
   arr[k] = arr2[j];
   j++;
  }
  k++;
 }
 while(i<r)
 {
  arr[k] = arr1[i];
  k++;
  i++; 
 }
 while(j<s)
 {
  arr[k] = arr2[j];
  j++;
  k++;
 }

}

void MergeSort(int arr[],int a, int c)
{
 if(a<c)
 {
   int b = (a+c)/2 ;
   MergeSort(arr,a,b);
   MergeSort(arr,b+1,c);
   Merge(arr,a,b,c);
 }

}
void PrintArray(int arr[],int size)
{
 int i;
 for(i=0;i<size;i++)
 {
  printf("%d ",arr[i]);
 }
}



int main()
{
 int a[100],n,p,i,j;
 printf("enter the no of values you want to enter:");
 scanf("%d",&n);
 for(i=0;i<n;i++)
 {
  scanf("%d",&a[i]); 
 }
 MergeSort(a,0,n-1);
 PrintArray(a,n);
 
}
