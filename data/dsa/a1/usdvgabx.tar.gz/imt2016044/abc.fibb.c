#include<stdio.h>
#include<stdlib.h>
int fibb(int n)
{
	int a,i,b,c;
	if((n==1)||(n==0))
	return n;
	a=0;
	b=1;
	c=1;
	for(i=2;i<n;i++)
	{
		a=b;
		b=c;
		c=(a+b)%100;
		
	}
	
	return c;
}
main()

{
	int n;
	scanf("%d",&n);
	printf("%d",fibb(n));	
}
