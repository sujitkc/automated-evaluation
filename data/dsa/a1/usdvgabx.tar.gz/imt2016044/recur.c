#include<stdio.h>
#include<stlib.h>
int recur(int n)
{
	if((n==0)||(n==1))
	{
		return 0;
	}
	else
	{
		return recur(n-1)+recur(n-2);
	}
}
main()
{
int n;
scanf("%d",&n);
printf("%d",recur(n));
}

