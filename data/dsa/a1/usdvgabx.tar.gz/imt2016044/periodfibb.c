#include<stdio.h>
#include<stdlib.h>
int period(int m)
{
	int a[3],i;
	a[0]=0;
	a[1]=1;
	a[2]=1;
for(i=3;1;i++)
{
	a[0]=a[1];
	a[1]=a[2];
	a[2]=(a[1]+a[0])%m;
	if((a[0]==0)&&(a[1]==1))
	{
		return i-2;
	}
}
return 0;
}
int fib(int n,int m)
{
	int f[n],i;
	f[0]=0;
	f[1]=1;
	for(i=2;i<=n;i++)
	{
		f[i]=(f[i-1]+f[i-2])%m;
	}
	return f[n];
}
main()
{
int n,m;
scanf("%d%d",&n,&m);
printf("%d",fib(n%period(m),m));
}
