/* FIBONACCI SERIES ALGO1 */


#include<stdio.h>
#include<time.h>
void main()
{
int a,b,c,n,i;
a=0;
b=1;
printf("enter value of n:");
scanf("%d",&n);
clock_t t;
	t = clock();
for (i=2;i<n;++i)
	{
	c=(a+b)%100;
	a=b;
	b=c;
	
	}
printf("%d\n",c);
t=clock()-t;
double time_spent = ((double)t)/ CLOCKS_PER_SEC;
printf("it took %f seconds to execute\n", time_spent);
}
