/* MATRIX (DECIMAL)
F(0)=0
F(1)=1
F(N)=............ */



#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void main()
{	
	int k,p;
	printf("Enter number of digits\n");
	scanf("%d",&p);
	char str[p];
	printf("Enter number\n");
	scanf("%s",str);
	printf("Enter k\n");
	scanf("%d",&k);
	int i=0, num[p];
	while(i<p)
	{
		num[i]=str[i]-'0';
		i++;
	}
	printf("%d\n",fn(num,p,k));
}
int mod(int a)
{
	return a%2;
}
int divide_bin(int *num, int p)
{
	int i=0,b=0,c=0;
	for(i=0;i<p;i++)
		if(num[i]==0) c++;
	if(c==p)
		return 0;
	for(i=p;i>0;i--)
	{
		num[i]=num[i-1];
	}
	num[i]=0;
	return 1;
}
void mat_mult(int (*a)[2], int b[2][2], int k)
{
	int m1,m2,m3,m4;
	m1=a[0][0]*b[0][0]+a[0][1]*b[1][0];
	m2=a[0][0]*b[0][1]+a[0][1]*b[1][1];
	m3=a[1][0]*b[0][0]+a[1][1]*b[1][0];
	m4=a[1][0]*b[0][1]+a[1][1]*b[1][1];
	a[0][0]=m1%k;
	a[0][1]=m2%k;
	a[1][0]=m3%k;
	a[1][1]=m4%k;
}
int fn(int* arr, int p, int k)
{
	int a[2][2]={{1,1},{1,0}},y[2][2]={{1,0},{0,1}};
	do
	{
		if (arr[p-1]==1)
		{
			mat_mult(y,a,k);
		}
		mat_mult(a,a,k);
	}while(divide_bin(arr,p)==1);
	return y[1][0];
}

