/* PERIOD OF FIBONACCI SERIES */



#include<stdio.h>
#include<time.h>
void main()
{
int a,b,c,p;
a=0;
b=1;
do
	{
	c=(a+b)%100;
	a=b;
	b=c;
	p++;
	if(a==0 && b==1)
		break;
	}
while(1);
printf("%d",p);
}
