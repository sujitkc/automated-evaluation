/* FIBONACCI SERIES ALGO1 */


#include<stdio.h>
#include<time.h>
int main()
{
int n,i; 
printf("enter value of n:\n");
scanf("%d",&n);
clock_t t;
	t= clock();
int f[n];
f[0]=0;
f[1]=1;
for(i=2;i<=n;i++)
{
f[i]=(f[i-1]+f[i-2])%100;
}
printf("%d\n",f[n-1]);
t = clock()-t;
double time_spent = ((double)t)/ CLOCKS_PER_SEC;
printf("it took %f seconds to execute \n", time_spent);

}
