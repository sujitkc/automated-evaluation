/*QUICK SORT */



#include <stdio.h>
#include <stdlib.h>

void swap(int *x,int *y)
{
int temp;
temp = *x;
*x = *y;
*y = temp;
}

int choosePivot(int i,int j )
{
return((i+j) /2);
}

void quicksort(int list[],int m,int n)
{
int key,i,j,k;
if( m < n)
	{
        k = choosePivot(m,n);
        swap(&list[m],&list[k]);
        key = list[m];
        i = m+1;
        j = n;
        while(i <= j)
        	{
        	while((i <= n) && (list[i] <= key))
                i++;
        	while((j >= m) && (list[j] > key))
                j--;
        	if( i < j)
                swap(&list[i],&list[j]);
      		}
        swap(&list[m],&list[j]);
        quicksort(list,m,j-1);
        quicksort(list,j+1,n);
   	}
}
void printlist(int list[],int n)
{
int i;
for(i=0;i<n;i++)
        printf("%d  ",list[i]);
}

void main()
{
printf("QUICK SORT\n");
int list[100],n;
int i = 0;
printf("Enter the size of array:\n");
scanf("%d",&n);
printf("Enter the elements in unsorted way:\n");
for(i = 0; i <n; i++ )
	{
	scanf("%d",&list[i]);
   	}
  
quicksort(list,0,n-1);
printf("Sorted Array:\n");
printlist(list,n);
}
