/* FIBONACCI SERIES ALGO1 */


#include<stdio.h>
#include<time.h>
int rec(int n)
{
if(n<2)
return n;
else
return ((rec(n-1)+rec(n-2))%100);
}
void main()
{
int n;
printf("enter value of n:");
scanf("%d",&n);
clock_t t;
	t= clock();
printf("%d",rec(n-1));
t = clock()-t;
double time_spent = ((double)t)/ CLOCKS_PER_SEC;
printf("it took %f seconds to execute \n", time_spent);
}

