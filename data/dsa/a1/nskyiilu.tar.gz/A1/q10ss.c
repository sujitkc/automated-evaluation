/* SELECTION SORT*/



#include <stdio.h>
#include <stdlib.h>
void main()
{
printf("SELECTION SORT");
int n,*p,i,j,temp;	
printf("\nEnter the size of array: ");
scanf("%d",&n);
p=(int *) malloc(n*2);
printf("\nEnter the elements in unsorted way:\n");
for(i=0;i<n;i++)
	{
	scanf("%d",p+i);
	}
for(i=0;i<n;i++)
	{
	for(j=0;j<n;j++)
		{
		if(*(p+i)<*(p+j))
			{
			temp=*(p+i);
			*(p+i)=*(p+j);
			*(p+j)=temp;
			}
		}
	}
printf("Sorted Array:\n");
for(i=0;i<n;i++)
	printf("%d ",*(p+i));
}
