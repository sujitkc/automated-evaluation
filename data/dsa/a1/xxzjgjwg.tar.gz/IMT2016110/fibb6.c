#include<stdio.h>
#include<stdlib.h>
int check_zero(int n[],int len);
int quo_div(int arr[],int d,int *len);
void mm(int (*a)[2],int (*b)[2]);
void power(int (*mat)[2],int n[],int len);

int main(){
  int n[1000000],len=1000000;
  for(int i=0;i<len;i++){
    n[i]=rand()%10;
  }
  int a[2][2]={{1,1},{1,0}};
  power(a,n,len);
}
int check_zero(int n[],int len){
  int zero=1;
  for(int i=0;i<len;i++){
    if(n[i]!=0) zero=0;
  }
  return zero;
}
int quo_div(int arr[],int d,int *len){
  int m=0,i=1,r=0,j=*len-1,di=1,arr1_len=0;
  int arr1[*len];
  while(j>=0){
    while(d>m){
      m+=arr[j]*i;
      i*=10;
      j--;
      if(j<0) {
        arr[0]=0;
        *len=1;
        break;break;
    }}
    //di=1;
    r=m%d;
    di=(m-r)/d;
    arr1[arr1_len]=di;
    arr1_len++;
    m=r;
    i=1;
    while(i<r){
      i*=10;
    }
  }
  *len=arr1_len;
  for(i=0;i<arr1_len;i++){
    arr[i]=arr1[i];
  }
  return r;
}
void mm(int (*a)[2],int (*b)[2]){
  int sol[2][2]={{0,0},{0,0}},i,j,k;
  for(i=0;i<2;i++){
    for(j=0;j<2;j++){
      for(k=0;k<2;k++){
        sol[i][j]+=a[i][k]*b[k][j];
      }
    }
  }
  for(i=0;i<2;i++){
    for(j=0;j<2;j++){
      //printf("%d\n",sol[i][j]);
      a[i][j]=sol[i][j]%100;
    }
  }
}
void power(int (*mat)[2],int n[],int len){
  int y[2][2]={{1,0},{0,1}},i=len-1,k=len;

  while(!check_zero(n,len)){
    if(quo_div(n,2,&len)==1) mm(y,mat);
    mm(mat,mat);
}
  printf("%d\n",y[1][0]);
}
