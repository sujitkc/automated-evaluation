#include<stdio.h>

void ms(int arr[],int i, int j);
void mearge(int arr[],int i,int k,int j);
void swap(int *a,int *b);
int main(){
  int arr[1000000];
  int i,j=0,len=1000000,a=0;
  FILE *fp;
  fp=fopen("file.txt","r");
//  puts("file reading started");
  for(i=1000000;i>0;i--){
    fread(&arr[a++],1,sizeof(int),fp);
  }
  //puts("filereading ended");
  //printf("%d\n",arr[0]);
  ms(arr,0,999999);
/*  for(int i=0;i<len;i++){
    printf("%d\n",arr[i]);
  }*/
}
void ms(int arr[],int i, int j){
  int mid=(i+j)/2;
  if (j<=i+1) {
    if(arr[i]>arr[j]) swap(&arr[i],&arr[j]);
  }
  else{
    ms(arr,i,mid);
    ms(arr,mid+1,j);
    mearge(arr,i,mid,j);
  }
}
void mearge(int arr[],int i,int k,int j){
    //printf("i=%d   j=%d\n",i,j);
    int arr1[j-i+1],left=i,right=k+1,a=0;
    while(left<=k && right<=j){
      if(arr[left]>arr[right]) arr1[a++]=arr[right++];
      else arr1[a++]=arr[left++];
    }
    while(left<=k) arr1[a++]=arr[left++];
    while(right<=j) arr1[a++]=arr[right++];
    //printf("a=%d\n",a);
    a=0;
    for(;i<=j;i++){
      arr[i]=arr1[a++];
    }
  }
void swap(int *a,int *b){
    int temp=*a;
    *a=*b;
    *b=temp;
  }
