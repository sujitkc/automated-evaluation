#include<stdio.h>
int main(){
  long unsigned int i=1;
  FILE *fp;
  fp=fopen("file.txt","w+");
  for(i=1000000;i>0;i--){
    fwrite(&i,1,sizeof(int),fp);
  }
}
