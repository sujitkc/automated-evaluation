#include<stdio.h>

void swap(int *a,int *b);

int main(){
  int arr[1000000];
  int i,j=0,len=1000000,a=0;
  FILE *fp;
  fp=fopen("file.txt","r");
  puts("file reading started");
  for(i=1000000;i>0;i--){
    fread(&arr[a++],1,sizeof(int),fp);
  }
  puts("file reading ended");
  for(i=0;i<len;i++){
    for(j=0;j<len-i-1;j++){
      if(arr[j]>arr[j+1]) swap(&arr[j],&arr[j+1]);
    }
  }
  for(i=0;i<len;i++){
    printf("%d\n",arr[i]);
  }
}
void swap(int *a,int *b){
  int temp=*a;
  *a=*b;
  *b=temp;
}
