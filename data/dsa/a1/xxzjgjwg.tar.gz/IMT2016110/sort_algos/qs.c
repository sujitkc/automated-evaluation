#include<stdio.h>
#include<stdlib.h>
void swap(int *num1,int *num2);
void quick_sort(int arr[],int i, int j);
int partition(int arr[],int start,int end);

int main(){
  int arr[1000000];
  int i,j=0,len=1000000,a=0;
  FILE *fp;
  fp=fopen("file.txt","r");
  //puts("file reading started");
  for(i=1000000;i>0;i--){
    fread(&arr[a++],1,sizeof(int),fp);
  }
  //puts("filereading ended");
//  printf("%d\n",arr[0]);
  quick_sort(arr,0,len-1);
/*  for(int i=0;i<len;i++){
    printf("%d\n",arr[i]);
  }*/

}
void swap(int *num1,int *num2){
  int temp=*num2;
  *num2=*num1;
  *num1=temp;
}
void quick_sort(int arr[],int i, int j){
  if(i<j){
    int k=partition(arr,i,j);
    quick_sort(arr,i,k-1);
    quick_sort(arr,k+1,j);
  }
}
int partition(int arr[],int start,int end){
  int r=start+rand()%(end-start+1),i=start-1,p=arr[r];
  swap(&arr[r],&arr[end]);
  for(int m=start;m<end;m++){
    if(arr[m]<p){
      i+=1;
      swap(&arr[i],&arr[m]);
    }
  }
  swap(&arr[i+1],&arr[end]);
  return i+1;
}
