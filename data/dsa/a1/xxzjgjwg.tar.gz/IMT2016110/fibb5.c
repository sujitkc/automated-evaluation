#include<stdio.h>
#include<stdlib.h>
void mm(int (*a)[2],int (*b)[2]){
  int sol[2][2]={{0,0},{0,0}},i,j,k;
  for(i=0;i<2;i++){
    for(j=0;j<2;j++){
      for(k=0;k<2;k++){
        sol[i][j]+=a[i][k]*b[k][j];
      }
    }
  }
  for(i=0;i<2;i++){
    for(j=0;j<2;j++){
      //printf("%d\n",sol[i][j]);
      a[i][j]=sol[i][j]%100;
    }
  }
}
void power(int (*mat)[2],int n[],int nn){
  int y[2][2]={{1,0},{0,1}},i=nn-1,k=nn;
  while(i>=0){
    if(n[i]==1) mm(y,mat);
    mm(mat,mat);
    i-=1;
  //  printf("%d\n",mat[0][0]);
  }
  printf("%d\n",y[1][0]);
}
int main(){
  int a[2][2]={{1,1},{1,0}};
  int len =1000000;
  int n[len];
  for(int i=0;i<len;i++){
	int temp=rand()%2;
	n[i]=temp;
}
  power(a,n,len);
}
