#include<stdio.h>

 long int fibb(long int n){
  long int arr[n];
  arr[0]=0;
  arr[1]=1;
   long int i;
  for(i=2;i<=n;i++){
    arr[i]=(arr[i-1]+arr[i-2])%20;
  }
  return arr[n];
}
int main(){
  printf("%ld\n",fibb(16));
}
