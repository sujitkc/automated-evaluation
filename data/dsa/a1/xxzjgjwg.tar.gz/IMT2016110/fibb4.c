#include<stdio.h>
#include<stdlib.h>

int divide(int arr[],int d,int len);
int fibb( int n,int d);
int find_period(int d);

int main(){

  int arr[1000000],div=100,len=1000000;
  for(int i=0;i<len;i++){
    arr[i]=rand()%10;
  }
  int p=find_period(div);
  int rem = divide(arr,100,2);

  printf("%d\n",fibb(rem,div));
}
int divide(int arr[],int d,int len){
  int m=0,r,i=1,j=len-1;

  while(j>=0){
    while(d>m){
      m+=arr[j]*i;
      i*=10;
      j--;
      if(j<0) break;
    }
    r=m%d;
    m=r;
    i=1;
    while(i<r){
      i*=10;
    }
  }
  return r;
}
int fibb( int n,int d){
 int arr[n];
 int a=0,b=1,c;
 int i;

 for(i=2;i<=n;i++){
   c=(a+b)%d;
   a=b;
   b=c;
 }

 return c;
}
int find_period(int d){
  int i=2,a,b,c;
  a=0;b=1;
  for(i=3;i<=6*d;i++){
    c=(a+b)%100;
    a=b;
    b=c;
    if(a==0 && b==1) break;
  }
//  printf("%d",i-1);
  return i-2;

}

