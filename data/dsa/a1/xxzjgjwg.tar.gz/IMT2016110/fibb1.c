#include<stdio.h>
#include<stdlib.h>

int fibb(int n){
  if(n<2) return n;
  else{
    return (fibb(n-1)+fibb(n-2))%20;
  }
}
int main(){
  int x=fibb(16);
  printf("%d\n",x);
}
