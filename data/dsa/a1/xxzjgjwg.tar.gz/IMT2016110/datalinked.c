#include<stdio.h>
#include<stdlib.h>
#include <time.h>

struct node{
  int data;
  struct node *next;
};

void insertatend(struct node **head,int data);
int delete_first(int first, int second);
void shorten_list(struct node **head);
void shorten_array(struct node *arr[]);
void delete(struct node **sptr,int n);
void view(struct node *sptr){

	struct node *currentptr=sptr;
	while(currentptr!=NULL){
		printf("%d\n",currentptr->data);
		currentptr=currentptr->next;
		}
	}
int main(){
  struct node *arr[10000];
  int i,num1,num2;
  for(i=0;i<10000;i++){
    arr[i]=NULL;
  }
  //to create the nodes
  for(i=0;i<100000;i++){
    num1 = rand()%10000;
    num2=rand();
    insertatend(&arr[num1],num2);
    //delete(&arr[num1],num2);
  }
// After this all the linked lists contain only one element
  for(i=0;i<10000;i++){
    if(arr[i]!=NULL){
      if(arr[i]->next!=NULL){
        shorten_list(&arr[i]);
      }
    }
  }
  for(i=0;i<9999;i++){
    if(arr[i]!=NULL){
      printf("%d\t",arr[i]->data);
    }
  }
}
void insertatend(struct node **head,int data){
  struct node *strtptr=*head,*newptr;
  newptr=malloc(sizeof(struct node));
  newptr->data=data;
  newptr->next=NULL;
  if(strtptr==NULL){
    *head=newptr;
  }
  else{
    while(strtptr->next!=NULL){
      strtptr=strtptr->next;
    }
    strtptr->next=newptr;
  }
}
int delete_first(int first, int second){
  if(first%2==0 && second%2==0){
    if(first>second) return 1;
    else return 0;
  }
  else if(first%2==1 && second%2==1){
    if(first<second) return 1;
    else return 0;
  }
  else{
    if(first%2==1) return 1;
    else return 0;
  }
}
void delete(struct node **sptr,int n){
  int found=0,i;
  struct node *cur=*sptr,*prev;
  if(*sptr!=NULL){
    if((*sptr)->data==n) (*sptr)=(*sptr)->next;
    else{
      while((cur)!=NULL){
        if((cur)->data==n){
          found=1;
          break;
        }
        prev=cur;
        cur=cur->next;
      }
      if(found==1){
        prev->next=cur->next;
      }
    }
  }
}
void shorten_list(struct node **head){
  struct node *headptr;
  while((*head)->next!=NULL){
    //this will check for the first two elements
    if(delete_first((*head)->data,((*head)->next)->data)){
      delete(head,(*head)->data);
    }
    else{
      delete(head,((*head)->next)->data);
    }
    headptr=*head;
  //this will do the job for the rest of the elements

    while((headptr)->next!=NULL){
      if(delete_first((headptr)->data,((headptr)->next)->data)){
        delete(&headptr,(headptr)->data);
      }
      else{
        delete(&headptr,((headptr)->next)->data);
      }
      if(headptr->next!=NULL) headptr=headptr->next;
    }
  headptr=*head;
  }
}
