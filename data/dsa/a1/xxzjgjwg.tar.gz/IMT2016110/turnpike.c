#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>

struct node{
  int data;
  struct node *next;
};

int findmax(struct node *ptr);
bool delete(struct node **sptr,int n);
void insert(struct node **sptr,int n);
void create_solun(struct node **head,int arr[],int n);
bool try(struct node **head,int arr[],int n,int right,int left);
int abs(int n);
void view(struct node *sptr);
void failed_left(struct node **head,int arr[],int n,int index,int end,int max);
void failed_right(struct node **head,int arr[],int n,int index,int end,int max);

int main(){
  int i,arr[100],num=6;
  struct node *head=NULL;

    insert(&head,2);
    insert(&head,5);
    insert(&head,7);
    insert(&head,8);
    insert(&head,10);
    insert(&head,3);
    insert(&head,5);
    insert(&head,6);
    insert(&head,8);
    insert(&head,2);
    insert(&head,3);
    insert(&head,5);
    insert(&head,1);
    insert(&head,3);
    insert(&head,2);
    //view(head);
    create_solun(&head,arr,num);
}
bool try(struct node **head,int arr[],int n,int right,int left){

  int i;
  int max=findmax(*head);
  bool done= true;
  arr[right]=max;

  //BASE CASE
  if(right==left){
    arr[right]=findmax(*head);
      for(i=left-1;i>=0;i--){
        if(!delete(head,abs(arr[i]-arr[right]))) {
          done=false;
          failed_left(head,arr,n,left,i,max);
          break;
            }
        }

      for(i=right+1;i<n;i++){
        if(!delete(head,abs(arr[i]-arr[right]))) {
          done=false;
          failed_right(head,arr,n,right,i,max);
          break;
        }
      }

    if(!done) {
    //  failed(head,arr,n,left,right,max);
      int num=abs(max-arr[n-1]);
        arr[left]=num;

          for(i=left-1;i>=0;i--){
            if(!delete(head,abs(arr[i]-num))) {
              done=false;
              failed_left(head,arr,n,left,i,num);
              break;
            }
          }

         for(i=right+1;i<n;i++){
          if(!delete(head,abs(arr[i]-arr[right]))) {
            done=false;
            failed_right(head,arr,n,right,i,num);
            failed_left(head,arr,n,left,-1,num);
            break;
          }
        }
      }
    }
  //RECURSIVE CASE
  else{
    arr[right]=max;

      for(i=left-1;i>=0;i--){
        if(!delete(head,abs(arr[i]-max))) {
          done=false;
          failed_left(head,arr,n,left,i,max);
          break;
        }
      }
      for(i=right+1;i<n;i++){
        if(!delete(head,abs(arr[i]-max))) {
          done=false;
          failed_right(head,arr,n,right,i,max);
          failed_left(head,arr,n,left,-1,max);
          break;
        }
      }

    if(done){
      if (!try(head,arr,n,right-1,left)){
      done=false;
      failed_left(head,arr,n,right,n,max);
      failed_right(head,arr,n,left,-1,max);
      }
    }
// THE SECOND TRY
    if(!done){
      done=true;
      int num=abs(arr[n-1]-max);
      arr[left]=num;

        for(i=left-1;i>=0;i--){
          if(!delete(head,abs(arr[i]-num))) {
            done=false;
            failed_left(head,arr,n,left,i,num);
            break;
          }
        }

        for(i=right+1;i<n;i++){

        if(!delete(head,abs(arr[i]-num))) {
          done=false;
          failed_right(head,arr,n,right,i,num);
          failed_left(head,arr,n,left,-1,num);
          break;
          }
        }
        if(done){
          if (!try(head,arr,n,right,left+1)){
            done=false;
            failed_left(head,arr,n,left,-1,num);
            failed_right(head,arr,n,right,n,num);
            }
          }
        }
    }
return done;
}
void create_solun(struct node **head,int arr[],int n){
  int i,max=findmax(*head);
  delete(head,max);
  arr[0]=0;
  arr[n-1]=max;
  if(try(head,arr,n,n-2,1)) {
    for(i=0;i<n;i++){
    printf("%d\n",arr[i]);}
    return;
    }

  puts("NOT POSSIBLE");
}
int findmax(struct node *ptr){
  int max=0;
  while(ptr!=NULL){
    if (ptr->data > max);
    max=ptr->data;
    ptr=ptr->next;
  }
  return max;
}
bool delete(struct node **sptr,int n){
	struct node *currentptr,*prevptr;
	int found = 0;
	currentptr=*sptr;
	prevptr=*sptr;
	while(currentptr!=NULL){
		if((currentptr->data)==n){
			found=1;
			break;
			}
  		prevptr=currentptr;
  		currentptr=currentptr->next;
		}
	if(found==1){
    if(currentptr==(*sptr)){
      *sptr=(*sptr)->next;
      free(currentptr);
    }
    else{
  		prevptr->next=currentptr->next;
      free(currentptr);

    }
    return true;
		}
  return false;
}
void insert(struct node **sptr,int n){
	struct node *newptr,*currentptr,*prevptr;
	newptr=malloc(sizeof(struct node));
	newptr->data=n;
	newptr->next=NULL;
	currentptr=(*sptr);
	prevptr=(*sptr);

	if((*sptr)==NULL){
		(*sptr)=newptr;
    (*sptr)->next=NULL;
		}
	else if((*sptr)->data>=n){
		newptr->next=*sptr;
		*sptr=newptr;
		}
	else{
		while(1){
			if(currentptr==NULL){
				break;}
			if((currentptr->data)>=n){
				break;
				}
			prevptr=currentptr;
			currentptr=currentptr->next;
		}
		newptr->next=currentptr;
		prevptr->next=newptr;
		}
}
int abs(int n){
  if(n<0) return -n;
  return n;
}
void view(struct node *sptr){
  puts("view");
	struct node *currentptr=sptr;
	while(currentptr!=NULL){
		printf("%d\n",currentptr->data);
		currentptr=currentptr->next;
		}
	}
void failed_left(struct node **head,int arr[],int n,int index,int end,int max){
  int i;
  for(i=index-1;i>end;i--){
    insert(head,abs(arr[i]-max));
  }

}
void failed_right(struct node **head,int arr[],int n,int index,int end,int max){
  int i;
  for(i=index+1;i<end;i++){
    insert(head,abs(arr[i]-max));
}
}
