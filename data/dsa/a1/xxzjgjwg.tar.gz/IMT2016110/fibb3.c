#include<stdio.h>

 long int fibb(long int n){
  long int arr[n];
  long int a=0,b=1,c=n;
   long int i;
  for(i=2;i<n;i++){
    c=(a+b)%100;
    a=b;
    b=c;
  }
  return c;
}
int main(){
  printf("%ld\n",fibb(1000000));
}
