#include<stdio.h>
int r(int n){
  if(n<2){
    return n;
  }
  else{
    return ((r(n-1)+r(n-2))%100);
  }
}
int main()
{
  int n;
  printf("enter the position: ");
  scanf("%d",&n );
  printf("%d\n",r(n));
  return 0;
}
