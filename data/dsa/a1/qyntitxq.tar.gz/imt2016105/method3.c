#include<stdio.h>
int i(int n){
  if(n==0){
    return 0;
  }
  int a=0,j,b=1,c;
  for(j=2;j<=n;j++){
    c=(a+b)%100;
    a=b;
    b=c;
  }
  return b;
}
int main()
{
  int n;
  printf("enter the position: ");
  scanf("%d",&n );
  printf("%d\n",i(n));
  return 0;
}
