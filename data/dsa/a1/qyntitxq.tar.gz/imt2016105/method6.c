#include<stdio.h>
int mul(int b[2][2]);
int f(int n);

int a[2][2]={{1,1},{1,0}};


int main(){
  int n;
  printf("enter the position in binary: ");
  scanf("%d",&n );
  int binary_val,r,base=1,decimal_val=0;
  binary_val=n;

while (n> 0){
  r= n % 10;
  decimal_val = decimal_val + r * base;
  n = n/ 10 ;
  base = base * 2;
}
n=decimal_val;
  printf("%d\n",f(n));
  return 0;
}



int f(int n){
  int a[2][2]={{1,1},{1,0}};
  int q;
 if (n==1){return 0;}
 if (n==2){return 1;}
 if(n>2){
  for(int i=0;i<n-1;i++){
    q=mul(a);
  }
}
  q=q%100;
    return q;
  }



int mul(int b[2][2]){
  int r[2][2];
  int i=0,j=0;
  for(i=0;i<2;i++){
    for(j=0;j<2;j++){
      r[i][j]=(a[i][0]*b[0][j])+(a[i][1]*b[1][j]);
    }
  }
  for(i=0;i<2;i++){
    for(j=0;j<2;j++){
      a[i][j]=r[i][j]%100;
    }
  }
  return a[1][0];
}
