#include<stdio.h>
#include<time.h>
#include<stdlib.h>
int main(){

  int n=10;
  int a[n];
  for(int k=0;k<n;k++){
    a[k]=rand();
  }
  for(int i=0;i<n;i++){
    for(int j=i+1;j<n;j++)
     {
         if(a[i]>a[j])
        {
          int temp;
             temp=a[i];
             a[i]=a[j];
             a[j]=temp;
         }
  }

}

  for(int l=0;l<n;l++){
    printf("%d\n",a[l]);
  }


    return 0;
  }
