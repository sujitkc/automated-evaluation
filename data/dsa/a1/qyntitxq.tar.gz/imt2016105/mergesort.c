#include<stdio.h>
#include<stdlib.h>
int merge(int a[],int l[],int r[],int na,int nl,int nr){
  int i=0,j=0,k=0;
  while(i<nl && j<nr){
    if(l[i]<=r[j]){
      a[k]=l[i];
      i=i+1;
      k=k+1;
    }
    else{
      a[k]=r[j];
      k=k+1;
      j=j+1;
    }
  }
  while(i<nl){
    a[k]=l[i];
    i=i+1;
    k=k+1;
  }
  while(j<nr){
    a[k]=r[j];
    j=j+1;
    k=k+1;
  }
  }
int mergesort(int a[],int na){
  int mid=na/2;
  if(na<2){
    return a[0];
  }
  else{
    int la[mid];
    int ra[mid];
    int i;
    for(i =0;i<mid;i++){
      la[i]=a[i];
    }
    int j;
    for(i=mid,j=0;i<na;i++,j++){
      ra[j]=a[i];
    }
    mergesort(la,mid);
    mergesort(ra,mid);
    merge(a,la,ra,na,mid,mid);

  }
}
int main(){

  int a[10];
  int i;
  for(i=0;i<10;i++){
    a[i]=rand();
  }
  mergesort(a,10);
  for(int z=0;z<10;z++){
    printf("%d\n",a[z]);
  }

}
