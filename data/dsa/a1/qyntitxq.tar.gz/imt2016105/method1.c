#include <stdio.h>
int p(int a){
  int p[a+1];
  p[0]=0;
  p[1]=1;
  for(int i=2;i<=a;i++){
    p[i]=(p[i-1]+p[i-2])%100;
  }
  return p[a];
}
void main()
{
  int i,n;
  printf("enter the position: ");
  scanf("%d",&n );
  i=p(n);
  printf("%d\n",i);
}
