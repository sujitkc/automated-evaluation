#include<stdio.h>
#include<stdlib.h>
int main()
{
  int n=10;
	int a[n],temp,i,j;
	for(i=0;i<n;i++)
	{
		a[i]=rand();
	}
	for(i=1;i<n;i++)
	{
		temp = a[i];
		j=i-1;
		while(temp<a[j] && j>=0)
		{
			a[j+1] = a[j];
			--j;
		}
    a[j+1]=temp;
	}
	for(i=0; i<n; i++){
		printf("%d\n",a[i]);
}
    return 0;
}
