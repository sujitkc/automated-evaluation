from random import randint
l=[[randint(0,100000) for i in range(0,10)]for j in range(0,10000)]
def short(l):
    a=len(l)
    for k in range(0,a-1):
        if(l[k]%2==0 and l[k+1]%2==0):
            if(l[k]<=l[k+1]):
                l.remove(l[k])
            else:
                l.remove(l[k+1])
            break
        elif(l[k]%2!=0 and l[k+1]%2!=0):
            if(l[k]>=l[k+1]):
                l.remove(l[k])
            else:
                l.remove(l[k+1])
            break
        elif(l[k]%2!=0 and l[k+1]%2==0):
            if(l[k]<=l[k+1]):
                l.remove(l[k])
            else:
                l.remove(l[k+1])
            break
        elif(l[k]%2==0 and l[k+1]%2!=0):
            if(l[k]>=l[k+1]):
                l.remove(l[k])
            else:
                l.remove(l[k+1])
            break
    k=k+2
z=[]
for m in range(0,len(l)):
    while(len(l[m])!=1):
        short(l[m])
    z.append(l[m][0])
while(len(z)!=1):
    short(z)
print z
