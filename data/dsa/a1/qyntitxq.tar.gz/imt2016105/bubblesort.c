#include<stdio.h>
#include<time.h>
#include<stdlib.h>
int main(){

  int n=10;
  int a[n];
  for(int k=0;k<n;k++){
    a[k]=rand();
  }
  for(int i=0;i<n-1;i++){
    for (int j=0;j<n-1-i;j++){
      if(a[j]>a[j+1]){
        int s;
        s=a[j];
        a[j]=a[j+1];
        a[j+1]=s;
      }

    }
  }
for(int l=0;l<n;l++){
  printf("%d\n",a[l]);
}
printf("done\n");

  return 0;
}
