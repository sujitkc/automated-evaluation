#include<stdio.h>
#include<time.h>
#include<stdlib.h>

int main(){
	int a[10], tmp, j;
	srand(time(0));
	for(int i=0;i<10;i++){
		a[i] = rand()%100;
		printf("%d ", a[i]);
	}
	for(int i=1;i<10;i++){
		tmp = a[i];
		j = i-1;
		while(j>=0 && a[j]>tmp){
			a[j+1] = a[j];
			j--;
		}
		a[j+1] = tmp;
	}
	printf("\n\n\n");
	for(int i=0;i<10;i++)
		printf("%d ", a[i]);
}