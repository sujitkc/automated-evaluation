#include<stdio.h>
#include<stdlib.h>
#include<time.h>

void msort(int a[], int l, int r);
void merge(int a[], int l, int k, int r);
void swap(int *a, int *b);
int b[10];

int main(){
	srand(time(0));
	int a[10];
	for(int i=0;i<10;i++){
		a[i] = rand()%100;
		printf("%d ", a[i]);
	}
	msort(a, 0, 9);
	printf("\n\n\n");
	for(int i=0;i<10;i++)
		printf("%d ", a[i]);
}

void swap(int *a, int *b){
	int tmp = *a;
	*a = *b;
	*b = tmp;
}

void merge(int a[], int l, int k, int r){
	int i = l, j = k+1, ctr = 0;
	while(i<=k && j<=r){
		if(a[i]<a[j])	b[ctr++] = a[i++];
		else			b[ctr++] = a[j++];
	}
	while(i<=k)
		b[ctr++] = a[i++];
	while(j<=r)
		b[ctr++] = a[j++];
	for(int tmp=l;tmp<=r;tmp++)
		a[tmp] = b[tmp-l];
}

void msort(int a[], int l, int r){
	if(l+1 == r)
		swap(&a[l], &a[r]);
	else if(r > l+1){
		int k = (r+l)/2;
		msort(a, l, k);
		msort(a, k+1, r);
		merge(a, l, k, r);
	}
}