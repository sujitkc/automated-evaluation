#include<stdio.h>

int recursive_fib_gen(int n){
	if(n<2)
		return n%100;
	else
		return (recursive_fib_gen(n-1)+recursive_fib_gen(n-2))%100;
}

int main(){
	int n;
	scanf("%d",&n);
	printf("%d",recursive_fib_gen(n));
	return 0;
}