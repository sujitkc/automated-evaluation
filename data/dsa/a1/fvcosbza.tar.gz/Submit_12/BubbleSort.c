#include<stdio.h>
#include<time.h>
#include<stdlib.h>

int main(){
	srand(time(0));
	int a[10], tmp;
	for(int i=0;i<10;i++){
		a[i] = rand()%100;
		printf("%d ", a[i]);
	}
	for(int i=0;i<10;i++){
		for(int j=0;j<(10-i-1);j++){
			if(a[j]>a[j+1]){
				tmp = a[j];
				a[j] = a[j+1];
				a[j+1] = tmp;
			}
		}
	}
	printf("\n\n\n");
	for(int i=0;i<10;i++)
		printf("%d ", a[i]);
}