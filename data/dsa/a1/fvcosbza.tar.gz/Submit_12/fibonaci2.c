#include<stdio.h>

int main(){
	int a[1000];
	a[0] = 0;
	a[1] = 1;
	for(int i=2;i<1000;i++){
		a[i] = (a[i-1] + a[i-2])%100;
	}
	printf("\nEnter the required value : ");
	int n;
	scanf("%d", &n);
	printf("Required Value : %d\n",a[n]);
	return 0;
}