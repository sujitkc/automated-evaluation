#include<stdio.h>
#include<stdlib.h>
#include<time.h>

int partition(int a[], int p, int r, int k){
	int x = a[r], i = p-1, tmp;
	//printf("Pivot : %d\n",x);
	for(int j=p;j<r;j++){
		if(a[j]<=x){
			i++;
			tmp = a[i];
			a[i] = a[j];
			a[j] = tmp;
		}
	}
	tmp = a[i+1];
	a[i+1] = a[r];
	a[r] = tmp;
	return i+1;
}

int rqs(int a[], int p, int r){
	if(p < r){
		int k = p + rand()%(r-p+1);
		int tmp = a[k];
		a[k] = a[r];
		a[r] = tmp;
		int q = partition(a, p, r, k);
		rqs(a, p, q-1);
		rqs(a, q+1, r);
	}
}

int main(){
	srand(time(0));
	int a[10];
	for(int i=0;i<10;i++){
		a[i] = rand()%100;
		printf("%d ", a[i]);
	}
	printf("\n");
	rqs(a, 0, 9);
	printf("\n\n\n");
	for(int i=0;i<10;i++)
		printf("%d ", a[i]);
}