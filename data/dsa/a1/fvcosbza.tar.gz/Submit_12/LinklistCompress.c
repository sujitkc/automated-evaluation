#include<stdio.h>
#include<stdlib.h>

struct node{
	int data;
	struct node *next;
};

void delete(struct node **head, int val);
void add(struct node **head, int n);
void check(int a, int b, struct node **head);
void traversal(struct node **head);
void verticalcompress(struct node *arr[], int size);

void add(struct node **startptr, int value)
{
	struct node *new_node;
	new_node=(struct node *)malloc(sizeof(struct node));
	new_node->data = value;
	new_node->next = *startptr;
	*startptr = new_node;
}

void delete(struct node **head, int val){
	struct node *currentptr=*head;
	struct node *prevptr=NULL;
	if(currentptr->data == val){
		struct node *temp=(*head);
		(*head)=temp->next;
		free(temp); 
	}
	else{
		while(currentptr->data!=val){
			prevptr = currentptr;
			currentptr = currentptr->next;
		}
		prevptr->next = currentptr->next;
		free(currentptr);
	}
}

void check(int a, int b, struct node **head){
	if(((a%2) == 0) && ((b%2) == 1))
		delete(head, b);
	else if(((a%2) == 1) && ((b%2) == 0))
		delete(head, a);
	else if(((a%2) == 0) && ((b%2) == 0))
		if(a>b)
			delete(head, a);
		else
			delete(head, b);
	else if(((a%2) == 1) && ((b%2) == 1))
		if(a>b)
			delete(head, b);
		else
			delete(head, a);
} 

void traversal(struct node **head){
	if((*head) == NULL)
		return;
	struct node *cur, *nxt, *tmp1, *tmp2;
	cur = (*head);
	nxt = (*head)->next;
	while(1){
		if(cur == NULL || nxt == NULL)
			return;
		else{
			tmp1 = cur;
			tmp2 = nxt;
			check(cur->data, nxt->data, &cur);
			cur = nxt->next;
			if(cur == NULL){
				cur = (*head);
				nxt = (*head)->next;
			}
			nxt = cur->next;
			if(nxt == NULL){
				cur = (*head);
				nxt = cur->next;
			}
		}
	}
}

void verticalcompress(struct node *arr[], int size){
	int flag, a, b;
	int ctr = 4;
	struct node *head = NULL;
	struct node *temp;
	do{
	for(int i=0; i<(size-1); i++){
		head = arr[i];
		if(head != NULL){
			a = head->data;
			for(int j=i+1; j<size; j++){
				//head = head->next;
				if(head != NULL){
					b = head->data;
					i = j;
					if(a%2 == 0 && b%2 == 0){
						if (b>a){
							temp = arr[j];
							free(temp);
							arr[j] = 0;
						}
						else{
							temp = arr[i];
							free(temp);
							arr[i] = 0;
						}
					}
					else if(a%2 == 1 && b%2 == 1){
						if (b<a){
							temp = arr[j];
							free(temp);
							arr[j] = 0;	
						}
						else{
							temp = arr[i];
							free(temp);
							arr[i] = 0;
						}	
					}
					else{
						if(a%2 == 1){
							temp = arr[i];
							free(temp);
							arr[i] = 0;
						}
						else{
							temp = arr[j];
							free(temp);
							arr[j] = 0;
						}
					}
				}
			}
		}
	}
	head = arr[0];
	for(int i=0;i<size;i++){
		if(head != NULL)
			ctr++;
	}
	}while(ctr==1);
}

int main(){
	struct node *a[4] = {0};
	int n,x;
	for(int i=0;i<4;i++){
		n = rand()%100;
		x = rand()%4;
		printf("Value : %d Position : %d\n", n, x);
		add(&a[x], n);
	}
	printf("\n\n\n");
	for(int i=0;i<4;i++)
		traversal(&a[i]);
	printf("After horizontal compression\n");
	for(int i=0;i<4;i++){
		if(a[i] != NULL){
			printf("%d\n",a[i]->data);
			if(a[i]->next == NULL)
				printf("NULL\n");
		}
		else{
			printf("NULL\n");
		}
	}
	verticalcompress(a, 4);
	printf("\n\n\nAfter vertical compression\n");
	for(int i=0;i<4;i++){
		if(a[i] != NULL){
			printf("%d\n",a[i]->data);
			if(a[i]->next == NULL)
				printf("NULL\n");
		}
		else{
			printf("NULL\n");
		}
	}
	return 0;
}