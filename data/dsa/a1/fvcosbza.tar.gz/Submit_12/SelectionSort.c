#include<stdio.h>
#include<stdlib.h>
#include<time.h>

int swap(int *a, int *b){
	int tmp = *a;
	*a = *b;
	*b = tmp;
}

int main(){
	int a[10];
	srand(time(0));
	for(int i=0;i<10;i++){
		a[i] = rand()%100;
		printf("%d ", a[i]);
	}
	int pos;
	for(int i=0;i<9;i++){
		pos = i;
		for(int j=i+1;j<10;j++){
			if(a[j]<a[pos])
				pos = j;
		}
		if(pos != i)
			swap(&a[i], &a[pos]);
	}
	printf("\n\n\n");
	for(int i=0;i<10;i++){
		printf("%d ", a[i]);
	}
}