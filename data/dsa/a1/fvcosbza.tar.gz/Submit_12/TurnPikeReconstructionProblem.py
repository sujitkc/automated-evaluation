d = [2,2,2,3,4,4,5,5,6,7,8,9,9,10,12,14,14,18,19,22,22,23,24,26,27,28,28,31,33,35,37,40,41,46,49,49,51,53,55,63,68,71,73,75,77]
m = len(d)
n = int((((1+8*m)**0.5)+1)/2)

print "Distance : ", d

def check(d, ans, l, r, num):
	tmparr = []
	lst1 = range(0,l)
	lst2 =  range(r+1, n)
	lst = lst1+lst2
	for i in lst:
		try:
			tmp = abs(num - ans[i])
			d.remove(tmp)
			tmparr.append(tmp)
		except Exception:
			d.extend(tmparr)
			return False
	return True		

def try_right(d, ans, l, r, val, lindex):
	if(check(d, ans, l, int(r), val)):
		ans[r] = val
		lindex.append(r)
		#print "Add right, Value : ", val, "   Ans : ", ans, "   d : ", d
		eval(d, ans, l, int(r-1), lindex)

def try_left(d, ans, l, r, val, lindex):
	if(check(d, ans, l, r, val)):
		ans[l] = val
		lindex.append(l)
		#print "Add left, Value : ", val, "   Ans : ", ans, "   d : ", d
		eval(d, ans, l+1, r, lindex)

def backtrack(d, ans, l, r, lindex):
	lasti = lindex.pop()
	if(lindex == []):
		print "No Solution"
		exit()

	print "BackTrack"
	for i in range(l) + range(r+1, n):
		d.append(abs(ans[lasti] - ans[i]))
	d.remove(0)
	ans[lasti] = -1

def eval(d, ans, l, r, lindex):
	try:
		val = max(d)
	except Exception:
		print "\n\n\nSolved"
		print "Answer : ", ans
		exit()
	
	try_right(d, ans, l, r, val, lindex)
	val = abs(max(d) - ans[n-1])
	try_left(d, ans, l, r, val, lindex)
	backtrack(d, ans, l, r, lindex)

ans = []
for i in range(n):
	ans.append(-1)
ans[0] = 0
ans[n-1] = max(d)
d.remove(max(d))
l = 1
r = int(n-2)
lindex = [n-1]
eval(d, ans, l, r, lindex)