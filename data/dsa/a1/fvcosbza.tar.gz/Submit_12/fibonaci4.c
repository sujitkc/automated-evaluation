#include<stdio.h>
#include<stdlib.h>

int main(){
	int a = 0;
	int b = 1;
	int c = 1, n;
	printf("Enter the required value : ");
	scanf("%d", &n);
	while(n){
		c = (a + b) % 100;
		a = b;
		b = c;
		n--;
	}
	printf("c : %d",c);
}