#include<stdio.h>

int main(){
	printf("Enter the required value : ");
	int a[500], i=3;
	a[0] = 0;
	a[1] = 1;
	a[2] = 1;
	while(a[i-2]!=a[0] || a[i-1]!=a[1]){
		a[i] = (a[i-2] + a[i-1])%100;
		i++;
	}
	int p = i-2, n;
	scanf("%d",&n);
	printf("\nPeriod : %d\nValue : %d", p, a[n%p]);
	return 0;
}