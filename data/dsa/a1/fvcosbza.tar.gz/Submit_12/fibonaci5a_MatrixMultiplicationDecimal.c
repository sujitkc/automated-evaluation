#include<stdio.h>
#include<string.h>

void divide(int a[100]);
void matrixMultiplication(int a[2][2], int b[2][2], int ans[2][2]);
int isZero(int a[], int size);
int isOdd(int a[], int size);
int eval(int arr[], int size);
void dividebytwo(int a[], int size);
void printarray(int a[2][2]);

int main(){
	char inch[100];
	printf("Enter the exponent in decimal\n");
	scanf("%s",inch);
	int a[100];
	for(int i=0;i<strlen(inch);i++)
		a[i] = (int)(inch[i]) -'0';
	//printf("Size %d\n",(int)strlen(inch));
	printf("Required Value : %d", eval(a, strlen(inch)));
	return 0;
}

int isZero(int a[], int size){
	int ctr = 0;
	for(int i=0;i<size;i++)
		if(a[i]==0)
			ctr++;
	return ctr == size;
}

int isOdd(int a[], int size){
	return (a[size-1]%2==1);
}

void printarray(int a[2][2]){
	for(int i=0;i<2;i++){
		for(int j=0;j<2;j++)
			printf("%d ", a[i][j]);
		printf("\n");
	}	
}

int eval(int arr[], int size){
	int ans[2][2] = {{1,0},{0,1}};
	int a[2][2] = {{1,1},{1,0}};
	//printf("isZero() return status : %d\n",isZero(arr, size));
	while(!isZero(arr, size)){	
		if(isOdd(arr, size))
			matrixMultiplication(ans, a, ans);
		matrixMultiplication(a, a, a);
		dividebytwo(arr, size);
		/*
		for(int i=0;i<size;i++)
			printf("%d", arr[i]);
		*/
		printf("\n");
	}
	/*
	for(int i=0;i<2;i++){
		for(int j=0;j<2;j++)
			printf("%d ", ans[i][j]);
		printf("\n");
	}
	*/
	return 	ans[1][0];	
}

void matrixMultiplication(int a[2][2], int b[2][2], int ans[2][2]){
	int tmp[2][2] = {{0,0},{0,0}};
	for(int i=0;i<2;i++){
		for(int j=0;j<2;j++){
			for(int k=0;k<2;k++){
				tmp[i][j] += (a[i][k] * b[k][j]);
				tmp[i][j] %= 100;
			}
		}
	}
	for(int i=0;i<2;i++)
		for(int j=0;j<2;j++)
			ans[i][j] = tmp[i][j];
}

void dividebytwo(int a[], int size){
	for(int i=0;i<size;i++){
		if(a[i]%2==1)
			a[i+1] = a[i+1] +10;
		a[i] /= 2;
	}
}