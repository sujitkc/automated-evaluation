#include<stdio.h>
#include<math.h>

void mm(int a[2][2], int b[2][2], int ans[2][2]){
	int tmp[2][2] = {{0,0},{0,0}};
	for(int i=0;i<2;i++){
		for(int j=0;j<2;j++){
			for(int k=0;k<2;k++){
				tmp[i][j] += (a[i][k] * b[k][j]);
				tmp[i][j] %= 100;
			}
		}
	}
	for(int i=0;i<2;i++)
		for(int j=0;j<2;j++)
			ans[i][j] = tmp[i][j];
}

int contobin(int n, int a[]){
	int x = 0;
	while(n!=0){
		if(n%2 == 0)	a[x] = 0;
		else			a[x] = 1;
		n /= 2;
		x++;
	}
	return x;
}

int eval(int n){
	int a[2][2] = {{1,1},{1,0}};
	int ans[2][2] = {{1,0},{0,1}};
	int arr[1000000];
	int y = 0;
	int size = contobin(n, arr);
	while(y < size){
		if(arr[y] == 1)
			mm(ans,a,ans);
		mm(a,a,a);
		y++;
	}
	return ans[1][0];
}

int main(){
	/*int a[2][2] = {{1,2}, {3,4}}, b[2][2] = {{5,6}, {7,8}}, c[2][2] = {{0,0}, {0,0}};
	mm(a, b, c);
	for(int i=0;i<2;i++){
		for(int j=0;j<2;j++)
			printf("%d ",c[i][j]);
		printf("\n");
	}*/
	printf("Enter the exponent : ");
	int n;
	scanf("%d",&n);
	printf("\n\n\n%d",eval(n));
	return 0;
}