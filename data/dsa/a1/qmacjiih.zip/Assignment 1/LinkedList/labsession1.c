#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#define RANGE 1000
#define ARRAY_SIZE 10
#define COUNT 100

struct node{
  int data;
  struct node * next;
};

typedef struct node NODE;

NODE * newNode(int data,NODE *next);
void insertBeg(NODE **start,int data);
void view(NODE * head);
void f1(NODE *head,NODE **prevNextPtr);
int f2(NODE **head,int n);

int main(){
  srand(time(NULL));
  NODE *arr[ARRAY_SIZE]={0};
  int i;
  for(i=0;i<COUNT;i++){
    int j=rand()%ARRAY_SIZE;
    int data=rand()%RANGE;
    insertBeg(&arr[j],data);
  }

  for(i=0;i<ARRAY_SIZE;i++){
    view(arr[i]);
    while(arr[i] && arr[i]->next)f1(arr[i],&arr[i]);
  }

  printf("\n");

  for(i=0;i<ARRAY_SIZE;i++){
    view(arr[i]);
  }

  printf("\nSoln: ");

  while(f2(arr,ARRAY_SIZE));

  for(i=0;i<ARRAY_SIZE;i++){
    if(arr[i])view(arr[i]);
  }
}

NODE * newNode(int data,NODE *next){
  NODE * temp=(NODE*)malloc(sizeof(NODE));
  temp->data=data;
  temp->next=next;
  return temp;
}

void insertBeg(NODE **start,int data){
      NODE *temp=newNode(data,*start);
      *start=temp;
}

void view(NODE * head){
  while(head){
    printf("%d ",head->data);
    head=head->next;
  }
  printf("\n");
}

void f1(NODE *head,NODE **prevNextPtr){
  if(head==NULL)return;
  if(head->next==NULL)return;
  NODE *t1=head;
  NODE *t2=head->next;

  if(t1->data%2==0 && t2->data%2==1){
    NODE *t3=t2->next;
    free(t2);
    t1->next=t3;
    f1(t3,&t1->next);

  }
  else if(t1->data%2==1 && t2->data%2==0){
    free(t1);
    *prevNextPtr=t2;
    f1(t2->next,&t2->next);
  }
  else if(t1->data%2==0 && t2->data%2==0&& t2->data>=t1->data){
    NODE *t3=t2->next;
    free(t2);
    t1->next=t3;
    f1(t3,&t1->next);

  }
  else if(t1->data%2==0 && t2->data%2==0&& t2->data<t1->data){
    free(t1);
    *prevNextPtr=t2;
    f1(t2->next,&t2->next);
  }
  else if(t1->data%2==1 && t2->data%2==1&& t2->data<=t1->data){
    NODE *t3=t2->next;
    free(t2);
    t1->next=t3;
    f1(t3,&t1->next);

  }
  else if(t1->data%2==1 && t2->data%2==1&& t2->data>t1->data){
    free(t1);
    *prevNextPtr=t2;
    f1(t2->next,&t2->next);
  }

}



int f2(NODE **head,int n){

  int n1=0;
  int n2=0;
  while(head[n1]==NULL&&n1<n)n1++;
  n2=n1+1;
  while(head[n2]==NULL&&n2<n)n2++;
//  printf("%d:%d\n",n1,n2);
  if(n1==n || n2==n)return 0;

  NODE *t1=head[n1];
  NODE *t2=head[n2];

  if(t1->data%2==0 && t2->data%2==1){
    free(t2);
    head[n2]=0;
  }
  else if(t1->data%2==1 && t2->data%2==0){
    free(t1);
    head[n1]=0;
  }
  else if(t1->data%2==0 && t2->data%2==0&& t2->data>=t1->data){
    free(t2);
    head[n2]=0;
  }
  else if(t1->data%2==0 && t2->data%2==0&& t2->data<t1->data){
    free(t1);
    head[n1]=0;
  }
  else if(t1->data%2==1 && t2->data%2==1&& t2->data<=t1->data){
    free(t2);
    head[n2]=0;
  }
  else if(t1->data%2==1 && t2->data%2==1&& t2->data>t1->data){
    free(t1);
    head[n1]=0;
  }
  f2(head+n2+1,n-n2-1);
  return 1;

}
