#include<stdio.h>
int algo3(int n){
  int a=0;
  int b=1;
  int c=1;
  int i;
  for(i=2;i<=n;i++){
    c=(a+b)%100;
    a=b;
    b=c;
  }
  return c;
}
int main(){
  int i=0;
  for(i=0;i<1000;i++)
  printf("%d:%d \n",i,algo3(i));
}
