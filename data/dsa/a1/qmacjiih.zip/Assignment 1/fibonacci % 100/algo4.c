#include<stdio.h>
int algo3(int n){
  int a=0;
  int b=1;
  int c=1;
  int i;
  for(i=2;i<=n;i++){
    c=(a+b)%100;
    a=b;
    b=c;
  }
  return c;
}
// 67542
// 43210
int mod(char n[],int p){
  int i=0;
  int r=0;
  while(n[i]!='\0'){
    r=(r*10+n[i]-'0')%p;
    i++;
  }
  return r;
}

int algo4(char n[]){
  int num=mod(n,300);
  return algo3(num);
}
int main(){
  printf("%d",algo4("120987654347890987654334567890987654323456789098765432345678907654567865456789098765432234567890098765433"));
}
