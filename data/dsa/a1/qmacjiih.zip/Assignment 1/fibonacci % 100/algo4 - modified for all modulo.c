#include<stdio.h>
int algo3(int n,int m){
  int a=0;
  int b=1;
  int c=1;
  int i;
  for(i=2;i<=n;i++){
    c=(a+b)%m;
    a=b;
    b=c;
  }
  return c;
}
int mod(char n[],int p){
  int i=0;
  int r=0;
  while(n[i]!='\0'){
    r=(r*10+n[i]-'0')%p;
    i++;
  }
  return r;
}

int findPeriod(int m){
  int a=0;
  int b=1;
  int c=1;
  int i=0;
  while(1){
    i++;
    c=(a+b)%m;
    if(b==0 && c==1)return i;
    a=b;
    b=c;
  }
  return 0;
}

int algo4(char n[],int m){
  int p=findPeriod(m);
  int num=mod(n,p);
  return algo3(num,m);
}
int main(){
  int i;
  printf("%d\n",algo4("121435987654323456789098765432345678909876541354",10));
  N
}
