#include<stdio.h>
#include<string.h>

//This assumes string input as Decimal

void rev(char *s){
  int l=strlen(s),i;
  for(i=0;i<l/2;i++){
    char t=s[i];
    s[i]=s[l-i-1];
    s[l-i-1]=t;
  }
}

int divide(char n[],int d){
  int r=0;
  rev(n);
  int l=strlen(n);
  int i=l-1;
  while(i>=0){
    int c=n[i]-'0';
    n[i]=(10*r+c)/d+'0';
    r=(r*10+c)%d;
    i--;
  }
  while(n[--l]=='0'){
    n[l]='\0';
  }
  rev(n);
  return r;
}

void MM(int A[2][2],int B[2][2],int m){
  int t[2][2]={0},i,j,k;

  for(i=0;i<2;i++)
    for(j=0;j<2;j++)
      for(k=0;k<2;k++)
        t[i][j]+=A[i][k]*B[k][j];
  for(i=0;i<2;i++)
    for(j=0;j<2;j++)
        A[i][j]=t[i][j]%m;
}

int algo6(char n[],int m){
  int x[2][2]={{1,1},{1,0}};
  int y[2][2]={{1,0},{0,1}};
  int l=strlen(n);
  int i=l-1;
  while(strlen(n)!=0){
    if(divide(n,2))MM(y,x,m);
    MM(x,x,m);
  }
  return y[1][0];
}



int main(){
  char n[]="24";
  printf("%d\n",algo6(n,100));

}
