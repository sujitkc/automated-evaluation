#include<stdio.h>
int algo1(int n){
  if(n<2)return n;
  return (algo1(n-1)+algo1(n-2))%100;
}
int main(){
  int i=0;
  for(i=0;i<100;i++)
  printf("%d:%d\n",i,algo1(i));
}
