#include<stdio.h>
#include<string.h>

//This assumes string input as binary

void MM(int A[2][2],int B[2][2],int m){
  int t[2][2]={0},i,j,k;

  for(i=0;i<2;i++)
    for(j=0;j<2;j++)
      for(k=0;k<2;k++)
        t[i][j]+=A[i][k]*B[k][j];
  for(i=0;i<2;i++)
    for(j=0;j<2;j++)
        A[i][j]=t[i][j]%m;
}

int algo5(char n[],int m){
  int x[2][2]={{1,1},{1,0}};
  int y[2][2]={{1,0},{0,1}};
  int l=strlen(n);
  int i=l-1;
  while(i>=0){
    if(n[i]=='1')MM(y,x,m);
    MM(x,x,m);
    i--;
  }

  return y[1][0];
}


int main(){
  int i,j;
  printf("%d \n",algo5("1010",100));


}
