#include<stdio.h>
int algo2(int n){
  int arr[n+1];
  arr[0]=0;
  arr[1]=1;
  int i=2;
  for(i=2;i<=n;i++){
    arr[i]=(arr[i-1]+arr[i-2])%100;
  }
  return arr[n];
}
int main(){
  int i=0;
  for(i=0;i<100000;i++)
  printf("%d:%d\n",i,algo2(i));
}
