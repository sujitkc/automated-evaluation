#include<stdio.h>
//Use NumberList.txt as input of 10^6 elements using piping or use generateList.c to generate Numbers and then pipe

//real	0m0.068s
//user	0m0.063s
//sys	0m0.002s 10^4

//real	0m6.151s
//user	0m6.124s
//sys	0m0.012s 10^5

void sort(int *arr,int n){
  int i,j,min,t;
  for(i=1;i<n;i++){
      t=arr[i];
      for(j=i-1;j>=0&&(t<arr[j]);j--)
        arr[j+1]=arr[j];

      arr[j+1]=t;
    }
}

void printArr(int *arr,int n){
  int i;
  for(i=0;i<n;i++)printf("%d\n",arr[i]);

}
int main(){
  int i;
  int n;
  scanf("%d",&n);
  int arr[n];
  for(i=0;i<n;i++){
    scanf("%d",arr+i);
  }

  sort(arr,n);
  printArr(arr,n);

}
