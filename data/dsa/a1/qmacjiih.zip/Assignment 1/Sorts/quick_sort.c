//Use NumberList.txt as input of 10^6 elements using piping or use generateList.c to generate Numbers and then pipe

// real	0m0.432s
// user	0m0.412s
// sys	0m0.014s 10^6

// real	0m0.404s
// user	0m0.386s
// sys	0m0.012s
#include<stdio.h>
#include<limits.h>
#include<stdlib.h>
#include<time.h>

void printArr(int *arr,int n){
  int i;
  for(i=0;i<n;i++)printf("%d ",arr[i]);
  printf("\n");

}

int partition(int *arr,int i,int j){
  int p=rand()%(j-i+1)+i;
  int pivot=arr[p];
  int t=arr[j];
  arr[j]=arr[p];
  arr[p]=t;

  int l=i-1,r;

  while(l<j-1&&arr[l+1]<=pivot)l++;
  for(r=l+1;r<j;r++){
    if(arr[r]<pivot){
        l++;
        t=arr[l];
        arr[l]=arr[r];
        arr[r]=t;
      }
  }

  l++;
  t=arr[j];
  arr[j]=arr[l];
  arr[l]=t;
  return l;
}
void quickSort(int *arr,int i,int j){
  if(j<=i)return;

  int k=partition(arr,i,j);
  quickSort(arr,i,k-1);
  quickSort(arr,k+1,j);
}

int main(){

  srand(time(NULL));
  int i;
  int n;
  scanf("%d",&n);
  int arr[n];
  for(i=0;i<n;i++){
    scanf("%d",arr+i);
  }

  quickSort(arr,0,n-1);
  for(i=0;i<n;i++)
    printf("%d\n",arr[i]);


}
