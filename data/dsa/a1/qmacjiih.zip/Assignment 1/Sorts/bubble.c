#include<stdio.h>
//Use NumberList.txt as input of 10^6 elements using piping or use generateList.c to generate Numbers and then pipe

//real	0m0.299s
//user	0m0.292s
//sys	  0m0.003s for 10^4 elements

//real	0m35.256s
//user	0m35.068s
//sys	  0m0.090s for 10^5 elements

// real	0m25.214s
// user	0m25.203s
// sys	0m0.009s for 10^5

void sort(int *arr,int n){
  int i,j,t;
  for(i=0;i<n-1;i++){
    for(j=0;j<n-1-i;j++){
      if(arr[j]>arr[j+1]){
        t=arr[j];
        arr[j]=arr[j+1];
        arr[j+1]=t;
      }
    }
  }
}

void printArr(int *arr,int n){
  int i;
  for(i=0;i<n;i++)printf("%d\n",arr[i]);

}
int main(){
  int i;
  int n;
  scanf("%d",&n);
  int arr[n];
  for(i=0;i<n;i++){
    scanf("%d",arr+i);
  }

  sort(arr,n);
  printArr(arr,n);

}
