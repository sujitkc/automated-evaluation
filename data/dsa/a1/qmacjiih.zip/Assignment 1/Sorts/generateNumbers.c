#include<stdio.h>
#include <time.h>
#include <stdlib.h>

int main(int argc,char *argv[]){


  int n,i,l,u;
  srand(time(NULL));
  n=atoi(argv[1]);
  l=atoi(argv[2]);
  u=atoi(argv[3]);

  printf("%d\n",n);
  for(i=0;i<n;i++){
    printf("%d\n",rand()%(u-l)+l);
  }
}
