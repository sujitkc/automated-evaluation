#include<stdio.h>
//Use NumberList.txt as input of 10^6 elements using piping or use generateList.c to generate Numbers and then pipe

// real	0m11.421s
// user	0m11.386s
// sys	0m0.018s 10^5

// real	0m0.128s
// user	0m0.123s
// sys	0m0.002s 10^4

void sort(int *arr,int n){
  int i,j,min,t;
  for(i=0;i<n-1;i++){
    min=i;
    for(j=i+1;j<n;j++){
      if(arr[j]<arr[min])min=j;
    }
    if(min!=i){
      t=arr[i];
      arr[i]=arr[min];
      arr[min]=t;
    }
  }
}

void printArr(int *arr,int n){
  int i;
  for(i=0;i<n;i++)printf("%d\n",arr[i]);

}
int main(){
  int i;
  int n;
  scanf("%d",&n);
  int arr[n];
  for(i=0;i<n;i++){
    scanf("%d",arr+i);
  }

  sort(arr,n);
  printArr(arr,n);

}
