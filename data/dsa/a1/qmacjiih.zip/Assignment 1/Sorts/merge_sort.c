//Use NumberList.txt as input of 10^6 elements using piping or use generateList.c to generate Numbers and then pipe

// real	0m0.010s
// user	0m0.006s
// sys	0m0.001s 10^4

// real	0m0.048s
// user	0m0.043s
// sys	0m0.003s 10^5

//real	0m0.452s
//user	0m0.426s
//sys	  0m0.016s   // for 10^6 elements

#include<stdio.h>
#include<limits.h>
#include<stdlib.h>
void merge(int *arr,int p,int q,int r){
  int n1=q-p+1;
  int n2=r-q;

  int L[n1+1];
  int R[n2+1];

  int i,j,k;
  for(i=0;i<n1;i++)L[i]=arr[p+i];
  for(i=0;i<n2;i++)R[i]=arr[q+i+1];

  L[n1]=INT_MAX;
  R[n2]=INT_MAX;

  for(i=0,j=0,k=0;i<n1+n2;i++){

    if(L[j]<=R[k])arr[i+p]=L[j++];
    else arr[i+p]=R[k++];
  }
}
void mergeSort(int *arr,int p,int r){
  if(r==p)return;
  int q=p+(r-p)/2;
  mergeSort(arr,p,q);
  mergeSort(arr,q+1,r);
  merge(arr,p,q,r);
}

int main(){


  int i;
  int n;
  scanf("%d",&n);
  int arr[n];
  for(i=0;i<n;i++){
    scanf("%d",arr+i);
  }

  mergeSort(arr,0,n-1);
  for(i=0;i<n;i++)
    printf("%d\n",arr[i]);


}
