#include<stdio.h>
int rec(int n);
int main(){
	int n=10;
	printf("%d\n",rec(n));
}

int rec(int n){
	if(n<2)
	 return n;
	 
	else{
		return((rec(n-1)+rec(n-2))%100);
	}
}
