#include<time.h>
#include<stdlib.h>
#include<stdio.h>
int fib4(int a,int b);
int fib3(int n);
int remainder(int a[],int n);
int main(){
	int a[1000],period,rea;
	srand(time(NULL));
	for (int i=0;i<1000;i++){
		a[i]=rand()%10;
	}
	period=fib4(0,1);
	rea=remainder(a,period);
	printf("%d\n",fib3(rea));
}
int fib4(int a,int b){
	int c,i;
	c=0;
	i=0;
	while(1){
		c=(a+b)%100;
		a=b;
		b=c;
		if(i!=0 && a==0 && b==1)
		  break;
		else
		 i++;
	}return i+1;
}
int remainder(int a[],int n){
	int i,m;
	int remainder1=0;
	m=sizeof (a)/sizeof (int) ;
	for(i=0;i<m;i++){
	remainder1=(remainder1*10 + a[i]) %n ; } 
	return remainder1;
}
int fib3(int n){
	int a,b,c,i;
	a=0;
	b=1;
	c=n;
	for(i=2;i<=n;i++){
		c=(a+b)%100;
		a=b;
		b=c;
	}return c;
}
