#include<stdio.h>

void main()
{
    int i,j,temp,A[10000]; 
	
	for(i=0;i<10000;i++)
	{
		A[i]=rand();
	}
	for(i=0;i<10000;i++)
	{
		for(j=i;j>0;j--)
		{
			if(A[j]<A[j-1])
			{
				temp=A[j];
				A[j]=A[j-1];
				A[j-1]=temp;
			}
		}
	}
    for(i=0;i<10000;i++)
    { 
	  printf("%d\n",A[i]);
    }
}