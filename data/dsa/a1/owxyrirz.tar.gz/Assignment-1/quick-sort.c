#include<stdio.h>
#include<stdlib.h>

int partition (int arr[], int l, int r)
{
    int pivot_index = l + rand() % (r-l+1);
    int pivot = arr[pivot_index];

    swap(&arr[pivot_index], &arr[r]);
    pivot_index = r;    

    int i = (l - 1);  
	int j; 
    for (j = l; j <= r- 1; j++)
    {
        if (arr[j] <= pivot)
        {
            i++;    
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[i + 1], &arr[pivot_index]);
    return (i + 1);
}
 
void quick_sort(int arr[], int l, int r)
{
    if (l < r)
    {
        
        int pivot_1 = partition(arr, l, r);
 
        quick_sort(arr, l, pivot_1 - 1);
        quick_sort(arr, pivot_1 + 1, r);
    }
}
void swap(int *p, int *q)
{
	int temp;
	temp = *p;
	*p = *q;
	*q = temp;
}

void printArray(int arr[], int size)
{
	int i;
    for (i = 0; i < size; i++)
    {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

int main()
{
	int i, j, arr[1000000];
	int size = 1000000;
	
	srand(time(NULL));
	
	for(i=0; i<size; i++)
		arr[i] = rand();
		
	quick_sort(arr, 0, size-1);
	printf("Sorted array is: ");
	printArray(arr, size);

	return 0;
}
