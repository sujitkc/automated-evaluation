#include<stdio.h>
 
int fib(int n)
{
  int a[n+1];
  int i;
 
  a[0] = 0;
  a[1] = 1;
 
  for (i = 2; i <= n; i++)
  {
    a[i] = (a[i-1] + a[i-2])%100;
  }
 
  return a[n];
}
 
int main ()
{
  int n;
  printf("Enter n: ");
  scanf("%d", &n);
  printf("\nAnswer = %d", fib(n));
  
  return 0;
}
