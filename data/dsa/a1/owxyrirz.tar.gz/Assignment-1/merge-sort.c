#include<stdio.h>

void Merge(int a[], int i, int k, int j){
	int b[1000000];
	int l = i;
	int r = k+1;
	int x=0;
	
	int y;
	
	while(l<=k && r<=j){
		if(a[l]<a[r])
			b[x++]=a[l++];
		else
			b[x++]=a[r++];
	}
	
	while(l<=k)
		b[x++]=a[l++];
		
	while(r<=j)
		b[x++]=a[r++];
		
	x=0;
	for(y=i; y<=j; )
	{
		a[y++]=b[x++];		
    }
}


void MergeSort(int a[], int i, int j){
	if(i<j){
	int k = (i+j)/2;
	MergeSort(a, i, k);
	MergeSort(a, k+1, j);
	Merge(a, i, k, j);
    }
}


int main()
{
	int i, j, a[1000000];
	int n = 1000000;
	
	srand(time(NULL));
	
	for(i=0; i<n; i++)
		a[i] = rand();	
		
	MergeSort(a, 0, 999999);
	
	printf("\n");
	
	for(i=0; i<n; i++)
		printf("%d  ", a[i]);
	
	return 0;	

}
