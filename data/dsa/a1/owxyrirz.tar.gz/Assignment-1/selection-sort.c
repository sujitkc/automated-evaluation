#include<stdio.h>

void swap(int *x, int *y){
	int t;
	t = *x;
	*x = *y;
	*y = t;	
}

int main()
{
	int i, j, a[1000000], m;
	int n = 1000000;
	
	srand(time(NULL));
	
	for(i=0; i<n; i++)
		a[i] = rand(); 
		
	for(j=n-1; j>0; j--)
	{
		m = j;
		for (i = j-1; i>=0; i--)
		{
			if(a[i]>a[m])
				m = i;
		}		
		swap(&a[m], &a[j]);		
	}
	
	printf("Sorted:\n ");
	for(i=0; i<n; i++)
		printf("%d  ", a[i]);
	
	return 0;	
}

