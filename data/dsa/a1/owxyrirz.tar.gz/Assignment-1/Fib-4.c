#include<stdio.h>
int m;
int fib(int n)
{
  int a = 0, b = 1, c, i;
  if( n == 0)
    return a;
  for (i = 2; i <= n; i++)
  {
     c = (a + b)%m;
     a = b;
     b = c;
  }
  return b;
}
 
int period(int m){
	int i;
	for(i=1; i<6*m; i++){
		if((fib(i)==0)&&(fib(i+1)==1))
			return i;
	}
}
 
int main ()
{
  int n;
  int x, p;
  printf("Enter n and m (respectively): ");
  scanf("%d %d", &n, &m);
  p = period(m);
  if(n>p)
    x = fib(n%p);
  else
    x = fib(n);  
  printf("\nPeriod = %d", p);
  printf("\nAnswer = %d", x);
  
  return 0;
}
