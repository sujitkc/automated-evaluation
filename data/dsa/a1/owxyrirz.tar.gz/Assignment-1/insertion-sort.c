#include<stdio.h>

int main()
{
	int i, j, a[1000000], t;
	int n = 1000000;
	
	srand(time(NULL));
	
	for(i=0; i<n; i++)
		a[i] = rand(); 
	
	for(i=1; i<n; i++){
		t=a[i];
		j=i-1;
		while(j>=0 && a[j]>t){
			a[j+1] = a[j];
			j--;
		}
		a[j+1] = t;
	}
	
	printf("Sorted:\n");
	for(i=0; i<n; i++)
		printf("%d  ", a[i]);
	
	return 0;	

}
