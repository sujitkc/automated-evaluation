#include<stdio.h>

void swap(int *x, int *y){
	int t;
	t = *x;
	*x = *y;
	*y = t;	
}

int main()
{
	int i, j, a[1000000];
	int n = 1000000;
	void swap(int *, int *);
	
	srand(time(NULL));
	
	for(i=0; i<n; i++)
		a[i] = rand(); 
	
	for(j=0; j<n; j++){
		for(i=0; i<n-1-j; i++){
			if(a[i]>a[i+1])
				swap(&a[i], &a[i+1]);
		}
	}	
	
	printf("Sorted:\n ");
	for(i=0; i<n; i++)
		printf("%d  ", a[i]);
	
	return 0;	

}
