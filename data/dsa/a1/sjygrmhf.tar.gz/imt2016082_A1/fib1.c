#include<stdio.h>
int func(int n){
	if(n==0||n==1)
		return n;
	else
		return (func(n-1)+func(n-2))%100;
}
int main(){
	int ans,num;
	printf("Enter the value of n:\n");
	scanf("%d",&num);
	ans=func(num);
	printf("F(%d) is %d\n",num,ans);
}
