#include<stdio.h>
int partition(int arr[],long int i,long int j,long int p)
{
	int x=*(arr+j);
	*(arr+j)=*(arr+p);
	*(arr+p)=x;
	x=*(arr+j);
	int l=i-1,m;
	for(m=i;m<=j-1;m++)
	{
		if(*(arr+m)<=x)
		{
			l++;
			int temp=*(arr+l);
			*(arr+l)=*(arr+m);
			*(arr+m)=temp;		
		}
	}
	int t=*(arr+l+1);
	*(arr+l+1)=*(arr+j);
	*(arr+j)=t;
	return l+1;
}
void QuickSort(int arr[],long int i,long int j)
{
  long int x=0;
	if(i<j)
	{
		long int p=i+rand()%(j-i+1);
		long int k=partition(arr,i,j,p);
    QuickSort(arr,i,k-1);
    QuickSort(arr,k+1,j);
    
	}
}
int main()
{
	FILE *fptr;
	fptr=fopen("file.txt","r");
	int size=10;
	int arr[size],i=0,num;
	while(fscanf(fptr,"%d",&num)>0)
	{
		arr[i]=num;
		i++;
	}
	fclose(fptr);
	QuickSort(arr,0,size-1);
	for(i=0;i<size;i++)
	{
		printf("%d\n",arr[i]);
	}
}
