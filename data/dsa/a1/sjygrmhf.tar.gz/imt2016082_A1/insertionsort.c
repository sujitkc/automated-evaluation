#include<stdio.h>
int main()
{
    int n;
	printf("Enter the size of array:\n");
	scanf("%d",&n);
	int arr[n],i,j,temp,num;
	printf("Enter the elements of array:\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
    for(i=1;i<n;i++)
    {
        num=arr[i];
        j=i-1;
        while(j>=0&&arr[j]>num)
        {
            arr[j+1]=arr[j];
            j--;
        }
        arr[j+1]=num;
    }  
    for(i=0;i<n;i++)
	{
		printf("%d ",arr[i]);
	}  
}
