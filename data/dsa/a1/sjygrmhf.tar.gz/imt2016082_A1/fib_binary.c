#include<stdio.h>
#include<string.h>
void MatrixMul(int *a,int *x){
	int row=2,col=2,i,j,k,pro=0;
	int m[2][2];
	for(i=0;i<row;i++){
		for(j=0;j<col;j++){
			pro=0;
			for(k=0;k<col;k++){
				pro+= (*((a+i*col)+k) * *((x+k*col)+j));
			}
			m[i][j]=pro;	
		}
	}
	for(i=0;i<row;i++){
		for(j=0;j<col;j++){
			*((a+i*col)+j)=m[i][j]%100;	
		}
	}
}
int main(){
  int a[2][2]={{1,0},{0,1}},cnt=0;
	int x[2][2]={{1,1},{1,0}},i;
	char s[10000];
	printf("Enter n in binary:\n");
	scanf("%s",s);
  int n[strlen(s)];
	for(i=0;i<strlen(s);i++){
		n[i]=s[i]-48;
	}
  for(i=strlen(s)-1;i>=0;i--){
    if(n[i]==1){
      MatrixMul((int *)a,(int *)x);
    }
    MatrixMul((int *)x,(int *)x);
	}
  printf("%d\n",a[1][0]);
}
