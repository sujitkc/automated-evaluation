#include<stdio.h>
#include<string.h>
#include<math.h>
int div(int *n,int len,int p){
	int carry=0,num,i;
	for(i=0;i<len;i++){
		num=(*(n+i)+carry*10)/p;
		carry=(carry*10 + *(n+i))%p;
		*(n+i)=num;
	}
	return carry;
}
int main(){
	char s[10000];
	printf("Enter the value of n:\n");
	scanf("%s",s);
	int num[strlen(s)],i,m,p;
	printf("Enter the value of m:\n");
	scanf("%d",&m);
	for(i=0;i<strlen(s);i++){
		num[i]=s[i]-48;
	}
	int a=0,b=1,c;	
	for(i=2;i<=m*m+1;i++){
		c=(a+b)%m;
		a=b;
		b=c;
		if(a==0&&b==1){
			break;	
		}
	}
	a=0;
	b=1;
	p=i-1;
	//printf("%d\n",p);
	int n=0,r=0;
	r=div(num,strlen(s),p);
	//printf("%d\n",r);
	if(r==0||r==1){
    printf("F(%d) is %d\n",r,r);
	}
	else{
		for(i=2;i<=r;i++){
			c=(a+b)%m;
			a=b;
			b=c;
		}
		printf("F(%s) is %d\n",s,c);
	}
}
