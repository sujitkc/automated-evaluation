from math import *
import random
def distance(s,num):
	a=[]
	a.append(num)
	for i in s:
		if i!=0:
			a.append(abs(i-num))
	return a

def check(d,s,num):
	c=d[0:]
	for i in distance(s,num):
		if i not in c:
			return False
		else:
			c.remove(i)
	return True

def backtrack(d,s,i,j):
	n=len(s)
	flag=0
	for x in s[0:n-1]:
		if x!=0:
				flag=1
				break
		if flag!=1:
			flag=0
	if(j<n-1 and i>0 and flag==1):
		num=min(s[j+1],max(s)-s[i-1])
		if num==s[j+1]:
			for x in distance(s,s[j+1]):
					d.append(x)
			d.remove(0)
			s[j+1]=0
			if check(d,s,max(s)-num):
					for x in distance(s,max(s)-num):
						d.remove(x)
					s[i]=s[n-1]-num
					func(d,s,i+1,j+1)
			else:
					backtrack(d,s,i,j+1)
		else:
			for x in distance(s,s[i-1]):
				d.append(x)
			d.remove(0)
			s[i-1]=0
			backtrack(d,s,i-1,j)
	if flag==0:
			print 'Impossible'
			return

def func(d,s,i,j):
	n=len(s)
	if len(d)==0:
		for x in s[1:]:
			if x==0:
				print "Impossible"
				return 0
		print s
		return 1
	elif i>0 and j>0 and i<n and j<n:
		Max=max(d)
		if check(d,s,Max):
			for x in distance(s,Max):
				d.remove(x)
			s[j]=Max
			func(d,s,i,j-1)
		elif check(d,s,max(s)-Max):
			for x in distance(s,max(s)-Max):
				d.remove(x)
			s[i]=s[n-1]-Max
			func(d,s,i+1,j)
		else:
			backtrack(d,s,i,j)
	else:
		print "Impossible"
		return 0
def t1():
	print '\t\t\tTest Case:1(Random)'
	print 'Distance array is:'
	d=[random.randint(1,10) for x in range(random.randint(1,10))]
	print d
	l=len(d)
	n=int((1+sqrt(1+8*l))/2)
	s=[0 for i in range(n)]
	print 'Coordinate array is:'
	func(d,s,1,n-1)
	print

def t2():
	print '\t\t\tTest Case:2'
	d=[1,2,2,2,3,3,3,4,5,5,5,6,7,8,10]
	print 'Distance array is:'
	print d
	l=len(d)
	n=int((1+sqrt(1+8*l))/2)
	s=[0 for i in range(n)]
	print 'Coordinate array is:'
	func(d,s,1,n-1)
	print

def t3():
	print '\t\t\tTest Case:3'
	d=[1,3,6,9,10,13,14,16,18,2,5,8,9,12,13,15,17,3,6,7,10,11,13,15,3,4,7,8,10,12,1,4,5,7,9,3,4,6,8,1,3,5,2,4,2,3,5,7,8,11,12,15,18,20,21]
	print 'Distance array is:'
	print d
	l=len(d)
	n=int((1+sqrt(1+8*l))/2)
	s=[0 for i in range(n)]
	print 'Coordinate array is:'
	func(d,s,1,n-1)
t1()
t2()
t3()
