#include<stdio.h>
int main(){
	int a=0,b=1,c,m=100;
	long int i,n;
	printf("Enter the value of n:\n");
	scanf("%ld",&n);
  if(n==0||n==1){
    printf("F(%ld) is %ld\n",n,n);
  }
  else{
	  for(i=2;i<=n;++i){
		  c=(a+b)%100;
		  a=b;
		  b=c;
	  }
	printf("F(%ld) is %d\n",n,c);
  }
}
