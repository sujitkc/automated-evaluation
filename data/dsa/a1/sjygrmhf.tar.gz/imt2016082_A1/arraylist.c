#include<stdio.h>
#include<stdlib.h>
struct node{
	int data;
	struct node *next;
};
void add(int num,struct node **head)
{
    struct node *new;
    new=malloc(sizeof(struct node));
    new->data=num;
    new->next=*head;
    *head=new;
}
void deleteFirst(struct node **head,struct node**curr)
{
	 struct node *temp;
	 temp=*curr;
	 if(*head==*curr){
                                
				*curr=(*curr)->next;
        *head=*curr;
        free(temp);			
			}
   else{
        struct node *prev;
        prev=*head;
        while(prev->next!=*curr){
          prev=prev->next;
        }
        prev->next=(*curr)->next;
        *curr=(*curr)->next;
        free(temp);
   }
}
void deleteSecond(struct node **head,struct node**curr)
{
	struct node *temp;
			temp=(*curr)->next;
			(*curr)->next=temp->next;
			if(temp->next!=NULL)
				*curr=temp->next;
			free(temp);
}
void operate(struct node **head)
{
	while(*head&&(*head)->next){
  	struct node *curr;
     curr=*head;
     while(curr->next){
      if(curr->data%2==0&&curr->next->data%2==0){
        if(curr->data>=curr->next->data){
         deleteFirst(head,&curr);
        }
        else{
				 deleteSecond(head,&curr);
        }
      }
			else if(curr->data%2!=0&&curr->next->data%2!=0){
				if(curr->data<=curr->next->data){
					deleteFirst(head,&curr);
				}
				else{
					deleteSecond(head,&curr);
				}
			}
			else if((curr->data%2==0&&curr->next->data%2!=0)||(curr->data%2!=0&&curr->next->data%2==0)){
				if(curr->data%2!=0){
					deleteFirst(head,&curr);
				}
				else{
					deleteSecond(head,&curr);
				}
			}
    }       
  }
}
int main()
{
		long int n=21,l=5,x;//n:no. of nodes l:len of arraylist
		struct node * arr[l];
		for(x=0;x<l;x++){
			arr[x]=NULL;
		}
		int i,j;
		while(n>0){
			n--;
			i=rand()%l;
			j=rand()%1000;//to generate numbers less than 1000
			add(j,&arr[i]);
    }
    for(x=0;x<l;x++){
        struct node **head;
        head=&arr[x];
        operate(head);
    }
		printf("After horizontal deletion:\n");
		for(x=0;x<l;x++){
				printf("%d\n",(*arr[x]).data);
		}
		struct node *startptr;
		startptr=malloc(sizeof(struct node));
		startptr=NULL;
		for(x=l-1;x>=0;x--){
				if(arr[x]){
				add(arr[x]->data,&startptr);}
		}
		operate(&startptr);
    struct node *curr;
		curr=startptr;
		while(curr){
				printf("Final answer: %d\n",curr->data);
				curr=curr->next;
		}
}
