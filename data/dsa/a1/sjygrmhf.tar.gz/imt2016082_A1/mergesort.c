#include<stdio.h>
void Merge(int arr[],long int i,long int k,long int j)
{
  long int l,r,x=0;
  int b[j-i+1];
  l=i;
  r=k+1;
  while(l<=k&&r<=j)
  {
    if(*(arr+l)<=*(arr+r))
    {
      b[x]=*(arr+l);
      l++;
      x++;
    }
    else
    {
      b[x]=*(arr+r);
      r++;
      x++;
    }
  }
  while(l<=k)
  {
    b[x]=*(arr+l);
    l++;
    x++;
  }
  while(r<=j)
  {
    b[x]=*(arr+r);
    r++;
    x++;
  }
  x=0;
  for(l=i;l<=j;l++)
  {
    *(arr+l)=b[x];
    x++;
  }
}
void MergeSort(int arr[],long int i,long int j)
{
  
  if(j<=i+1)
    {
      if(*(arr+i)>*(arr+j))
        {
          int temp=*(arr+i);
          *(arr+i)=*(arr+j);
          *(arr+j)=temp;
        }
    }
  else
  {
    long int k=(i+j)/2;
    MergeSort(arr,i,k);
    MergeSort(arr,k+1,j);
    Merge(arr,i,k,j);
  }
}
int main()
{
	FILE *fptr;
	fptr=fopen("file.txt","r");
	int size=10;
	int arr[size],i=0,num;
	while(fscanf(fptr,"%d",&num)>0)
	{
		arr[i]=num;
		i++;
	}
	fclose(fptr);
	MergeSort(arr,0,size-1);
  	for(i=0;i<size;i++)
  	{
    		printf("%d\n",arr[i]);
  	}
}
