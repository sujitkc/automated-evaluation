from random import *
il=[0]
times=randrange(8,10)
for i in range(times):
        k=randrange(1,20)
        while k not in il:
                il.append(k)
il.sort()
print "initial list"
print il
il=[0,7,13,14,17]
l=[]
while len(il) is not 1:
        x=il.pop()
        for q in il:
                g=abs(q-x)
                l.append(g)
l.sort()
print "list of distances"
print l
def distance(element,dis,c,number):
    while dis!=[]:
        val=mmax(dis)
        list1=verify(val,element,dis)
        list12=verify((element[-1]),element,dis)
        if list1!=False:
            for k in list1:
                dis.remove(k)
            element=element[:c]+[val]+element[c:]
        elif list12!=False:
            for k in list1:
                dis.remove(k)
            element=element[:c]+[element[-1]-val]+element[c:]
            c+=1
        else:
            list12=False
            while(list12==False):
                for q in element:
                    if q!=element[c]:
                        ab=(q-element[c]) if q>element[c] else (element[c]-q)
                        dis.append(ab)
                val2=element[-1]-element[c]
                element.remove(element[c])
                list12=verify(val2,element,dis)
                if list12!=False:
                    for k in list12:
                        dis.remove(k)
                    element=element[:c]+[val2]+element[c:]
                    c+=1
    return element
def mmax(list1):
    m=list1[0]
    for i in list1:
        if i>m:
            m=i
    return m
def verify(val,element,dis):
    list1=[]
    chk=[]
    for i in element:
        if(i!=-1):
            found=0
            for j in range(len(dis)):
                if not j in chk:
                    if val-i==dis[j] or i-val==dis[j]:
                        list12=False
                        while(list12==False):
                            for q in element:
                                if q!=element[c]:
                                    ab=(q-elementt[c])if q>element[c] else (element[c]-q)
                                    dis.append(ab)
                            val2=element[-1]-element[c]
                            element.remove(element[c])
                            list12=verify(val2,element,dis)
                            if list12!=False:
                                for k in list12:
                                    dis.remove(k)
                                element=element[:c]+[val2]+element[c:]
                                c+=1
    return element
def verify(val,element,dis):
    list1=[]
    chk=[]
    for i in element:
        if(i!=-1):
            found=0
            for j in range(len(dis)):
                if not j in chk:
                    if val-i==dis[j] or i-val==dis[j]:
                        chk.append(j)
                        list1.append(dis[j])
                        found=1
                        break
            if found==0:
                return False
    return list1
def begin(dis,number):
    element=[0]+[dis[-1]]
    dis.remove(dis[-1])
    nod=distance(element[:],dis,1,number)
    print nod
#l=[1,2,2,2,3,3,3,4,5,5,5,6,7,8,10]
print "One of possible answer is:"
print begin(l,times)
