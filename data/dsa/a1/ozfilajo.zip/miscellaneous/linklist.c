//linked list problem
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
struct node
{
    int data;
    struct node *next;
};struct node *arr[10];
struct node head;
void rdelete()
{
    int j,i;
    for(i=0;i<10;i++)
    {
        if(arr[i]!=NULL)
        {
            int  k;
            for(j=i+1;j<10;j++)
            {
                if(arr[j]!=NULL)
                {
                    k=j;
                    break;
                }
            }
        if(j!=10)
        {
            if((arr[i]->data)%2==0 &&(arr[k]->data)%2==0)
            {
                if(arr[i]->data > arr[k]->data)
                {
                    arr[i]=NULL;
                    head.data  = arr[k]->data;
                }
                else
                {
                    arr[k]=NULL;
                    head.data=arr[i]->data;
                    i=i-1;
                }
            }
            else if(((arr[i]->data)%2!=0 && (arr[k]->data)%2!=0))
            {
                if(arr[i]->data > arr[k]->data)
                {
                    arr[k]=NULL;
                    head.data=arr[i]->data;
                    i=i-1;
                }
                else
                {
                    arr[i]=NULL;
                    head.data  = arr[k]->data;
                }
            }
            else if(((arr[i]->data)%2==0 && (arr[k]->data)%2!=0))
            {
                arr[k]=NULL;
                head.data=arr[i]->data;
                i=i-1;
            }
            else if(((arr[i]->data)%2!=0 && (arr[k]->data)%2==0))
            {
                arr[i]=NULL;
                head.data  = arr[k]->data;
            }
        }
        }
    }

}
void print(int i)
{
    int a;
    a=i;
    struct node *temp = arr[a];
    if(temp==NULL)
    {
        printf("NULL\n");
    }
    else
    {
        while(temp!=NULL)
        {
            printf("%d  ",temp->data);
            temp=temp->next;
        }
        printf("\n");
    }
}
void ldelete(int a){
        struct node *temp=arr[a];
        if(((temp->data)%2==0 && (temp->next->data)%2==0))
        {
            if(temp->data > temp->next->data)
            {
                arr[a]=temp->next;
                free(temp);
            }
            else
            {
                temp=temp->next;
                arr[a]->next = temp->next;
                free(temp);
            }
        }
        else if(((temp->data)%2==0 && (temp->next->data)%2!=0))
        {
          temp=temp->next;
          arr[a]->next = temp->next;
          free(temp);
        }
        else if(((temp->data)%2!=0 && (temp->next->data)%2==0))
        {
          arr[a]=temp->next;
          free(temp);
        }

        else if(((temp->data)%2!=0 && (temp->next->data)%2!=0))
        {
            if(temp->data > temp->next->data)
            {
              temp=temp->next;
              arr[a]->next = temp->next;
              free(temp);
            }
            else
            {
              arr[a]=temp->next;
              free(temp);
            }
        }
}
void main(){
    head.next=NULL;
    srand(time(NULL));
    struct node *temp,*n,*q;
    int i;
    for(i=0;i<10;i++)
    {
        arr[i]=NULL;
    }
    int a,b;
    for(i=0;i<10;i++)
    {
        a=rand()%10;
        b=rand()%100;
        temp=malloc(sizeof(struct node));
        temp->data=b;
        temp->next=NULL;
        if(arr[a]==NULL)
            {
                arr[a]=temp;
            }
        else

        {
            n = arr[a];
            while(n->next!=NULL)
            {
                n=n->next;
            }
            n->next=temp;
        }
    }
    for(i=0;i<10;i++)
    {
        print(i);
    }
    printf("\nDELETE\n");
    struct node *rah = NULL;
    for(i=0;i<10;i++)
    {
        rah = arr[i];
        if(rah==NULL || rah->next==NULL)
        {
            continue;
        }
        else
        {
            while(rah->next!=NULL)
            {
                ldelete(i);
                rah = arr[i];
            }
        printf("\n");

        }
    }
    for(i=0;i<10;i++)
    {
        print(i);
    }
    rdelete();
    printf("\n%d\n",head.data);
}
