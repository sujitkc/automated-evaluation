//using recursion
#include<stdio.h>
#include<stdlib.h>
int fib(int i)
{
  int c;
  if(i==i||i==0)
  {
    return i;
  }
  else
  {
    c=fib(i-1)+fib(i-2);
    return c;
  }
}
void main()
{
  int num,i,temp;
  printf("Enter the number till where you want the series\n");
  scanf("%d",&num);
  printf("The series is\n");
  for(i=0;i<num;i++)
  {
    temp=fib(i);
    if(temp<=num)
      printf("%d\n",temp);
    else
      break;
  }
}
