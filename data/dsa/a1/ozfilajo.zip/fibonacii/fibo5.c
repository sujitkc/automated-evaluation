//matrix way of fibonaci
#include<stdio.h>
#include<math.h>
#include<time.h>
int matmul(int a[][2],int b[][2])
{
    int mul[2][2],i,j,k;
    for(i=0;i<2;++i)
    {
        for(j=0;j<2;++j)
        {
            mul[i][j]=0;
            for(k=0;k<2;++k)
                mul[i][j]=(mul[i][j]+a[i][k]*b[k][j])%100;
      }
    }
	for(i=0;i<2;++i)
	{
        for(j=0;j<2;++j)
        {
            a[i][j]=mul[i][j];
		}
	}
}
double power(int arr[])
{
    int A[][2] = {{1,1},{1,0}},Ans[][2]={{1,0}, {0,1}};
    int c=100;
    while(c>0)
    {
        if(arr[c]==1)
            matmul(Ans,A);
        matmul(A,A);
        c--;
    }
    return Ans[1][0];
}
void main()
{
    int arr[100],i;
    time_t t;
    srand((unsigned) time(&t));
    for(i=0;i<100;i++)
    {
        arr[i]=rand()%2;
        printf("%d",arr[i]);
    }
    int ans;
    ans=power(arr);
    printf("\n%d",ans);
}
