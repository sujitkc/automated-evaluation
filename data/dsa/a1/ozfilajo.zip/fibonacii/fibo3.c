//using same 2 digits
#include<stdio.h>
#include<stdlib.h>
int num1=0,num2=1;
int fib(int i)
{
  if(i==0||i==1)
  {
    return i;
  }
  else
  {
    int numf;
    numf=(num1+num2)%100;
    num1=num2;
    num2=numf;
    return numf;
  }
}
void main()
{
    int numo,i,temp;
    printf("Enter the number of the term till where you want the series\n");
    scanf("%d",&numo);
    printf("The series is\n");
    for(i=0;i<=numo;i++)
    {
        temp=fib(i);
        printf("%d\n",temp);
    }
}
