//periodicity
#include<time.h>
#include<stdio.h>
void main()
{
    printf("number is\n");
    int v,l,arr[1000],i,r,c,temp[3];
    time_t t;
    srand((unsigned) time(&t));
    for(i=0;i<1;i++)
    {
        r=rand()%999;
        printf("%d",r);
        arr[i]=r;
    }
    i=999;
    long int j;
    j=arr[i];
    while(i>0)
    {
        i--;
        v=0;
        if(arr[i]/100!=0)
        {
            c=3;
            temp[v++]=arr[i]/100;
            temp[v++]=arr[i]/10-10*temp[v-1];
            temp[v]=arr[i]-10*temp[v-1]-100*temp[v-2];
        }
        if(arr[i]/10!=0)
        {
            c=2;
            temp[v++]=arr[i]/100;
            temp[v]=arr[i]/10-10*temp[v-1];
        }
        else
        {
            c=1;
            temp[v]=arr[i];
        }
        for(l=0;l<c;l++)
        {
            j=j*10+temp[l];
        }
        j=j%100;
    }
    printf("\nAnswer is %ld",j);
}

