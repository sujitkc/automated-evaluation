//using array
#include<stdio.h>
#include<stdlib.h>
int temp=2;
int buffer(int i)
{
  int a1[10000],c;
  a1[0]=0;
  a1[1]=1;
  if(i<2)
    return a1[i];
  else
  {
    a1[temp]=a1[temp-1]+a1[temp-2];
    c=a1[temp];
    temp+=1;
    return c;
  }
}
void main()
{
  int num,i,temp;
  printf("Enter the number till where you want the series\n");
  scanf("%d",&num);
  printf("The series is\n");
  for(i=0;i<num;i++)
  {
    temp=buffer(i);
    if(temp<=num)
      printf("%d\n",temp);
    else
      break;
  }
}
