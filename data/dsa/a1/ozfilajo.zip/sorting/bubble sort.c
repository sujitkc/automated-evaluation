//bubble sort
#include<stdio.h>
#include<stdlib.h>
void main()
{
    int i,arr[101],j,temp;
    time_t t;
    srand((unsigned) time(&t));
    printf("printing unsorted array\n");
    for(i=0;i<100;i++)
    {
        arr[i]=rand()%1000;
        printf("%d  ",arr[i]);
    }
    for(j=0;j<99;j++)
    {
        for(i=0;i<99-j;i++)
        {
            if(arr[i+1]<arr[i])
            {
                temp=arr[i];
                arr[i]=arr[i+1];
                arr[i+1]=temp;
            }
        }
    }
    printf("\nprinting sorted array\n");
    for(i=0;i<100;i++)
    {
        printf("%d  ",arr[i]);
    }
}
