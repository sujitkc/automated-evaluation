//quick sort
#include<stdio.h>
#include<stdlib.h>
void sort(int *a,int *b)
{
    int t;
    t=*a;
    *a=*b;
    *b=t;
}
int partition(int arr[],int l,int h)
{
    int pivot,m,i,j,c;
    time_t t;
    srand((unsigned) time(&t));
    while(1)
    {
      m=rand()%100;
      if(m>=l||m<=h)
      {
          pivot=m;
          break;
      }
      c++;
    }
    i=l-1;
    for(j=l;j<h;j++)
    {
        if(arr[j]<=pivot)
        {
            i++;
            swap(&arr[i],&arr[j]);
        }
    }
    swap(&arr[i+1],&arr[h]);
    return i+1;
}
void quickSort(int arr[],int l,int h)
{
    if(l<h)
    {
        int p;
        p=partition(arr,l,h);
        quickSort(arr,l,p-1);
        quickSort(arr,p+1,h);
    }
}
void main()
{
    int i,arr[101],j,l=0,h=100;
    time_t t;
    srand((unsigned) time(&t));
    printf("printing unsorted array\n");
    for(i=0;i<100;i++)
    {
        arr[i]=rand()%1000;
        printf("%d  ",arr[i]);
    }
    quickSort(arr,l,h);
    printf("\nprinting sorted array\n");
    for(i=0;i<100;i++)
    {
        printf("%d  ",arr[i]);
    }
}
