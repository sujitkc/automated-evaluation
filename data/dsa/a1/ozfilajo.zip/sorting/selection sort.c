//selection sort
#include<stdio.h>
#include<stdlib.h>
void main()
{
    int i,arr[101],j,temp,min;
    time_t t;
    srand((unsigned) time(&t));
    printf("printing unsorted array\n");
    for(i=0;i<100;i++)
    {
        arr[i]=rand()%1000;
        printf("%d  ",arr[i]);
    }
    for(i=0;i<99;i++)
    {
      min=i;
      for(j=i+1;j<100;j++)
      {
         if(arr[j]<arr[min])
            min=j;
      }
      if(min!=i)
      {
         temp=arr[min];
         arr[min]=arr[i];
         arr[i]=temp;
      }
   }
    printf("\nprinting sorted array\n");
    for(i=0;i<100;i++)
    {
        printf("%d  ",arr[i]);
    }
}
