//insertion sort
#include<stdio.h>
#include<stdlib.h>
void main()
{
    int i,arr[101],j,temp;
    time_t t;
    srand((unsigned) time(&t));
    printf("printing unsorted array\n");
    for(i=0;i<100;i++)
    {
        arr[i]=rand()%1000;
        printf("%d  ",arr[i]);
    }
    for (i=1;i<100;i++)
    {
       temp=arr[i];
       j=i-1;
       while (j>=0&&arr[j]>temp)
       {
           arr[j+1]=arr[j];
           j=j-1;
       }
       arr[j+1]=temp;
   }
    printf("\nprinting sorted array\n");
    for(i=0;i<100;i++)
    {
        printf("%d  ",arr[i]);
    }
}
