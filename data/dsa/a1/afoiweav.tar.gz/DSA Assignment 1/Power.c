//Power Function

#include <stdio.h>

int power (int x, int y);
void main()
{
    int x, y;
    printf ("\nEnter the number whose exponential is to be found: ");
    scanf ("%d", &x);
    printf ("\nEnter the power: ");
    scanf ("%d", &y);

    printf ("\nAnswer: %d\n\n", power(x , y));
}

int power (int x, int y)
{
    int n = 1;
    while (y > 0)
    {
        if ((y % 2) == 1)
            n = n * x;
        x *= x;
        y /= 2;
    }
    return n;
}