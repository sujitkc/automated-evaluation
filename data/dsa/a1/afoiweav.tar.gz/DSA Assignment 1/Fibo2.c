//Obtaining Fibonacci Series without using Recursion

#include<stdio.h>

int main()
{
	int n, a = 0, b = 1, c = 0;

    printf ("\nEnter 'n' (n -> Number of elements): ");
	scanf("%d", &n);

    printf ("\nThe Fibonacci Series is:\n ");
    for(int i = 0; i <= n; i++)
    {
		printf ("%d ", c);
		a = b;
		b = c;
        c = (a + b) % 100;
	}
    printf ("\n\n");
}