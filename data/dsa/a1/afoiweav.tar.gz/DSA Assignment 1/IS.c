//Insertion Sort

#include <stdio.h>

void InsertionSort (int arr[], int n);

void main()
{
    int n;
    printf ("\nEnter the size of the array: ");
    scanf ("%d", &n);
    int arr[1000];
    printf ("\nEnter the elements of the array: ");
    for (int i = 0; i < n; i++)
    {
        scanf ("%d", &arr[i]);
    }
    InsertionSort (arr, n);
    printf ("\nSorted Array: ");
    for (int j = 0; j < n; j++)
    {
        printf ("%d ", arr[j]);
    }
    printf ("\n\n");
}

void InsertionSort (int arr[], int n)
{
    int key;
    for (int i = 1; i < n; i++)
    {
        key = arr[i];
        int j = i - 1;
        while (j >= 0 && arr[j] > key)
        {
            arr[j + 1] = arr[j--];
        }
        arr[j + 1] = key;
    }
}



