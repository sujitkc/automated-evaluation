//Bubble Sort

#include <stdio.h>

void BubbleSort (int arr[], int n);
void swap (int *xptr, int *yptr);

void main()
{
    int n;
    printf ("\nEnter the size of the array: ");
    scanf ("%d", &n);
    int arr[1000];
    printf ("\nEnter the elements of the array: ");
    for (int i = 0; i < n; i++)
    {
        scanf ("%d", &arr[i]);
    }
    BubbleSort (arr, n);
    printf ("\nSorted Array: ");
    for (int j = 0; j < n; j++)
    {
        printf ("%d ", arr[j]);
    }
    printf ("\n\n");
}

void BubbleSort (int arr[], int n)
{
   for (int i = 0; i < n-1; i++)
   {      
        for (int j = 0; j < n-i-1; j++)
        { 
            if (arr[j] > arr[j + 1])
                swap (&arr[j], &arr[j + 1]);
        }
   }
}

void swap (int *xptr, int *yptr)
{
    int temp = *xptr;
    *xptr = *yptr;
    *yptr = temp;
}
