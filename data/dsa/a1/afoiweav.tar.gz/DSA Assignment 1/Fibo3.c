//Printing Fibonacci Series using arrays

#include <stdio.h>

void main()
{
    int n;
    printf ("\nEnter 'n' (n -> Number of elements): ");
	scanf("%d", &n);

    int a[1000] = {0, 1};
    for (int i = 2; i < n; i++)
        a[i] = (a[i-1] + a[i-2]) % 100;

    printf ("\nThe Fibonacci Series is:\n ");
    for (int j = 0; j < n; j++)
        printf("%d ", a[j]);    
    printf ("\n\n");    
}