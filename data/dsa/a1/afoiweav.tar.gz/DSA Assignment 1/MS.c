//Merge Sort

#include <stdio.h>

void MergeSort(int arr[], int l, int r);
void merge(int arr[], int l, int mid, int r);
void swap (int *xptr, int *yptr);

int temp_arr[1000];

void main()
{
    int n;
    printf ("\nEnter the size of the array: ");
    scanf ("%d", &n); 
    int arr[1000];
    printf ("\nEnter the elements of the array: ");
    for (int i = 0; i < n; i++)
    {
        scanf ("%d", &arr[i]);
    }
    MergeSort (arr, 0, n - 1);
    printf ("\nSorted Array: ");
    for (int j = 0; j < n; j++)
    {
        printf ("%d ", arr[j]);
    }
    printf ("\n\n");
}

void MergeSort(int arr[], int l, int r)
{
    if (l = r - 1)
    {
        if (arr [l] > arr [r])
            swap (arr[l], arr[r]);
    }

    else if (r > l + 1)
    {
        int mid = l + ((r - l) / 2);
 
        MergeSort(arr, l, mid);
        MergeSort(arr, mid + 1, r);
 
        merge(arr, l, mid, r);
    }
}

void merge(int arr[], int l, int mid, int r)
{
    int i = l, j = mid + 1, a = 0;
    while (i <= mid && j <= r)
    {
        if (arr[i] < arr[j])
            temp_arr[a++] = arr[i++];
        else 
            temp_arr[a++] = arr[j++];
    } 

    while (i <= mid)
        temp_arr[a++] = arr[i++];
    while (j <= r)
        temp_arr[a++] = arr[j++];  

    int b = 0;  
    for (i = l; i <= r; i++)
        arr[i++] = temp_arr[b++];
}

void swap (int *xptr, int *yptr)
{
    int temp = *xptr;
    *xptr = *yptr;
    *yptr = temp;
}





