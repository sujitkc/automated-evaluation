//Obtaining Fibonacci Series using Matrix Multiplication

#include <stdio.h>

void multi_matrix();

int a[2][2] = {{1, 1}, {1, 0}}, c[2][2];

void main()
{
    int n;
    printf ("\nEnter 'n' (n -> Number of elements): ");
	scanf("%d", &n);

    for(int i = 0; i < 2; i++)
    {
        for(int j = 0; j < 2; j++)
        {
            if(i == j)
                c[i][j] = 1;
            else
                c[i][j] = 0;
        }
    }

    printf ("\nThe Fibonacci Series is:\n ");

    for(int i = 0; i < n; i++)
    {
        printf ("%d ", (c[1][0])); 
        multi_matrix();
    }
    printf ("\n\n");
}

void multi_matrix()
{
    int b[10][10];
    for(int i = 0; i < 2; i++)
    {
        for(int j = 0; j < 2; j++)
        {
            b[i][j] = 0;
            for(int k = 0; k < 2; k++)
                b[i][j] = (b[i][j] + (a[i][k] * c[k][j])) % 100;
        }
    }
    for(int i = 0; i < 2; i++)
    {
        for(int j = 0; j < 2; j++)
            c[i][j] = b[i][j];
    }
} 
