//Selection Sort

#include <stdio.h>

void SelectionSort (int arr[], int n);
void swap (int *xptr, int *yptr);

void main()
{
    int n;
    printf ("\nEnter the size of the array: ");
    scanf ("%d", &n);
    int arr[1000];
    printf ("\nEnter the elements of the array: ");
    for (int i = 0; i < n; i++)
    {
        scanf ("%d", &arr[i]);
    }
    SelectionSort (arr, n);
    printf ("\nSorted Array: ");
    for (int j = 0; j < n; j++)
    {
        printf ("%d ", arr[j]);
    }
    printf ("\n\n");
}

void SelectionSort (int arr[], int n)
{
   int max_index; 
   for (int i = 0; i < n-1; i++)
   {    
       max_index = 0;  
        for (int j = 1; j < n-i; j++)
        { 
            if (arr[j] > arr[max_index])
                max_index = j;
            if (n-1-i > max_index)
                swap (&arr[max_index], &arr[n-1-i]);
        }
   }
}

void swap (int *xptr, int *yptr)
{
    int temp = *xptr;
    *xptr = *yptr;
    *yptr = temp;
}
