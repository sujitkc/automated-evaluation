//Quick Sort

#include <stdio.h>

void Rand_QuickSort (int arr[], int i, int j);
int randomPivot (int arr[],int i, int j);
int partition (int arr[], int i, int j, int p);
void swap (int *xptr, int *yptr);

void main()
{
    int n;
    printf ("\nEnter the size of the array: ");
    scanf ("%d", &n); 
    int arr[1000];
    printf ("\nEnter the elements of the array: ");
    for (int i = 0; i < n; i++)
    {
        scanf ("%d", &arr[i]);
    }
    Rand_QuickSort (arr, 0, n - 1);
    printf ("\nSorted Array: ");
    for (int j = 0; j < n; j++)
    {
        printf ("%d ", arr[j]);
    }
    printf ("\n\n");
}

void Rand_QuickSort (int arr[], int i, int j)
{
    if (j <= i + 1)
    {
        if (arr[i] > arr[j])
            swap (arr[i], arr[j]);
    }
        
    int p = randomPivot (arr, i, j);
    int k = partition (arr, i, j, p);
    Rand_QuickSort (arr, i, k);
    Rand_QuickSort (arr, k+1, j);
}

int randomPivot (int arr[],int i, int j)
{
    return arr[i + (rand() % (j - i + 1))];
}

int partition (int arr[], int i, int j, int p)
{
    int l = i, r = j;
    while (l <= r)
    {
        while (l <= r && arr[l] <= p)
            l++;
        while (l <= r && arr[r] > p)
            r--;
        if (l < r)
            swap (l, r);

        l++;
        r--;
    }
    return r;
}

void swap (int *xptr, int *yptr)
{
    int temp = *xptr;
    *xptr = *yptr;
    *yptr = temp;
}