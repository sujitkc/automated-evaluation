#include <stdio.h>


int main()
{
    int n,c=0,i,b,a;
    a=0;
    b=1;
    printf("Enter no.\n");
    scanf("%d",&n);
    for(i=2;i<n;i++)
    {
        c=a+b;
        a=b;
        b=c;
        
    }
    printf("%d",c);
}