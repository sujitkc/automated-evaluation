#include<stdio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node *next;
};

struct node add(struct node **head,int value)
{
	struct node *ctrptr,*prevptr=NULL,*newptr;
	ctrptr=*head;
	newptr=malloc(sizeof(struct node));
	newptr->data=value;
	newptr->next=NULL;

	while(ctrptr!=NULL)
	{
		prevptr=ctrptr;
		ctrptr=ctrptr->next;
	}

	if(prevptr==NULL)
	{
		*head=newptr;
	}	

	else
	{
		prevptr->next=newptr;
	}
	return **head;
}

void showlist(struct node **head)
{
	struct node *ctrptr,*prevptr=NULL,*newptr;
	ctrptr=*head;
	while(ctrptr!=NULL)
	{
		printf("%d ",ctrptr->data);
		ctrptr=ctrptr->next;
	}

}

int main()
{
	int n, x;
	struct node *head;
	head=NULL;
	struct node *arr[10]={0};
	for(int i=0;i<15;i++)
	{
		x = rand()%10;
		n = rand()%50;
		add(&arr[x],n);
	}
	for(int i=0;i<10;i++)
	{
		showlist(&arr[i]);
		printf(".\n");
	}
	for(int i=0;i<10;i++)
	{
		while(1)
		{
			struct node *ctrptr;
			ctrptr=arr[i];
			if(ctrptr==NULL)
				break;
			if(arr[i]->next==0)
			{
				break;
			}
			if((ctrptr->data%2)==0 && ((ctrptr->next)->data)%2!=0)
			{
				ctrptr->next=(ctrptr->next)->next;
			}
			else if((ctrptr->data%2)!=0 && ((ctrptr->next)->data)%2!=0)
			{
				if((ctrptr->data)<(ctrptr->next)->data)
				{
					arr[i]=ctrptr->next;
				}
				else
				{
					ctrptr->next=(ctrptr->next)->next;
				}
			}
			else if((ctrptr->data%2)==0 && ((ctrptr->next)->data)%2==0)
			{
				if((ctrptr->data)<(ctrptr->next)->data)
				{
					ctrptr->next=(ctrptr->next)->next;
				}
				else
				{
					arr[i]=ctrptr->next;
				}
			}
			else if((ctrptr->data%2)!=0 && ((ctrptr->next)->data)%2==0)
			{
				arr[i]=ctrptr->next;
			}
		}
	}
	printf("After solving..\n");
	for(int i=0;i<10;i++)
	{
		showlist(&arr[i]);

		printf(".\n");
	}

	for(int i=0;i<10;i++)
	{
		if(arr[i]==0)
			continue;
		else
			add(&head,arr[i]->data);
	}
	while(1)
		{
			struct node *ctrptr;
			ctrptr=head;
			if(ctrptr==NULL)
				break;
			if(head->next==0)
			{
				break;
			}
			if((ctrptr->data%2)==0 && ((ctrptr->next)->data)%2!=0)
			{
				ctrptr->next=(ctrptr->next)->next;
			}
			else if((ctrptr->data%2)!=0 && ((ctrptr->next)->data)%2!=0)
			{
				if((ctrptr->data)<(ctrptr->next)->data)
				{
					head=ctrptr->next;
				}
				else
				{
					ctrptr->next=(ctrptr->next)->next;
				}
			}
			else if((ctrptr->data%2)==0 && ((ctrptr->next)->data)%2==0)
			{
				if((ctrptr->data)<(ctrptr->next)->data)
				{
					ctrptr->next=(ctrptr->next)->next;
				}
				else
				{
					head=ctrptr->next;
				}
			}
			else if((ctrptr->data%2)!=0 && ((ctrptr->next)->data)%2==0)
			{
				head=ctrptr->next;
			}
		}
		printf("Final:%d",head->data);

	return 0;
}