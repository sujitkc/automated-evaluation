#include<stdio.h>
#include<math.h>
#include<string.h>
void mult(int *I,int *x){
	int row=2,col=2,i,j,k,p=0;
	int m[2][2];
	for(i=0;i<row;i++){
		for(j=0;j<col;j++){
			p=0;
			for(k=0;k<col;k++){
				p+= (*((I+i*col)+k) * *((x+k*col)+j));
			}
			m[i][j]=p;	
		}
	}
	for(i=0;i<row;i++){
		for(j=0;j<col;j++){
			*((I+i*col)+j)=m[i][j]%100;	
		}
	}
}
void divide(int *n,int len){
	int carry=0,num,i;
	for(i=0;i<len;i++){
		num=(*(n+i)+carry*10)/2;
		carry=(*(n+i))%2;
		*(n+i)=num;
	}
}
int main(){
	int I[2][2]={{1,0},{0,1}};
	int x[2][2]={{1,1},{1,0}};
	char s[1000];
	printf("Enter the value of n:\n");
	scanf("%s",s);
	int i;
	int n[strlen(s)];
	for(i=0;i<strlen(s);i++){
		n[i]=s[i]-48;
	}
	int f=1;
	while(f){
		if(n[strlen(s)-1]%2==1){
			mult((int *)I,(int *)x);
		}
		mult((int *)x,(int *)x);
		divide(n,strlen(s));
		for(i=0;i<strlen(s);i++){
			if(n[i]!=0){
				f=1;
				break;	
			}
			f=0;
		}
	}
	printf("%d\n",I[1][0]);
}
