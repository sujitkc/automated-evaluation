#include<stdio.h>



int power(int f[2][2],int n)
{
    int i;
    int m[2][2]={{1,1},{1,0}};
    for(i=2;i<=n;i++)
    {
        multiply(f,m);
    }
    return f[1][1];
}
int multiply(int f[2][2],int m[2][2])
{
    
        int x=m[0][0]*f[0][0]+m[0][1]*f[1][0];
        int y=m[1][0]*f[0][0]+m[0][1]*f[1][1];
        int z=m[0][1]*f[0][0]+m[1][1]*f[1][0];
        int w=m[0][1]*f[1][0]+m[1][1]*f[1][1];
  f[0][0]=x%10;
  f[0][1]=y%10;
  f[1][0]=z%10;
  f[1][1]=w%10;
}
void main()
{
    int n;
    printf("ENter no.");
    scanf("%d",&n);
    int k;
    int f[2][2]={{1,1},{1,0}};
    k=power(f,n);
    printf("%d",k);
}
   