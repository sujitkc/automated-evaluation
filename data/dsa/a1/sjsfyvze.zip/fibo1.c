#include <stdio.h>

int fibo(int n)
{
    if(n==0 || n==1)
    return n;
    else
    return (fibo(n-1)+fibo(n-2))%10;
}
int main()
{
    int n;
    printf("Enter no.");
    scanf("%d",&n);
    int k=fibo(n);
    printf("%d",k);
}