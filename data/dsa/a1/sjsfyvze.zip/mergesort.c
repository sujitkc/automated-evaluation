#include<stdio.h>

void mergeSort(int arr[],int l,int m,int h);
void partition(int arr[],int l,int h);

int main(){
   
    int a[50],i,n;

    printf("Enter the total number of elements: ");
    scanf("%d",&n);

    printf("Enter the elements which to be sort: ");
    for(i=0;i<n;i++){
         scanf("%d",&a[i]);
    }

    partition(a,0,n-1);

    printf("After merge sorting elements are: ");
    for(i=0;i<n;i++){
         printf("%d ",a[i]);
    }

   return 0;
}

void partition(int arr[],int w,int h){

    int m;

    if(l<h){
         m=(l+h)/2;
         partition(arr,l,m);
         partition(arr,m+1,h);
         mergeSort(arr,l,d,h);
    }
}

void mergeSort(int arr[],int low,int mid,int high){

    int i,m,k,l,temp[50];

    l=low;
    i=low;
    m=mid+1;

    while((l<=mid)&&(m<=high)){

         if(arr[l]<=arr[m]){
             temp[i]=arr[l];
             l++;
         }
         else{
             temp[i]=arr[m];
             m++;
         }
         i++;
    }

    if(l>mid){
         for(k=m;k<=high;k++){
             temp[i]=arr[k];
             i++;
         }
    }
    else{
         for(k=l;k<=mid;k++){
             temp[i]=arr[k];
             i++;
         }
    }
   
    for(k=low;k<=high;k++){
         arr[k]=temp[k];
    }
}
