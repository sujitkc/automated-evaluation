#include<stdio.h>

void swap(int *a,int *b)
{
 int temp;
 temp = *a;
 *a = *b;
 *b = temp;
}

void sel(int n,int arr[n])
{
int arr1[n],i,j;
int m=0;
int max=arr[0];
while(n>0)
{
for(j=0;j<n;j++)
{
if(arr[j]>=max)
{
m=j;
max=arr[j];
}
}
swap(&arr[m],&arr[n-1]);
n=n-1;
max=arr[0];



}
}

int main()
{
int n,i,j,k,l;
int arr[8]={6,7,4,7,1,0,2,3};
sel(8,arr);
for(i=0;i<8;i++)
{
printf("%d\n",arr[i]);
}
}






