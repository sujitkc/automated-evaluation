#include<stdio.h>
main()
{
	int a=0;
	int b=1;
	int c,i,n;
	scanf("%d",&n);
	for(i=2;i<=n;i++)
	{
		c=(a+b);
		a=b;
		b=c;
	}
	printf("%d",c);
}