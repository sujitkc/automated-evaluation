#include<stdio.h>
int rect(int n);
int rect(int n)
{
    if(n<2)
        return n;
    else
        return (rect(n-1)+rect(n-2));
}
int main()
{
int n;
printf("enter the number");
scanf("%d",&n);
    printf("%d",rect(n));
}
