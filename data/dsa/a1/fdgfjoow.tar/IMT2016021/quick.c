#include <stdio.h>
#include <stdlib.h>
void swap(int *a,int *b)
{
    int temp;
    temp = *a;
    *a = *b;
    *b = temp;
}
void Partition(int arr[],int n,int i,int k)
{
   if(i == k) {

       return ;
   }
   else
   {
       int s =  QuickSort(arr,i,k,n);
       Partition(arr,n,i,s);
       Partition(arr,n,s+1,k);
   }
}

int  QuickSort(int arr[],int i, int k,int n)
{
    int p = rand() % n;
	int m;
    arr[p] = m;
  while(i < k)
  {

    p = rand() % n;
    while(arr[i]< m)
    {
        i++;
    }
    while(m < arr[k])
    {
        k--;
    }
    swap(&arr[i],&arr[k]);



  }
   if(i==k)
   {return i-1;}
   return i;
}

int main()
{
    int arr[100],i;
    int n;
    printf("enter the no of values of the array:");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }

    Partition(arr,n,0,n-1);
    for(i=0;i<n;i++)
    {
        printf("%d",arr[i]);
    }
}