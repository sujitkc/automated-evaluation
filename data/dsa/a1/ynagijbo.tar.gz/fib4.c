#include <stdio.h>

 
 
int main()
{
	int a=0;
	int b=1;
	int m;
	scanf("%d",&m);
	int c;
	for(int i=2;i<=(6*m+1);i++)
	{
		c = (a+b)%m;
		a=b;
		b=c;
		if(c==0 && a==1){
			 printf("%d",i);
			 break;
			}

	}
} 
