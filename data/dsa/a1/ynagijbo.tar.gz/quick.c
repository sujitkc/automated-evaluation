#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

void swap(int *a, int *b){
	int tmp = *a;
	*a = *b;
	*b = tmp;
}

int partition(int arr[],int left,int right,int p)
{	int temp;
	//printf("In partition\n");
	int l=left;
	int r=right;
	while(l<=r)
	{
		while(l<=r && arr[l]<=p)
		{
			//printf("Loop1\n");
			l++;
		}
		while(l<=r && arr[r]>p)
		{
			//printf("Loop2\n");
			r--;
		}
		if(l<r)
		{	
			temp = arr[l];
			arr[l] = arr[r];
			arr[r] = temp; 
			l++;
			r--;
		}
	//printf("Exit partition\n");	
	}
	return r;
}

void RQS(int a[],int left,int right)
{	int temp;
	//printf("Came here\n");
	if(right == left+1)
		{
			if(a[right]<a[left])
			{
				temp=a[right];
				a[right]=a[left];
				a[left]=temp;
			}
			return;
		}

	else if(left>=right)
	{	
		return;
	}
	int p = a[left+rand()%(right-left+1)];
	int k = partition(a,left,right,p);
	RQS(a,left,k);
	RQS(a,k+1,right); 


}

int main()
{
	srand(time(0));
	int a1[6] = {1,1,5,2,0,3};/*
	for(int i=0;i<6;i++){
		a1[i] = rand()%100;
		printf("%d ",a1[i]);
	}*/
	printf("\n\n\n");
	RQS(a1,0,5);
	for(int i=0;i<6;i++)
	{
		printf("%d ",a1[i]);
	}
}