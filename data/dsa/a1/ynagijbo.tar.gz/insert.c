#include <stdio.h>
#include <stdlib.h>

int main()
{
	int a[5];
	for(int i=0;i<5;i++)
	{
		scanf("%d",&a[i]);
	}
	for(int i=0;i<5;i++)
	{	int j=i-1;
		int key=a[i];
		while(j>=0 && a[j]>key)
		{
			
			a[j+1]=a[j];
			j--;
		}
		a[j+1]=key;
	}

	for(int i=0;i<5;i++)
	{
		printf("%d",a[i]);
	}
}