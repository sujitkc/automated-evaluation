def matmul(a,b):
	c=[[0,0],[0,0]]
		for i in range(len(a)):
			for j in range(len(a[0])):
				for k in range(len(b)):
					c[i][j]+=a[i][k]*b[k][j]
	return c

def conbin(n):
	l=[]
	while(n>=1):
		if((n%2)==0):
			l.insert(0,0)
		else:
			l.insert(0,1)
		n=n/2
	return l

def power(a,n):
	y=[[1,0],[0,1]]
	k=len(conbin(n))
	i=0
	while(i<k):
		if(conbin(n)[i]==1):
			y=matmul(y,a)
			a=matmul(a,a)
			i=i+1
	return a

a=[[1,1],[1,0]]
print power(a,6)
print conbin(5)

