#include <stdio.h>
int main()
{	
	int n;
	scanf("%d",&n);
	int a=0,b=1,c=n;
	for(int i=2;i<=n;i++)
	{
		printf("Entered the loop\n");
		c=(a+b)%100;
		a=b;
		b=c;
		printf("%d %d %d\n",a,b,c);
	}
}