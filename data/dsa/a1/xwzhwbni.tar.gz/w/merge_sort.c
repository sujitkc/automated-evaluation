#include<stdio.h>
void partition(int a[],int p,int r)
{	int q=(r+p)/2;
	if(p<r)
	{
		partition(a,p,q);
		partition(a,q+1,r);
		merge(a,p,r,q);
	}
}
void merge(int a[],int p,int r,int q)
{
	int n1=q-p;
	int n2=r-q-1;
	int l[n1];
	int m[n2];
	int k,i,j;
	for(i=0;i<n1;i++)
	{
		l[i]=a[i+p];
	}
	for(i=0;i<n2;i++)
	{
		m[i]=a[q+1+i];
	}
	i=0;
	j=0;
		for(k=0;k<(n1+n2);k++)
		{
			if(l[i]<m[j])
			{
				a[k]=l[i];
				i++;
			}
			if(l[i]>m[j])
			{
				a[k]=m[j];
				j++;
			}
		}
}
	void main()
	{
		int i;
		int a[]={5,4,3,2};
		partition(a,0,3);
		for(i=0;i<4;i++)
		{
			printf("%d ",a[i]);
		}
	}
