#include<stdio.h>
void main()
{
	int i,j,k;
	
	int a[]={5,6,7,3,1};
	int key;
	for(j=1;j<5;j++)
	{
		key=a[j];
		i=j-1;
		while(i>=0 && a[i]>key)
		{
			a[i+1]=a[i];
			i--;
		}
		a[i+1]=key;
	}
	for(k=0;k<5;k++)
	{
		printf("%d ",a[k]);
	}
}
