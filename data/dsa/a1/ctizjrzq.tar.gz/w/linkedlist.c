#include <stdio.h>
#include <stdlib.h>

struct node
{
	int data;
	struct node *next;
};
struct node *head[10]={NULL};

int compressH()
{
	for(int i=0;i<10;i++)
	{  
		struct node *temp=malloc(sizeof(struct node));
		struct node *curr=head[i];
		while(curr->next->next!=NULL)
		{   
			if((curr->next->data%2==0)&&curr->data%2!=0)
			{	
				temp=curr->next;
				curr->next=temp->next;

			}

			else if((curr->next->data%2==0)&&curr->data%2==0)
			{	if(curr->data>curr->next->data)
				{	temp=curr->next;
					curr->next=temp->next;
				}
				else
				{ 
				temp=curr->next;
				curr->data=curr->next->data;
				curr->next=temp->next;
				}
			}
			else
			{
				if(curr->data<curr->next->data)
				{   
					temp=curr->next;
					curr->next=temp->next;
				}
				else
				{ 
				temp=curr->next;
				curr->data=curr->next->data;
				curr->next=temp->next;
				}
			}
		}
		curr=curr->next;
	}	
	return 0;
}
int compressV()
{
	int i;
	for(int j=1;j<9;j++)
	{  for(int i=0;i<=j;i++)
		{
			if((head[i]->data%2==0)&&(head[i+1]->data%2!=0))
			{
				head[i]->data=0;
			}
			else if((head[i]->data%2!=0)&&(head[i+1]->data%2==0))
			{
				head[i+1]->data=0;
			}
			else if((head[i]->data%2==0)&&(head[i+1]->data%2==0))
				if(head[i]->data>head[i+1]->data)
					head[i]->data=0;
				else
					head[i+1]->data=0;
			else
				if(head[i]->data<head[i+1]->data)
					head[i]->data=0;
				else
					head[i+1]->data=0;
		}				
	}
	
	return 0;
}
int addinlist()
{   int x= rand()%10;
	int y= rand()%100;
	struct node *curr= head[x];
		struct node *temp= malloc(sizeof(struct node));
	if(head[x]==NULL)
	{  
		temp->data=y;
		temp->next=NULL;
		head[x]=temp; 
	}
	else
	{
		while(curr->next!=NULL)
		{ 
		curr=curr->next;
		}
		temp->next=NULL;
		temp->data=y;
		curr->next=temp;
	}
 return 0;
}
int view()
{
	int x;
	printf("enter the list no.");
	scanf("%d",&x);
	struct node *curr=head[x];
	while(curr->next!= NULL)
	{	
		printf("%d ",curr->data);
		curr= curr->next;
	}
	return 0;
}
int viewlast()
{ 
 for(int i=0;i<10;i++)
 	{ 
 		if(head[i]->data!=-1 || head[i]->data!=0)
 			printf("\n\t%d",head[i]->data);
	}
	return 0;
}

int main()
{  

for (int i = 0; i < 100; ++i)
{   
	addinlist();
}



view();
compressH();
view();
compressV();
viewlast();
return 0;
}


