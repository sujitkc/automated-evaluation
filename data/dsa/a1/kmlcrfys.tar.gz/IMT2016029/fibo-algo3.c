#include <stdio.h>
int fib(int n){
	int a=0;
	int b=1;
	int c;
	int i;
	for(i=0;i<n-1;i++){
	c=b;
	b=a+b;
	a=c;
	}
	return b;
}
int main()
{
	int n=10;
	printf(" %d ",fib(n));
	
}
