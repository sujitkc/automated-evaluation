#include <stdio.h>
int f(int x){
	
	if(x==0){
		return 0;
	}
	else if(x==1){
		return 1;
	}
	else{
	return (f(x-1)+f(x-2))%100;
	}
	}
int main()
{
	int n=10;
	printf(" %d ",f(n));
		
}
