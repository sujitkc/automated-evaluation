#include<stdio.h>
void swap(int *m,int *n)
{
	int temp;
	temp=*m;
	*m=*n;
	*n=temp;
}
int divide(int n,int arr[n],int left,int right,int pivot)
{
	int m;
	int a=left;
	int b=right;
	int p=pivot;
	m=arr[p];
	while(a<b)
	{
		while(arr[a]<m)
		{
			a++;
		}
		while(arr[b]>m)
		{
			b--;
		}
		swap(&arr[a],&arr[b]);
	}
	if(a==right){return a-1;}
	return a;
}
void sort(int n,int arr[n],int left,int right)
{
	int pivot;
	if(left==right)
	{
		return;
	}

	
	pivot=(right+left)/2;
	//divide(n,arr,left,right,pivot);
	int d=divide(n,arr,left,right,pivot);
	sort(n,arr,left,d);
	sort(n,arr,d+1,right);
	

}
int main()
{
	int i;
	int arr[10]={10,9,8,7,6,5,4,3,2,1};
	sort(10,arr,0,9);
	for(i=0;i<10;i++)
	{
		printf("%d\n",arr[i]);
	}
}