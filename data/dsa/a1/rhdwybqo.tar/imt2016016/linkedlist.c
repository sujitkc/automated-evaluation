#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node *next;
};

void main(){
    struct node *arr[21];
    int i;
    for(i=0;i<21;i++){
        arr[i]=NULL;
    }
    struct node *ptr,*temp,*l,*kk;

    int a=20,ti,tn,count;
    while (a-->0){
        ti=rand()%20;
        tn=rand()%100;
        if(arr[ti]==NULL){
            arr[ti]=malloc(sizeof(struct node));
            arr[ti]->data=tn;
            arr[ti]->next=NULL;
        }
        else{
            temp=malloc(sizeof(struct node));
            temp->data=tn;
            temp->next=arr[ti];
            arr[ti]=temp;
        }

    }


    for(i=0;i<20;i++){
        if(arr[i]!=NULL){
            ptr=arr[i];
            l=arr[i];
            while(l!=NULL){
                printf("%d  ",l->data);
                l=l->next;
            }
            puts("");
            l=arr[i];
            if(ptr!=NULL){
                while(ptr!=NULL && ptr->next!=NULL ){
                    if(ptr->data%2==0 && (ptr->next)->data%2==0){
                        if((ptr->data)>((ptr->next)->data)){
                            if(ptr==arr[i]){
                                arr[i]=ptr->next;
                            }
                            else{
                                temp=ptr;
                                ptr=ptr->next;
                                kk->next=ptr;
                                free(temp);
                            }
                        }
                        else{
                            ptr->next=(ptr->next)->next;
                        }

                    }

                    else if(ptr->data%2==1 && (ptr->next)->data%2==1){
                        if(ptr->data>(ptr->next)->data){

                            ptr->next=(ptr->next)->next;
                        }
                        else{
                            if(ptr==arr[i]){
                                arr[i]=ptr->next;
                            }
                            else{
                                temp=ptr;
                                ptr=ptr->next;
                                kk->next=ptr;
                                free(temp);
                            }
                        }


                    }
                    else{

                        if(ptr->data%2==1 && (ptr->next)->data%2==0){
                            if(ptr==arr[i]){
                                arr[i]=ptr->next;
                            }
                            else{
                                temp=ptr;
                                ptr=ptr->next;
                                kk->next=ptr;
                                free(temp);
                            }

                        }
                        if(ptr->data%2==0 && (ptr->next)->data%2==1){

                            ptr->next=(ptr->next)->next;

                        }
                    }
                    kk=ptr;
                    if(ptr->next!=0)
                        ptr=ptr->next;
                    if(ptr->next==NULL){
                        l=arr[i];
                        count=0;
                        while(l!=NULL){
                            count++;
                            l=l->next;
                        }
                        if(count>1){
                            ptr=arr[i];
                        }
                    }

                }


            }
        }
    }
    puts("\n\n");
    int j;
    count=0;
    for(i=0;i<20;i++){
        if (arr[i]!=NULL){
            count++;
        }
    }
    for(i=0;i<20;i++){
        if(arr[i]!=NULL)
            printf("%d %d\n",arr[i]->data,i);
    }
    printf("%d\n",arr[3]==NULL);
    while (count>=1){
        if (count!=1){
            for(i=0;i<19;i++){
                if(arr[i]!=NULL){
                    for(j=i+1;j<20;j++){
                        if (arr[j]!=NULL){
                            printf("\nthis i j %d %d  and %d  %d\n",i,j,arr[i]->data,arr[j]->data);
                            if(arr[j]->data%2==0 && arr[i]->data%2==0){
                                if(arr[j]->data>arr[i]->data){
                                    arr[j]=NULL;
                                }
                                else{
                                    arr[i]=NULL;
                                }
                            }
                            else if(arr[j]->data%2==1 && arr[i]->data%2==1){
                                if(arr[j]->data>arr[i]->data){
                                    arr[i]=NULL;
                                }
                                else{
                                    arr[j]=NULL;
                                }
                            }
                            else{
                                if(arr[j]->data%2==1 && arr[i]->data%2==0){
                                    arr[j]=NULL;
                                }
                                else{
                                    arr[i]=NULL;
                                }
                            }
                            count--;
                            i=j+1;
                            break;
                        }
                    }
                }
            }
        }
        else{
            for(i=0;i<20;i++){
                if(arr[i]!=NULL){
                    printf("the answer is %d",arr[i]->data);
                }

            }
            count--;

        }

    }


}


