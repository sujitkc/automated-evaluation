#include<stdio.h>
#include<math.h>
int main(){
    long long int a=0,b=1,c,k,p=0;
    printf("enter the number: ");
    scanf("%lld",&k);
    while(p<k){
        c=(a+b)%100;
        a=b;
        b=c;
        p=p+1;
    }
    printf("%d ",a);
}
