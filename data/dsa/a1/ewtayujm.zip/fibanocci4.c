#include<stdio.h>
#include<math.h>
long long int main()
{
	long long int n,j;
	long long int p ,count=0,i,sum=0;
	int t;
	printf("number;");
	scanf("%lld",&n);
	j=pow(10,6);
	long long int a[j];
	while (n/10!=0)
	
	{
		p=n%10;
		n=n/10;
		a[count]=p;
		count++;
	}
	a[count]=n;
	for (i=2;i<=count;i++)
	{
		sum=sum+a[i];
	}
	sum=sum%3;
	t=(sum*100)+(a[1]*10)+a[0];
	/*for(i=0;i<=count;i++)
	{
	printf("%lld",a[i]);	
}
*/ printf("%d",t);
}
