#include <stdio.h>
#include <stdlib.h>
int a[10];
void merge(int b[],int l,int m,int r)
{
	int x=m+1,k=1,temp[r-l+1],s=0;
	while(x<=r&& k<=m)
	{
		if(b[x]<=b[k])
		{
			a[s++]=b[x++];
		}
		else
		{
			a[s++]=b[k++];
		}
	}
	while(x<=r)
	{
		a[s++]=b[x++];
	}
	while(k<=m)
	{
		a[s++]=b[k++];
	}
	for(int i=0;i<s;i++)
	b[l+i]=a[i];
	}
	
	void sort(int b[],int l,int r)// dividing the array
	{
		if(l<r)
		{
			int m=(r+l)/2;
			sort(b,l,m);
			sort(b,m+1,r);
			merge(b,l,m,r);
		}
	}
	void print(int b[],int size)
	{
		int i;
		for(i=0;i<size;i++)
		{
			printf("%d\n",b[i]);
		}
	}
	int main ()
			{
				int size =10,arr[10],i;
				for(i=0;i<size;i++)
				{
					arr[i]=rand()%20;
				}
				print(arr,size);
				sort(arr,0,9);
				printf("\n\n");
				print(a,size);
			}
	
