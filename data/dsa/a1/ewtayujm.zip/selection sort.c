#include<stdio.h>
int main()
{
	int a[100],i,n,j,t;
	printf("enter the no of elements to be sorted :");
	scanf("%d",&n);
	for(i=0;i<n;++i)
	{
		scanf("%d",&a[i]);
	}
	for(j=0;j<n;++j)
	for(i=j+1;i<n;++i)
	{
		if(a[j]>a[i])
		{
			t=a[j];
			a[j]=a[i];
			a[i]=t;
		}
	}
	for(i=0;i<n;++i)
	printf("%d",a[i]);
	return 0;
}
