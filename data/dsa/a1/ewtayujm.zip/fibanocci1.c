#include<stdio.h>
#include<math.h>
int main()
{
	long long int i,n,j;
	j=pow(10,6);
	long long int a[j];
	printf("enter the no required:");
	scanf("lld",&n);
	a[1]=0;
	a[2]=1;
	for (i=2;i<=j;++i)
	{
		a[i]=(a[i-1]+a[i-2])%100;
	}
	printf("%lld\n",a[n]);
	return 0;
	
}
