#include <stdio.h>
#include <math.h>
int main()
{
	long long int a=0,b=2,m=0,c,l;
	printf("enter the no:");
	scanf("%lld",&l);
	while(m<l)
	{
	c=(a+b)%100;
	a=b;
	b=c;
	m=m+1;
	}
printf("%d",a);
}
