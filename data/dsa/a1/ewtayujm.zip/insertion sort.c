#include <stdio.h>
int main()
{
	int i,j,k,t,a[100];
	printf("enter no of elements: ");
	scanf("%d",&k);
	printf("enter %d elements :",k);
	for(i=0;i<k;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=1;i<k;i++)
	{
		t=a[i];
		j=i-1;
		while(t<a[j]&&(j>0))
		{
			a[j+1]=a[j];
			j=j-1;
		}
		a[j+1]=t;
	}
	printf("the sorted elements are:");
	for(i=0;i<k;i++)
	{
		printf("%d,a[i]");
	}
			return 0;
	}
	
