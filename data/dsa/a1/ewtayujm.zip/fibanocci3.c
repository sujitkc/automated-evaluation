#include<stdio.h>
#include<stdlib.h>
int fib(int n)
{
	long long int fib[2][2]={{1,1},{1,0}},rec[2][2]={{1,0},{0,1}},t[2][2]={{0,0},{0,0}};
	int i,j,k;
	while(n)
	{
		for(i=0;i<2;i++)
		{
			for(j=0;j<2;j++)
			{
				for(k=0;k<2;k++)
				{
					t[i][j]=(t[i][j]+rec[i][k]*fib[k][j]);
					
				}
			}
		}
		for(i=0;i<2;i++)
		{
		for(j+0;j<2;j++)
		{
			rec[i][j]=t[i][j];
		}
	}
	for(i=0;i<2;i++)
	{
		for(j=0;j<2;j++)
		{
			for(k=0;k<2;k++)
			{
				t[i][j]=(t[i][j]+fib[i][k]*fib[k][j]);
				
		}
	}
	
	}
	for(i=0;i<2;i++)
	{
		for(j=0;j<2;j++)
		{
			fib[i][j]=t[i][j];
			
		}
	}
	n=n/2;
	
}
return (rec[0][1]);
}
int main()
{
	long long int n;
	printf("enter the no");
	scanf("lld",&n);
	printf("%lld",fib(n));
}
