#include<stdio.h>
#include<conio.h>
void quicksort(int array[],int firstindex,intlastindex)
int pivotindex ,temp,index1,index2;
if(firstindex <lastindex)
{
	pivotindex=firstindex; 
	index1=firstindex;
	index2=lastindex;
	
	while(array[index1]<=array[pivotindex]&&index1<lastindex)
	{
		index1++;
	}
	while(array[index2]>array[pivotindex])
	{
		index2--;
    }
    if(index1<index2)
	{
		temp=array[index2];
		array[index1]=array[index2];
		array[index2]=temp;
	}
	}
temp=array[pivotindex];
array[pivotindex]=array[index2];
array[index2]=temp;
	quick sort(array,firstindex,index2-1);
	quick sort(array,index2+1,lastindex);
}
}
int main()
{ 
int array[100],n,i;
printf("enter the number of the element you want to sort:");
scanf("%d",&n);
printf("enter elementsin the list:");
for(i=0;i<n;i++)
{
	scanf("%d",&array[i]);
	
}
quick sort(array,0,n-1);
printf("sorted elements:");
for(i=0;i<n;i++)
printf("%d",array[i]);
getch();
return0;

	

