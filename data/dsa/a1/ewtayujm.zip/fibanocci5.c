#include<stdio.h>

void multi(int a[][2],int b[][2])
{
	int c[2][2]={{0,0},{0,0}};
	
	for(int i=0;i<2;i++)
	for(int j=0;j<2;j++)
	for(int k=0;k<2;k++)
	c[i][k]+=a[i][j]*b[j][k];
	for(int i=0;i<2;i++)

	for(int j=0;j<2;j++)
	a[i][j]=c[i][j];
}
int fib(int arr[],int n)
{
	int a[2][2]={{1,1},{1,0}},p[2][2]={{1,0},{0,1}};
	for(int i=0;i<n;i++)
	{
	if(arr[i]==1)
	{
	multi(p,a);
	}
	multi(a,a);
	}
	return p[1][0];	
}

int dec_to_bin(int n)
{	n=n-1;
	int size;
	if(n!=0)
	size=(log(n)/log(2))+1;
	else
	size=1;
	int arr[size];
	for(int i=0;i<size;i++)
	{
		arr[i]=n%2;
		n=n/2;
	}
	return fib(arr,size);
}
main()
{
printf("%d",dec_to_bin(6));
}                        
