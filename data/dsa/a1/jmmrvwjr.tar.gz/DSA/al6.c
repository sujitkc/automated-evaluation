#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int main()
{
  int a=0,b=1,c=0,i=0;
  int peroid;
  while(1)
  {
    c=(a+b)%100;
    a=b;
    b=c;
    if(i!=1 && a==0 && b==1)
        break;
    i++;
  }
  peroid=i+1;
  int num[1000];
  srand(time(NULL));
  for(i=0;i<1000;i++)
    num[i]=rand()%10;
  int remainder=0;
  for(i=0;i<1000;i++)
      remainder=(remainder + num[i]*10) % peroid;
  for(i=2;i<=remainder ;i++)
  {
    c=(a+b)%100;
    a=b;
    b=c;

  }
  printf("%d\n",remainder);
  printf("%d\n",c);
}
