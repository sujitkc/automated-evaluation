#include<stdio.h>
#include <time.h>
#include <stdlib.h>

int main()
{
  int a[1000000],i,j,x;
  for(i=1;i<1000001;i++)
  {
    //srand(time(NULL));
    a[1000000-i]= (i);
  }
  for(i=1;i<1000000;i++)
  {
    x=a[i];
    j=i-1;
    while(j>=0 & a[j]>x)
    {
      a[j+1]=a[j];
      j=j-1;
    }
    a[j+1]=x;
  }
  for(i=0;i<1000000;i++)
  {
    printf("%d\n",a[i]);
  }
}
