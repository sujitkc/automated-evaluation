
def difference(n):
    l=[]
    for i in range(len(n)):
        for j in range(len(n)):
            if(n[len(n)-(i+1)]-n[j] >0):
                l.append(n[len(n)-(i+1)]-n[j])
    return l
def tr(l1,l2,k):
    if(k==0):
         return True
    else:
        boo=True
        l2.append(l1[-1])
        l=difference(l2)
        temp=[]
        for i in l1:
            for j in l:
                if(j==i):
                    temp.append(i)
                    l1.remove(i)
                    l.remove(j)

        if(len(l)==0):
            boo=True
        if(not boo):
            l1=l1+temp
            l2.pop()
            l2.append(g-l1[-1])
            l=difference(l2)
            temp=[]
            for i in l1:
                for j in l:
                    if(j==i):
                        temp.append(i)
                        l1.remove(i)
                        l.remove(j)
            if(len(l)==0):
                boo=True
        if(boo):
            if(not tr(l1,l2,k-1)):
                boo=False

        if(not boo):
            l1=l1+temp

        return boo

l1=[n for n in map(int,raw_input("enter the list: ").split(","))]
o=len(l1)
g=l1[o-1]
l2=[0]
l2.append(l1[o-1])
l1.remove(l1[o-1])
tr (l1,l2,3)
print l2

