#include<stdio.h>
#include<stdlib.h>
int partition(int arr[],int i,int j)
{
  int r,x=arr[j],p=i-1,a,temp;
  r=i+rand()%(j-i+1);
  x=arr[r];
  temp=arr[r];
  arr[r]=arr[j];
  arr[j]=temp;
  for(a=i;a<j;a++)
  {
    if(arr[a]<=x)
    {

      p++;
      temp=arr[p];
      arr[p]=arr[a];
      arr[a]=temp;
    }
  }
  temp=arr[p+1];
  arr[p+1]=arr[j];
  arr[j]=temp;
  return p+1;
  }

void quicksort(int arr[],int i,int j)
{
  int p,k;
  if(i<j)
  {
    k=partition(arr,i,j);
    quicksort(arr,i,k-1);
    quicksort(arr,k+1,j);
  }
}

int main()
{
  int n=1000000,arr[n],i;
  for(i=0;i<n;i++)
  {
    arr[n-1-i]=i;
  }
  quicksort(arr,0,n-1);

}
