void bs(int arr[],int len){
int i,j;
for(i=0;i<len;i++)
{
  for(j=i+1;j<len;j++)
  {
  if(arr[i]>arr[j])
    {
  int temp=arr[i];
  arr[i]=arr[j];
  arr[j]=temp;
    }
  }
}
int main()
{
  int n,arr[n],i;
  n=1000000;
  for(i=1;i<n+1;i++)
  {
    arr[n-i]=i;
  }
  bs(arr,n);
}
