#include<stdio.h>
int dp(int n)
{
  if(n<2)
  {
    return n;
  }
  else
  {
    int i;
    for(i=2;i<=n;i++)
    {
      return ((dp(n-1)+dp(n-2))%100) ;
    }
  }
}
int main()
{
  printf("%d"\n",dp(1000));
}
