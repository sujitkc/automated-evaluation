#include <stdio.h>
int main()
{
  int i,j,n;
  n=1000000;
  int a[n];
  for(i=1;i<n+1;i++)
  {
    a[n-i]=i;
  }
  for(j=0;j<n+1;j++)
  {
    int imin=j;
    for(i=j+1;i<n;i++)
    {
      if(a[i]<a[imin])
      {
        imin=i;
      }
    }
    if(imin != j)
    {
      int temp;
      temp=a[imin];
      a[imin]=a[j];
      a[j]=temp;
    }
  }
  for(i=0;i<n;i++)
  {
    printf("%d\n",a[i]);
  }
}
