#include<time.h>
#include<stdlib.h>
#include<stdio.h>
int power(int arr[2][2],int num[],int len);
void mul(int arr[2][2],int n[2][2]);
void mul(int arr[2][2],int n[2][2])
{
  int c[2][2]={{0,0},{0,0}};
  for(int i=0;i<2;i++)
    for(int j=0;j<2;j++)
      for(int k=0;k<2;k++)
        c[i][j]+=arr[i][k]*n[k][j];
    for(int i=0;i<2;i++)
      for(int j=0;j<2;j++)
        arr[i][j]=c[i][j]%100;
  }

int power(int arr[2][2],int num[],int len)
{
  int y[2][2]={{1,0},{0,1}};
  int i=0;
  while(i<len){
    if(num[len-i-1]==1)
    {
      mul(y,arr);
    }
      mul(arr,arr);
      i++;
  }

		return y[1][0];

}

int main ()
{
  int arr[2][2]={{1,1},{1,0}},i=0,j;
  int num[1000000];
  srand(time(NULL));
  for(i=0;i<1000000;i++)
  {num[i]=rand()%2;}
  int c=power(arr,num,i);
  printf("%d",c);
}
