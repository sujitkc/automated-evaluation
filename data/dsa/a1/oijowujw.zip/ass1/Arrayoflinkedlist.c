#include<stdio.h>
#include<stdlib.h>

struct node
{
    int data;
    struct node *link;
};

struct node* arr[1000000];
void delete_nodes();
void insert(long int a,long int b);
void delete1(struct node *root,long int num,long int i);
long int max(long int a,long int b);
long int min(long int a,long int b);
long int len(struct node *root);
long int after_length(struct node *root);
long int count_hori();

void insert(long int a,long int b)
{
    if(arr[a]==NULL)
    {
        struct node *temp;
        temp=(struct node*)malloc(sizeof(struct node));
        temp->data=b;
        temp->link=NULL;
        arr[a]=temp;
    }
    else
    {
        struct node *temp=arr[a],*p;
        p=(struct node*)malloc(sizeof(struct node));
        while(temp->link!=NULL)
        {
            temp=temp->link;
        }
        p->data=b;
        temp->link=p;
        p->link=NULL;
    }
}


void delete1(struct node *root,long int num,long int i)
{
    struct node *temp ,*p;
    temp=root;
    if(root->data==num&&root->link!=NULL)
    {
        arr[i]=temp->link;
        temp->link=NULL;
    }

    else{
    while(1)
   {
        if(temp->link->data==num&&temp->link->link==NULL)
          {
              temp->link=NULL;
              return;
          }
     else if(temp->data==num&&temp->link->data!=num)
      {
        p=temp->link;
        temp->link=NULL;
        struct node *q;
        q=root;
        while(1)
        {
          if(q->link==temp)
            {
             q->link=p;
             break;
            }
         else
             q=q->link;
        }
         break;
      }
     else
     {
      temp=temp->link;
     }
  }
}
}

void delete_nodes()
{
    long int i,a,b,k,l;
    for(i=0;i<1000000;i++)
    {
      if(arr[i]!=NULL&&len(arr[i])>1)
      {
         while(len(arr[i])!=1)
         {
             struct node *temp=arr[i];
             if(len(arr[i])==2)
                {
                  k=arr[i]->data;
                  l=arr[i]->link->data;
                  if((k%2==0&&l%2==0)||(k%2!=0&&l%2!=0))
                     delete1(arr[i],max(k,l),i);
                  else
                  {
                      if(k%2!=0)
                         delete1(arr[i],k,i);
                      else
                         delete1(arr[i],l,i);
                  }
                  break;
                }


             while(after_length(temp)>=2)
                 {
                    a=temp->data;
                    b=temp->link->data;
                    temp=temp->link->link;
                   if((a%2==0&&b%2==0)||(a%2!=0&&b%2!=0))
                      delete1(arr[i],max(a,b),i);
                   else
                    {
                      if(a%2!=0)
                         delete1(arr[i],a,i);
                      else
                         delete1(arr[i],b,i);
                    }
                 }
         }
      }
    }
    
    long int f=0,g=1;
    while(count_hori()!=1)
    {
        while(g!=1000000-1){
       if(arr[f]==NULL)
        {
          f++;
          g++;
        }
       else if(arr[f]!=NULL&&arr[g]==NULL)
           g++;
       else if(arr[f]!=NULL&&arr[g]!=NULL)
           {
               if(arr[f]->data%2==0&&arr[g]->data%2==0)
               {
                   if(arr[f]->data>arr[g]->data)
                      arr[g]=NULL;
                   else
                      arr[f]=NULL;
                    f++;
                    g++;
               }
           }
        }
        f=0;
        g=1;
    }
    // reducing ends
    for(i=0;i<1000000;i++)
    {
        if(arr[i]!=NULL)
        {
            printf("%d\n",arr[i]->data);
            break;
        }
    }
}

long int count_hori()
{
  long int l=0;
  long int w;
  for(w=0;w<1000000;w++)
  {
      if(arr[w]!=NULL)
        l++;
  }
  return l;
}

long int after_length(struct node *root)
{
  long int l=0;
  struct node *temp;
  temp=root;
  while(temp!=NULL)
  {
      temp=temp->link;
      l++;
  }
  free(temp);
  return l;
}

long int max(long int a,long int b)
{
    if(a>=b)
     return (a);
    return b;
}

long int min(long int a,long int b)
{
    if(a<=b)
        return a;
    return b;
}

long int len(struct node *root)
{
  int l=0;
  struct node *temp;
  temp=root;
  while(temp!=NULL)
  {
      temp=temp->link;
      l++;
  }
  free(temp);
  return l;
}

int main()
{
    long int i;
    for(i=0;i<1000000;i++)
    {
        arr[i]=NULL;
    }
    for(i=0;i<1000000;i++)
    {
        long int a,b;
        a=rand() % 1000000;
        b=rand() % 1000000;
        insert(a,b);
    }
    delete_nodes();
}
