#include<stdio.h>
#include<stdlib.h>
int partition(int a[],int start,int end){
  int pivot=a[end];
  int pindex=start;
  int i=0,temp;
  for(i=start;i<end;i++){
    if(a[i]<=pivot){
      temp=a[i];
      a[i]=a[pindex];
      a[pindex]=temp;
      pindex=pindex+1;
    }

  }
  int f;
  f=a[pindex];
  a[pindex]=a[end];
  a[end]=f;
  return pindex;
}
int qs(int a[],int start,int end){
  if(start>=end){
    return a[end];
  }
  else{
    int pindex=partition(a,start,end);
    qs(a,start,pindex-1);
    qs(a,pindex+1,end);
  }
}
int main(){
  int a[10],i;
  for(i=0;i<10;i++){
    a[i]=rand();
  }
  qs(a,0,9);
  int z=0;
  for(z=0;z<10;z++){
    printf("%d\n",a[z]);
  }


}
