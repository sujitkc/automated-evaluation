#include<stdio.h>
void selectionsort(int a[],int n);

int main(){
	int a[]={34,24,11,19,10},i;
	selectionsort(a,5);
	for(i=0;i<5;i++){
		printf("%d\n",a[i]);
	}
}

void selectionsort(int a[],int n){
	int i,j,min,temp,loc;
		
		for(i=0;i<n;i++){
			min=a[i];
			loc=i;
			for(j=i;j<n;j++){
				if(a[j]<a[loc]){
					loc=j;
				}
			}
			temp=a[i];
			a[i]=a[loc];
			a[loc]=temp;
		}

}
