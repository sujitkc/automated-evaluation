#include<stdio.h>
void mergesort(int a[],int strt,int end);
void merge1(int a[],int i,int k,int j);
void print(int a[],int len);

int main(){
	int a[]={34,24,11,19,10},i;
	mergesort(a,0,4);
	print(a,5);
	}


void mergesort(int a[],int strt,int end){
	int temp;
	if(end<=strt+1){
		if(a[strt]>a[end]){
			temp=a[strt];
			a[strt]=a[end];
			a[end]=temp;
		}
	}
	else{
		int mid=(strt+end)/2;
		mergesort(a,strt,mid);
		mergesort(a,mid+1,end);
		merge1(a,strt,mid,end);
	}
}


void merge1(int a[],int i1,int j1,int j2)
{
    int temp[1000];    
    int i,j,k;
    i=i1; 
    j=j1+1; 
    k=0;
    
    while(i<=j1 && j<=j2)    
    {
        if(a[i]<a[j])
            temp[k++]=a[i++];
        else
            temp[k++]=a[j++];
    }
    
    while(i<=j1)   
        temp[k++]=a[i++];
        
    while(j<=j2)   
        temp[k++]=a[j++];
        
    
    for(i=i1,j=0;i<=j2;i++,j++)
        a[i]=temp[j];
}

 
 void print(int a[],int len){
 	int i;
 		for(i=0;i<len;i++){
		printf("%d\n",a[i]);}
 }
