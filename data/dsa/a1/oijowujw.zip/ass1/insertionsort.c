#include<stdio.h>
void insertionsort(int a[],int n);

int main(){
	int a[]={34,24,11,19,10,-1},i;
	insertionsort(a,6);
	for(i=0;i<6;i++){
		printf("%d\n",a[i]);
	}
}

void insertionsort(int a[],int n){
	int i,j,temp;
	for(i=0;i<n;i++){
		temp=a[i];
		for(j=i-1;j>=0;j--){
			if(a[j]>temp){
				a[j+1]=a[j];
				a[j]=temp;
			}
		}
	}
	
	
	
}
