
void modified_bubblesort(int a[],int n){
	int i,j,temp,flag;
	
	for(i=1;i<n;i++){
	flag=0;
	 for(j=0;j<n-i;j++){
	 	if (a[j]>a[j+1]){
	 		flag=1;
	 		temp=a[j+1];
	 		a[j+1]=a[j];
	 		a[j]=temp;
		   }
		}
		if(flag==0){
			return;
		}
	 }

}
