#include<time.h>
#include<stdlib.h>
#include<stdio.h>
int power(int arr[2][2],int num[],int len);
void mul(int arr[2][2],int n[2][2]);
int check(int number[],int len);
void divi(int arr[],int a,int n);

void mul(int arr[2][2],int n[2][2])
{
  int c[2][2]={{0,0},{0,0}};
  for(int i=0;i<2;i++)
    for(int j=0;j<2;j++)
      for(int k=0;k<2;k++)
        c[i][j]+=arr[i][k]*n[k][j];
    for(int i=0;i<2;i++)
      for(int j=0;j<2;j++)
        arr[i][j]=c[i][j]%100;
  }

int check(int number[],int len){
	int a=0;
	for (int i=0;i<len;i++)
		if(number[i]==0)
			a=a+1;
	if (a==len)
			return 0;
	else
    return 1;
}

void  divi(int num[],int a,int n)
{
  int i;
  for(i=0;i<n;i++)
  {
    if(i!=(n-1))
    {
      if(num[i]%a==0)
      {
        num[i]=num[i]/a;
      }
      else if((num[i]%a)<n && num[i]%a>0)
      {
        num[i+1]=(num[i]%a)*10+ num[i+1];
        num[i]=num[i]/a;
      }
    }
    else if(i==n-1)
    {
      num[i]=num[i]/a;
    }
  }
}
int power(int arr[2][2],int num[],int len)
{
  int y[2][2]={{1,0},{0,1}};
  while(check(num,len)){

    if(num[len-1]%2==1)
    {
      mul(y,arr);
    }
      mul(arr,arr);
      divi(num,2,len);
  }

		return y[1][0];

}

int main ()
{
  int arr[2][2]={{1,1},{1,0}},i=0,j;
  int num[1000];
  srand(time(NULL));
  for(i=0;i<1000;i++)
    num[i]=rand()%10;
  int c=power(arr,num,i);
  printf("%d",c);
}
