#include<stdio.h>
#include<stdlib.h>
main(){
int n=1000;
int a[n],i,j,d;
srand(time(NULL));
for(i=0;i<n;i++){
	a[i]=rand()%n;
}
for(i=0;i<n-1;i++){
	for(j=0;j<n-1-i;j++){
		if(a[j]>a[j+1]){
			d=a[j];
			a[j]=a[j+1];
			a[j+1]=d;
		}
	}
}	

for(i=0;i<n;i++){
	printf("%d\n",a[i]);
}
}
