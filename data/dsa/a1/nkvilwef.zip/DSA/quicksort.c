#include<stdio.h>
#include<stdlib.h> 

int partition(int* a, int l, int h)

{

    srand(time(NULL));

    int pivotIdx = l + rand() % (h-l+1),j,k;

    int pivot = a[pivotIdx];

    
            k=a[pivotIdx];
            a[pivotIdx]=a[h];
        a[h]=k;
        
    pivotIdx = h;

    int i = l -1,v;

 

    for(j=l; j<=h-1; j++)

    {

        if(a[j] <= pivot)

        {

            i = i+1;

            v=a[i];
            a[i]=a[j];
        a[j]=v;
        }

    }

 

    
    
            v=a[i+1];
            a[i+1]=a[pivotIdx];
        a[pivotIdx]=v;
        
    return i+1;

}

 

void quick_sort(int* a, int l, int h)

{

    if(l < h) {

        int mid = partition(a, l, h);

        quick_sort(a, l, mid-1);

        quick_sort(a, mid+1, h);

    }

}

void main()

{
int n=1000;
int a[n],i,j,d;
srand(time(NULL));
for(i=0;i<n;i++){
	a[i]=rand()%n;
}

    
    quick_sort(a, 0,n-1);
    for(i=0;i<n;i++){
printf("%d\n",a[i]);
}

}
