#include<stdio.h>
main(){
	int n=1000;
int a[n],i,j,d,m;
srand(time(NULL));
for(i=0;i<n;i++){
	a[i]=rand() %n;
}

for(i=0;i<n-1;i++){
	d=0;
	for(j=1;j<n-i;j++){
		if(a[j]>a[d]){
			d=j;
			
		}
	}
		m=a[d];
		a[d]=a[n-i];
		a[n-i]=m;
	
}
for(i=0;i<n;i++){
	printf("%d\n",a[i]);
}
	

}


