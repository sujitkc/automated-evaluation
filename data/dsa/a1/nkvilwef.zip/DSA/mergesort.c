#include<stdio.h>
#include<stdlib.h>
void Merge(int a[], int i, int k, int j){
	int l = i;
	int r = k+1;
	int x=0,b[j+1];
	
	int y;
	
	while(l<=k && r<=j){
		if(a[l]<a[r])
			b[x++]=a[l++];
		else
			b[x++]=a[r++];
	}
	
	while(l<=k)
		b[x++]=a[l++];
		
	while(r<=j)
		b[x++]=a[r++];
		
	x=0;
	for(y=i; y<=j; y++)
		a[y]=b[x++];	
}
 

void MergeSort(int a[], int i, int j){
	if(i<j){
	
	int k = (i+j)/2;
	MergeSort(a, i, k);
	MergeSort(a, k+1, j);
	Merge(a, i, k, j);
          }
}
 

 

int main()
{
	int n=1000;
	srand(time(NULL));
    int a[n];
    int i;
    for (i=0;i<n;i++){
    	a[i]=rand()%n;
	}
 
    MergeSort(a, 0, n - 1);
    for (i=0;i<n;i++){
    	printf("%d\n",a[i]);
	}
 
    return 0;
}

