#include <stdio.h>
int fibarray(int n);
int main()
{
  int n;
  scanf("%d",&n);
  printf("%d\n",fibarray(n));
}
int fibarray(int n){
  int i,arr[n];
  arr[0]=0;
  arr[1]=1;
  for (i=2;i<n;i++)
  {
    arr[i]=(arr[i-1]+arr[i-2])%100;
  }
  return arr[n-1];
}
