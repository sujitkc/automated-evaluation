#include <stdio.h>
int recfibo(int n,int m);
int main()
{
  int n;
  scanf("%d",&n );
  printf("%d\n",recfibo(n,100) );
}
int recfibo(int n,int m){
  if(n==1 || n==2){
    return n-1;
  }
  else{
    return (recfibo(n-1,m)+recfibo(n-2,m))%m;
  }
}
