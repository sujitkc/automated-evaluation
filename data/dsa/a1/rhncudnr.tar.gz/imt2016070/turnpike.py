class node:
    def __init__(self,parent,left,right,main,final):
        self.parent=parent
        self.left=left
        self.right=right
        self.main=main
        self.final=final

def check(main,final,val):
    maintemp=[]
    for i in main:
        maintemp.append(i)
    finaltemp=final
    for i in finaltemp:
        temp=abs(i-val)
        if(maintemp.count(temp)>0):
            maintemp.remove(temp)
        else:
            return False
    return True
def solve(current,maxOfMain,n):
    if(current.left==None and current.right==None):
        if(check(current.main,current.final,max(current.main))):
            maintemp=map(lambda x:x,current.main)
            finaltemp=map(lambda x:x,current.final)
            val=max(current.main)
            for i in finaltemp:
                maintemp.remove(abs(i-val))
            finaltemp.append(val)
            finaltemp.sort()
            if(len(finaltemp)==n and len(maintemp)==0):
                print finaltemp
                print sorted(map(lambda x:maxOfMain-x,finaltemp))
                exit()
            current.left=node(current,None,None,maintemp,finaltemp)
            return solve(current.left,maxOfMain,n)
        else:
            current.left=1
            return solve(current,maxOfMain,n)
    elif(current.left!=None and current.right==None):
        if(check(current.main,current.final,maxOfMain-max(current.main))):
            maintemp=map(lambda x:x,current.main)
            finaltemp=map(lambda x:x,current.final)
            val=maxOfMain-max(current.main)
            for i in finaltemp:
                maintemp.remove(abs(i-val))
            finaltemp.append(val)
            finaltemp.sort()
            if(len(finaltemp)==n and len(maintemp)==0):
                print finaltemp
                print sorted(map(lambda x:maxOfMain-x,finaltemp))
                exit()
            current.right=node(current,None,None,maintemp,finaltemp)
            return solve(current.right,maxOfMain,n)
        else:
            current.right=1
            if(current.parent==None):
                print "No such points exist"
                exit()
            return solve(current.parent,maxOfMain,n)
    elif(current.left!=None and current.right!=None):
        if(current.parent==None):
            print "No such points exist"
            exit()
        return solve(current.parent,maxOfMain,n)



if __name__=="__main__":
    main=map(int,raw_input("Enter the distances array\n").split())
    main.sort()
    l=len(main)
    n=(1+((1+8*l)**0.5))/2
    if(n-int(n)==0):
        n=int(n)
        maxOfMain=max(main)
        final=[0,maxOfMain]
        main.remove(maxOfMain)
        startnode=node(None,None,None,main,final)
        solve(startnode,maxOfMain,n)
    else:
        print "No such point exists"
