#include <stdio.h>
int partition(int A[],int start,int end);
void quicksort(int A[],int start, int end);
int main()
{
  srand ( time(NULL) );
  int A[100];
  int i;
  for(i=0;i<100;i++){
    A[i]=rand()%100;

  }
  for(i=0;i<100;i++)
  printf("%d ",A[i]);
  printf("\n\n");
  quicksort(A,0,99);
  for(i=0;i<100;i++)
  printf("%d ",A[i]);
  printf("\n");
}
int partition(int A[],int start,int end){
  int pivot=A[end];
  int pIndex=start;
  int i;
  for(i=start;i<end;i++){
    if(A[i]<=pivot){
      int temp=A[i];
      A[i]=A[pIndex];
      A[pIndex]=temp;
      pIndex++;
    }
  }
  int temp=A[pIndex];
  A[pIndex]=A[end];
  A[end]=temp;
  return pIndex;
}
void quicksort(int A[],int start, int end){
  if(start<end){
    int pIndex=partition(A,start,end);
    quicksort(A,start,pIndex-1);
    quicksort(A,pIndex+1,end);
  }
}
