#include <stdio.h>
int fibarray(int n);
int findFibonacciPeriod(int m,int arr[]);
int main()
{
  int n,m;
  printf("Which fibonacci number do you want?\n");
  scanf("%d",&n);
  printf("Enter m\n");
  scanf("%d",&m);
  int arr[6*m];
  int period=findFibonacciPeriod(m,arr);
  printf("%d\n",period);
  int index=(n-1)%period;
  printf("%d\n",arr[index]);
}
int findFibonacciPeriod(int m,int arr[]){
  int i;
  arr[0]=0;
  arr[1]=1;
  for (i=2;i<6*m;i++)
  {
    arr[i]=(arr[i-1]+arr[i-2])%m;
    if(arr[i]==1 && arr[i-1]==0){
      return i-1;
    }
  }
}
