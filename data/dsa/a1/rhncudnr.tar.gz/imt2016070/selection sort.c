#include<stdio.h>
int selection_sort(int a[],int n)
{
	int i,j,min,temp;
	for(i=0;i<n;i++)
	{
		min=i;
		for(j=i+1;j<n;j++)
		{
			if(a[j]<a[min])
			{
				min=j;
				
			}
		}
		temp=a[i];
		a[i]=a[min];
		a[min]=temp;
	}
	return a[n];
}
int main()
{
	int n,i,j,temp;
	printf("enter the length of list");
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	selection_sort(a,n);
	for(i=0;i<n;i++)
	{
		printf("%d\t",a[i]);
	}
	
}

