#include <stdio.h>
#include <stdlib.h>
#define size 1000000
struct node{
int data;
struct node *nextptr;
};
void view(struct node *startptr);
void insert(struct node **startptr,int newdata);
int length(struct node *startptr);
void delete(struct node **head,int deletedata);
void reducehori(struct node **startptr);
void VertiShrink(struct node** head);
int count = 0;
int main()
{ srand ( time(NULL) );
  struct node *arr[size]={NULL};
  int i;
  for (i = 0; i < 100000; i++) {
    /* code */

    int index=rand()%size;

    int number=rand();
    insert(&arr[index],number);

  }
printf("\n" );
struct node *verti=NULL;
for(i=0;i<size;i++){
  reducehori(&arr[i]);
  if(arr[i]!=NULL)
  insert(&verti,(arr[i])->data);

}
printf("\n" );
while(1)
{
    if(count > 0)
        break;
    VertiShrink(&verti);
}
view(verti);
}




void insert(struct node **startptr,int newdata){
  struct node *temp;
  temp=(struct node*)malloc(sizeof(struct node));
  temp->data=newdata;
  temp->nextptr=*startptr;
  *startptr=temp;
}

void view(struct node *startptr)
{
if((startptr)==NULL)
printf("The linked list is empty");
struct node *currentptr=startptr;
while(currentptr!=NULL)
{
printf("%d ",currentptr->data);
currentptr=currentptr->nextptr;
}
printf("\n");
}
int length(struct node *startptr){
  struct node *currentptr=startptr;
  if(currentptr==NULL)
  return 0;
  else{
    int count=0;
    while(currentptr!=NULL){
      currentptr=currentptr->nextptr;
      count++;
    }
    return count;
  }
}
void delete(struct node **head,int deletedata)
{
    struct node *current = *head;
    if(*head == NULL)
    {
        printf("There are no elements in the linked list\n");
        return;
    }
    else if((*head)->data==deletedata)
        *head=(*head)->nextptr;


    else
    {
        while(current->nextptr!=NULL )
        {
            if(current->nextptr->data==deletedata)
            {
                free(current->nextptr);
                current->nextptr=current->nextptr->nextptr;
                return;
            }
            if(current->nextptr!=NULL)
                current=current->nextptr;
        }

        if(current->nextptr==NULL)
            printf("The element doesn't exist in the linked list\n");
        else
        {
            free(current->nextptr);
            current->nextptr=current->nextptr->nextptr;
        }
    }
}
void reducehori(struct node **startptr){
  if(*startptr!=NULL){
    while(length(*startptr)!=1){
      struct node *currentptr=*startptr;
      while(1){
        int temp1=currentptr->data;
        if(currentptr->nextptr!=NULL){
          currentptr=currentptr->nextptr;
          int temp2=currentptr->data;
          if(temp1%2==0 && temp2%2==0){
            if(temp1<temp2){
              delete(startptr,temp1);
            }
            else{
              delete(startptr,temp2);
            }
          }
          else if(temp1%2==1 && temp2%2==1){
            if(temp1>temp2){
              delete(startptr,temp1);
            }
            else{
              delete(startptr,temp2);
            }
          }
          else{
            if(temp1%2==1){
              delete(startptr,temp1);
            }
            else{
              delete(startptr,temp2);
            }
          }
        }
        else{
          break;
        }
        if(currentptr->nextptr!=NULL){
          currentptr=currentptr->nextptr;
        }
        else{
          break;
        }
      }

    }
  }
}
void VertiShrink(struct node** head)
{
    struct node* current = *head;

    if(current == NULL || current -> nextptr == NULL)
    {
        count += 1;
        return;
    }

    if((current -> data) % 2 ==0 && (current -> nextptr -> data) % 2 == 0)
    {
        if((current -> data) > (current -> nextptr -> data))
        {
            delete(head, current-> nextptr -> data);
        }
        else
            delete(head, current -> data);
        return;
    }

    if((current -> data) % 2 ==1 && (current -> nextptr -> data) % 2 == 1)
    {
        if((current -> data) > (current -> nextptr -> data))
        {
            delete(head, current -> data);
        }
        else
            delete(head, current -> nextptr -> data);
        return;
    }

    if((current -> data) % 2 ==0 && (current -> nextptr -> data) % 2 == 1)
    {
        delete(head, current -> nextptr -> data);
        return;
    }
}
