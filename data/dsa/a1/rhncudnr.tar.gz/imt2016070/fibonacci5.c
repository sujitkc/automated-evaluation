	#include <stdio.h>
	#include <string.h>
	#include <math.h>
	void multiply(int F[2][2], int M[2][2]);
  void power(int F[2][2], int n);
	int fib(int n);
int isZero(char n[]);
int binaryfib(char n[]);
void binaryPower(int F[2][2],char n[]);
int decimalToBinary(char n[]);
void divideByTwo(char n[]);
	int main()
	{
		char n[10000];
		printf("1. Binary\n");
		printf("2. Decimal\n");
		int ch1;
		scanf("%d",&ch1);
		if(ch1==1){
			printf("Enter the term whose fibonacci number is to be found in binary\n");
			scanf("%s",n);
			printf("%d\n",binaryfib(n));


		}
		else if(ch1==2){
			printf("Enter the term whose fibonacci number is to be found in decimal\n");
			scanf("%s",n);
			printf("%d\n",decimalToBinary(n));


		}


	}
	void multiply(int F[2][2], int M[2][2]){
		int c[2][2],i,j,k;
		for (i = 0; i < 2; i++) {
	    for (j = 0; j < 2; j++) {
	      int sum = 0;
	      for (k = 0; k < 2; k++) {
	      	sum = sum + F[i][k] * M[k][j];
	        }
	        c[i][j] = sum;
	      }
	   }
		 for(i=0;i<2;i++){
			 for(j=0;j<2;j++){
				 F[i][j]=c[i][j]%100;
			 }
		 }
	}
	void power(int F[2][2], int n){
	  if( n == 0 || n == 1){
	      return;
			}
	  int M[2][2] = {{1,1},{1,0}};

	  power(F, n/2);
	  multiply(F, F);

	  if (n%2 != 0)
	     multiply(F, M);
	}
	int fib(int n){
  int F[2][2] = {{1,1},{1,0}};
  if (n <= 0){
			printf("Invalid input\n");
      return -1;
		}
		else if(n==1){
			return 0;
		}
  power(F, n);
  return F[1][1];
}
int binaryfib(char n[]){
	int F[2][2] = {{1,1},{1,0}};
	if(isZero(n)==1){
		printf("Invalid input\n");
		return -1;
	}
	binaryPower(F,n);
	return F[1][1];
}
void binaryPower(int F[2][2],char n[]){
	int M[2][2] = {{1,1},{1,0}};
	int i;
	for(i=1;i<strlen(n);i++){
		if(n[i]=='0'){
			multiply(F,F);
		}
		else{
			multiply(F,F);
			multiply(F,M);
		}
	}
}
int isZero(char n[]){
	int i;
	for(i=0;i<strlen(n);i++){
		if(n[i]!='0'){
			return 0;
		}
	}
	return 1;
}
int decimalToBinary(char n[]){
	char binarybuffer[100000];
	int a=0,length=strlen(n);
	while(isZero(n)!=1){
		binarybuffer[a]=((n[length-1]-'0')%2)+'0';
		a++;
		divideByTwo(n);
	}
	binarybuffer[a]='\0';
	int i;
	length=strlen(binarybuffer);
	for(i=0;i<length/2;i++){
		char temp=binarybuffer[i];
		binarybuffer[i]=binarybuffer[length-1-i];
		binarybuffer[length-1-i]=temp;
	}
	return binaryfib(binarybuffer);
}
void divideByTwo(char n[]){
	int i;
	for(i=0;i<strlen(n);i++){
		if((n[i]-'0')%2==0){
			n[i]=((n[i]-'0')/2)+'0';
		}
		else{
			n[i]=((n[i]-'0')/2)+'0';
			if(i+1!=strlen(n))
			n[i+1]=n[i+1]+10;
		}
	}
}
