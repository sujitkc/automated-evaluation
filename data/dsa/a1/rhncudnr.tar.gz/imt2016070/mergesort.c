#include <stdio.h>
#include <stdlib.h>
int B[10];
void merge(int A[],int i,int k,int j);
void sort(int A[],int i,int j);
int main(){
  int A[10];
  int i;
  for(i=0;i<10;i++){
    A[i]=10-i;

  }
  sort(A,0,10-1);
  for(i=0;i<10;i++){
    printf("%d ",A[i]);
  }
}
void merge(int A[],int i,int k,int j){
  int l=i;
  int r=k+1;
  int a=0;
  while(l<=k && r<=j){
    if(A[l]<A[r]){
      B[a++]=A[l++];
    }
    else{
      B[a++]=A[r++];
    }
  }
  while(l<=k){
    B[a++]=A[l++];
  }
  while(r<=j){
    B[a++]=A[r++];
  }
  a=0,l=i;
  while(l<=j){
    A[l++]=B[a++];
  }
}
void sort(int A[],int i,int j){
  if(j==i+1){
    int temp=A[i];
    A[i]=A[j];
    A[j]=temp;
  }
  else if(j>i+1){
    int k=(i+j)/2;
    sort(A,i,k);
    sort(A,k+1,j);
    merge(A,i,k,j);
  }
}
