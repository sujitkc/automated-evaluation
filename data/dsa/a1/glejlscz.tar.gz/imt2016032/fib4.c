#include<stdio.h>

int main()
{
	int n;
	printf("Enter the number no of terms:\n");
	scanf("%d",&n);
	if (n==0)
		printf("0");
	else{
		int a[2][2]={{1,1},{1,0}};
		int b[2][2]={{1,1},{1,0}};
		int i;
		for (i=2;i<=n-1;i++)
		{
			int p =  a[0][0]*b[0][0] + a[0][1]*b[1][0];
  			int q =  a[0][0]*b[0][1] + a[0][1]*b[1][1];
  			int r =  a[1][0]*b[0][0] + a[1][1]*b[1][0];
  			int s =  a[1][0]*b[0][1] + a[1][1]*b[1][1];
 			a[0][0] = p;
  			a[0][1] = q;
  			a[1][0] = r;
  			a[1][1] = s;
		}
		printf("%d",a[0][0]);
	}

}
