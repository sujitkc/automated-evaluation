#include<stdio.h>
int main()
{
	int len;
	printf("Enter number of elements:\n");
	scanf("%d",&len);
	int a[len],k;
	printf("Enter %d elements:\n",len);
	for(k=0;k<len;k++)
	{
		scanf("%d",&a[k]);
	}
	int i, j,x;
	for (i=0;i<len-1;i++)
	{
		for(j=0;j<len-1-i;j++)
		{
			if(a[j]>a[j+1])
			{
				x=a[j];
				a[j]=a[j+1];
				a[j+1]=x;
			}
		}
	}
	printf("sorted elements are\n");
	for(k=0;k<len;k++)
	{
		printf("%d ",a[k]);
	}
	return 0;
}
