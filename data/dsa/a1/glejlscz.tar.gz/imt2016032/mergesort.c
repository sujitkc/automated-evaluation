#include<stdio.h>

void MMerge(int a[],int i, int mid, int j)
{
    int x[j-i+1];
    int l=i,r=mid+1,m=0;

    while(l<=mid && r<=j)
	{
        if(a[l]<a[r])
            x[m++]=a[l++];
        else
            x[m++]=a[r++];
    }

    while(l<=mid)
	{
        x[m]=a[l];
        m++;
        l++;
        }
    while(r<=j){
        x[m]=a[r];
        m++;
        r++;
        }
    for(l=i,r=0;l<=j;l++,r++)
        a[l]=x[r];
}




void sort(int a[], int l, int h)
{
	if(l<h){
		int m;
	m= (l+h)/2;
	sort(a,l,m);
	sort(a,m+1,h);
	MMerge(a,l,m,h);
	}
}


int main()
{
	int len;
	printf("enter number of elements.\n");
	scanf("%d",&len);
	int a[len],k;
	printf("enter %d elements.\n",len);
	for(k=0;k<len;k++){
		scanf("%d",&a[k]);
	}
	sort(a,0,len-1);
	printf("sorted elements are\n");
	for(k=0;k<len;k++){
		printf("%d ",a[k]);
	}

	return 0;
}
