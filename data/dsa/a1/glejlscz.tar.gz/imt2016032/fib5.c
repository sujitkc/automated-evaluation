#include<stdio.h>
int fibb(int xx[], int n, int m)
{
	xx[0]=0; xx[1]=1;
	int i;
	for(i=2;i<6*m+1;i++){
		xx[i]=(xx[i-1]+xx[i-2])%m;
		if((xx[i]==1) && (xx[i-1]==0))
		{
			return (i-1);
		}
	}
	return -1;
}
int main()
{
	int n,m;
	printf("Enter the number:\n ");
	scanf("%d",&n);

	printf("Enter the value of the modulus:\n ");
	scanf("%d",&m);
	int xx[6*m];
	int c;
	c=fibb(xx,n,m);
	if (c!= -1)	printf("The %dth number is %d",n,xx[n%c]);
	else printf("The %dth number of is %d",n,xx[n]);
}
