#include <stdio.h>
int main ()
{
	int x, p, i, j,len;
	printf("enter number of elements.\n");
	scanf("%d",&len);
	int a[len];
	printf("enter %d elements.\n",len);
	for(i=0;i<len;i++)
	{
        scanf("%d",&a[i]);
	}
	for (i=0;i<len;i++)
	{
		p=i;
		for (j=i+1;j<len;j++)
		{
			if (a[j]<a[p])
			{
				p=j;
			}
		}
		x=a[p];
		a[p]=a[i];
		a[i]=x;
	}
	for (i=0;i<len;i++)
	{
		printf("%d ", a[i]);
	}
	return 0;
}
