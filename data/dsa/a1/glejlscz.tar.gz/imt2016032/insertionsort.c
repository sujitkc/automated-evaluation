#include<stdio.h>
int main()
{
	int n;
	printf("Enter number of elements:\n");
	scanf("%d",&n);
	int a[n],k;
	printf("Enter %d elements:\n",n);
	for(k=0;k<n;k++){
		scanf("%d",&a[k]);
	}
	int i,j,p,x;
	for (i =1;i<=n;i++){
		p=i;
		for(j=i-1;j>=0;j--){
			if(a[p]<a[j]){
				x=a[j];
				a[j]=a[p];
				a[p]=x;
				p=j;
			}
			else
				break;
		}
	}
	printf("sorted elements are\n");
	for(k=0;k<n;k++)
	{
		printf("%d ",a[k]);
	}
	return 0;

}
