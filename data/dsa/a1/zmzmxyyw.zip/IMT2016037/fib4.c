#include<stdio.h>
int findperiod(int m)
{
    int i,arr[6*m];
    arr[0]=0;
    arr[1]=1;
    for(i=2;i<6*m;i++)
    {
        arr[i]=(arr[i-1]+arr[i-2])%m;
    }
    for(i=5;i<6*m;i++)
    {
        if(arr[i]==0 && arr[i+1]==1)
        {
            return i;
        }
    }
}
int modulo (int arr,int num,int period)
{
    int i,sum=0;
    sum=0;
    while(i<num)
    {
        while(sum<period&&i<num)
        {
            sum=sum*10+arr[i];
        }
        sum=sum%m;
        i++;
    }
    return sum;
}
int fib(int n,int m)
{
     int i,arr[n+1];
    arr[0]=0;
    arr[1]=1;
    for(i=2;i<=n;i++)
    {
        arr[i]=(arr[i-1]+arr[i-2])%m;
    }
    return arr[n];
}
int main()
{
int i,n,m;
scanf("%d",&m);
int arr[n];
/for(i=0;i<n;i++)
{
scanf("%d",&arr[i]);
}
sum=modulo(arr,n,period(m));
printf("%d\n",fib(sum,m));

}
