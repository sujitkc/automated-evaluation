#include<stdio.h>
int fib100(int n)
{
if(n==0 ||n==1)
{
return n;
}
else
{
return (fib100(n-1)+fib100(n-2))%100;
}
}
int main()
{

    int n;
    scanf("%d",&n);
    printf("%d\n",fib100(n));

}
