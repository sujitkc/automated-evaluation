#include<stdio.h>
void selectionsort(int *arr,int n)
{
	int i,j,t;
	for (i =0; i < n; ++i)
	{
		for(j=0;j<n-i;j++)
		{
			if(arr[j]>arr[n-i])
			{
				t=arr[j];
				arr[j]=arr[n-i];
				arr[n-i]=t;


			}
		}
		/* code */
	}

}
int main()
{
	int i,n;
	scanf("%d",&n);
	int arr[n];
	for (i = 0; i <n; ++i)
	{
		scanf("%d",&arr[i]);
		/* code */
	}
	selectionsort(arr,n);
	for (i = 0; i <n; ++i)
	{
		printf("%d\t",arr[i]);
		/* code */
	}
}
