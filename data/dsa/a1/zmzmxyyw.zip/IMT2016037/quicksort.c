#include<stdio.h>
#include<stdlib.h>
int ran(int *arr,int i,int j)
{
int t,r=rand()%(j-i+1);
return arr[r];
}
int partion(int *arr,int i,int j,int p)
{
int t,l=i,r=j;
while(l<r)
{
while(l<r && arr[l]<p)
{
l++;
}
while(l<r && arr[r]>p)
{
r--;
}
t=arr[l];
arr[l]=arr[r];
arr[r]=t;
}

if(r==j)
{
return r-1;
}
else
{
return r;
}
}
void Quicksort(int *arr,int i,int j)
{
int r,k,t;
if(j<=i+1)
{
if(j==i+1)
{
	if(arr[j]<arr[i])
	{
t=arr[i];
arr[i]=arr[i+1];
arr[i+1]=arr[i];
}}}

else
{
r=ran(arr,i,j);
k=partion(arr,i,j,r);
Quicksort(arr,i,k);
Quicksort(arr,k+1,j);

}
}
int main()
{
int i,n;
scanf("%d",&n);
int arr[n];
for(i=0;i<n;i++)
{
scanf("%d",&arr[i]);
}
Quicksort(arr,0,n-1);
for(i=0;i<n;i++)
{
	printf("%d\t",arr[i]);
}

}
