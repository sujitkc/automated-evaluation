#include<stdio.h>
#include<stdlib.h>

int check_if_all_zeroes(int *arr,int n)
{
    int i,count=0;
    for(i=0;i<n;i++)
    {
      if(arr[i]==0)
      {
          count++;

      }
    }
if(count==n)
    {
    return 0;
    }
    else
    {
        return 1;
    }

}
void shift_right_by_one(int *arr,int n)
{
    int i;
    for(i=n-1;i>=0;i--)
    {
        if(i==0)
        {
            arr[i]=0;
        }
        else{
        arr[i]=arr[i-1];
        }

    }
}
int multiply(int a[2][2],int b[2][2])
{
    int i,j,k,sum,c[2][2];
    for(i=0;i<2;i++)
{
    for(j=0;j<2;j++)
{
    sum=0;
for(k=0;k<2;k++)
{
sum=sum+(a[i][k]*b[k][j]);
}
c[i][j]=sum%100;
}
}
for(i=0;i<2;i++)
{
    for(j=0;j<2;j++)
    {
       a[i][j]=c[i][j];

    }
}
}
int main()
{
    int n;
    printf("Enter the number of bits in binary form works even for 10^6 digits\n");
    scanf("%d",&n);

int i,j,arr[n],arr1[2][2]={{1,1},{1,0}},arr2[2][2]={{1,0},{0,1}};
 printf(" Now Enter the number in binary form (0's and 1's)\n  ");
for(i=0;i<n;i++)
{
    scanf("%d",&arr[i]);
}
while(check_if_all_zeroes(arr,n))
{
    if(arr[n-1]==1)
    {
        multiply(arr2,arr1);
    }
    multiply(arr1,arr1);
    shift_right_by_one(arr,n);

}
printf("%d\n",arr2[1][0]);

}


