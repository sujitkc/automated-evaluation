#include<stdio.h>
void merge(int *a ,int p,int q,int r)
{
	int i=p,j=q+1,k=0,c[r-p+1];
while(i<=q & j<=r)
	{
	if(a[i]<a[j])
	{
     c[k++]=a[i++];

	}
	else
	{
	  	c[k++]=a[j++];


	}
}

while(i<=q)
{
	c[k++]=a[i++];


}
while(j<=r)
{
	c[k++]=a[j++];

}

for (i = 0; i<r-p+1; i++)
{
	a[p+i]=c[i];

		/* code */

}
}
void mergesort(int *a,int i,int j)
{int k,t;
	if(j==i+1)
	{
		if(a[j]<a[i])
		{
			t=a[i];
			a[i]=a[j];
			a[j]=t;
		}

	}

	else if(j>i+1)
	{
		k=(i+j)/2;
		mergesort(a,i,k);
		mergesort(a,k+1,j);
                merge(a,i,k,j);
	}

}

int main()
{
	int i,n;
scanf("%d",&n);
   int a[n];

for (i = 0; i<n; i++)
{
		scanf("%d",&a[i]);
}
	mergesort(a,0,n-1);
for (i = 0; i<n; i++)
{
		printf("%d\t",a[i]);
}

}
