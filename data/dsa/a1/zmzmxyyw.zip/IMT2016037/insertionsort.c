#include<stdio.h>
void insertsort(int *a,int n)
{
int i,j,temp;
	for (i = 1; i<=n; ++i)
	{ j=i-1;
		temp=a[i];
		while(j>=0 && a[j]>temp)
		{
			a[j+1]=a[j];
			j--;
		}
		a[j+1]=temp;
		/* code */
	}
	for (i = 0; i < n; ++i)
{
	printf("%d\t",a[i]);
	/* code */
}
}
int main()
{
	int i,n;
	scanf("%d",&n);
int  arr[n];
for (i = 0; i < n; ++i)
{
	scanf("%d",&arr[i]);
	/* code */
}
insertsort(arr,n);

}
