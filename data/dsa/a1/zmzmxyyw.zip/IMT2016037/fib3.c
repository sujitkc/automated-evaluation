#include<stdio.h>
int fib100(int n)
{
int i=1,first=0,second=1,fib;
if(n==0 || n==1)
{
    return n;
}
else
{
while(i<n)
{
fib=(first+second)%100;
first=second;
second=fib;
i++;
}
}
return fib;

}
int main()
{

    int n;
    scanf("%d",&n);
    printf("%d\n",fib100(n));

}
