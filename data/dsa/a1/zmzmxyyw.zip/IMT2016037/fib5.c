#include<stdio.h>
int size(int n)
{
    int k=1,count=0;
    while(k<=n)
    {
        k=2*k;
        count++;

    }
    return count;
}
void binary(int *arr,int n)
{
    int i,num=size(n);
    for(i=num-1;i>=0;i--)
    {
        arr[i]=(n%2);
        n=n/2;

    }
    //
    printf("%d\n",num);
    for(i=0;i<num;i++)
    {
        printf("%d\t",arr[i]);

    }

}
int check_if_all_zeroes(int *arr,int n)
{
    int i,count=0;
    for(i=0;i<size(n);i++)
    {
      if(arr[i]==0)
      {
          count++;

      }
    }
if(count==size(n))
    {
    return 0;
    }
    else
    {
        return 1;
    }

}
void shift_right_by_one(int *arr,int n)
{
    int i;
    for(i=size(n)-1;i>=0;i--)
    {
        if(i==0)
        {
            arr[i]=0;
        }
        else{
        arr[i]=arr[i-1];
        }

    }
}
int multiply(int a[2][2],int b[2][2])
{
    int i,j,k,sum,c[2][2];
    for(i=0;i<2;i++)
{
    for(j=0;j<2;j++)
{
    sum=0;
for(k=0;k<2;k++)
{
sum=sum+(a[i][k]*b[k][j]);
}
c[i][j]=sum%100;
}
}
for(i=0;i<2;i++)
{
    for(j=0;j<2;j++)
    {
       a[i][j]=c[i][j];

    }
}

}
int main()
{
    int n;
    scanf("%d",&n);
int i,j,arr[size(n)],arr1[2][2]={{1,1},{1,0}},arr2[2][2]={{1,0},{0,1}};
binary(arr,n);
while(check_if_all_zeroes(arr,n))
{
    if(arr[size(n)-1]==1)
    {
        multiply(arr2,arr1);
    }
    multiply(arr1,arr1);
    shift_right_by_one(arr,n);

}
printf("%d\n",arr2[1][0]);

    }


