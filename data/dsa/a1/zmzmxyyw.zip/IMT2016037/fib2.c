#include<stdio.h>
int fib100(int n)
{
int i,arr[n+1];
arr[0]=0;
arr[1]=1;
for(i=2;i<n+1;i++)
{
arr[i]=(arr[i-1]+arr[i-2])%100;
}
//for(i=0;i<n+1;i++){printf("%d ",arr[i]);}
printf("%d\n",arr[n]);
return arr[n];
}

int main()
{

    int n;
    scanf("%d",&n);
    //printf("%d\n",fib100(n));
    fib100(n);

}
