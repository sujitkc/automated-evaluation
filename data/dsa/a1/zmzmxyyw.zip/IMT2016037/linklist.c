#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *next;
};


void insert(struct node **arrstart,int num)
{
	struct node *temp=(struct node*)malloc(sizeof(struct node)),*current;
	temp->data=num;
	temp->next=NULL;
	if(*arrstart==NULL)
	{
		*arrstart=temp;

	}
	else if(*arrstart!=NULL)
	{
		current=*arrstart;

		while(current->next!=NULL)
		{
			current=current->next;

		}

		current->next=temp;
			}
}
void delete(struct node **arrstart)
{
	struct node *current,*currentnext;
	current=*arrstart;
	currentnext=current->next;
	while(currentnext!=NULL)
	{



		if(current->data%2==0 && currentnext->data%2==0)
		{
			if(current->data>currentnext->data)
			{
								*arrstart=currentnext;
								free(current);

			}
			else
			{
				current->next=currentnext->next;
				free(currentnext);
			}
		}
		else if(current->data%2!=0 && currentnext->data%2!=0)
		{
		if(current->data<currentnext->data)
			{
				*arrstart=currentnext;
				free(current);
							}
			else
			{
				current->next=currentnext->next;
				free(currentnext);
			}
		}
			else if(current->data%2!=0 && currentnext->data%2==0)
			{
				*arrstart=currentnext;
				free(current);

			}
			else
			{
				current->next=currentnext->next;
				free(currentnext);

			}
		current=*arrstart;
	currentnext=current->next;

		}

}

int main()
{
	int i,j,num,arrchoice;
	struct node *arr[1000],*headptr;
	for(i=0;i<1000;i++)
	{
		arr[i]=NULL;


	}
	for(i=0;i<10000;i++)
	{
		num=rand()%10000;
		arrchoice=rand()%1000;
		insert(&arr[arrchoice],num);
	}
	for(i=0;i<1000;i++)
	{
		if(arr[i]!=NULL)
		{
		delete(arr+i);
		}


	}
	headptr=NULL;
	for(i=0;i<1000;i++)
	{
		if(arr[i]!=NULL)
		{
		insert(&headptr,arr[i]->data);
		}


	}
	delete(&headptr);
	printf("%d\n",headptr->data );


}
