import random
import timeit
# l[0]=added_list , l[1]=d , l[2]=s , l[3]=True/False
def check_right(d,s,i,l):
	l.pop()
	l.pop()
	l.pop()
	temp=[]
	a=d[len(d)-i]
	h=True
	
	for j in s:
		diff = abs(j-a)
		if diff in d:
			temp.append(diff)
			d.remove(diff)
		else:
			h=False
			break
			
	if not h:
		for k in temp:
				d.append(k)
		d.sort()
		l.append(d)
		l.append(s)
		l.append(h)
		return l
	s.append(a)
	s.sort()
	l[0].append(a)
	l.append(d)
	l.append(s)
	l.append(h)
	return l

def check_left(d,s,i,l):
	temp=[]
	a=abs(s[len(s)-1]-d[len(d)-i])
	if a not in d:
		l[3]=False
		return l
	l.pop()
	l.pop()
	l.pop()
	h=True
	
	for j in s:
		diff = abs(j-a)
		if diff in d:
			temp.append(diff)
			d.remove(diff)
		else:
			h=False
			break
			
	if not h:
		for k in temp:
				d.append(k)
		d.sort()
		l.append(d)
		l.append(s)
		l.append(h)
		return l
	s.append(a)
	s.sort()
	l[0].append(a)
	l.append(d)
	l.append(s)
	l.append(h)
	return l

def main_loop(l):
	i=1
	
	if not l[1]:
		exit()
		
	
	check_right(l[1],l[2],i,l)
	print "s =",l[2]
	if l[3]:
		main_loop(l)
	
	
	check_left(l[1],l[2],i,l)
	print "s =",l[2]
	if l[3]:
		main_loop(l)
	
	
	wrng=l[0][len(l[0])-1]
	l[2].remove(wrng)

	for i in l[2]:
		diff=abs(wrng-i)
		l[1].append(diff)

	l[1].sort()
	l[0].remove(wrng)
	print "s =",l[2]
	return l
		
d=[1,2,2,2,3,3,3,4,5,5,5,6,7,8,10]
'''c=[0]
for i in range(20):
	a = random.randrange(1,100)
	c.append(a)
c.sort()
print "c=",c

d=testing(c)'''
print "d =",d
s=[]
l=[]
added_list=[]

s.append(0)
s.append(d[len(d)-1])
d.remove(d[len(d)-1])

l.append(added_list)
l.append(d)
l.append(s)
l.append(True)

main_loop(l)

