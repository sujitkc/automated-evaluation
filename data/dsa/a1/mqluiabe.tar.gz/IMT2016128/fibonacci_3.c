#include <stdio.h>
void main(){
	int i,j=0,k=1,n,temp;
	scanf("%d",&n);
	printf("0\n1\n");
	for(i=0;i<n;i++){
		temp=k;
		k=(j+k)%100;
		j=temp;
		printf("%d\n",k);
	}
}