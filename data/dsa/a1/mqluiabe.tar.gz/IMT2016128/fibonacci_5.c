#include<stdio.h>

int fibo(int n){
    if(n==1){return 0;}
	int ar[2][2]={{1,1},{1,0}},p[2][2]={{1,1},{1,0}},i,a,b,c,d;
	for(i=2;i<n;i++){
		a=(ar[0][0]*p[0][0])+(ar[0][1]*p[1][0]);
	    b=(ar[0][0]*p[0][1])+(ar[0][1]*p[1][1]);
	    c=(ar[1][0]*p[0][0])+(ar[1][1]*p[1][0]);
	    d=(ar[1][0]*p[0][1])+(ar[1][1]*p[1][1]);
		ar[0][0]=a;ar[0][1]=b;ar[1][0]=c;ar[1][1]=d;
		}
		return ar[1][0];
	}

void main(){
    int n,x;
    printf("enter n\n");
    scanf("%d",&n);
    x=fibo(n);
    printf("%d\n",x);
	}