#include <stdio.h>

int main(){
	int ar[1000000],i=0,n,m,j;
	int a=1,b=1,temp;
	printf("enter n\n");
	scanf("%d",&n);
	printf("enter m\n");
	scanf("%d",&m);
	printf("0\n");
	printf("1\n");
	printf("1\n");
	n=n-3;
	while(b!=1 || a!=0){
		if(n==0)
				return 0;
		temp=b;
		b=(a+b)%m;
		a=temp;
		ar[i]=b;
		i++;
		n--;
		printf("%d\n",b);
	
		}
	printf("1\n");
	while(n!=0){
		if(j==i){
			printf("1\n");
			j=0;
		}
		printf("%d\n",ar[j]);
		j++;
		n--;
	}
	return 0;
}