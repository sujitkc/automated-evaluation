import random
import timeit

l=[]
for i in range(1000001):
	a = random.randrange(1,1000001)
	l.append(a)

def quick_sort(l,p,r):
	if p<r:
		i=random.randrange(p,r+1)
		temp=l[r]
		l[r]=l[i]
		l[i]=temp
		q=partition(l,p,r)
		quick_sort(l,p,q-1)
		quick_sort(l,q+1,r)
		return l

def partition(l,p,r):
	i=p-1
	for j in range(p,r):
		if l[j]<=l[r]:
			i +=1
			temp=l[i]
			l[i]=l[j]
			l[j]=temp
	temp=l[i+1]
	l[i+1]=l[r]
	l[r]=temp
	return i+1

#l=[2,8,7,1,3,5,6,4]
print quick_sort(l,0,len(l)-1)

