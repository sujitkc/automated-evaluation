#include <stdio.h>

int rec(int n){
	if(n-1==0){
		return 0;}
	else if(n-1==1){
		return 1;
	}
	else{
		return (rec(n-1)+rec(n-2))%100;
	}
}

void main(){
	int i,n;
	scanf("%d",&n);
	printf("%d\n",rec(n));
}