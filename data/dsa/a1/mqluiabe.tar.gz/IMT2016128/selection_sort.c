#include <stdio.h>
void main(){
	int i=0,j=0,t,m=0,n=10;
	int a[10]={1,5,2,7,8,9,3,0,4,6};
	for(j=0;i<10;i++){
		m=0;
		for(i=1;j<=n-j;j++){
			if(a[i]>a[m])
				m=i;
			if(n-1-j>m){
				t=a[m];
				a[m]=a[n-1-j];
				a[n-1-j]=t;
			}
		}
	}
	for (i=0;i<10;i++)
	{
		printf("%d\n",a[i]);
	}
}