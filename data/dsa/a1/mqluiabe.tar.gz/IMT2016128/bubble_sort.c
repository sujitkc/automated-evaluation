#include <stdio.h>

int *bubble_sort(int *a){
	int i,j,t=0;
	for(i=0;i<10;i++){
		for(j=0;j<10-i;j++){
			if(a[j+1]<a[j]){
				t=a[j+1];
				a[j+1]=a[j];
				a[j]=t;
			}
		}
	}
	return a;
}

void main(){
	int i;
	int a[10]={1,5,2,7,8,9,3,0,4,6};
	int *g=bubble_sort(a);
	for (i=0;i<10;i++)
	{
		printf("%d\n",g[i]);
	}
}