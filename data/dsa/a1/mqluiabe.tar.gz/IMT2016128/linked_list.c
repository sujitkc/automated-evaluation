#include <stdio.h>
#include <stdlib.h>

struct node{
    int s;
    struct node *link;
};

void main(){
    struct node *arr[10000];
    int i;
    for(i=0;i<10000;i++)
        arr[i]=NULL;
    struct node *p,*temp,*l,*o;
	int a=100000,x,y,c;
    while (a-->0){
        x=rand()%10000;
        y=rand()%500;
        while(y==0)
            y=rand()%500;
        if(arr[x]==NULL){
            arr[x]=malloc(sizeof(struct node));
            arr[x]->s=y;
            arr[x]->link=NULL;
    	    }
        else{
            temp=malloc(sizeof(struct node));
            temp->s=y;
            temp->link=arr[x];
            arr[x]=temp;
        	}
	}
	for(i=0;i<10000;i++){
        if(arr[i]!=NULL){
            p=arr[i];
            l=arr[i];
            l=arr[i];
            if(p!=NULL){
                while(p!=NULL && p->link!=NULL ){
                    if(p->s%2==0 && (p->link)->s%2==0){
                        if((p->s)>((p->link)->s)){
                            if(p==arr[i])
                                arr[i]=p->link;
                            else{
                                temp=p;
                                p=p->link;
                                o->link=p;
                                free(temp);
                            	}
                        	}
                        else
                            p->link=(p->link)->link;

                    	}
					else if(p->s%2==1 && (p->link)->s%2==1){
                        if(p->s>(p->link)->s)
							p->link=(p->link)->link;
                        else{
                            if(p==arr[i])
                                arr[i]=p->link;
                            else{
                                temp=p;
                                p=p->link;
                                o->link=p;
                                free(temp);
                            	}
                        	}
						}
                    else{
						if(p->s%2==1 && (p->link)->s%2==0){
                            if(p==arr[i])
                                arr[i]=p->link;
                            else{
                                temp=p;
                                p=p->link;
                                o->link=p;
                                free(temp);
                            	}

                        	}
                        else if(p->s%2==0 && (p->link)->s%2==1)
							p->link=(p->link)->link;
	                    }
                    o=p;
                    if(p->link!=0)
                        p=p->link;
                    if(p->link==NULL){
                        l=arr[i];
                        c=0;
                        while(l!=NULL){
                            c++;
                            l=l->link;
                        		}
                        if(c>1)
                            p=arr[i];
                    	}
					}
				}
       		}
    	}
    int j;
    c=0;
    for(i=0;i<10000;i++){
        if (arr[i]!=NULL)
            c++;
    }
    while (c>=1){
        if (c!=1){
            for(i=0;i<9999;i++){
                if(arr[i]!=NULL){
                    for(j=i+1;j<10000;j++){
                        if (arr[j]!=NULL){
                            if(arr[j]->s%2==0 && arr[i]->s%2==0){
                                if(arr[j]->s>arr[i]->s)
                                    arr[j]=NULL;
                                else
                                    arr[i]=NULL;
                            	}
                            else if(arr[j]->s%2==1 && arr[i]->s%2==1){
                                if(arr[j]->s>arr[i]->s)
                                    arr[i]=NULL;
                                else
                                    arr[j]=NULL;
                            	}
                            else{
                                if(arr[j]->s%2==1 && arr[i]->s%2==0)
                                    arr[j]=NULL;
                                else
                                    arr[i]=NULL;
                            	}
                            c--;
                            i=j+1;
                            break;
                        	}
                    	}
                	}
            	}
        	}
        else{
            for(i=0;i<10000;i++){
                if(arr[i]!=NULL)
                    printf("answer is %d\n",arr[i]->s);
            	}
            c--;
			}
		}
	}