import random
import timeit


l=[]
for i in range(1000001):
	a = random.randrange(1,1000001)
	l.append(a)

def sort(l):
	if l[0]<=l[1]:
		return l
	else:
		temp=l[1]
		l[1]=l[0]
		l[0]=temp
		return l

def divide(l):
	if len(l)==1:
		return l
	if len(l)==2:
		l=sort(l)
		return l
	a=len(l)/2
	l1=[]
	l2=[]		
	for i in range(a):
		l1.append(l[i])
	for i in range(a,len(l)):			
		l2.append(l[i])
	l1=divide(l1)
	l2=divide(l2)
	l=merge(l1,l2)
	return l

def merge(l1,l2):
	i=0
	j=0
	l=[]
	while(i<len(l1) and j<len(l2)):
		if l1[i]<= l2[j]:
			l.append(l1[i])
			i +=1
		else:
			l.append(l2[j])
			j +=1
	if i==len(l1):
		while(j<len(l2)):
			l.append(l2[j])
			j +=1
	else:
		while(i<len(l1)):
			l.append(l1[i])
			i +=1
	return l

print divide(l)

