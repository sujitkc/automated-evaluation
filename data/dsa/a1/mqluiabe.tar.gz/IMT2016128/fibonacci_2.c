#include <stdio.h>
void main(){
	int i,n;
	scanf("%d",&n);
	int a[n];
	a[0]=0;
	a[1]=1;
	printf("0\n1\n");
	for(i=1;i<n-1;i++){
		a[i+1]=(a[i]+a[i-1])%100;
		printf("%d\n",a[i+1]);
	}
}