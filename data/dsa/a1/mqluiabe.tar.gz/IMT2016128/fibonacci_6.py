import random
def func(a,b):
	l=[[0 for row in range(len(a))] for col in range(len(b[0]))]
	for i in range(len(a)):
		for j in range(len(b[0])):
			for k in range(len(b)):
				l[i][j] += a[i][k]*b[k][j]
	for i in range(2):
		for j in range(2):
			l[i][j]=l[i][j]%100
	return l

def power(x,n):
	y=[[1,0],[0,1]]
	for i in range(len(n)):
		if i==len(n)-1:
			x=func(x,y)
		elif n[i]==1:
			x=func(x,x)
		elif n[i]==0:
			x=func(x,func(x,x))
	return x

g=[[1,1],[1,0]]
n=[]
for i in range(1000000):
	n.append(random.randrange(0,2))
p=power(g,n)
print p[1][0] 