#include<stdio.h>
#include<conio.h>

void MergeSort(int a[],int temp[],int left,int right)
{
	int mid;
	if(right>left)
	{
		mid=(left+right)/2;
		MergeSort(a,temp,left,mid);
		MergeSort(a,temp,mid+1,right);
		Merge(a,temp,left,mid+1,right);
	}
}

void Merge(int a[],int temp[],int left,int mid,int right)
{
	int left_end,temp_pos,i,j;
	left_end=mid-1;
	int size=right-left+1;
	temp_pos=left;
	while(left<=left_end && mid<=right)
	{
		if(a[left]>a[mid])
		{
			temp[temp_pos]=a[mid];
			temp_pos+=1;
			mid+=1;
		}
		else
		{
			temp[temp_pos]=a[left];
			temp_pos+=1;
			left+=1;
		}
	}
	while(left<=left_end)
	{
		temp[temp_pos]=a[left];
		temp_pos+=1;
		left+=1;	
	}
	while(mid<=right)
	{
		temp[temp_pos]=a[mid];
		temp_pos+=1;
		mid+=1;
	}
	for(i=0;i<size;i++)
	{
		a[right]=temp[right];
		right-=1;
	}
}

int main()
{
	int n,i,j,p;
	scanf("%d",&n);
	int a[n];
	int b[n];
	for(j=0;j<n;j++)
	{
		b[j]=0;
	}
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	MergeSort(a,b,0,n-1);
	for(p=0;p<n;p++)
	{
		printf("%d",a[p]);
	}
	return 0;
}
