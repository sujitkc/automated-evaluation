#include<stdio.h>

void MatrixMultiply(int A[2][2],int B[2][2])
{int C[2][2]={{0,0},{0,0}};
int i,j,k,p,o;
 for(i=0;i<2;i++)
   for(j=0;j<2;j++){
    int sum=0;
    for(k=0;k<2;k++)
    sum+=A[i][k]*B[k][j];
    C[i][j]=sum%100;
}
 for(p=0;p<2;p++)
  for(o=0;o<2;o++)
   A[p][o]=C[p][o];
}

void Power(int x[2][2],unsigned long int n)
{int y[2][2]={{1,0},{0,1}};
int i,j;
 while(n>0)
 {if(n%2==1)MatrixMultiply(y,x);
  MatrixMultiply(x,x);
  n=n/2;
 }
 for(i=0;i<2;i++)
  for(j=0;j<2;j++)
   x[i][j]=y[i][j];
}

int main()
{int i,j;
 int A[2][2]={{1,1},{1,0}};
 Power(A,1000);
 printf("\nF(n)=%d\n",A[1][0]);
 getch();
}
