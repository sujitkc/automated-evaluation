def A(X,y):
    L=[]
    for i in X:
        L.append(i)
    L.append(y)
    return L

def D1(X,y):
    D=[]
    for i in X:
        D.append(abs(i-y))
    return D

def isS(L,D):
    check=True
    T=[]
    for i in L:
        T.append(i)
    for i in D:
        if i in T:
            T.remove(i)
        else:
            check=False
            break
    return check

def Remove(L,D):
    for i in D:
        L.remove(i)
    return L

def DP(L,X,width):
    width=max(L)
    L.remove(width)
    X=[0,width]
    Place(L,X,width)

def Place(L,X,width):
    if len(L)==0:
        print X
    else:
        y=max(L)
        if isS(L,D1(X,y)):
            D=D1(X,y)
            X=A(X,y)
            L=Remove(L,D)
            Place(L,X,width)
            X.remove(y)
            for i in D:
             L.append(i)

        if isS(L,D1(X,width-y)):
            D=D1(X,width-y)
            X=A(X,width-y)
            Remove(L,D)
            Place(L,X,width)
            X.remove(width-y)
            for i in D:
             L.append(i)

X=[]
L=[2,5,6,8,9,12,3,4,6,7,10,1,3,4,7,2,3,6,1,4,3]
width=0
DP(L,X,width)
print
