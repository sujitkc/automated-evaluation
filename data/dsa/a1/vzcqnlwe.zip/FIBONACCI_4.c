#include<stdio.h>
int Fibonacci(int n,int m)
{
int a=0;
int b=1;
int c,i;
for(i=2;i<=n;i++)
{
c=(a+b)%m;
a=b;
b=c;
}
return c;
}

int Period(int m)
{
int a=0;
int b=1;
int c=1;
int i=0;
while(1)
{
i++;
c=(a+b)%m;
a=b;
b=c;
if(a==0 && b==1)
return i;
}
}

int C2I(char n[],int period)
{
int i=0;
int num=0;
while(n[i]!='\0')
{
num=(num*10+n[i]-'0')%period;
i++;
}
return num;
}

int ANS(char n[],int m)
{
int number=C2I(n,Period(m));
return Fibonacci(number,m);
}

void main()
{
printf("%d",ANS("199",100));
getch();
}
