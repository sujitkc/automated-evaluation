#include<stdio.h>
#include<conio.h>

int main()
{
	int n,i,j,temp,k,l;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(j=1;j<n;j++)
	{
		temp=a[j];
		k=j-1;
		while(k>=0&&a[k]>temp)
		{
			a[k+1]=a[k];
			k--;
		}
	a[k+1]=temp;
    }
	for(l=0;l<n;l++)
	{
		printf("%d ",a[l]);
	}
	printf("\n");
	return 0;
}
