#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

void swap(int *a,int *b)
{
	int temp=*a;
	*a=*b;
	*b=temp;
}

int partition(int a[],int low,int high)
{
	int i=low-1;
	int j;
	int pivotId=low+(rand()%(high-low+1));
	swap(&a[pivotId],&a[high]);
	pivotId=high;
	for(j=low;j<high;j++)
	{
		if(a[j]<=a[pivotId])
		{
			i++;
			swap(&a[i],&a[j]);
		}
	}
	swap(&a[i+1],&a[high]);
	return (i+1);
}

void quicksort(int a[],int low,int high)
{
	int pi;
	if(low<high)
	{
		pi=partition(a,low,high);
		quicksort(a,low,pi-1);
		quicksort(a,pi+1,high);
	}
}

int main()
{
	int n,i,j;
	int a[n];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	quicksort(a,0,n-1);
	for(j=0;j<n;j++)
	{
		printf("%d",a[j]);
	}
	return 0;
}
