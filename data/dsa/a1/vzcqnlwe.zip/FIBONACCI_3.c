#include<stdio.h>
int Fibonacci(unsigned long int n)
{
int a=0;
unsigned long int i;
int b=1;
unsigned long int c;
for(i=2;i<=n;i++)
{
c=(a+b)%100;
a=b;
b=c;
}
return c;
}
void main()
{
printf("%d",Fibonacci(2342));
getch();
}
