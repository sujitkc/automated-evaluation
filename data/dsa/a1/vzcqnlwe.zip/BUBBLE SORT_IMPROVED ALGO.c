#include<stdio.h>
#include<conio.h>

int main()
{
	int n,flag=1,i;
	int temp,p,q,k;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(p=0;p<n-1&&flag;p++)
	{
		flag=0;
		for(q=0;q<n-p-1;q++)
		{
			if(a[q]>a[q+1])
			{
			temp = a[q];
			a[q] = a[q+1];
			a[q+1] = temp;
			flag=1;
			}
		}
		if (flag==0)
		{
			for(k=0;k<n;k++)
			{
				printf("%d",a[k]);
			}
			break;
		}
	}
	return 0;
}
