#include<stdio.h>
#include<conio.h>

int main()
{
	int n,a[n],i,j,p,q,e;
	int temp;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(p=0;p<n-1;p++)
	{
		for(q=0;q<n-p-1;q++)
		{
			if(a[q]>a[q+1])
			{
				temp = a[q];
				a[q] = a[q+1];
				a[q+1] = temp;
			}
		}
	}
	for(e=0;e<n;e++)
	{
		printf("%d",a[e]);
	}
	return 0;
}
