#include<stdio.h>
#include<conio.h>
 int main()
 {
 	int n,i,j,min;
 	scanf("%d",&n);
 	int a[n];
 	int p,q,temp;
 	for(q=0;q<n;q++)
 	{
 	scanf("%d",&a[q]);	
	}
 	for(i=0;i<n-1;i++)
 	{
 	  min=i;
	  for(j=i+1;j<n;j++)
	  {
	    if(a[j]<a[min])
		 { 
		    min=j;
	     }
      }
      temp=a[min];
      a[min]=a[i];
      a[i]=temp;
	}
	for(p=0;p<n;p++)
	{
		printf("%d",a[p]);
	}
	return 0;
 }
