#include<stdio.h>
#include<stdlib.h>


void merge(int n,int arr[n],int i,int k,int j)
{
	int a=0,p=i,q=k+1,z,b[n];
	while(p<=k&&q<=j)
	{

	if(arr[p]<arr[q])
		{
			b[a]=arr[p];
			a++;
			p++;
		}
	else
		{
			b[a]=arr[q];
			a++;
			q++;
		}


	}

	while(p==k+1&&q<=j)
		{
			b[a]=arr[q];
			a++;
			q++;
		}
	while(q==j+1&&p<=k)
		{
			b[a]=arr[p];
			a++;
			p++;
		}
		z=0;
	while(z!=a)
		{
			arr[i]=b[z];
			i++;
			z++;
		}
}
void swap(int *a,int *b)
        {
            int temp;
            temp=*a;
            *a=*b;
            *b=temp;
         }


int ms(int n,int arr[n],int i,int j)
{

	int k;
	int z=j-1;
	k=rand()%z+i;
	if(i==j)
		{
			return arr[n];
		}
	if(i+1==j)
		{
			if(arr[i]<=arr[j])
				{
					return arr[n];
				}
			else
				{
				 swap(&arr[i],&arr[j]);
				 return arr[n];
				}
		}

	ms(n,arr,i,k);
	ms(n,arr,k+1,j);
	merge(n,arr,i,k,j);
	return arr[n];
	}
int main()
{
	int i,n;
	n=10;
	
	int arr[10]={9,8,3,4,6,1,9,5,7,0};
	ms(10,arr,0,9);	
	
	for(i=0;i<n;i++)
	{
		printf("%d\n",arr[i]);
	}

	return 0;
}






















