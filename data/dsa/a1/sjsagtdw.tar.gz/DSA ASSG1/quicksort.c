#include <stdio.h>
#include <stdlib.h>
void swap(int *m,int *n)
{
	int temp;
	temp=*m;
	*m=*n;
	*n=temp;
}
int divide(int n,int arr[],int left,int right,int pivot)
{
	int m;
	int a=left;
	int b=right;
	int p=pivot;
	m=arr[p];
	while(a<b)
	{
		while(arr[a]<m)
		{
			a++;
		}
		while(arr[b]>m)
		{
			b--;
		}
		swap(&arr[a],&arr[b]);
	}
	if(a==right)
		{
			return a-1;
		}
	return a;
}
void sort(int n,int arr[],int left,int right)
{
	int pivot;
	if(left==right)
	{
		return;
	}
	int z=right-left;
	pivot=(rand()%z)+left;
	//divide(n,arr,left,right,pivot);
	int d=divide(n,arr,left,right,pivot);
	sort(n,arr,left,d);
	sort(n,arr,d+1,right);
	

}
int main()
{
	int i,n;
	n=1000000	;
	int arr[n];
	for(i=0;i<n;i++)
	{
		arr[i]=n-i;
	}
	sort(n,arr,0,n-1);
}