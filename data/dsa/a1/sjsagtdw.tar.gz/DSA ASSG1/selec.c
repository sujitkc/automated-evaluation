#include<stdio.h>
void swap(int *m,int *n)
{
	int temp;
	temp=*m;
	*m=*n;
	*n=temp;
}
	void selec(int n,int arr[])
{
	int i, m;
	while(n>0)
	{
		m=0;
	for(i=0;i<n;i++)
	{
		
		if(arr[m]<arr[i])
		{
			m=i;
			
		}
		
		
	}
	swap(&arr[m],&arr[n-1]);
	n--;
	}
}
int main()
{
	int i,n;
	n=10;
	int arr[10];
	for(i=0;i<n;i++)
	{
		arr[i]=6;
	}
	selec(10,arr);
for(i=0;i<n;i++)
	{
		printf("%d",arr[i]);
	}

	
	return 0;
}
