#include<stdio.h>
int  fib(int n)
{
	int arr[n+1],i;
	
	arr[0]=0;
	arr[1]=1;
	for(i=2;i<n+1;i++)
	{
		arr[i]=arr[i-1]+arr[i-2];
	}
	if(n==0)
	{
		return 0; 
	}
	else if(n==1)
	{
		return 1;
	}
	else
	{
		return (arr[n])%100;
	}

	

}
int main()
{
	
	printf("%d\n",fib(1000000) );
	
}