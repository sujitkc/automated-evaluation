#include <stdio.h>
int *pdt(int a[],int b[])
{
	int c[4],i;
	for(i=0;i<4;i++)
	{
		c[i]=0;
	}
	c[0]=a[0]*b[0]+a[1]*b[2];
	c[1]=a[0]*b[1]+a[1]*b[3];
	c[2]=a[2]*b[0]+a[3]*b[2];
	c[3]=a[2]*b[1]+a[3]*b[3];
	for(i=0;i<4;i++)
	{
		a[i]=c[i];
	}
	return a;
}
int main()
{
	int i,k,n,z,t;
	scanf("%d",&n);
	k=0;
	int m=n;
	while(m!=0)
	{
		m=m/2;
		k=k+1;
	}
	
	int arr[k],arr1[k];
	for(i=0;i<k;i++)
	{
		arr[i]=0;
		arr1[i]=0;
	}
	int p=0;
	while(n!=0)
	{
		arr[p]=n%2;
		arr1[p]=n%2;
		n=n/2;
		p++;
	}
	for(i=0;i<k;i++)
	{
		arr[i]=arr1[k-1-i];
	}
	int u[4]={1,1,1,0};
	int v[4]={1,0,0,1};
	for(i=0;i<k;i++)
	{
		if(arr[k-1-i]==1)
		{
			pdt(v,u);
			pdt(u,u);
		}
		else if(arr[k-1-i]==0)
		{
			pdt(u,u);
		}
	}
	printf("%d\n",v[2]%100 );
	
}