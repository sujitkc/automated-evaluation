#include<stdio.h>
void swap(int *m,int *n)
{
	int temp;
	temp=*m;
	*m=*n;
	*n=temp;
}
void bubblesort(int n,int arr[n])
{
	int j;
	

	while(n>0)
	{


	for(j=0;j<n-1;j++)
	{
		if(arr[j]>arr[j+1])
		{
			swap(&arr[j],&arr[j+1]);
		}
	}
	n--;
}

}
int main()
{
	int i;
	int arr[8]={1,5,9,6,42,6,3,2};
	bubblesort(8,arr);
	for(i=0;i<8;i++)
	{
		printf("%d\n",arr[i]);
	}
	return 0;
}
