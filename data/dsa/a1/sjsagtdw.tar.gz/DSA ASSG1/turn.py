def check(l1,l3):
	l5=[]
	l6=l1*1
	
	for i in range(0,len(l3)):
		t=l1[len(l1)-1]-l3[i]
		if t>0:
			t=t
		else:
			t=-t
		l5.append(t)
	
	for i in l5:
		if i not in l6:
			
			return 0
		else:
			l6.remove(i)
		
	return 1
def check1(l1,l3):
	l5=[]
	l6=l1*1
	
	for i in range(0,len(l3)):
		k=len(l1)
		t=(l3[1]-l1[k-1])-l3[i]
		if t>0:
			t=t
		else:
			t=-t
		l5.append(t)
		 
	
	for i in l5:
		if i not in l6:
			
			return 0
		else:
			l6.remove(i)
			

	return 1

l1=[1,2,3,4,5,6,7,8,10,11,13,14,15,17,18]
n=len(l1)
p=l1[n-1]
l3=[]
l3.append(0)
l3.append(p)
l1.remove(p)
def rec(l1,l3):
		if(check(l1,l3)==1):
			l3.append(l1[len(l1)-1])
			u=l1[len(l1)-1]
			for i in range(0,len(l3)-1):
				r=u-l3[i]
				if r>0:
					r=r
				else:
					r=-r
				if r in l1:
					l1.remove(r)
			
		elif(check(l1,l3)==0):
			if(check1(l1,l3)==1):
				l3.append(l3[1]-l1[len(l1)-1])
				z=l1[len(l1)-1]
				for i in range(0,len(l3)-1):
					r=l3[1]-z-l3[i]
					if r>0:
						r=r
					else:
						r=-r
					if r in l1:
						l1.remove(r)
					
			elif(check1(l1,l3)==0):
				while(check(l1,l3)!=1 and check1(l1,l3)!=1):
					j=l3.pop()
					l1.append(j)
					for i in range(1,len(l3)):
						l=j-l3[i]
						 	

						if l>0:
							l=l
						else:
							l=-l
						l1.insert(0,l)
					l3.append(l3[1]-j)
					q=l1[len(l1)-1]
					for i in range(0,len(l3)-1):
						r=l3[1]-q-l3[i]
						if r>0:
							r=r
						else:
							r=-r
						if r in l1:
							l1.remove(r)
		
				

while(len(l1)!=0):
	rec(l1,l3)

print l3
















