#include<stdio.h>
int fib(int n)
{
	int a,b,i,c,num=0;
	a=0;
	b=1;
	
	while(1)
	{
	num++;
	c=(a+b)%n;
	a=b;
	b=c;
	if(a==0 && b==1)
	{
		break;
	}
	}
	return num;
}

	

	


int main()
{
	int n,k;
	scanf("%d",&n);
	k=fib(n);
	printf("%d\n",k);
	
}