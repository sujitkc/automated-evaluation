#include <stdio.h>
#include <stdlib.h>
struct node
{
	int key;
	struct node *next;
	
};

struct node* insert(struct node *head,int n)
{
	struct node *newnode;
	struct node *curr;
	curr=head;
	newnode =(struct  node*) malloc(sizeof(struct node));
	newnode->key=n;
	if(head==NULL)
	{
		
		newnode->next=NULL;
		return newnode;
	}
	else
	{
		while(curr->next!=NULL)
		{
			curr=curr->next;

		}
		curr->next=newnode;
		newnode->next=NULL;
	}
	return head;
}





int simplify(struct node *head)
{

	
		struct node *curr,*hd;
		
		curr=head->next;
		hd=head;
	
		while(curr!=NULL)
		{
			
			if(hd->key%2==1 && curr->key%2==1)
			{
				if((hd->key)>(curr->key))
				{

					curr=curr->next;
					hd->next=curr;
				}
				else
				{
					hd=hd->next;
					curr=curr->next;
				}
			}
			else if(hd->key%2==0 && curr->key%2==0)
			{
				if((hd->key)>(curr->key))
				{
					hd=hd->next;
					curr=curr->next;
					

					
				}
				else
				{
					curr=curr->next;
					hd->next=curr;
				}
			}
			else if(hd->key%2==1 && curr->key%2==0)
			{
				hd=hd->next;
				curr=curr->next;
					
			}
			else if(hd->key%2==0 && curr->key%2==1)
			{
				curr=curr->next;
				hd->next=curr;
			}
		}
		return hd->key;
}
int main()
{
int i;
struct node *arr[1000];
struct node *nh;
nh=NULL;
for(i=0;i<1000;i++)
{
	arr[i]=NULL;
}

for(i=0;i<10000;i++)
{
	int k;
	k=rand()%1000;
	arr[k]=insert(arr[k],rand()%10);
} 
for(i=0;i<1000;i++)
{
	if(arr[i]!=NULL)
	{
	int m=simplify(arr[i]);
	nh=insert(nh,m);
	}
}

int d=simplify(nh);
printf("%d\n",d);
}
