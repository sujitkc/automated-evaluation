#include<stdio.h>
int fib(int n)
{
	int a,b,i,c;
	
	a=0;
	b=1;
	for(i=0;i<n-1;i++)
	{
	c=a+b;
	a=b;
	b=c;
	}	
	if(n==0)
	{
		return 0;

	}
	else if(n==1)
	{
		return 1;
	}
	else
	{
		return c%100;
	}
	

	

}
int main()
{
	int n;
	scanf("%d",&n);
	
	printf("%d\n",fib(n) );
	
}