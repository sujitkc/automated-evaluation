#include <stdio.h>
int main()
{
	int i,t,k,a[100];
	printf("enter no.s");
	for(i=0;i<=4;i++)
	{
		scanf("%d",&a[i]);
	}

	for(i=0;i<=4;i++)
	{
		for(k=i;k<4;k++)
		{
			if(a[i]>a[k+1])
			{
				t=a[k+1];
				a[k+1]=a[i];
				a[i]=t;
			}
		}
	}
	for(i=0;i<=4;i++)
	{
		printf("%d\t",a[i]);
	}
	return 0;
}