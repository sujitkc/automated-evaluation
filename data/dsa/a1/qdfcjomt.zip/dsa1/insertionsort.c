#include <stdio.h>
int main()
{
	int i,n=5,a[1000],t;
	printf("enter no.");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=1;i<=n-1;i++)
	{
		if(a[i-1]>a[i])
		{
			while(i>=1)
			{
				if(a[i-1]>a[i])
				{
					t=a[i];
					a[i]=a[i-1];
					a[i-1]=t;
					i--;
				}
				else
				{
					break;
				}
			}
		}
	}
	for(i=0;i<n;i++)
	{
		printf("%d\t",a[i]);
	}
	return 0;
}