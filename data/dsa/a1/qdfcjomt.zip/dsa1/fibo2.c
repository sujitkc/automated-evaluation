#include <stdio.h>
#include <time.h>
int main()
{	
	long long int a,b,c,n,i;
	scanf("%lli",&n);
	clock_t tic = clock();
	a=0;
	b=1;
	for(i=2;i<=n;i++)
	{
		c=(a+b)%100;
		a=b;
		b=c;
	}
	clock_t toc = clock();
	printf("%lli\n",c);
	printf("Elapsed: %f seconds\n", (double)(toc -tic) / CLOCKS_PER_SEC);
	return 0;
}