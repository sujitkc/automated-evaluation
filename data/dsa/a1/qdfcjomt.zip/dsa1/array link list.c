#include <stdio.h>
#include <stdlib.h>
#include <time.h>
struct node 
{
	int val;
	struct node *next;
};
void insert(struct node **a)
{
	int j,x;
	struct node *temp,*r;
	temp=*a;
		x=rand()%20+1;
		if(*a==NULL)/*list is empty, create first node*/
		{
			temp=malloc(sizeof(struct node));
			temp->val=x;
			temp->next=NULL;
			*a=temp;
		}
		else
		{
		while(temp->next!=NULL)/*add a new node at last*/
			{
			temp=temp->next;                                  /* temp function always start from the beginning*/

			}
			temp->next=malloc(sizeof(struct node));
			temp->next->val=x;
			temp->next->next=NULL;
		}
	//}
	
}
void display(struct node *a)
{
	while(a!=NULL)
	{
		printf("%d\t",a->val);
		a=a->next;
	}
	printf("\n");
}
void delete(struct node **a)
{
	struct node *temp,*r;
	temp=*a;
	int i,c=0;
	if(temp!=NULL)
	{
		while((*a)->next!=NULL)
		{
			temp=*a;
			while(temp->next!=NULL)
			{

				if(temp->val%2==0 && temp->next->val%2==0)  // if both are even bigger one is deleted
				{
					if(temp->val>=temp->next->val)
					{
						if(temp==*(a))
						{

							r=temp->next;
							*a=r;
							free(temp);
							temp=r->next;
							if(temp==NULL)
							{
								break;
							}
						}
						else
						{
							r->next=temp->next;				
							free(temp);
							r=r->next;
							if(r!=NULL || r->next!=NULL)
							{
								temp=r->next;
							}
							if(temp==NULL)
							{
								break;
							}

						}
					}
					else
					{
						if(temp==(*a))
						{
							r=temp;
							temp=temp->next;
							r->next=temp->next;
							*a=r;
							free(temp);
							if(r!=NULL || r->next!=NULL)
							{
								temp=r->next;
							}
							if(temp==NULL)
							{
								break;
							}
						}
						else
						{
							r=temp;
							temp=temp->next;
							r->next=temp->next;
							free(temp);	
							if(r!=NULL || r->next!=NULL)
							{
								temp=r->next;
							}
							if(temp==NULL)
							{
								break;
							}
						}	
					}
				}
				else if(temp->val%2!=0 && temp->next->val%2!=0) // if both are odd smaller one is deleted
				{
					if(temp->val<=temp->next->val)
					{
						if(temp==*(a))
						{

							r=temp->next;
							*a=r;
							free(temp);
							temp=r->next;
							if(temp==NULL)
							{
								break;
							}
						}
						else
						{
							r->next=temp->next;				
							free(temp);
							r=r->next;
							if(r!=NULL || r->next!=NULL)
							{
								temp=r->next;
							}
							if(temp==NULL)
							{
								break;
							}

						}
					}
					else
					{
						if(temp==(*a))
						{
							r=temp;
							temp=temp->next;
							r->next=temp->next;
							*a=r;
							free(temp);
							if(r!=NULL || r->next!=NULL)
							{
								temp=r->next;
							}
							if(temp==NULL)
							{
								break;
							}
						}
						else
						{
							r=temp;
							temp=temp->next;
							r->next=temp->next;
							free(temp);	
							if(r!=NULL || r->next!=NULL)
							{
								temp=r->next;
							}
							if(temp==NULL)
							{
								break;
							}
						}	

					}
				}
				else if(temp->val%2==0 && temp->next->val%2!=0 ||temp->val%2!=0 && temp->next->val%2==0 ) //  if one is even and other is odd smaller one is deleted
				{
					if(temp->val<=temp->next->val)
					{
						if(temp==*(a))
						{

							r=temp->next;
							*a=r;
							free(temp);
							temp=r->next;
							if(temp==NULL)
							{
								break;
							}
						}
						else
						{
							r->next=temp->next;				
							free(temp);
							r=r->next;
							if(r!=NULL || r->next!=NULL)
							{
								temp=r->next;
							}
							if(temp==NULL)
							{
								break;
							}

						}
					}
					else
					{
						if(temp==(*a))
						{
							r=temp;
							temp=temp->next;
							r->next=temp->next;
							*a=r;
							free(temp);
							if(r!=NULL || r->next!=NULL)
							{
								temp=r->next;
							}
							if(temp==NULL)
							{
								break;
							}
						}
						else
						{
							r=temp;
							temp=temp->next;
							r->next=temp->next;
							free(temp);	
							if(r!=NULL || r->next!=NULL)
							{
								temp=r->next;
							}
							if(temp==NULL)
							{
								break;
							}
						}	
					}
				}
			}
		}
	}
	display(*a);

}
int main()
{	
	long long int i,j,x,n,m;
	printf("enter no. of linked list of array");
	scanf("%lli",&n);
	struct node *A[n];
	printf("enter total no. of nodes in array of linked lists");
	scanf("%lli",&m);
	srand(time(NULL));
	for(i=0;i<n;i++)
	{
		A[i]=NULL;
	}
	for(i=0;i<m;i++)
	{
		j=rand()%n;
		insert(&A[j]);
	}
	for(i=0;i<n;i++)
	{
		display(A[i]);
	}
	printf("if both even bigger number is deleted, if both are odd smaller number is deleted,if one is even and other is odd then smaller one is deleted\n");
	printf("display deleted list\n");
	for(i=0;i<n;i++)
	{
		delete(&A[i]);
	}
	long long int k=0;
	j=1;
	while(A[k]==NULL)
	{
		k++;
		j++;
	}
	while(A[j]==NULL)
	{
		j++;
	}
	while(j<10)
	{
		if(A[k]->val%2==0 && A[j]->val%2==0)
		{
			if(A[k]->val>A[j]->val)
			{
				A[k]=NULL;
				k=j;
				j++;
			}
		
			else
			{
				A[j]=NULL;
				j++;
			}
		}
		else if(A[k]->val%2!=0 && A[j]->val%2!=0)
		{
			if(A[k]->val<A[j]->val)
			{
				A[k]=NULL;
				k=j;
				j++;

			}
		
			else
			{
				A[j]=NULL;
				j++;
			}
		}
		else if(A[k]->val%2!=0 && A[j]->val%2==0 || A[k]->val%2==0 && A[j]->val%2!=0)
		{
			if(A[k]->val>A[j]->val)
			{
				A[k]=NULL;
				k=j;
				j++;
			}
		
			else
			{
				A[j]=NULL;
				j++;
			}
		}
		while(A[j]==NULL)
		{
			j++;
		}
	}
	printf("answer of turn pike reconstruction =%d",A[k]->val);
	return 0;

}