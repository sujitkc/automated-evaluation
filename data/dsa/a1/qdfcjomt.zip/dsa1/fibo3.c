#include <stdio.h>
#include <time.h>
int main()
{
	long long int f[100000],n,m;
	scanf("%lli",&m);
	f[0]=0;
	f[1]=1;
	n=1;
	while(1)
	{
		n++;
		f[n]=(f[n-1]+f[n-2])%m;
		if(f[n]==0)
		{
			n=n+1;
			f[n]=(f[n-1]+f[n-2])%m;
			if(f[n]==1)
			{
				break;
			}
			n=n-1;
		}
	}
	n=n-1;
	printf("n at which the fibo series repeat");
	printf("%lli",n);
	return 0;
}

