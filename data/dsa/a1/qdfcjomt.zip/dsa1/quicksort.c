#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int a[10]={1,3,9,8,2,7,5};
void swap(int *a,int *b)
{
	int t;
	t=*a;
	*a=*b;
	*b=t;
}
int partition(int a[],int i,int j)
{
	int k,t,index=i,r;
	int part=a[j];
	for(k=i;k<=j-1;k++)
	{
		if(a[k]<=part)
		{
			swap(&a[index],&a[k]);
			index++;
		}
	}
	swap(&a[index],&a[j]);
	for(r=0;r<7;r++)
	{
		printf("%d\t",a[r]);
	}
	printf("\n");
	return index;

}
void randpivot(int a[],int i,int j)
{
	int p;
	srand(time(NULL));
	p=i+(rand()%(j-i+1));
	//printf("%d\n",a[p]);
	swap(&a[p],&a[j]);
}
int quicksort(int a[],int i,int j)
{
	int c;
	if(i<j)
	{
		randpivot(a,i,j);
		c=partition(a,i,j);
		quicksort(a,i,(c-1));
		quicksort(a,(c+1),j);
	}
} 
int main()
{
	int i,j;
	i=0;
	j=6;
	quicksort(a,i,j);
	printf("quick sort list\n");
	for(i=0;i<7;i++)
	{
		printf("%d\t",a[i]);
	}
	return 0;
}