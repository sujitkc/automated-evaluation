#include <stdio.h>
#include <time.h>
int rec(int n)
{
	if(n<2)
	{
		return n;
	}
	else
	{
		return((rec(n-1)+rec(n-2))%100);
	}
}
int main()
{
	int n,a;
	scanf("%d",&n);
	clock_t tic = clock();
	a=rec(n);
	clock_t toc = clock();
	//double time_spent =(double)(end-begin) / CLOCK_PER_SEC;
	printf("%d\n",a);
	printf("Elapsed: %f seconds\n", (double)(toc - tic) / CLOCKS_PER_SEC);
	return 0;
}