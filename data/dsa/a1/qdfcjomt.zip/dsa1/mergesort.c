#include <stdio.h>
int A[8]={56,34,24,67,56,12,90,54};
int B[10];
void merging(int i,int k,int j)
{
	int l,r,m=0,p,c=0;
	l=i;
	r=k+1;
	while(l<=k && r<=j)
	{	
		if(A[l]>=A[r])
		{
			B[m]=A[r];
			r++;
			m++;
		}
		else if(A[l]<A[r])
		{
			B[m]=A[l];
			m++;
			l++;
		}

	}
	while(l<=k)
	{
		B[m]=A[l];
		m++;
		l++;	
	}
	while(r<=j)
	{
		B[m]=A[r];
		r++;
		m++;
	}
	m=0;
	for(p=i;p<=j;p++)
	{
		A[p]=B[m];
		m++;
	}
	//printf("%d",c);
	for(c=0;c<8;c++)
	{
		printf("%d\t",A[c]);
	}
	printf("\n");



}
void ms(int i,int j)
{
	int k,t;
	if(j==i)
	{
		return;
	}
	/*else if(j=i+1)
	{
		if(A[i]>A[j])
		{
			t=A[i];
			A[i]=A[j];
			A[j]=t;
		}	
	}*/
	if(j>i)
	{
		
		k=(i+j)/2;
		ms(i,k);
		ms(k+1,j);
		merging(i,k,j);

	}
}
int main()
{
	int i=0,j=7,k;

	//for(k=0;k<n;k++)
	//{
	//	scanf("%d",&A[k]);
	//}
	ms(i,j);
	printf("merge sorted list\n");
	for(k=0;k<=7;k++)
	{
		printf("%d\t",A[k]);
	}
	return 0;
}