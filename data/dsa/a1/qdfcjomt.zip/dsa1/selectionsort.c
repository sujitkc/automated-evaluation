#include <stdio.h>
int main()
{
	int i,t,k,a[100];
	printf("enter no.s");
	for(i=0;i<=4;i++)
	{
		scanf("%d",&a[i]);
	}

	for(i=0;i<=4;i++)
	{
		for(k=0;k<=3-i;k++)
		{
			if(a[k]>a[k+1])
			{
				t=a[k+1];
				a[k+1]=a[k];
				a[k]=t;
			}
		}
	}
	for(i=0;i<=4;i++)
	{
		printf("%d\t",a[i]);
	}
	return 0;
}