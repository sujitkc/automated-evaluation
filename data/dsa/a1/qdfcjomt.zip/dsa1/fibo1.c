#include <stdio.h>
#include <time.h>
int main()
{
	long long int f[99999],i,n;
	scanf("%lli",&n);
	clock_t tic = clock();
	f[0]=0;
	f[1]=1;
	for(i=2;i<=n;i++)
	{
		f[i]=f[i-1]+f[i-2];
		f[i]=f[i]%100;
	}
	clock_t toc = clock();
	printf("%lli\n",f[n]);
	printf("Elapsed: %f seconds\n",(double)(toc-tic) / CLOCKS_PER_SEC);
	return 0;
}