#include<stdio.h>
void (multi(int a[2][2],int b[2][2]))
{
	int c[2][2];
	int i,j,n;
	for(i=0;i<2;i++)
	{
		for(j=0;j<2;j++)
		{
			c[i][j]=0;
		}
	}
	for(i=0;i<2;i++)
	{
		for(j=0;j<2;j++)
		{
			for(n=0;n<2;n++)
			{
				c[i][j]=((a[i][n]*b[n][j]+c[i][j])%100);
			}
		}
	}	
	for(i=0;i<2;i++)
		for(j=0;j<2;j++)
		{
			a[i][j] = c[i][j];
		}						
}
// n is the number in binary form given in reverse order i.e., place value increses as the index increses .
int power(int a[2][2],int n[1000])
{
	int y[2][2] = {{1,0},{0,1}};
	int i;
	for(i=0;i<6;i++)
	{
		if(n[i] == 1)
		{
			multi(y,a);
		}
		multi(a,a);
	}
	return y[1][0];
}
void main()
{
	int arr[2][2]={{1,1},{1,0}};
	int a[6]={1,1,1,0,0,1};
	printf("%d\n",power(arr,a));		
}
