//selection sort
#include<stdio.h>
void swap(int* a,int* b)
{
	int* t;
	*t = *a;
	*a = *b;
	*b = *t;
}
void sort(int a[1000000])
{
	int m = 0;
	int i,j,n=100000;
	for(j=0;j<n-1;j++)
	{
		for(i=1;i<n-j;i++)
		{
			if(a[i]>a[m])
			{
				m = i;
			}
		}
		if (a[n-j-1]<a[m])
		{
			swap(&a[m],&a[n-j-1]);
		}
	}
}
main()
{
	int a[100000];
	int i,k;
	for(i=0;i<100000;i++)
	{
		k = rand()%10000;
		a[i] = k;
	}
	sort(a);
}
