//Insertion sort
#include<stdio.h>
void sort(int a[1000000])
{
	int t,j,i;
	int n=100000;
	for(i=1;i<n;i++)
	{
		t = a[i];
		j = i - 1;
		while (j>=0 && a[j] > t)
		{
			a[j+1] = a[j--];
		}
		a[j+1] = t;
	}
}
void main()
{
	int arr[100000];
	int i,k;
	for(i=0;i<100000;i++)
	{
		k = rand()%10000;
		arr[i] = k;
	}
	sort(arr);
}

