#include<stdio.h>
void divide_by_2(int arr[1000000])
{
	int k=0,i;
	//no of digits in given number is 2
	for(i=0;i<2;i++)
	{
		k = (k%2)*10 + arr[i];
		arr[i] = k/2;
	}
}
int binary(int arr[100000])
{
	int b[1000000],c[100000];
	int j,i=0;
	//checking if the array is zero by verifying last element of array
	while(arr[1] != 0)
	{
		c[i] = (arr[1]%2);//1 or 0 is dependent on if the last digit is even or odd
		divide_by_2(arr);
		i++;
	}
	for(j=0;j<i;j++)
	{
		arr[j] = c[j];
	}
	return i;
}
void (multi(int a[2][2],int b[2][2]))
{
	int c[2][2];
	int i,j,k;
	for(i=0;i<2;i++)
	{
		for(j=0;j<2;j++)
		{
			c[i][j]=0;
		}
	}
	for(i=0;i<2;i++)
	{
		for(j=0;j<2;j++)
		{
			for(k=0;k<2;k++)
			{
				c[i][j]=((a[i][k]*b[k][j]+c[i][j])%100);
			}
		}
	}	
	for(i=0;i<2;i++)
		for(j=0;j<2;j++)
		{
			a[i][j] = c[i][j];
		}						
}
void main()
{
	int n[100000] = {3,9};
	int i;	
	int k = binary(n);
	int y[2][2] = {{1,0},{0,1}};
	int a[2][2]={{1,1},{1,0}};
	for(i=0;i<k;i++)
	{
		if(n[i] == 1)
		{
			multi(y,a);
		}
		multi(a,a);
	}
	printf("%d\n", y[1][0]);
}
