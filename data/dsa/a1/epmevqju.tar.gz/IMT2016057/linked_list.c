#include<stdio.h>
#include<stdlib.h>
struct node
{
	int value;
	struct node *next;
};
void add(struct node **sptr,int n)
{
	struct node *newnode;
	newnode = (struct node*)malloc(sizeof(struct node));
	newnode -> value = n;
	if(*sptr== NULL)
	{
		*sptr = newnode;
		newnode -> next = NULL;
	}
	else
	{
		struct node *temp = *sptr;
		while (temp -> next != NULL)
		{
			temp = temp -> next;
		}
		temp -> next = newnode;
		newnode -> next = NULL;
	}
}
void display(struct node *sptr)
{
	if( sptr== NULL)
		printf("NULL\n");
	else
	{
	      struct node *temp = sptr;
		while(temp->next!= NULL)
		{
		 printf("%d->",temp->value);
		 temp = temp-> next;
      		}	
     		printf("%d->NULL\n",temp->value);
   	}
}
void del(struct node **sptr,int n)
{
	struct node *temp=*sptr;
	struct node *t=*sptr ;
	if(temp-> value ==n)
	{
		*sptr = temp ->next;
		free(temp);
	}
	else
	{
		while (temp != NULL)
		{
			temp = temp -> next;
			if (temp -> value ==n)
			{
				t -> next = temp->next;
				free(temp);
				break;		
			}
			t = t -> next;	
		}
	}
}
void half(struct node **sptr)
{
	struct node *temp=*sptr;
	struct node *t = temp -> next;
	while (1)
	{ 
		if((temp -> value)%2==0 && (t -> value)%2==1)
		{
			del(sptr,t -> value);
		}
		else if ((temp -> value)%2==1 && (t -> value)%2==0)
		{
			del(sptr,temp->value);
			temp = t;
		}
		else if ((temp -> value)%2==0 && (t -> value)%2==0)
		{
			if (temp -> value > t -> value)
			{
				del(sptr,temp -> value);
				temp = t;
			}
			else
			{
				del(sptr,t -> value);
			}
		}
		else if((temp -> value)%2==1 && (t -> value)%2==1)
		{
			if(temp -> value > t -> value)
			{
				del(sptr,t -> value);
			}
			else
			{
				del(sptr,temp -> value);
				temp = t;
			}
		}
		if (temp -> next == NULL)
		{
			break;
		}
		temp = temp -> next;
		if (temp -> next == NULL)
		{
			break;
		}			
		t = temp -> next;
	}
}
void main()
{	
	struct node *arr[10000],*temp;
	int i,j,k;
	for(i=0;i<10000;i++)
	{
		arr[i]=NULL;
	}
	for(i=0;i<100000;i++)
	{
		j=rand()%10000;
		k=rand()%100000;
		add(&arr[j],k);
	}
	for(i=0;i<10000;i++)
	{
		if( arr[i] != NULL)
		{
			while(arr[i]->next != NULL)
				half(&arr[i]);
		}
		display(arr[i]);
	}
}
	
