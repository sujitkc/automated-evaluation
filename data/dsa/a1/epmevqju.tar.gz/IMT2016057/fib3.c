#include<stdio.h>
int rem(int arr[1000],int n)
{
	int i,k;
	k=arr[0];
	for(i=1;i<50;i++)
	{
		k = (k%n)*10 + arr[i];
	}
	k = k%n;
	return k;
}
int fib(int n)
{
	int a,b,c,i;
	a=0;
	b=1;
	for(i=2;i<=n;++i)
	{
		c=((a+b)%100);
		a=b;
		b=c;
	}
	return c;
}
void main()
{
	//storing a 50 digit number in an array place value of arr[i]=10^(50-i)
	int arr[50]={1,4,4,5,1,4,5,1,5,7,2,8,5,6,9,7,2,3,4,7,9,2,7,1,7,1,7,1,7,7,5,5,1,8,4,1,5,1,4,1,1,5,1,8,2,8,5,5,2,5};
	int k;
	k = rem(arr,300);
	printf("%d\n",fib(k));
}

