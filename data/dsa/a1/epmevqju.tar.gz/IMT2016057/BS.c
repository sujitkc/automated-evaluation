//bubble sort
#include<stdio.h>
void swap(int* a,int* b)
{
	int* t;
	*t = *a;
	*a = *b;
	*b = *t;
}
void sort(int arr[1000000])
{
	int i,j,n=100000;
	for(j=0;j<n-1;j++)
	{
		for(i=0;i<n-1-j;i++)
		{
			if(arr[i]>arr[i+1])
			{
				swap(&arr[i],&arr[i+1]);
			}
		}
	}
}
main()
{
	int a[100000];
	int i,k;
	for(i=0;i<100000;i++)
	{
		k = rand()%10000;
		a[i] = k;
	}
	sort(a);
}
