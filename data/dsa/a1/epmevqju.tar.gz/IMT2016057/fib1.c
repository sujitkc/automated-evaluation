#include<stdio.h>
int fib(int n)
{
	int arr[1000000],i;
	arr[0] = 0;
	arr[1] = 1;
	for (i=2;i <= n;++i)
	{
		arr[i] =((arr[i-1]+arr[i-2])%100);
	}
	return arr[n];
}
void main()
{
	printf("%d\n",fib(1000000));
}
