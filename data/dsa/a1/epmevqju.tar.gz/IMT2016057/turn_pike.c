#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
struct node
{
	int value;
	struct node *next;
};
int abs(int t)
{
	if(t>0)
		return t;
	return -t;
}
bool del(struct node **sptr,int n)
{
	struct node *temp=*sptr;
	struct node *t=*sptr ;
	if(temp-> value ==n)
	{
		*sptr = temp ->next;
		free(temp);
		return true;
	
	}
	else
	{
		while (temp->next != NULL)
		{
			temp = temp -> next;
			if (temp -> value ==n)
			{
				t -> next = temp->next;
				free(temp);
				return true;		
			}
			t = t -> next;	
		}
	}
	return false;
}
void display(struct node *sptr)
{
	if( sptr== NULL)
		printf("NULL\n");
	else
	{
	      struct node *temp = sptr;
		while(temp->next!= NULL)
		{
		 printf("%d->",temp->value);
		 temp = temp-> next;
      		}	
     		printf("%d->NULL\n",temp->value);
   	}
}
void add(struct node **sptr,int n)
{
	struct node *newnode;
	newnode = (struct node*)malloc(sizeof(struct node));
	newnode -> value = n;
	struct node *temp = *sptr;
	struct node *t = *sptr;
	if(temp == NULL)
	{
		*sptr = newnode;
		newnode->next = NULL;
	}
	else if(temp->value<n)
	{
		*sptr = newnode;
		newnode -> next = temp;
	}
	else
	{
		temp = temp->next;
		while(temp!=NULL && temp -> value > n)
		{
			temp = temp -> next;
			t = t->next;
		}
		t -> next = newnode;
		newnode -> next = temp;
	}
}
void failed(struct node **sptr,int n,int a[],int l,int r)
{
	int i;
	for(i=n-1;i>r;i--)
	{
		add(sptr,abs(n-a[i]));
	}
	for(i=0;i<l+1;i++)
	{
		add(sptr,abs(n-a[i]));
	}
}
bool try(struct node **sptr,int n,int arr[],int l,int r)
{
	int i,j;
	bool result = true;
	if(l+1 == r)
	{
		int max = (*sptr) -> value;
		arr[r] = max;
		for(i=n-1;i>r;i--)
		{
			if(del(sptr,abs(max-arr[i])) == false)
			{
				result = false;
				break;
			}
		}
		for(j=0;j<l+1;j++)
		{
			if(del(sptr,abs(max-arr[j]))==false)
			{
				result = false;
				break;
			}
		}
		if(result == false)
		{
			result = true;
			failed(sptr,max,arr,j,i);
			arr[l+1] = abs(arr[n-1] - max);
			for(i=n-1;i>r;i--)
			{
				if(del(sptr,abs(abs(arr[n-1] - max)-arr[i])) == false)
				{
					result = false;
					break;
				}
			}
			for(j=0;j<l+1;j++)
			{
				if(del(sptr,abs(abs(arr[n-1] - max)-arr[j]))==false)
				{
					result = false;
					break;
				}
			}
			if(result == false)
			{				
				failed(sptr,abs(max-arr[n-1]),arr,j,i);
			}
		}
	}
	else
	{
		int max = (*sptr) -> value;
		arr[r] = max;
		for(i=n-1;i>r;i--)
		{
			if(del(sptr,abs(max-arr[i])) == false)
			{
				result = false;
				break;
			}
		}
		for(j=0;j<l+1;j++)
		{
			if(del(sptr,abs(max-arr[j]))==false)
			{
				result = false;
				break;
			}
		}
		if(result == true)
		{
			if(try(sptr,n,arr,l,r-1) == false)
			{
				failed(sptr,max,arr,j,i);
				result = false;
			}
		}	
		else
		{
			failed(sptr,max,arr,j,i);		
			result = true;
			arr[l+1] = abs(arr[n-1] - max);
			for(i=n-1;i>r;i--)
			{
				if(del(sptr,abs(abs(arr[n-1] - max)-arr[i])) == false)
				{
					result = false;
					break;
				}
			}
			for(j=0;j<l+1;j++)
			{
				if(del(sptr,abs(abs(arr[n-1] - max)-arr[j]))==false)
				{
					result = false;
					break;
				}
			}
			if(result == true)
			{
				if(try(sptr,max,arr,l+1,r) == false)
				{
					failed(sptr,abs(max-arr[n-1]),arr,j,i);
					result = false;
				}
			}
			else
				failed(sptr,abs(max-arr[n-1]),arr,j,i);
		}
	}
	return result;		
}
void main()
{
	int a[100],i,n=5;
	a[0] = 0;
	struct node *t =NULL;
	add(&t,1);
	add(&t,3);
	add(&t,7);
	add(&t,2);
	add(&t,6);
	add(&t,4);
	add(&t,10);
	add(&t,9);
	add(&t,7);
	add(&t,3);
	display(t);
	a[n-1] = t ->value;
	del(&t,t->value);
	if(try(&t,n,a,0,n-2) == true)
	{
		for(i=0;i<n;i++)
			printf("%d\t",a[i]);
		printf("\n");
	}
	else
		printf("\nInvalid input\n");
}
