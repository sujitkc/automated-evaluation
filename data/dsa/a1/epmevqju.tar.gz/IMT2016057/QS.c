//quick sort
#include<stdio.h>
void swap(int* a,int* b)
{
	int t;
	t = *a;
	*a = *b;
	*b = t;
}
int partition(int a[],int i,int j)
{
	int p;
	p = a[j];
	int l = i,r = j-1;
	while(l<=r)
	{
		while(l<=r && a[l]<=p)
		{
			l++;
		}
		while(l<=r && a[r]>p)
		{
			r--;
		}
		if(l<r)
		{
			swap(&a[l],&a[r]);
			l++;
			r--;
		}
	}
	if(r != j-1)
		swap(&a[j],&a[l]);
	return r+1;
}
void qs(int arr[],int i,int j)
{
	if(i<j)
	{
		int k = partition(arr,i,j);
		qs(arr,i,k-1);
	 	qs(arr,k+1,j);
	}
}
void main()
{
	int arr[1000000];
	int i,k;
	for(i=0;i<1000000;i++)
	{
		k = rand()%1000000;
		arr[i] = k;
	}
	qs(arr,0,999999);
}
