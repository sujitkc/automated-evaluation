//merge sort
#include<stdio.h>
void swap(int* a,int* b)
{
	int t;
	t = *a;
	*a = *b;
	*b = t;
}
void merge(int a[],int i,int k,int j)
{
	int m,l=i,r=k+1,n=0;
	int b[1000000];
	while(l<=k && r<=j)
	{
		if(a[l]<a[r])
		{
			b[n++] = a[l++];
		}
		else
		{
			b[n++] = a[r++];
		}
	}
	while(l<=k)
	{
		b[n++] = a[l++];
	}
	while(r<=j)
	{
		b[n++] = a[r++];
	}
	for(m=0;m < n;m++)
	{
		a[m+i] = b[m];
	}
}
void sort ( int a[] , int i , int j)
{
	if(j == i+1||j==i)
	{
		if(a[j]<a[i])
		{
			swap(&a[j],&a[i]);
		}
	}
	else
	{
		int k = (i+j)/2;
		sort(a,i,k);
		sort(a,k+1,j);
		merge(a,i,k,j);
	}
}
void main()
{
	int arr[1000000];
	int i,k;
	for(i=0;i<1000000;i++)
	{
		k = rand()%1000000;
		arr[i] = k;
	}
	sort(arr,0,999999);
}
