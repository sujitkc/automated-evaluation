#include<stdio.h>

void insertion_sort(int a[],int n)
{
	int value, hole;
	for (int i = 1; i < n; ++i)
	{
		value=a[i];
		hole=i;
		while(hole>0 && a[hole-1]>value)
		{
			a[hole]=a[hole-1];
			hole=hole-1;
		}
		a[hole]=value;
	}
}

int main()
{
	int arr[]={5,3,2,0,7,1};
	insertion_sort(arr,6);
	for (int i = 0; i < 6; ++i)
	{
		printf("%d ",arr[i]);
	}
	return 0;
}