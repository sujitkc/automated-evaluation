#include<stdio.h>

int main()
{
	unsigned long long int n=100000000;
	int a,b,c;
	a=0;
	b=1;
	c=1;
	for(int i=0;i<n;i++)
	{
		a=b;
		b=c;
		c=(a+b)%100;
	}
	printf("%d",c);
}