#include<stdio.h>
#include<stdlib.h>

int partition(int a[], int start, int end)
{
	int temp, pivot;
	pivot=a[end];
	int p;
	p=start;
	for (int i = start; i < end; ++i)
	{
		if(a[i]<=pivot)
		{
			temp=a[i];
			a[i]=a[p];
			a[p]=temp;
			p++;
		}
	}
	temp=a[p];
	a[p]=a[end];
	a[end]=temp; 
	return p;
}

int random_partition(int a[], int start, int end)
{
	int pivot_index;
	pivot_index = (rand() % (end - start)) + start;
	int p, temp;
	temp = a[pivot_index];
	a[pivot_index]=a[end];
	a[end]=temp;
	p = partition(a,start,end);
	return p;
}

void quick_sort(int a[], int start, int end)
{
	if (start<end)
	{
		int p;
		p = random_partition(a,start,end);
		quick_sort(a,start,p-1);
		quick_sort(a,p+1,end);
	}
}

int main()
{
	int arr[]={5,3,2,1,7,1};
	quick_sort(arr, 0, 5);
	for (int i = 0; i < 6; ++i)
	{
		printf("%d ",arr[i]);
	}
	return 0;
}