#include<stdio.h>

int fib(int *arr, int n)
{
	arr[0]=0;
	arr[1]=1;
	if (n==0)
		return arr[0];
	if (n==1)
		return arr[1];
	else 
		return (fib(arr,n-1)+fib(arr,n-2))%100;
}

int main()
{
	int n=39;
	int arr[n];
	printf("%d",fib(arr,n));
}
