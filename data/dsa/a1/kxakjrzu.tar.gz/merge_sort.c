#include<stdio.h>

void merge(int l[], int nl, int r[], int nr, int a[])
{
	int i=0,j=0,k=0;
	while(i<nl && j<nr)
	{
		if(l[i]<=r[j])
		{
			a[k]=l[i];
			i++;
		}
		else
		{
			a[k]=r[j];
			j++;
		}
		k++;
	}
	while(i<nl)
	{
		a[k]=l[i];
		i++;
		k++;
	}
	while(j<nr)
	{
		a[k]=r[j];
		j++;
		k++;
	}
}

void merge_sort(int a[], int n)
{
	if (n<2)
		return;
	int mid;
	mid=n/2;
	int left[mid],right[n-mid];
	for (int i = 0; i < mid; ++i)
		{
			left[i]=a[i];
		}
	for (int i = mid; i < n; ++i)
		{
			right[i-mid]=a[i];
		}
	merge_sort(left,mid);
	merge_sort(right,n-mid);
	merge(left, mid, right, n-mid, a);	
}

int main()
{
	int arr[]={5,3,2,0,7,1};
	merge_sort(arr, 6);
	for (int i = 0; i < 6; ++i)
	{
		printf("%d ",arr[i]);
	}
	return 0;
}