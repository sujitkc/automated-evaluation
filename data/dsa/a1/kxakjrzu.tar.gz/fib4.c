#include<stdio.h>

int fib(unsigned long long int n)
{
	int a,b,c,m;
	a=0;
	b=1;
	c=1;
	m=10000;
	for(int i=0;i<n;i++)
	{
		a=b;
		b=c;
		c=(a+b)%m;
	}
	return c;
}

int main()
{
	unsigned long long int n=1000000000;
	int a,b,p,c,m;
	a=0;
	b=1;
	c=1;
	m=100;
	for(int i=2;i<6*m;i++)
	{
		if(fib(i)==0&&fib(i+1)==1)
		{
			p=i;
			break;
		}
	}
	printf("%d",fib(n%p));
}