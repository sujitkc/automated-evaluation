#include<stdio.h>
#include<string.h>

void mult(int a[][2],int b[][2], int c[][2])
{
	int temp;
	int t[2][2];
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<2;j++)
		{
			temp=0;
			for(int k=0;k<2;k++)
			{
				temp=temp+a[i][k]*b[k][j];
			}
			t[i][j]=temp%100;
		}
	}
	for (int i = 0; i < 2; ++i)
	{
		for (int j = 0; j < 2; ++j)
		{
			c[i][j] = t[i][j];
		}
	}
}

int checkOdd(int x[1000])
{
	int count=0;
	for (int i = 0; i < 1000; i++)
	{
		if(x[i]==10)
		{
			break;
		}
		count++;
	}
	return x[count-1]%2;
}

void div(int x[1000])
{
	int d=0,y;
	for (int i = 0; i < 1000; ++i)
	{
		if(x[i]==10)
			break;
		y=10*d+x[i];
		x[i]=y/2;
		d=y%2;
	}
}

int comp(int x[1000])
{
	for (int i = 0; i < 1000; ++i)
	{
		if(x[i]==10)
		{
			break;
		}
		if(x[i]!=0)
		{
			return 1;
		}
	}
	return 0;
}

int power(int a[][2],int c[][2], int x[])
{
	while(comp(x)==1)
	{
		if(checkOdd(x)==1)
			mult(c,a,c);
		mult(a,a,a);
		div(x);
	}
	return c[1][0];
}

void dec_to_bin(int x[1000], int bin[1000])
{
	for (int i = 999; i >0 ; --i)
	{
		bin[i]=checkOdd(x);
		div(x);
	}
	for (int i = 0; i < 1000; ++i)
	{
		printf("%d ",bin[i]);
	}
}

int main()
{
	int x[1000], temp[1000], bin[1000]={0};
	char *s="123456789123456789";
	for (int i = 0; i < strlen(s); ++i)
	{
		x[i]=(int)s[i]-48;
	}
	x[strlen(s)]=10;
	for (int i = 0; i <= strlen(s); ++i)
	{
		temp[i]=x[i];
	}
	int a[2][2],c[2][2];
	a[0][0]=1;
	a[1][1]=0;
	a[0][1]=1;
	a[1][0]=1;
	c[0][0]=1;
	c[1][1]=1;
	c[0][1]=0;
	c[1][0]=0;
	printf("%d ",power(a,c,x));
	dec_to_bin(temp,bin);
}