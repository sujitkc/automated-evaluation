def solve(pos,left,right,d,s,n):
	if d==[]:
		print(s)
		exit()
	maxi=max(d)
	
	if possible(d,s,left,right,maxi):
		s[right]=maxi
		pos.append(right)
		solve(pos,left,right-1,d,s,n)
	
	if possible(d,s,left,right,s[n-1]-maxi):
		s[left]=s[n-1]-maxi
		pos.append(left)
		solve(pos,left+1,right,d,s,n)

	rem=pos.pop()
	maxi=s[rem]
	for i in range(left):
		d.append(abs(maxi-s[i]))
	for i in range(right+1,n):
		d.append(abs(maxi-s[i]))
	d.remove(0)
	if pos==[]:
		print("No solution")
		exit()

def possible(d,s,left,right,maxi):
	temp=[]
	for i in range(left):
		if abs(maxi-s[i]) in d:
			d.remove(abs(maxi-s[i]))
			temp.append(abs(maxi-s[i]))
		else:
			d.extend(temp)
			return False
	for i in range(right+1,n):
		if abs(maxi-s[i]) in d:
			d.remove(abs(maxi-s[i]))
			temp.append(abs(maxi-s[i]))
		else:
			d.extend(temp)
			return False
	return True

if __name__ == '__main__':
	d=[]
	m=int(input("m = "))
	n=int((1+(8*m+1)**0.5)/2)
	s=[-1]*n
	print("n = " + str(n))
	for i in range(m):
		num=int(input())
		d.append(num)
	s[0]=0
	s[n-1]=max(d)
	d.remove(max(d))
	left=1
	right=n-2
	pos=[]
	pos.append(n-1)
	solve(pos,left,right,d,s,n)
