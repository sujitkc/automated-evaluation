#include<stdio.h>

void bubble_sort(int arr[],int n)
{
	for (int k = 1; k < n; ++k)
	{
		int flag=0;
		for (int i = 0; i < n-k; ++i)
		{
			if (arr[i]>arr[i+1])
			{
				int temp;
				temp=arr[i];
				arr[i]=arr[i+1];
				arr[i+1]=temp;
				flag=1;
			}
		}
		if (flag==0)
			break;
	}
}

int main()
{
	int arr[]={5,3,2,0,7,1};
	bubble_sort(arr,6);
	for (int i = 0; i < 6; ++i)
	{
		printf("%d ",arr[i]);
	}
	return 0;
}