#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<stdbool.h>

struct node
{
	long int data;
	struct node *next;
};

void insert(struct node **head1, long int val)
{
	struct node *newnode=(struct node *)malloc(sizeof(struct node));
	newnode->data = val;
	newnode->next = NULL;
	if((*head1) == NULL)
	{
		(*head1) = newnode;
	}
	else
	{	
		struct node *current = (*head1);
		struct node *prev = NULL;		
		while(current != NULL)
		{
			prev = current;
			current = current->next;
		}
		prev->next = newnode;
	}
}

bool check_even(struct node **head1)
{	
	struct node *current;
	while(current!=NULL)
	{
		if(current->data % 2 == 0)
		{	return true;}
		current = current->next;	
	}
	return false;
}

int main()
{
	long int i;
	time_t t1 = time(0);
	srand(t1);
	int flag=0,j,k1=0,k2=0;
	long int even[10]={0},odd[10]={0};
	struct node* arr[10] = {0};
	for(i=0;i<10;i++)
	{		
		long int r = rand();
		printf("%ld ", r);
		long int n = rand()%10;
		insert(&arr[n], r);
	}
	for(i=0;i<10;i++)
	{
		struct node *current;		
		current = arr[i];
		while(current != NULL)
		{
			if(check_even(&current)==true)
			{
				flag=1;
				even[k1]=current->data;
				k1++;
			}
			else
			{
				odd[k2]=current->data;
				k2++;
			}
			current=current->next;
		}
	}		
	if(flag==0)
		{
			long int max;
			max=odd[0];			
			for(j=1;j<10;j++)
			{
				if(odd[j]>max)
				{max=odd[j];}
			}
			printf("\n\n\n%ld",max);
		}
	else
		{
			long int min;
			min=even[0];
			for(j=1;j<10;j++)
			{
				if(even[j]<min)
				{min=even[j];}
			}
			printf("\n\n\n%ld",min);
		}
	return 0;	
}
