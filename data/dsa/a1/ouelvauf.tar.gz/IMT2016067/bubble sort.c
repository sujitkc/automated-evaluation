#include <stdio.h>
void bubblesort(int arr[],int num)
	{
		int i,temp;
		for(int j=0;j<num;j++){
		for(i=0;i<num-j;i++)
		{
			if(arr[i]>arr[i+1])
			{
				temp=arr[i];
				arr[i]=arr[i+1];
				arr[i+1]=temp;
		}
	}
	}
}

void main(){
	int n;
	printf("Enter no. of elements:");
	scanf("%d",&n);
	int arr1[n];
	for(int k=0;k<n;k++){
		scanf("%d",&arr1[k]);
	}
	bubblesort(arr1,n);
	printf("Sorted array:");
	for(int k=0;k<n;k++){
		printf("%d ",arr1[k]);
	}
}
