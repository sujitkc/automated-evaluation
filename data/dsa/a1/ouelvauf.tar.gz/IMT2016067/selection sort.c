#include<stdio.h>
int main()
{
	int arr[100],i,n,j,temp;
	printf("Enter no. of elements:");
	scanf("%d",&n);
	for(i=0;i<n;++i)
	{
		scanf("%d",&arr[i]);
	}
	for(j=0;j<n;++j)
	for(i=j+1;i<n;++i)
	{
		if(arr[j]>arr[i])
		{
			temp=arr[j];
			arr[j]=arr[i];
			arr[i]=temp;
		}
	}
	for(i=0;i<n;++i)
	printf("%d",arr[i]);
	return 0;
}
