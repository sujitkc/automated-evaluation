#include <stdio.h>
int algo2(int n){
	int f[n];
	f[0]=0;
	f[1]=1;
	for(int i=2;i<n;i++){
		f[i]=(f[i-1]+f[i-2]);
	}
	int temp;
	temp=f[n-1]%100;
	return temp;
}
void main(){
	int y,num;
	printf("The element required:");
	scanf("%d",&num);
	y=algo2(num);
	printf("The last 2 digits are:%d",y);

}
