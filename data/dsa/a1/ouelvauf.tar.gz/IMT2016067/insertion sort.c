#include <stdio.h>
int main()
{
	int i,j,k,t,arr[100];
	printf("No of elements:");
	scanf("%d",&k);
	printf("Enter elements :",k);
	for(i=0;i<k;i++)
	{
		scanf("%d",&arr[i]);
	}
	for(i=1;i<k;i++)
	{
		t=arr[i];
		j=i-1;
		while(t<arr[j]&&(j>0))
		{
			arr[j+1]=arr[j];
			j=j-1;
		}
		arr[j+1]=t;
	}
	printf("The sorted list is:");
	for(i=0;i<k;i++)
	{
		printf("%d",arr[i]);
	}
			return 0;
	}
	
