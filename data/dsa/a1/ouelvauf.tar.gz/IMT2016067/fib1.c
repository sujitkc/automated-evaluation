#include <stdio.h>
int algo1(int n){
	int k;
	if(n==0){
		return n;
	}
	if(n==1){
		return 1;
	}
	return algo1(n-1)+algo1(n-2);
}
	
void main(){
	int num,y;
	printf("The element required:");
	scanf("%d",&num);
	y=algo1(num);
	int d;

	d=y%100;
	printf("The last 2 digits are:%d\n",d );
}

	
