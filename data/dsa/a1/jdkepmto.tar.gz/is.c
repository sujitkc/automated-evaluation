#include<stdio.h>

int main()
{
	int arr[1000000];
	int n=6,m=0;
	for(int i=0;i<6;i++)
	{
		scanf("%d",&arr[i]);
	}

	for(int i=1;i<n;i++)
	{
		int j=i-1,t=arr[i];
		while(j>=0 && arr[j]>t)
		{
			arr[j+1]=arr[j];
			j--;
		}
		arr[j+1]=t;
	}
	for(int i=0;i<6;i++)
	{
		printf("%d ",arr[i]);
	}
}