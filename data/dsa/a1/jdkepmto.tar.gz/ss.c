#include<stdio.h>

int main()
{
	int arr[1000000];
	int n=6,m=0;
	for(int i=0;i<6;i++)
	{
		scanf("%d",&arr[i]);
	}
	for(int i=0;i<n-1;i++)
	{
		m=i;
		for(int j=i+1;j<n;j++)
		{
			if(arr[m]>arr[j])
				m=j;
		}
		if(m!=i)
		{
			int temp=arr[m];
			arr[m]=arr[i];
			arr[i]=temp;
		}
	}
	for(int i=0;i<6;i++)
	{
		printf("%d ",arr[i]);
	}
}