a=0
b=1
n=100
c=n
for i in range(10000000):
	c=(a+b)%100
	a=b
	b=c
print c