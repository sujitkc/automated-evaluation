from random import randint
import random

n=input("Total Points: ")
maxLimit=input("Max Distance: ")


def create_distanceSet(s):
    d=[]
    i=0
    j=0
    while(i<len(s)):
        j=i+1
        while(j<len(s)):
            d.append(abs(s[j]-s[i]))
            j+=1
        i+=1
    d.sort()
    return d
def create_randPoints(n,maxLimit):
    s=[]
    random.seed(9002)
    i=1
    s.append(0)
    while(i<n):
        s.append(randint(1,maxLimit-1))
        i+=1
    s[n-1]=maxLimit
    s.sort()
    return s

def solve(d,n,x):
    x[0]=0
    x[n-1]=max(d)
    d.remove(max(d))

    if searchSoln(d,x,n,1,n-1):
        return True
    else:
        return False

def searchSoln(d,x,n,start,end):
    if(len(d)==0):
        return True
    mx=max(d)
    removed=[]
    try:
        i=0
        for i in range(start)+range(end,n):
            d.remove(abs(mx-x[i]))
            removed.append(abs(mx-x[i]))
        x[end-1]=mx
        solved=searchSoln(d,x,n,start,end-1)
        if(solved):return True
    except:
        pass

    x[end-1]=0
    d.extend(removed)

    removed=[]
    mx=max(x)-mx
    try:
        for i in range(start)+range(end,n):
            d.remove(abs(mx-X[i]))
            removed.append(abs(mx-X[i]))
        x[start]=mx
        solved=searchSoln(d,x,n,start+1,end)
        if(solved):return True
    except:
        pass

    x[start]=0
    d.extend(removed)


s=create_randPoints(n,maxLimit)

d=create_distanceSet(s)
print "OriginalSet:",s
print "Distances:",d

i=0
x=[]
while(i<n):
    x.append(0)
    i+=1

solve(d,n,x)

print "Solution:"
print x
