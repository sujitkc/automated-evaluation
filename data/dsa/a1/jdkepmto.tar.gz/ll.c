#include<stdio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node *next;
};

struct node add(struct node **head,int value)
{
	struct node *crtptr,*prevptr=NULL,*newptr;
	crtptr=*head;
	newptr=malloc(sizeof(struct node));
	newptr->data=value;
	newptr->next=NULL;

	while(crtptr!=NULL)
	{
		prevptr=crtptr;
		crtptr=crtptr->next;
	}

	if(prevptr==NULL)
	{
		*head=newptr;
	}	

	else
	{
		prevptr->next=newptr;
	}
	return **head;
}

void view(struct node **head)
{
	struct node *crtptr,*prevptr=NULL,*newptr;
	crtptr=*head;
	while(crtptr!=NULL)
	{
		printf("%d ",crtptr->data);
		crtptr=crtptr->next;
	}

}

int main()
{
	int n, x;
	struct node *head;
	head=NULL;
	struct node *arr[10]={0};
	for(int i=0;i<15;i++)
	{
		x = rand()%10;
		n = rand()%50;
		add(&arr[x],n);
	}
	for(int i=0;i<10;i++)
	{
		view(&arr[i]);
		printf(".\n");
	}
	for(int i=0;i<10;i++)
	{
		while(1)
		{
			struct node *crtptr;
			crtptr=arr[i];
			if(crtptr==NULL)
				break;
			if(arr[i]->next==0)
			{
				break;
			}
			if((crtptr->data%2)==0 && ((crtptr->next)->data)%2!=0)
			{
				crtptr->next=(crtptr->next)->next;
			}
			else if((crtptr->data%2)!=0 && ((crtptr->next)->data)%2!=0)
			{
				if((crtptr->data)<(crtptr->next)->data)
				{
					arr[i]=crtptr->next;
				}
				else
				{
					crtptr->next=(crtptr->next)->next;
				}
			}
			else if((crtptr->data%2)==0 && ((crtptr->next)->data)%2==0)
			{
				if((crtptr->data)<(crtptr->next)->data)
				{
					crtptr->next=(crtptr->next)->next;
				}
				else
				{
					arr[i]=crtptr->next;
				}
			}
			else if((crtptr->data%2)!=0 && ((crtptr->next)->data)%2==0)
			{
				arr[i]=crtptr->next;
			}
		}
	}
	printf("After solving..\n");
	for(int i=0;i<10;i++)
	{
		view(&arr[i]);

		printf(".\n");
	}

	for(int i=0;i<10;i++)
	{
		if(arr[i]==0)
			continue;
		else
			add(&head,arr[i]->data);
	}
	while(1)
		{
			struct node *crtptr;
			crtptr=head;
			if(crtptr==NULL)
				break;
			if(head->next==0)
			{
				break;
			}
			if((crtptr->data%2)==0 && ((crtptr->next)->data)%2!=0)
			{
				crtptr->next=(crtptr->next)->next;
			}
			else if((crtptr->data%2)!=0 && ((crtptr->next)->data)%2!=0)
			{
				if((crtptr->data)<(crtptr->next)->data)
				{
					head=crtptr->next;
				}
				else
				{
					crtptr->next=(crtptr->next)->next;
				}
			}
			else if((crtptr->data%2)==0 && ((crtptr->next)->data)%2==0)
			{
				if((crtptr->data)<(crtptr->next)->data)
				{
					crtptr->next=(crtptr->next)->next;
				}
				else
				{
					head=crtptr->next;
				}
			}
			else if((crtptr->data%2)!=0 && ((crtptr->next)->data)%2==0)
			{
				head=crtptr->next;
			}
		}
		printf("Finally:\n%d",head->data);

	return 0;
}