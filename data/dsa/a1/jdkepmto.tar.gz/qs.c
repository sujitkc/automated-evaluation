#include<stdio.h>
#include<stdlib.h>
#include<time.h>

int partition(int arr[],int p,int l,int r)
{
	while(l<=r)
	{
		while(l<=r && arr[l]<=p)
			l++;
		while(l<=r && arr[r]>p )
			r--;
		if(l<r)
		{
		
			int temp=arr[r];
			arr[r]=arr[l];
			arr[l]=temp;
			l++;
			r--;
		}
		
	}
	return r;
}

void qs(int arr[],int l,int r)
{
	int p,k,q=(r-l+1);
	if(r==l+1)
	{	if(arr[r]<arr[l])
		{
			int temp=arr[r];
			arr[r]=arr[l];
			arr[l]=temp;
		}
		return;
	}
	else if(l>=r)
		return;

	p=arr[l+rand()%(r-l+1)];
	//printf("Inside qs()\n");
	k=partition(arr,p,l,r);
	qs(arr,l,k);
	qs(arr,k+1,r);
}

int main()
{
	srand(time(0));
	int arr[1000000] = {21,59,15,57,33,30};
	int n=6,m=0;
	/*for(int i=0;i<6;i++)
	{
		arr[i]=rand()%100;
	}*/
	printf("abc\n");
	for(int i=0;i<6;i++)
	{
		printf("%d ",arr[i]);
	}
	printf("abc\n");		
	qs(arr,0,5);
	for(int i=0;i<6;i++)
	{
		printf("%d ",arr[i]);
	}		
}