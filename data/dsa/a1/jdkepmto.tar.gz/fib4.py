def matmul(a,b):
	c=[[0,0],[0,0]]
	for i in range(len(a)):
		for j in range(len(a[0])):
			for k in range(len(b)):
				c[i][j]+=a[i][k]*b[k][j]
	return c

def power(a,n):
	y=[[1,0],[0,1]]
	k=len(n)
	i=0
	while(i<k):
		if(n[i]==1):
			y=matmul(y,a)
		a=matmul(a,a)
		i=i+1
	return a

a=[[1,1],[1,0]]
print power(a,[1,1,0])



