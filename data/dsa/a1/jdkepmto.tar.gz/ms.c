#include<stdio.h>

void merge(int arr[],int l,int mid,int r)
{
	int n1=mid-l+1;
	int n2=r-(mid);
	int arr1[n1],arr2[n2];
	for(int i=0;i<n1;i++)
	{
		arr1[i]=arr[i+l];
	}
	for(int i=0;i<n2;i++)
	{
		arr2[i]=arr[mid+1+i];
	}
	int i=0,j=0,k=l;
	while(i<n1 && j<n2)
	{
		if(arr1[i]<=arr2[j])
		{
			arr[k]=arr1[i];
			k++;
			i++;
		}
		else
		{
			arr[k]=arr2[j];
			k++;
			j++;
		}
	}
	while(i<n1)
	{
		arr[k]=arr1[i];
		k++;
		i++;
	}
	while(j<n2)
	{
		arr[k]=arr2[j];
		k++;
		j++;
	}
}

void mergesort(int arr[],int l,int r)
{
	if((r==l+1) && (arr[l]>arr[r]))
	{
		int temp=arr[r];
		arr[r]=arr[l];
		arr[l]=temp;
	}
	else if(l<r)
	{
		int mid=(l+r)/2;
	
		mergesort(arr,l,mid);
		mergesort(arr,mid+1,r);
		merge(arr,l,mid,r);
	}
}

int main()
{
	int arr[]={1,6,8,9,7,10};
	int n=6,m=0;
	/*for(int i=0;i<6;i++)
	{
		scanf("%d",&arr[i]);	
	}*/
	printf("a\n");
	mergesort(arr,0,5);
	printf("a\n");
	for(int i=0;i<6;i++)
	{
		printf("%d ",arr[i]);
	}

}