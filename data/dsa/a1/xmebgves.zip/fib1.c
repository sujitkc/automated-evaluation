#include <stdio.h>

int f(int n)
{
	if(n<2 && n>-1)
	{
		return 1;
	}
	else 
	{
		return (f(n-1)+f(n-2))%100;
	}
}

int main()
{
printf("%d\n",f(39) );
}
