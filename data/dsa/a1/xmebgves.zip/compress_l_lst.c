#include <stdio.h>
#include <stdlib.h>

struct listnode{
	int data;
	struct listnode *nextptr;
};


void view(struct listnode* sptr)
{
	struct listnode *currentptr;
	currentptr=sptr;
	while(currentptr !=NULL)
	{
		printf("%d\t",currentptr->data);
		currentptr=currentptr->nextptr;
	}
	printf("\n");
}

void insert(struct listnode **sptr,int value)
{
	struct listnode *currentptr,*prevptr,*newptr;
	prevptr=NULL;
	currentptr=*sptr;
	newptr=malloc(sizeof(struct listnode));
	newptr->data=value;
	newptr->nextptr=NULL;
	while(currentptr!=NULL)
	{
		prevptr=currentptr;
		currentptr=currentptr->nextptr;
	}
	if(prevptr==NULL) 
	{
		newptr->nextptr=*sptr;
		*sptr=newptr; 
	}
	else	
	{
		prevptr->nextptr=newptr;
	}
}

void delete(struct listnode **sptr,int value)
{	
	struct listnode *currentptr,*prevptr,*temp;
	prevptr=NULL;
	currentptr=*sptr;
	if((currentptr->data)==value)
	{
		temp=currentptr;
		*sptr=currentptr->nextptr;
		free(temp);
	}
	else
	{	
		while((currentptr->data)!=value && (currentptr->nextptr)!= NULL)
		{
			prevptr=currentptr;
			currentptr=currentptr->nextptr;
		}
		prevptr->nextptr=currentptr->nextptr;
		free(currentptr);
	}
}


void hreduce(struct listnode **sptr)
{
	struct listnode *p1,*istartptr,*startptr,*temp;

	istartptr=*sptr;
	p1=istartptr;
	
	while(1)
	{	
		startptr=*sptr;
		if(startptr==NULL || startptr->nextptr==NULL)
		{break;}
		else
		{
			if((p1->data)%2==0 && ((p1->nextptr)->data)%2==0)
			{
				if((p1->data)>((p1->nextptr)->data))
				{
					delete(sptr,p1->data);
					p1=*sptr;
				}
				else
				{
					delete(sptr,(p1->nextptr)->data);
				}
			}
			else if((p1->data)%2!=0 && ((p1->nextptr)->data)%2!=0)
			{
				if((p1->data)>((p1->nextptr)->data))
				{
					delete(sptr,(p1->nextptr)->data);
				}
				else
				{
					delete(sptr,p1->data);
					p1=*sptr;
				}
			}
			else if(((p1->data)%2==0 && ((p1->nextptr)->data)%2!=0) || ((p1->data)%2!=0 && ((p1->nextptr)->data)%2==0))
			{
				if((p1->data)%2!=0)
				{
					delete(sptr,p1->data);
					p1=*sptr;
				}
				else
				{
					delete(sptr,(p1->nextptr)->data);
				}
			}
		}
	}
}


int main()
{
	int n=10000;
	struct listnode* arr[10000]={0};
	
	for(int i=0;i<100000;i++)
	{
		int pos = rand()%n;
		int value = rand();
		insert(&arr[pos],value);
	}

	for(int i=0;i<n;i++)
	{
		view(arr[i]);
	}

	printf("_________________________\n");
	for(int i=0;i<n;i++)
	{
		hreduce(&arr[i]);
	}
	for(int i=0;i<n;i++)
	{
		view(arr[i]);
	}
	printf("_________________________\n");

	while(1)
	{
		int count=0;
		for(int i=0;i<n;i++)
		{
			for(int j=i+1;j<n;j++)
			{
				if(arr[i]!=NULL && arr[j]!=NULL)
				{
					if((arr[i]->data)%2==0 && (arr[j]->data)%2==0)
					{
						if((arr[i]->data)>(arr[j]->data))
						{
							delete(&arr[i],arr[i]->data);
							i++;
							break;
						}
						else
						{
							delete(&arr[j],arr[j]->data);
							i++;
							break;
						}
					}
					else if((arr[i]->data)%2!=0 && (arr[j]->data)%2!=0)
					{
						if((arr[i]->data)<(arr[j]->data))
						{
							delete(&arr[i],arr[i]->data);
							i++;
							break;
						}
						else
						{
							delete(&arr[j],arr[j]->data);
							i++;
							break;
						}
					}
					if(((arr[i]->data)%2!=0 && (arr[j]->data)%2==0) || ((arr[i]->data)%2==0 && (arr[j]->data)%2!=0))
					{
						if((arr[i]->data)%2!=0)
						{
							delete(&arr[i],arr[i]->data);
							i++;
							break;
						}
						else
						{
							delete(&arr[j],arr[j]->data);
							i++;
							break;
						}
					}
				}
				else if(arr[i]==NULL)
				{
					break;
				}
				else
				{
					continue;
				}
			}
		}
		//check if only 1 element
		for(int i=0;i<n;i++)
		{
			if(arr[i]==NULL)
			{
				count++;
			}
		}
		if(count==n-1)
			{
				break;
			}
	}

	for(int i=0;i<n;i++)
	{
		if(arr[i]!=NULL)
		{
			printf("%d\n",arr[i]->data );
		}
	}
}
