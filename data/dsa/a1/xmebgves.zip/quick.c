#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int partition(int *arr,int s,int e)
{
	/*int l,r,temp,i;
	l=s;
	r=e;
	while(l<r)
	{
		while(arr[l]<p)
		{
			l++;
		}
		while(arr[r]>=p)
		{
			r--;
		}
		if(l<r)
		{
			temp=arr[r];
			arr[r]=arr[l];
			arr[l]=temp;
		}
	}
	return r;*/

	int l,temp,p;
	l=s;
	p=s+rand()%(e-s+1);

	temp=arr[e];
	arr[e]=arr[p];
	arr[p]=temp;
	for(int i=s;i<e;i++)
	{
		if(arr[i]<arr[e])
		{
			temp=arr[i];
			arr[i]=arr[l];
			arr[l]=temp;
			l++;
		}
	}
	temp=arr[e];
	arr[e]=arr[l];
	arr[l]=temp;

	return l;
}

void quick_sort(int *arr,int s,int e)
{
	int p,k;
	if(e<=s)
	{
		return;
	}
	k=partition(arr,s,e);
	quick_sort(arr,s,k);
	quick_sort(arr,k+1,e);

}

int main()
{
	int n=100;
	int arr[n];
	for(int i=0;i<n;i++)
	{
		arr[i]=rand();
	}
	srand(time(NULL));
	for(int i=0;i<n;i++)
	{
		printf("%d\t",arr[i] );
	}

	printf("\n\n");
	quick_sort(arr,0,n-1);
	for(int i=0;i<n;i++)
	{
		printf("%d\t",arr[i] );
	}
}