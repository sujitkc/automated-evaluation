#include <stdio.h>

int f(int n)
{
	int a,b,c;
	a=0;
	b=1;
	if(n==0)
	{
		return a;
	}
	if(n==1)
	{
		return b;
	}
	else
	{
		for(int i=2;i<n;i++)
		{
			c=(a+b)%100;
			a=b;
			b=c;
		}
		return c;
	}
}

int main()
{
	int n=14;
	printf("%d\n",f(n) );
}
//0 1 1 2 3 5 8 13 21 34