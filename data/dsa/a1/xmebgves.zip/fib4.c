#include <stdio.h>

int f(int n,int m)
{
	int a,b,c;
	a=0;
	b=1;
	if(n==0)
	{return a;}
	if(n==1)
	{return b;}
	else
	{
		for(int i=2;i<n;i++)
		{
			c=(a+b)%m;
			a=b;
			b=c;
		}
		return c;
	}
}


int main()
{
	int m=1000;
	for(int i=1;i<=6*m;i++)
	{
		if(f(i,m)==0 && f(i+1,m)==1)
		{
			printf("%d\n",i-1);
		}
	}
}
//0 1 1 2 3 5 8 13 21 34