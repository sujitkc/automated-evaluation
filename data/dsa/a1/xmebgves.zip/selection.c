#include <stdio.h>
#include <stdlib.h>

int main()
{
	int n=10;
	int arr[n];
	int temp;
	for(int i=0;i<n;i++)
	{
		arr[i]=rand()%20;
	}
	for(int i=0;i<n;i++)
	{
		printf("%d\t",arr[i] );
	}
	printf("\n\n");

	for(int j=0;j<n;j++)
	{
		int max_i=0;
		for(int i=0;i<n-1-j;i++)
		{
			if(arr[i]>arr[max_i])
			{
				max_i=i;
			}
		}
		if(arr[max_i]>arr[n-1-j])
		{
			temp=arr[n-1-j];
			arr[n-1-j]=arr[max_i];
			arr[max_i]=temp;
		}
	}

	for(int i=0;i<n;i++)
	{
		printf("%d\t",arr[i] );
	}
		
}