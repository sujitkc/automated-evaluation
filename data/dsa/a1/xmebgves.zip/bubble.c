#include <stdio.h>
#include <stdlib.h>

int main()
{
	int n=10;
	int arr[n];
	int temp;
	for(int i=0;i<n;i++)
	{
		arr[i]=rand()%20;
	}
	for(int i=0;i<n;i++)
	{
		printf("%d\t",arr[i] );
	}
printf("\n\n");
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n-i;j++)
		{
			if(arr[j]>arr[j+1])
			{
				temp=arr[j+1];
				arr[j+1]=arr[j];
				arr[j]=temp;
			}
		}
	}
	for(int i=0;i<n;i++)
	{
		printf("%d\t",arr[i] );
	}
}