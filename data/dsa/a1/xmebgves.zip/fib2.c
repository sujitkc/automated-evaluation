#include <stdio.h>

int f(int *arr,int n)
{
	if(n==1)
	{
		arr[0]=0;
		return arr[0];
	}
	else if(n==2)
	{
		arr[1]=1;
		return arr[1];
	}
	else
	{
		arr[n]=(f(arr,n-1)+f(arr,n-2))%100;
		return arr[n];
	}	
}

int main()
{
	int n=5;
	int arr[n];
	printf("%d\n",f(arr,n) );
}
//0 1 1 2 3 5 8 13 21 34