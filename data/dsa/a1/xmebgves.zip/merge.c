#include <stdio.h>
#include <stdlib.h>

void merge(int *arr,int s,int k,int e)
{
	int l,r;
	l=s;
	r=k+1;
	int a=0;
	int temp[e-s+1];
	while(l<=k && r<=e)
	{
		if(arr[l]>arr[r])
		{
			temp[a]=arr[r];
			a++;
			r++;
		}
		else
		{
			temp[a]=arr[l];
			a++;
			l++;
		}
	}
	while(l<=k)
	{
		temp[a]=arr[l];
		a++;
		l++;
	}
	while(r<=e)
	{
		temp[a]=arr[r];
		a++;
		r++;
	}
	for(l=s;l<e+1;l++)
    {
    	arr[l]=temp[l-s];
    }
}

void merge_sort(int *arr,int s,int e)
{
	int temp;
	int k;
	if(e-s<2)
	{
		if(arr[e]<arr[s])
		{
			temp=arr[e];
			arr[e]=arr[s];
			arr[s]=temp;
		}
	}
	else 
	{
		k=(e+s)/2;
		merge_sort(arr,s,k);
		merge_sort(arr,k+1,e);
		merge(arr,s,k,e);
	}
}

int main()
{
	int n=10;
	int arr[n];
	int temp;
	for(int i=0;i<n;i++)
	{
		arr[i]=rand()%20;
	}
	for(int i=0;i<n;i++)
	{
		printf("%d\t",arr[i] );
	}
	printf("\n\n");

	merge_sort(arr,0,n-1);

	for(int i=0;i<n;i++)
	{
		printf("%d\t",arr[i] );
	}
		
}