#include <stdio.h>
#include <stdlib.h>

int main()
{
	int n=10;
	int arr[n];
	int temp;
	for(int i=0;i<n;i++)
	{
		arr[i]=rand()%20;
	}
	for(int i=0;i<n;i++)
	{
		printf("%d\t",arr[i] );
	}
	printf("\n\n");

	int j;
	for(int i=1;i<n;i++)
	{
		temp=arr[i];
		for(j=i-1;j>=0;j--)
		{
			if(temp<arr[j])
			{
				arr[j+1]=arr[j];
			}
			else
			{
				break;
			}
		}
		arr[j+1]=temp;
	}

	for(int i=0;i<n;i++)
	{
		printf("%d\t",arr[i] );
	}
}