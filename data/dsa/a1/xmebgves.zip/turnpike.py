distance=[1, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 4, 5, 5, 5, 6, 6, 7, 7, 8, 8, 9]
n=int((1+(8*len(distance)+1)**0.5)/2)
soln=[0]*n
soln[0]=0
soln[n-1]=distance[len(distance)-1]
distance.remove(distance[len(distance)-1])
left=1
right=n-2
pos=[]
pos.append(n-1)

def turnpike(pos,left,right,distance,soln,n):
	if distance==[]:
		print soln
		exit()
	max_index=max(distance)
	
	if check(distance,soln,left,right,max_index):
		soln[right]=max_index
		pos.append(right)
		turnpike(pos,left,right-1,distance,soln,n)
	
	if check(distance,soln,left,right,soln[n-1]-max_index):
		soln[left]=soln[n-1]-max_index
		pos.append(left)
		turnpike(pos,left+1,right,distance,soln,n)

	rem=pos.pop()
	max_index=soln[rem]
	for i in range(left):
		distance.append(abs(max_index-soln[i]))
	for i in range(right+1,n):
		distance.append(abs(max_index-soln[i]))
	distance.remove(0)
	if pos==[]:
		print "No solution"
		exit()

def check(distance,soln,left,right,max_index):
	temp=[]
	for i in range(left):
		if abs(max_index-soln[i]) in distance:
			distance.remove(abs(max_index-soln[i]))
			temp.append(abs(max_index-soln[i]))
		else:
			distance.extend(temp)
			return False
	for i in range(right+1,n):
		if abs(max_index-soln[i]) in distance:
			distance.remove(abs(max_index-soln[i]))
			temp.append(abs(max_index-soln[i]))
		else:
			distance.extend(temp)
			return False
	return True

	
turnpike(pos,left,right,distance,soln,n)
