def solve(last_index,left,right,d,pos_arr):#last_index -> index of the previous added one
	try:
		num = max(d)#this is next number to take out
	except ValueError:#this is error given if d is an empty sequence
		print "Solved"
		print pos_arr
		exit()

	if is_possible(d,pos_arr,left,right,num):#right branch
		pos_arr[right] = num
		last_index.append(right)
		solve(last_index,left,right-1,d,pos_arr)

	#comes here means right one is not possible or something on this branch didn't work
	
	num = pos_arr[n-1] - max(d)#for left insertion

	if is_possible(d,pos_arr,left,right,num):#left branch
		pos_arr[left] = num
		last_index.append(left)
		solve(last_index,left+1,right,d,pos_arr)

	#comes here means left one is not possible or something on this branch didn't work	

	#backtracking
	temp = last_index.pop()#take the last position out of d

	if last_index == []:
		print "No solution"
		exit() #want to completly stop it
	
	for i in range(left)+range(right+1,n):#put all numbers back in d
		d.append(abs(pos_arr[temp] - pos_arr[i]))
	d.remove(0)
	pos_arr[temp] = -1

def is_possible(d,pos_arr,left,right,num):
	l = []
	for i in range(left)+range(right+1,n):
		try:
			t = abs(num - pos_arr[i])#since left and right together
			d.remove(t)
			l.append(t)
		except ValueError:#raised if t not there in d
			d.extend(l)
			return False
	return True#removes all the distances also

if __name__ == "__main__":
	d = []
	print "enter s(the set of points):",
	s = map(int,raw_input().split())
	if len(s) <= 1:
		print "too few elements"
		exit()
	for i in xrange(len(s)-1):
		for j in xrange(i+1,len(s)):
			d.append(s[j]-s[i])
	d.sort()
	print "d =",d
	m = len(d)
	n = int((((1+8*m)**0.5)+1)/2)
	pos_arr = [-1 for i in xrange(n)]
	pos_arr[0] = 0
	pos_arr[n-1] = max(d)
	d.remove(max(d))
	left = 1
	right = n-2
	last_index = [n-1]
	solve(last_index,left,right,d,pos_arr)