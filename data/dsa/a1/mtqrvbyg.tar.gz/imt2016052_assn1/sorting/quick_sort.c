#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int size = 10;

void swap(int *a,int *b)
{
	int temp;
	temp = *a;
	*a = *b;
	*b = temp;
}

void print_a(int a[])
{
	for (int i = 0; i < size; ++i)
	{
		printf("%d ",a[i]);
	}
	printf("\n");
}

int partition(int a[],int i,int j,int p)//p is the pivot
{
	int l = i ,r = j;
	while(l < r)//so stop when r crosses over l
	{
		while(l < r && a[l] < p)//not <= since then l will overshoot
			l++;
		while(l < r && a[r] > p)
			r--;
		if(l < r)//i.e. didn't quit because i reached the end//<= made a lot of difference
		{
			swap(&a[l],&a[r]);
			if(a[l] != p || a[l] == a[r]) l++;
			if(a[r] != p || a[l] == a[r]) r--;
		}
	}
	return l;//the index of the pivot//in some cases its r but its l-1 in all cases

}

void rqs(int a[],int i,int j)
{
	
	if(i >= j)
		return;
	time_t t;
	srand((unsigned) time(&t));
	int p = a[(rand()%(j-i+1))+i];
	int k = partition(a,i,j,p);//k is the index around where the partition happened
	if(i < k-1)//if they are equal means just one element therefor it is sorted
		rqs(a,i,k-1);
	if(k+1 < j)
		rqs(a,k+1,j);
}

int main()
{
	int a[] = {4 ,5 ,2 ,1 ,3 ,6 ,6 ,8 ,7 ,10};//{0,-2,5,1,90,4,8,0,3,1};
	//         0,1, 2,3, 4,5,6,7,8,9
	rqs(a,0,size-1);
	printf("sorted array is: ");
	print_a(a);
}