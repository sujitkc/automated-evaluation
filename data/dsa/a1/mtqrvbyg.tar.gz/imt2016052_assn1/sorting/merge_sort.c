#include <stdio.h>

void merge(int arr[],int i,int j,int k)
{
	int l = i,r = k+1,a = 0;
	int b[100];
	while(l<=k && r <= j)
	{
		if(arr[l] < arr[r])
			b[a++] = arr[l++];
		else
			b[a++] = arr[r++];
	}
	while(l <= k)//this way do it without an extra if condition
		b[a++] = arr[l++];
	while(r <= j)
		b[a++] = arr[r++];
	a = 0;
	for(int t = i; t <= j ; t++)
		arr[t] = b[a++];
}

void merge_sort(int arr[],int i,int j)//j is last index
{
	if(j == i)
		return;//this will break it down to one more level and will come only till there
	int k = 0;
	k = (i+j)/2;
	merge_sort(arr,i,k);
	merge_sort(arr,k+1,j);
	merge(arr,i,j,k);
}

int main()
{
	int arr[] = {3,9,9,8,6,9,0,2,-1,45};
	merge_sort(arr,0,9);
	printf("sorted array is: ");
	for (int i = 0; i < 10; ++i)
		printf("%d ",arr[i]);
	printf("\n");
}