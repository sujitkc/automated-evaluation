#include <stdio.h>

void swap(int *a,int *b)
{
	int temp;
	temp = *a;
	*a = *b;
	*b = temp;
}

void print_a(int a[],int size)
{
	for (int i = 0; i < size; ++i)
	{
		printf("%d ",a[i]);
	}
	printf("\n");
}

void bubble_sort(int arr[],int size)
{
	for(int i = 0 ; i < size ; i++)
	{
		for(int j = 0 ; j < size - 1 - i ; j++)
		{
			if(arr[j] > arr[j+1])
				swap(&arr[j],&arr[j+1]);
		}
	}	
}

int main()
{
	int a[] = {3,9,9,8,2,4,3};
	int size = 7;
	bubble_sort(a,size);
	printf("sorted array is: ");
	print_a(a,size);
}