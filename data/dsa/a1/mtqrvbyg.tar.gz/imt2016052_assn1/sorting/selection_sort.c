#include <stdio.h>

void swap(int *a,int *b)
{
	int temp;
	temp = *a;
	*a = *b;
	*b = temp;
}

void print_a(int a[],int size)
{
	for (int i = 0; i < size; ++i)
	{
		printf("%d ",a[i]);
	}
	printf("\n");
}

void selection_sort(int arr[],int size)
{
	int min;
	for(int i = 0 ; i < size ; i++)
	{
		min = i;
		for(int j = i+1 ; j < size ; j++)
		{
			if(arr[j] < arr[min])//min is index to be able to swap at end
				min = j;
		}
		swap(&arr[i],&arr[min]);
	}
}

int main()
{
	int a[] = {3,9,9,8,2,4,3};
	int size = 7;
	selection_sort(a,size);
	printf("sorted array is: ");
	print_a(a,size);
}