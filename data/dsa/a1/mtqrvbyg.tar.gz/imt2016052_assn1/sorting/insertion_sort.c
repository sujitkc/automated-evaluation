#include <stdio.h>

void print_a(int a[],int size)
{
	for (int i = 0; i < size; ++i)
	{
		printf("%d ",a[i]);
	}
	printf("\n");
}

void ins_sort(int arr[],int size)
{
	int t = 0,j;
	for(int i = 1; i < size ; i++)
	{
		j = i-1;
		t = arr[i];
		while(j >= 0 && arr[j] > t)
		{
			arr[j+1] = arr[j];
			j--;
		}
		arr[j+1] = t;
	}
}

int main()
{
	int a[] = {3,9,9,8,6,9,0,2,-1,45};
	int size = 10;
	ins_sort(a,size);
	printf("sorted array is: ");
	print_a(a,size);
}