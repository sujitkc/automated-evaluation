#include <stdio.h>

int main()
{
	int a[10000000] = {0};
	int n = 1000000;
	//printf("Enter the number: ");
	//scanf("%d",&n);
	a[0]= 0;
	a[1] = 1;
	for(int i = 2; i <= n ; i++)
	{
		a[i] = (a[i-1]+a[i-2])%100;
	}	
	printf("%d\n",a[n]);
}