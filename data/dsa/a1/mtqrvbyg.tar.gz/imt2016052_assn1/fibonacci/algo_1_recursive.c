#include <stdio.h>

int fib_mod(int n)
{
	if( n < 2 )
		return n;
	return (fib_mod(n-1)+fib_mod(n-2))%100;
}

int main()
{
	int n = 40;
	//printf("Enter the number: ");
	//scanf("%d",&n);
	printf("%d\n",fib_mod(n));
}