#include <stdio.h>
#include <stdlib.h>

void matrix_multiply(int a[][2],int b[][2],int c[][2])
{
	int t = 0;
	int temp[2][2] = {{0,0},{0,0}};
	for (int i = 0; i < 2; ++i)//row number of i
	{
		for (int j = 0; j < 2; ++j)//column number of j
		{
			t = 0;
			for (int k = 0; k < 2; ++k)//traversing through that coulmn
			{
				t = t + (a[i][k] * b[k][j]);	
			}
			temp[i][j] = t%100;
		}
	}
	
	for(int i=0;i<2;i++)
		for(int j=0;j<2;j++)
			c[i][j] = temp[i][j];//in case c is a or b have done it later
}

void input_decimal(int num[])
{
	char inp[501];
	printf("Enter the number:");
	scanf("%s",inp);
	int i = 0;
	while(inp[i] != '\0')
	{
		num[i] = ((int)inp[i]) - 48;//stores msb first
		i++;
	}
	num[i] = 10;//this will work like the null charechter in strings
}

void div_by_2(int num[])//num = num/2
{
	int i = 0;
	int t = 0,carry = 0;//this is the carry
	while(num[i] != 10)
	{
		t = num[i];
		num[i] = (carry*10 + t)/2;
		carry = (carry*10 + t)%2;
		i++;
	}
}

int mod_by_2(int num[])
{
	int i = 0;
	while(num[i] != 10) 
		i++;
	return num[i-1]%2;//returned this itself rather than using two if conditions
}

int check_zero(int n[])//checks if n is zero
{
	int i = 0;
	while(n[i] != 10)
	{
		if(n[i] != 0)
			return 1;
		i++;
	}
	return 0;
}

void print_n(int n[])
{
	int i = 0;
	while(n[i] != 10)
	{
		printf("%d",n[i]);
		i++;
	}
	printf("\n");
}

void print_matrix(int x[][2])
{
	for(int i = 0 ; i < 2 ; i++)
	{
		for(int j = 0 ; j < 2 ; j++)
		{
			printf("%d ",x[i][j]);
		}
		printf("\n");
	}
}

int power(int n[])
{
	int x[2][2] = {{1,1},{1,0}};
	int y[2][2] = {{1,0},{0,1}};
	while(check_zero(n) != 0)
	{
		/*print_matrix(x);
		print_matrix(y);
		print_n(n);
		printf("\n");*/
		if(mod_by_2(n) == 1)
			matrix_multiply(y,x,y);//y*x = y
		matrix_multiply(x,x,x);//x*x = x
		div_by_2(n);//n = n/2
	}
	return y[1][0];
}

void convert_to_bin(int n[],int m[])//stores binary of n in m
{
	int i = 0;
	int b[500];
	while(n[i] != 10)
	{
		b[i] = n[i];
		i++;
	}
	b[i] = 10;
	i = 0;
	while(check_zero(b) != 0)//storing the lsb first
	{
		m[i] = mod_by_2(b);
		div_by_2(b);//kept a temp since storing the new value in b in the divide func
		i++;
	}
	m[i] = 10;
}

int power_using_bin(int n[])//n is a binary number
{
	int x[2][2] = {{1,1},{1,0}};
	int y[2][2] = {{1,0},{0,1}};
	int i = 0;
	while(n[i] != 10)
	{
		/*print_matrix(x);
		print_matrix(y);
		print_n(n);
		printf("\n");*/
		if(n[i] == 1)
			matrix_multiply(y,x,y);//y*x = y
		matrix_multiply(x,x,x);//x*x = x
		i++;//n = n/2
	}
	return y[1][0];
}

int main()
{
	int num[501] = {0},bin[501] = {0};
	input_decimal(num);
	convert_to_bin(num,bin);
	printf("using decimal:%d\n",power(num));
	printf("using binary:%d\n",power_using_bin(bin));

}