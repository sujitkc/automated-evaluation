#include <stdio.h>

int main()
{
	int a = 0,b = 1,c;
	int n = 1000000000;
	//       123456789
	//printf("Enter the number: ");
	//scanf("%d",&n);
	for(int i = 2; i <= n ; i++)
	{
		c = (a + b)%100;
		a = b;
		b = c;
	}	
	printf("%d\n",c);
}