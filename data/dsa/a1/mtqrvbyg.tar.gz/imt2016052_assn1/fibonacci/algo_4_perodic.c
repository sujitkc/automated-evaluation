#include <stdio.h>

int find_period(int m)//m is the mod
{
	int a = 0,b = 1,c,p = 1;
	c = (a + b)%m;
	a = b;
	b = c;
	while(a != 0 || b != 1)
	{
		c = (a + b)%m;
		a = b;
		b = c;
		p++;
	}
	return p;
}

int main()
{
	int a = 0,b = 1,c,p = find_period(100);
	printf("period: %d\n",p);
	int n;
	//long long int n = 1000000000000000000;
	//                   12345678901234567890
	printf("Enter the number: ");
	scanf("%d",&n);
	n = n%p;
	for(int i = 2; i <= n ; i++)
	{
		c = (a + b)%100;
		a = b;
		b = c;
	}	
	printf("%d\n",c);
}