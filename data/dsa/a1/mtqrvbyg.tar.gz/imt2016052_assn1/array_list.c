//if there are even numbers in the list the answer will be the smallest even number
//if there are only odd numbers in the lis the answer will be the largest odd number

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

struct node
{
	int data;
	struct node *link;
};

typedef struct node node;

void add_list(node **head,int val)//adds to front of the linked list.head is a pointer to the pointer of the top node
{
	node *newptr = (node*)malloc(sizeof(node));
	if(newptr == NULL)
	{
		printf("Can't allocate memory\n");
		return;
	}
	newptr -> data = val;
	newptr -> link = *head;
	*head = newptr;
}

void make_list(int n,int m,node*arr[])//n->no.of lists;m->no.of elements
{
	time_t t;
	srand((unsigned) time(&t));
	int val,temp = m,row;
	while(temp > 0)
	{
		row = rand()%n;//this is the row where the random element is added
		val = rand()%m;//this is the value which will be added there
		add_list(&arr[row],val);
		temp--;
	}
}

void traverse(node * head)
{
	node * temp = head;
	while(temp != NULL)	
	{
		printf("%d -> ",temp -> data);
		temp = temp -> link;
	}	
	printf("NULL\n");
}

int even_exists(node* head)
{
	node * temp = head;
	while(temp != NULL)
	{
		if (temp->data%2 == 0)
			return 1;
		temp = temp -> link;
	}
	return 0;//returns 0 even when head is null
}

int find_ans(node* head)//returns the answer for one list
{
	if(even_exists(head))
	{
		int min = head -> data;
		node * temp = head;
		while(temp != NULL)
		{
			if (temp->data < min)
				min = temp -> data;
			temp = temp -> link;
		}
		return min;
	}
	else
	{
		int max = -1;//assuming only positive numbers,so won't add to final list if answer is -1.not making it the first element since the list might be empty
		node * temp = head;
		while(temp != NULL)
		{
			if (temp->data > max)
				max = temp -> data;
			temp = temp -> link;
		}
		return max;
	}
}

int main()
{
	const int n = 10,m = 20;
	node *arr[n];

	for (int i = 0; i < n; ++i)
		arr[i] = NULL;

	make_list(n,m,arr);

	printf("The list is:\n");
	for (int i = 0; i < n; ++i)
		traverse(arr[i]);

	int temp;
	node * final;

	for (int i = 0; i < n; ++i)//making a new linked list which stores the answers of each row
	{
		temp = find_ans(arr[i]);
		if(temp != -1)//case where list was not null.if list was null keeping it null
			add_list(&final,temp);
	}
	printf("\nThe answer is:%d\n",find_ans(final));
}
