#include <stdio.h>
#include <math.h>
void matrixMul(int a[][2],int b[][2],int c2[][2]){
    int c[2][2];
    c[0][0] = (a[0][0]*b[0][0] + a[0][1]*b[1][0])%100;
    c[0][1] = (a[0][0]*b[0][1] + a[0][1]*b[1][1])%100;
    c[1][0] = (a[1][0]*b[0][0] + a[1][1]*b[1][0])%100;
    c[1][1] = (a[1][0]*b[0][1] + a[1][1]*b[1][1])%100;
    c2[0][0] = c[0][0]; c2[1][0] = c[1][0]; c2[0][1] = c[0][1]; c2[1][1] = c[1][1];
}

int decimalToBinary(int arr[],int arr2[],int n){
    int i,num=0,remainder,j=0;
    for(i=0;i<n;i++){
        num+=arr2[i]*pow(10,n-i-1);
    }
    num = num%300;
    int size = (int)(log(num)/log(2));
    while(num != 0) {
        remainder = num%2;
        num = num/2;
        arr[j] = remainder;
        j++;
    }
    return size;
}
void pow2(int a[][2],int arr2[],int n){
    int i,j;
    int arr[1000];
    
    int size = decimalToBinary(arr,arr2,n);
    int y[2][2] = {{1,0},{0,1}};
    for(i=0;i<=size;i++)
    {
        if(arr[i] == 1)
            matrixMul(y,a,y);
        matrixMul(a,a,a);
    }
    printf("%d",y[1][0]);
}

int main()
{
	int i,j;
    int a[2][2] = {{1,1},{1,0}};
    int arr2[] = {8,6,5,4,1,0};
    pow2(a,arr2,6);
	return 0;
}
