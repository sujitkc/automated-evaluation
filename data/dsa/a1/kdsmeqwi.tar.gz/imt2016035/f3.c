#include <stdio.h>

int fib(int n){
    int a=0,b=1,c;
    int i;
    for(i=2;i<=n;i++){
    c=b;
    b=a+b;
    a=c;
    }
    return b;
}

int main()
{
	int n = 10;
    printf("%d",fib(n));
	return 0;
}
