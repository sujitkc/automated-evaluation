#include <stdio.h>

void mergesort(int a[], int first, int last){
    int mid;
    if(first<last){
        mid = (first+last)/2;
        mergesort(a,first,mid);
        mergesort(a,mid+1,last);
        merge(a,first,last,mid);
    }
    
}

void merge(int a[], int first, int last, int mid){
    int temp[50];
    int i,j,k;
    i = first;
    j = mid+1;
    k = 0;
    
    while(i<=mid && j<=last){
        if(a[i]<a[j])
            temp[k++] = a[i++];
        else
            temp[k++] = a[j++];
    }
    while(i<=mid)
        temp[k++] = a[i++];
    while(j<=last)
        temp[k++] = a[j++];
    
    for(i=first,j=0;i<=last;i++,j++)
        a[i]=temp[j];
}
int main()
{
    int a[10] = {3,7,2,1,10,8,6,7,5,9};
    int i,n = 10;
    mergesort(a,0,n-1);
    for(i=0;i<n;i++)
        printf("%d ",a[i]);
    return 0;
}
