#include <stdio.h>

int fib(int n){
    int arr[n];
    int i;
    arr[0] = 0; arr[1] = 1;
    for(i=2;i<=n;i++){
        arr[i] = (arr[i-1]+arr[i-2])%100;
    }
    return arr[n];
}

int main()
{
	int n = 6;
    printf("%d",fib(n));
	return 0;
}
