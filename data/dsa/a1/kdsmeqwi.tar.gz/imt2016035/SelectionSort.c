#include <stdio.h>

void selectionSort(int a[], int n){
    int i,j,temp;
    for(i=0;i<n;i++){
        int minIndex = i;
        for(j=i+1;j<=n;j++){
            if(a[j]<a[minIndex])
                minIndex = j;
        }
        if(minIndex!=i){
                temp = a[i];
                a[i] = a[minIndex];
                a[minIndex] = temp;
            }
    }
}
int main()
{
    int a[10] = {3,7,2,1,10,8,6,7,5,9};
    int i,n = 10;
    selectionSort(a,n);
    for(i=0;i<n;i++)
        printf("%d ",a[i]);
	return 0;
}