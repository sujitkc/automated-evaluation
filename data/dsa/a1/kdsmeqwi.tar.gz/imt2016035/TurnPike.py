
D = [1,2,2,2,3,3,3,4,5,5,5,6,7,8,10]
S = []

def solve(D,S):
    m = max(D)
    D.remove(m)
    S.append(0)
    S.append(m)
    return solveRecursive(D,S)

def solveRecursive(D,S):
    if not D :
        return True
    distMax = max(D)
    pointsMax = max(S)
    a = solveHelper(D,S,distMax)
    b = solveHelper(D,S,pointsMax-distMax)
    if(a or b): return True
    else : return False

def solveHelper(D,S,pointToAdd):
    removed = []
    for i in S:
        if(abs(i-pointToAdd) not in D):
            for j in removed:
                D.append(j)
            del removed[:]
            return False
        else :
            removed.append(abs(i-pointToAdd))
            D.remove(abs(i-pointToAdd))
    S.append(pointToAdd)
    a = solveRecursive(D,S)
    if a: return True
    else:
        S.remove(pointToAdd)
        for j in removed:
            D.append(j)
        return False

solve(D,S)
S.sort()
print(S)



