#include <stdio.h>

int fib(int n, int m){
    int arr[6*m];
    int i;
    int r = 0;
    arr[0] = 0; arr[1] = 1;
    for(i=2;i<=n;i++){
        arr[i] = (arr[i-1]+arr[i-2])%m;
        if(arr[i-1]==0 && arr[i]==1)
        {
            r = i-1;
            break;
            
        }
    }
    if(r!=0)
        return arr[n%r];
    else 
        return arr[n];
}

int main()
{
	int n = 310;
    int m = 100;
    printf("%d",fib(n,m));
	return 0;
}
