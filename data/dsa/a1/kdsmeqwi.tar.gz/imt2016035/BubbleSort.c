#include <stdio.h>

void bubbleSort(int a[],int n){
    int i,j,temp;
    for(i=0;i<n;i++){
        for(j=0;j<n-i-1;j++){
            if(a[j]>a[j+1]){
                temp = a[j];
                a[j] = a[j+1];
                a[j+1] = temp;
                }
            }
        }
    }
int main()
{
    int a[10] = {3,7,2,1,10,8,6,7,5,9};
    int i,n = 10;
    bubbleSort(a,n);
    for(i=0;i<n;i++)
        printf("%d ",a[i]);
	return 0;
}
