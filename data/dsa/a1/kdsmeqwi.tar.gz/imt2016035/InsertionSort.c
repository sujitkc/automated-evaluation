#include <stdio.h>

void insertionSort(int a[],int n){
    int i,j;
    for(i=0;i<=n;i++){
        j=i-1;
        int curNum = a[i];
        while(a[j]>curNum && j>=0){
            a[j+1] = a[j];
            j-=1;
        }
        a[j+1] = curNum;
    }
}
int main()
{
    int a[10] = {3,7,2,1,10,8,6,7,5,9};
    int i,n = 10;
    insertionSort(a,n);
    for(i=0;i<n;i++)
        printf("%d ",a[i]);
	return 0;
}