#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

typedef struct node {
    int val;
    struct node *next;
} node_t;

void print_list(node_t *head){
    node_t *current = head;
    while(current!=NULL){
        printf("%d ",current->val);
        current = current->next;
    }
    printf("\n");
}
int indexValue(node_t *head,int n){
    int i;
    node_t *current = head;
    for(i=0;i<n;i++){
        current = current->next;
    }
    return current->val;
}

void push(node_t *head, int val){
    node_t *current = head;
    while(current->next != NULL){
        current = current->next;
    }
    current->next = malloc(sizeof(node_t));
    current->next->val = val;
    current->next->next = NULL;
}

int pop(node_t **head){
    int retval = -1;
    node_t *next_node = NULL;
    if(*head == NULL){
        return -1;
    }
    next_node = (*head)->next;
    retval = (*head)->val;
    free(*head);
    *head = next_node;
    
    return retval;
}

int remove_by_index(node_t **head, int n){
    int i;
    int retval = -1;
    node_t *current = *head;
    node_t *temp_node = NULL;
    if(n==0){
        return pop(head);
    }
    for(i=0;i<n-1;i++){
        if(current->next==NULL){
            return -1;
        }
        current = current->next;
    }
    temp_node = current->next;
    retval = temp_node->val;
    current->next = temp_node->next;
    free(temp_node);
    
    return retval;
}
int reduce(node_t **head,int n){
     int i,j=0,z=0;
    while((*head)->next!=NULL){
    for(i=0;i<(n-j)/2;i++){
        int a = indexValue(*head,i);
        int b = indexValue(*head,i+1);
        if(a%2==0){
            if(b%2==0){
                if(a>b)
                    remove_by_index(head,i);
                else
                    remove_by_index(head,i+1);
            }
            if(b%2!=0)
                remove_by_index(head,i+1);
        }
        if(a%2!=0){
            if(b%2!=0){
                if(a<b)
                    remove_by_index(head,i);
                else
                    remove_by_index(head,i+1);
            }
            if(b%2==0)
                remove_by_index(head,i);
        }
        z++;
    }
    j=z;
    }
    return (*head)->val;
}
int reduce_array(node_t *arr[],int n){
    int i;
    node_t *head = malloc(sizeof(node_t));
    head->val = reduce(&arr[0],n);
    head->next = NULL;
    for(i=1;i<n;i++){
        push(head,reduce(&arr[i],n));
    }
    return reduce(&head,n);
    
}
int main()
{
    srand(time(NULL));
    int i,j;
    int n = 7;
    node_t *arr[n];
    
    for(i=0;i<n;i++){
        arr[i] = NULL;
        arr[i] = malloc(sizeof(node_t));
        arr[i]->val = 1;
        arr[i]->next = NULL;
        for(j=0;j<n-1;j++)
            push(arr[i],rand()%20+1);
        print_list(arr[i]);
    }
    printf("\n%d\n",reduce_array(arr,n));
	return 0;
}
