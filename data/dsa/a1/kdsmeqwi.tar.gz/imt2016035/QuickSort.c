#include <stdio.h>
#include <stdlib.h>

void quicksort(int a[], int l, int h){
    if(l<h){
        int p = partition(a,l,h);
        quicksort(a,l,p-1);
        quicksort(a,p+1,h);
    }
}

int partition(int a[],int l,int h) {
    int temp,i,j;
    int pivotIndex = l+rand()%(h-l+1);
    int pivotValue = a[pivotIndex];
    temp = a[pivotIndex];
    a[pivotIndex] = a[l];
    a[l] = temp;
    
    int border = l;
    for(i=l+1;i<=h+1;i++){
        if(a[i]<pivotValue){
            border+=1;
            temp = a[border];
            a[border] = a[i];
            a[i] = temp;
        }
    }
    temp = a[l];
    a[l] = a[border];
    a[border] = temp;
    
    return border;
}
int main()
{
    int a[10] = {3,7,2,1,10,8,6,7,5,9};
    int i,n = 10;
    quicksort(a,0,n-1);
    for(i=0;i<n;i++)
        printf("%d ",a[i]);
    return 0;
}