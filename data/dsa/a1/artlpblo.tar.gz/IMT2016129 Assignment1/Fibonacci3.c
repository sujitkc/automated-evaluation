#include<stdio.h>
int Fibonacci(int n)
{int a=0;
 int b=1;
 int c;
 for(int i=2;i<=n;i++)
 {c=(a+b)%100;
  a=b;
  b=c;
 }
 return c;
}

void main()
{printf("%d",Fibonacci(10));
}
