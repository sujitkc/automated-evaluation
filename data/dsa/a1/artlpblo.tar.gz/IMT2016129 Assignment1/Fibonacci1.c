#include<stdio.h>
int Fibonacci(int n)
{if(n<2)return n;
 else return(Fibonacci(n-1)+Fibonacci(n-2))%100;
}
void main()
{printf("%d",Fibonacci(10));
}
