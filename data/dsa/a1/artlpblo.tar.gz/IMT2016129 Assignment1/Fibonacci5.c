#include<stdio.h>

void MatrixMultiply(int A[2][2],int B[2][2])
{int C[2][2]={{0,0},{0,0}};
 for(int i=0;i<2;i++)
   for(int j=0;j<2;j++){
    int sum=0;
    for(int k=0;k<2;k++)
    sum+=A[i][k]*B[k][j];
    C[i][j]=sum%100;
}
 for(int i=0;i<2;i++)
  for(int j=0;j<2;j++)
   A[i][j]=C[i][j];
}

void Power(int x[2][2],int n)
{int y[2][2]={{1,0},{0,1}};
 while(n>0)
 {if(n%2==1)MatrixMultiply(y,x);
  MatrixMultiply(x,x);
  n=n/2;
 }
 for(int i=0;i<2;i++)
  for(int j=0;j<2;j++)
   x[i][j]=y[i][j];
}

int main()
{int i,j;
 int A[2][2]={{1,1},{1,0}};
 Power(A,157);
 printf("%d %d\n%d %d",A[0][0],A[0][1],A[1][0],A[1][1]);
 printf("\nF(n)=%d\n",A[1][0]);
}
