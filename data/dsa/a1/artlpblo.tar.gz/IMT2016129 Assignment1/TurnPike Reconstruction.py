def Union(X,y):
    S=[]
    for i in X:
        S.append(i)
    S.append(y)
    return S

def Distance(X,y):
    D=[]
    for i in X:
        D.append(abs(i-y))
    return D

def isSubset(L,D):
    check=True
    T=[]
    for i in L:
        T.append(i)
    for i in D:
        if i in T:
            T.remove(i)
        else:
            check=False
            break
    return check

def Remove(L,D):
    T = []
    for i in L:
        T.append(i)
    for i in D:
        T.remove(i)
    return T

def PartialDigest(L,X,width):
    width=max(L)
    L.remove(width)
    X=[0,width]
    Place(L,X,width)

def Place(L,X,width):
    if len(L)==0:
        print X
        Y = [ width - i for i in X ]
        print Y
        return True
    else:
        y=max(L)
        if isSubset(L,Distance(X,y)):
            D=Distance(X,y)
            if Place(Remove(L,D),Union(X,y),width):
                return True

        if isSubset(L,Distance(X,width-y)):
            D=Distance(X,width-y)
            if Place(Remove(L,D),Union(X,width-y),width):
                return True

        return False

X=[]
L=[2,3,4,7,11,12,1,2,5,9,10,1,4,8,9,3,7,8,4,5,1]
width=0
PartialDigest(L,X,width)
