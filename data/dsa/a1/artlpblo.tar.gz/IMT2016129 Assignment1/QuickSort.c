#include<stdio.h>
#include<stdlib.h>
#define n 100000

int  partition(int A[],int start,int end,int pivot)
{int pivotValue=A[pivot];
 int temp=A[start];
 A[start]=A[pivot];
 A[pivot]=temp;
 int l=start+1;
 int r=end;
 while(l<=r)
 {while(l<=r && A[l]<=pivotValue)l++;
  while(l<=r && A[r]>pivotValue)r--;
  if(l<=r)
  {temp=A[l];
   A[l]=A[r];
   A[r]=temp;
  }
 }
 temp=A[r];
 A[r]=A[start];
 A[start]=temp;
 return r;
}

void quicksort(int A[],int start,int end)
{if(start<end)
 {int pivot=start+rand()%(end-start+1);
  int k=partition(A,start,end,pivot);
  if(k<=end)
  {quicksort(A,start,k-1);
   quicksort(A,k+1,end);
  }
 }
}      

void main()
{int i;
 int A[n];
 for(i=0;i<n;i++)
  A[i]=rand()%n;
 quicksort(A,0,n-1);
 for(int i=0;i<n;i++)
  printf("%d\n",A[i]);
}
