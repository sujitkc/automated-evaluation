#include<stdio.h>
#include<stdlib.h>

struct node{
  int data;
  struct node * next;
};

typedef struct node NODE;

NODE * newNode(int data,NODE *next){
  NODE * temp=(NODE*)malloc(sizeof(NODE));
  temp->data=data;
  temp->next=next;
  return temp;
}

void insertBeg(NODE **start,int data){
      NODE *temp=newNode(data,*start);
      *start=temp;
}

void view(NODE * head){
  while(head){
    printf("%d ",head->data);
    head=head->next;
  }
  printf("\n");
}

void f1(NODE *head,NODE **prevNextPtr){
  if(head==NULL)return;
  if(head->next==NULL)return;
  NODE *t1=head;
  NODE *t2=head->next;

  if(t1->data%2==0 && t2->data%2==1){
    NODE *t3=t2->next;
    free(t2);
    t1->next=t3;
    f1(t3,&t1->next);

  }
  else if(t1->data%2==1 && t2->data%2==0){
    free(t1);
    *prevNextPtr=t2;
    f1(t2->next,&t2->next);
  }
  else if(t1->data%2==0 && t2->data%2==0&& t2->data>=t1->data){
    NODE *t3=t2->next;
    free(t2);
    t1->next=t3;
    f1(t3,&t1->next);

  }
  else if(t1->data%2==0 && t2->data%2==0&& t2->data<t1->data){
    free(t1);
    *prevNextPtr=t2;
    f1(t2->next,&t2->next);
  }
  else if(t1->data%2==1 && t2->data%2==1&& t2->data<=t1->data){
    NODE *t3=t2->next;
    free(t2);
    t1->next=t3;
    f1(t3,&t1->next);

  }
  else if(t1->data%2==1 && t2->data%2==1&& t2->data>t1->data){
    free(t1);
    *prevNextPtr=t2;
    f1(t2->next,&t2->next);
  }

}



int f2(NODE **head,int n){

  int n1=0;
  int n2=0;
  while(head[n1]==NULL&&n1<n)n1++;
  n2=n1+1;
  while(head[n2]==NULL&&n2<n)n2++;
  printf("%d:%d\n",n1,n2);
  if(n1==n || n2==n)return 0;

  NODE *t1=head[n1];
  NODE *t2=head[n2];

  if(t1->data%2==0 && t2->data%2==1){
    free(t2);
    head[n2]=0;
  }
  else if(t1->data%2==1 && t2->data%2==0){
    free(t1);
    head[n1]=0;
  }
  else if(t1->data%2==0 && t2->data%2==0&& t2->data>=t1->data){
    free(t2);
    head[n2]=0;
  }
  else if(t1->data%2==0 && t2->data%2==0&& t2->data<t1->data){
    free(t1);
    head[n1]=0;
  }
  else if(t1->data%2==1 && t2->data%2==1&& t2->data<=t1->data){
    free(t2);
    head[n2]=0;
  }
  else if(t1->data%2==1 && t2->data%2==1&& t2->data>t1->data){
    free(t1);
    head[n1]=0;
  }
  f2(head+n2+1,n-n2-1);
  return 1;

}

int main(){

  NODE *arr[10000]={0};
  int i;
  for(i=0;i<100;i++){
    int j=rand()%10;
    int data=rand()%100;
    insertBeg(&arr[j],data);
  }

  for(i=0;i<10;i++){
    view(arr[i]);
    while(arr[i] && arr[i]->next)f1(arr[i],&arr[i]);
  }

  for(i=0;i<10;i++){
    view(arr[i]);
  }

  printf("\n");

  while(f2(arr,10));

  for(i=0;i<10;i++){
    view(arr[i]);
  }





}
