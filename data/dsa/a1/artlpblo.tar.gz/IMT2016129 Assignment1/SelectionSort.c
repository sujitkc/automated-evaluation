#include <stdio.h>
void main()
{int num[100000];
for(int i=0;i<100000;i++)
 {int j=rand()%100000;
  num[i]=j;
 }
 int min,minpos;
	for(int i=0;i<100000;i++)
	{min=num[i];minpos=i;
		for(int j=i;j<100000;j++)
		{if(num[j]<min)
			{min=num[j];
			minpos=j;
			}
		}
	int temp=num[i];
	num[i]=min;
	num[minpos]=temp;
	}
printf("The values in ascending order are :\n");
for(int i=0;i<100000;i++)
printf("%d\n",num[i]);
}

