#include<stdio.h>
void main()
{int arr[100000];
for(int i=0;i<100000;i++)
 {int j=rand()%100000;
  arr[i]=j;
 }
int i,x,j;
for(i=1;i<100000;i++)
{x=arr[i];
 j=i-1;
  while(j>=0&&arr[j]>x)
  {arr[j+1]=arr[j];
   j=j-1;
  }
  arr[j+1]=x;
 }
for(int i=0;i<100000;i++)
printf("%d\n",arr[i]);
}
