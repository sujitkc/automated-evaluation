#include<stdio.h>
int Fibonacci(int n,int m)
{int a=0;
 int b=1;
 int c;
 for(int i=2;i<=n;i++)
 {c=(a+b)%m;
  a=b;
  b=c;
 }
 return c;
}

int FindPeriod(int m)
{int a=0;
 int b=1;
 int c=1;
 int i=0;
 while(1)
 {i++;
  c=(a+b)%m;
  a=b;
  b=c;
  if(a==0 && b==1)return i;
 }
}

int Mod(char n[],int period)
{int i=0;
 int r=0;
 while(n[i]!='\0')
 {r=(r*10+n[i]-'0')%period;
  i++;
 }
 return r;
}

int MakeNumber(char n[],int m)
{int number=Mod(n,FindPeriod(m));
 return Fibonacci(number,m);
}

void main()
{printf("%d",MakeNumber("157",100));
}
