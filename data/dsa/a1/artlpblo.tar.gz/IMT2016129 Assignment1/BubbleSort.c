#include <stdio.h>
void main()
{
 int num[100000];
 for(int i=0;i<100000;i++)
 {int j=rand()%100000;
  num[i]=j;
 }
   for(int i=0;i<100000;i++)
   {
      for(int j=0;j<100000-i;j++)
      {
         if(num[j]>num[j+1])
         {
            int t=num[j];
            num[j]=num[j+1];
            num[j+1]=t;
         }
      }
   }
printf("The numbers in ascending order are:\n");
 for(int i=0;i<100000;i++)
   printf("%d\n",num[i]);
}
