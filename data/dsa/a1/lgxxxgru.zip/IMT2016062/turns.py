list1=[1,2,2,2,3,3,3,4,5,5,5,6,7,8,10] #list
print "list of differences between elements"
print list1
a=list1.pop()
final=[0]
max=a
sec=[a]
final.append(a)
flag=1
temp=-1
def distance(temp,flag):
        if flag==1:
                temp=list1.pop()
                final.append(temp)
        for i in final:
            k=abs(temp-i)
            if k==0:
                continue
            if k==temp and flag==1:
                sec.append(k)
                continue
            if k==temp and flag==0:
                sec.append(k)
            if k in list1:
                list1.remove(k)
                sec.append(k)
            else:
                for j in range(len(final)+1):
                    m=sec.pop()
                    list1.append(m)
                list1.sort()
                flag=0
                final.pop()
                t=final.pop()
                temp=max-t
                final.append(temp)
                distance(temp,flag) #recursive call
        flag=1
while(len(list1) is not 1):
        flag=1
        distance(temp,flag)
final.sort()
print "Initial list from which the difference list was made"
print final
