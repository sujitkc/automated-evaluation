#include<stdio.h>
#include<stdlib.h>
void mul(int x1[2][2],int x2[2][2]){
	int i,j,k;
	int x3[2][2];
	x3[0][0] = 0;
	x3[0][1] = 0;
	x3[1][0] = 0;
	x3[1][1] = 0;
	for(i=0;i<2;i++){
		for(j=0;j<2;j++){
			for(k=0;k<2;k++){
				x3[i][j]=x3[i][j]+(x1[i][k]*x2[k][j]);
			}
		}
	}
	for(i=0;i<2;i++){
		for(j=0;j<2;j++){
			x1[i][j]=x3[i][j]%100;
		}
	}
}
int powe(int x1[2][2],int x2[],int n){
	int x4[2][2];
	x4[0][0] =1;
	x4[0][1] =0;
	x4[1][0] =0;
	x4[1][1] =1;
	int i=n-1;
	while(i>=0){
		if(x2[i]==1){
			mul(x4,x1);
		}
		mul(x1,x1);
		i--;
	}
	int j,k;
	for(j=0;j<2;j++){
		for(k=0;k<2;k++){
			x1[j][k]=x4[j][k];
		}
	}
}
int fibo(int x2[],int n){
	int x1[2][2];
	x1[0][0] = 1;
	x1[0][1] = 1;
	x1[1][0] = 1;
	x1[1][1] = 0;
	powe(x1,x2,n);
	return x1[1][0];
}
void main(){
	int n;
	printf("enter the no of digits in binary-->\t");
	scanf("%d",&n);
	int x2[n],i;
	for(i=0;i<n;i++){
		x2[i]=rand()%2;
	}
	printf("the binary conversion of the number is -->");
	for(i=0;i<n;i++){
		printf("%d ",x2[i]);
	}
	printf("\n");
	int temp  = fibo(x2,n);
	printf("\nThe answer of this binary number is-->%d\n\n",temp);
}
