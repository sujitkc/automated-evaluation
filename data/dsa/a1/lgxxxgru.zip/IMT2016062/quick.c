#include<stdio.h>
#include <stdlib.h>
int partition(int arr[],int x,int y,int p){
  int l=x,r=y;
  printf("l r p %d %d %d\n",l,r,p);
  while(r>=l){
    while(arr[l]<=p){
      l++;
    }
    while(arr[r]>p){
      r--;
    }
    if(l<r){
      int temp = arr[l];
      arr[l] = arr[r];
      arr[r] = temp;
      //l++;
      //r--;
    }
    if(l==r){

      r--;
    }
  }
  for (int q = x; q <= y; q++) {
    printf("%d ",arr[q]);
  }
  printf("\n");
  printf("r %d \n",r);

  return r;
}
int random1(int l,int r){
  return (l+(rand()%(r-l+1)));
}
int quicksort(int arr[],int l,int r){
  if(l>=r);
  else{
    int p = random1(l,r);
    printf("pivot%d \n", arr[p]);

    int k = partition(arr,l,r,arr[p]);
      quicksort(arr,l,k);
      quicksort(arr,k+1,r);
  }
  return 0;
}
void print(int arr[], int size){
    int i;
    for (i=0; i < size; i++)
        printf("%d ", arr[i]);
    printf("\n");
}
int main(){
  int n;
  printf("Size of array");
  scanf("%d",&n);
  int arr[n];
  for(int i=0;i<n;i++){
    scanf("%d",&arr[i]);
  }
  int size  = sizeof(arr)/sizeof(arr[0]);
  quicksort(arr,0,size-1);
  print(arr,size);
}
