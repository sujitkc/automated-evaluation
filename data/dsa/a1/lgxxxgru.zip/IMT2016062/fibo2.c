#include<stdio.h>
#include<stdlib.h>
int temp=2;
int arr(int n){
  int a1[10000];
  a1[0]=0;
  a1[1]=1;
  if(n<2){
    return a1[n];
  }
  else{
    a1[temp]= a1[temp-1]+a1[temp-2];
    int c = a1[temp];
    temp+=1;
    return c;
  }
}
int main(){
  int x;
  printf("Enter the number till where you want the series\n");
  scanf("%d",&x);
  for(int i=0;i<x;i++){
    int temp1 = arr(i);
    if(temp1<=x)
      printf("%d ",temp1);
    else
      break;
  }
  printf("\n");
  return 0;
}
