void merge(int arr[], int l, int m, int r){
    int i, j, k;
    int n1 = m - l + 1;
    int n2 =  r - m;
    int le[n1], re[n2];
    for (i = 0; i < n1; i++)
        le[i] = arr[l + i];
    for (j = 0; j < n2; j++)
        re[j] = arr[m + 1+ j];
    i = 0;
    j = 0;
    k = l;
    while (i < n1 && j < n2){
        if (le[i] <= re[j]){
            arr[k] = le[i];
            i++;
        }
        else{
            arr[k] = re[j];
            j++;
        }
        k++;
    }
    while (i < n1){
        arr[k] = le[i];
        i++;
        k++;
    }
    while (j < n2){
        arr[k] = re[j];
        j++;
        k++;
    }
}
void mergeSort(int arr[], int l, int r){
    if (l < r)
    {
        int m = (l+r)/2;
        mergeSort(arr, l, m);
        mergeSort(arr, m+1, r);
        merge(arr, l, m, r);
    }
}
void print(int arr[], int x){
    int i;
    for (i=0; i < x; i++){
        printf("%d ", arr[i]);
      }
    printf("\n");
}
int main(){
    int x;
    printf("Size of array\n");
    scanf("%d",&x);
    int arr[x];
    for(int i=0;i<x;i++){
      scanf("%d",&arr[i]);
    }
    printf("Given array is \n");
    print(arr,x);
    mergeSort(arr,0,x-1);
    printf("\nSorted array is \n");
    print(arr,x);
    return 0;
}
