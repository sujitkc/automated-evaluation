#include<stdio.h>
#include<stdlib.h>
int a=0,b=1;
int reuse(int n){
  if(n==0 ||n==1){
    return n;
  }
  else{
    int c = (a+b)%100;
    a=b;
    b=c;
    return c;
  }
}
int main(){
    int x;
    printf("Enter the number till where you want the series\n");
    scanf("%d",&x);
    for(int i=0;i<=x;i++){
      int temp = reuse(i);
        printf("%d ",temp);
    }
    printf("\n");
    return 0;
}
