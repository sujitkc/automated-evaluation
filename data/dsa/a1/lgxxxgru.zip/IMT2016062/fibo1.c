#include<stdio.h>
#include<stdlib.h>
int rec(int n){
  if(n==1||n==0){
    return n;
  }
  else{
    int c = rec(n-1)+rec(n-2);
    return c;
  }
}
int main(){
  int x;
  printf("Enter the number till where you want the series\n");
  scanf("%d",&x);
  for(int i=0;i<x;i++){
    int temp = rec(i);
    if(temp<=x)
      printf("%d ",temp);
    else
      break;
  }
  printf("\n");
  return 0;
}
