#include<stdio.h>
int main(){
  int arr[10];
  for(int i=0;i<10;i++){
    scanf("%d",&arr[i]);
  }
  for(int i=1;i<10;i++){
    int c =i;
    while(c>=1){
      if(arr[c]<arr[c-1]){
        int temp=arr[c];
        arr[c]=arr[c-1];
        arr[c-1]=temp;
      }
      c--;
    }
  }
  for(int i=0;i<10;i++){
    printf("%d ",arr[i]);
  }
  return 0;
}
