#include<stdio.h>
#include<time.h>
int main(){
    printf("Enter the number -->");
    int v,arr[1000],i,r,temp[3];
    time_t t;
    srand((unsigned) time(&t));
    for(i=0;i<1000;i++){
        r=rand()%150;
        printf("%d",r);
        arr[i]=r;
    }
    i=999;
    long long int j;
    int flag;
    j=arr[i];
    while(i>0)
    {
        v=0;
        if(arr[i]%100==0){
            flag=3;
            temp[v]=arr[i]/100;
            v=v+1;
            temp[v]=((arr[i]/10)-(10*temp[v-1]));
            v=v+1;
            temp[v]=(arr[i]-(10*temp[v-1])-(100*temp[v-2]));
        }
        if(arr[i]%10==0){
            flag=2;
            temp[v]=arr[i]/100;
            v=v+1;
            temp[v]=((arr[i]/10)-(10*temp[v-1]));
        }
        else{
            flag=1;
            temp[v]=arr[i];
        }
        for(int l=0;l<flag;l++){
            j=j*10+temp[l];
        }
        j=j%300;
        i=i-1;
    }
    printf("\nANSWER-->%lld\n",j);
    return 0;
}
