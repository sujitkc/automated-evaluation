#include<stdio.h>
main(){
int n,i;
printf("Enter a number");
scanf("%d",&n);
int a[n+1];
a[0]=0;
a[1]=1;
for(i=2;i<=n;i++){


  a[i]=(a[i-1]+a[i-2]);

}
printf("%d",a[n]);

}

















