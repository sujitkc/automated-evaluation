#include<stdio.h>
int fibo1(int n){


if(n<2)
  return n;
else
  return (fibo1(n-1)+fibo1(n-2))%100;

}
main(){
int n;
printf("enter a number");
scanf("%d",&n);
printf("%d",fibo1(n));






}
