#include<stdio.h>
fibo3(int n){
int a=0;
int b=1;
int i,c;
for(i=1;i<n;i++){
    c=(a+b)%100;
    a=b;
    b=c;
}
return c;
}
main(){
int n;
printf("Enter a number");
scanf("%d",&n);
printf("%d",fibo3(n));



}
















