#include <stdio.h>
#include <stdlib.h>

struct node{
	int data;
	struct node *next;
};


	struct node insert(){
		struct node *head=NULL;
		int i;
		for(i=0;i<10;i++){
			struct node *temp=(struct node*)(malloc(sizeof(struct node)));
			temp->data=((rand()%20)+1);
			temp->next=head;
			head=temp;
		}
		return *head;
	}
void print(struct node *x){
	struct node *temp1;
	temp1=x;
	while(temp1!=NULL){
		printf(" %d ",temp1->data);
		temp1=temp1->next;
	}
}
void del(struct node *a,struct node *b){
	struct node *temp5;
	struct node *temp6;
	temp5=b;
	if(a==b){
		b=b->next;
		free(a);
	}
	else{
	while(temp5->next!=a){
		temp5=temp5->next;
		}
	temp6=temp5->next;
	temp5->next=temp6->next;
	free(temp6);
	free(a);
	}
}
void compress(struct node *y){
	struct node *temp2;
	struct node *temp3;
	struct node *temp4;
	temp2=y;
	temp3=y->next;
	temp4=temp3->next;
	while(y->next!=NULL){

		if((temp2->data)%2==0 && (temp3->data)%2==1){
			del(temp3,y);
			struct node *temp3;
			if((temp4==NULL || temp4->next==NULL)&& (y->next!=NULL)){
			temp2=y;
			temp3=y->next;
			temp4=temp3->next;
		}
		else if(y->next!=NULL){

			temp3=temp4->next;
			temp2=temp4;
			temp4=temp3->next;

		}
		}
		else if((temp2->data)%2==1 && (temp3->data)%2==0){
			del(temp2,y);
			struct node *temp2;
			if((temp4==NULL || temp4->next==NULL)&& (y->next!=NULL)){
			temp2=y;
			temp3=y->next;
			temp4=temp3->next;
		}
		else if(y->next!=NULL){

			temp3=temp4->next;
			temp2=temp4;
			temp4=temp3->next;
			}
		}
		else if((temp2->data)%2==1 && (temp3->data)%2==1){
			if((temp2->data)>(temp3->data)){
				del(temp3,y);
				struct node *temp3;
				if((temp4==NULL || temp4->next==NULL)&& (y->next!=NULL)){
				temp2=y;
				temp3=y->next;
				temp4=temp3->next;
		}
				else{

				temp3=temp4->next;
				temp2=temp4;
				temp4=temp3->next;

				}
			}
			else{
				del(temp2,y);
				struct node *temp2;
				if((temp4==NULL || temp4->next==NULL)&& (y->next!=NULL)){
			temp2=y;
			temp3=y->next;
			temp4=temp3->next;
		}
		else if(y->next!=NULL){

				temp3=temp4->next;
				temp2=temp4;
				temp4=temp3->next;

		}
			}
		}
		else if((temp2->data)%2==0 && (temp3->data)%2==0){
			if((temp2->data)>(temp3->data)){
				del(temp2,y);
				struct node *temp2;
			if((temp4==NULL || temp4->next==NULL)&& (y->next!=NULL)){
			temp2=y;
			temp3=y->next;
			temp4=temp3->next;
		}
		else if(y->next!=NULL){

				temp3=temp4->next;
				temp2=temp4;
				temp4=temp3->next;

		}
			}
			else{
				del(temp3,y);
				struct node *temp3;
				if((temp4==NULL || temp4->next==NULL)&& (y->next!=NULL)){
			temp2=y;
			temp3=y->next;
			temp4=temp3->next;
		}
		else if(y->next!=NULL){

				temp3=temp4->next;
				temp2=temp4;
				temp4=temp3->next;

		}
			}
		}

	}
	free(temp2);
	free(temp3);
	free(temp4);

}
int main()
{
struct node arr[10];
int i;
for(i=0;i<10;i++){
	arr[i]=insert();
	print(arr);
	compress(arr);
}

	}
