#include<stdio.h>
int fibo(int n){
	int a=0;
	int b=1,c;
	for(int i=1;i<n;i++){	
	    c=(a + b)%100;
	    a=b;
		b=c;
	
}
return c;
}
int main(){
int n;
	printf("Enter number: ");
	scanf("%d",&n);
	printf("Fibonacci%100 of number: ");
	printf("%d\n",fibo(n));
	return 0;
}
