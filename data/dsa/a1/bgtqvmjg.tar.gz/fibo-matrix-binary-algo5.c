#include<stdio.h>
void multiply(int f[2][2],int a[2][2]){
	int j,k,l;
	int s[2][2]={{0,0},{0,0}};
	for(j=0;j<2;j++){
		for(k=0;k<2;k++){
			for(l=0;l<2;l++){
				s[j][k]=s[j][k]+f[j][l]*a[l][k];
			}
		}
	}
	for(j=0;j<2;j++){
		for(k=0;k<2;k++){
			f[j][k]=s[j][k]%100;
		}
	}
}
int power(int f[2][2],int a[],int n){
	int y[2][2]={{1,0},{0,1}};
	int i=n-1;
	while(i>= 0){
		if(a[i]==1){
			multiply(y,f);
		}
		multiply(f,f);
		i=i-1;
	}
	int j,k;
	for(j=0;j<2;j++){
		for(k=0;k<2;k++){
			f[j][k]=y[j][k];
		}
	}
}
int fibo(int a[],int n)
{
  int f[2][2] = {{1,1},{1,0}};
  
  power(f, a,n);
	int i,j;

  return f[1][0];
}
int main(){
	int n;
	printf("Enter the number of digits of binary: ");
	scanf("%d",&n);
	int a[n],i;
	for(i=0;i<n;i++){
		a[i]=rand()%2;
	}
	printf("Obtained binary number: ");
	for(i=0;i<n;i++){
		printf("%d ",a[i]);}
  	printf("\nFibonacci of number%100 = %d\n", fibo(a,n));
	return 0;
}
