import math

def tofindx(d,x,tofind):
	for i in range(len(d)):
		if d[i]==x:
			return True
		else:
			return False

def turnpike(d,lens,tofind,p=1,s=1):
    g=True
    for i in tofind:
        if i==None:
            g=False
    if g==True:
        global KK
        if tofind not in KK:
            print "Set can be: ",tofind
            KK.append(tofind)
        return
    d2=[]
    for i in d:
        d2.append(i)
    ii=0
    tofind2=[]
    while (ii<lens):
        tofind2.append(tofind[ii])
        ii+=1

    tofind2[lens-1-p]=max(d2)
    test=True
    i=0
    while(i<lens):
        if tofind2[i]!=None:
            if i!=len(tofind2)-1-p:
                try:
                    d2.remove(abs(tofind2[lens-1-p]-tofind2[i]))
                except:
                    test=False
                    break
        i+=1            

    if test==True:
        turnpike(d2,lens,tofind2,p+1,s)
    test=True
    i=0
    while (i<len(d)):
        if abs(d[i]-max(tofind))==max(d):
            nu=d[i]
            break
        i+=1
    try:
        tofind[s]=nu
    except:
        test=False
    if test==True:
        for i in range(lens):
            if tofind[i]!=None:
                if i!=s:
                    try:
                        d.remove(abs(no-tofind[i]))
                    except:
                        test=False
                        break

    if test==True:
        turnpike(d,lens,tofind,p,s+1)    
            


print "Enter 'd': ",
d=map(int,raw_input().split(' '))

d.sort()
lens=((1+math.sqrt(1+8*len(d)))/2)

pppp=int(lens)
if pppp!=lens:
    print "NOT POSSIBLE"
else:
    lens=int(lens)
    tofind=[None]*lens
    tofind[lens-1]=max(d)
    tofind[0]=0
    d.remove(max(d))
    KK=[]

    turnpike(d,lens,tofind)
    if len(KK)==0:
        print "NOT POSSIBLE"

