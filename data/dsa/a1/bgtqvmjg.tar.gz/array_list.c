#include<stdio.h>
#include<stdlib.h>
struct node{
	int data;
	struct node* next;
}*latest;
void deletenode(struct noode *a[],int i){
	struct node *temp;
	//struct node *latest;
	temp=latest->next;
	if(temp->data%2==0 && latest->data%2==0){
		if(latest->data>temp->data){
			a[i]=temp;
			free(latest);
		}
	
		else{
			latest->next=temp->next;
			free(temp);
		}
	}
	else if(temp->data%2!=0 && latest->data%2!=0){
		if(latest->data<temp->data){
			a[i]=temp;
			free(latest);
		}
	
		else{
			latest->next=temp->next;
			free(temp);
		}
	}
	else{
		if(latest->data%2==0){
			latest->next=temp->next;
			free(temp);
		}
		else{
			a[i]=temp;
			free(latest);
		}
	}	
}
int main(){
	int n,i,j,index,dat,nn;
	struct node *a[10000];
	struct node *temp,*current,*l,*ptr;
	for(i=0;i<10000;i++){
		a[i]=NULL;
	}
	printf("Enter number of element you want in array of linked list: ");
	scanf("%d",&nn);
	for(i=0;i<nn;i++){
		index=rand()%10000;
		dat=rand()%500;
		if(a[index]==NULL){
			a[index]=malloc(sizeof(struct node));
			a[index]->data=dat;
			a[index]->next=NULL;
		}
		else{
			temp=malloc(sizeof(struct node));
			temp->data=dat;
			temp->next=a[index];
			a[index]=temp;
		}
	}
	puts("Obtained array of linked list: ");
	for(i=0;i<10000;i++){						
		if(a[i]!=NULL){
		current=a[i];
		
		while(current!=NULL){
			
			printf("%d  ",current->data);
			current=current->next;
		}
		printf("\n");		
	}
	}
	puts("");
	for(i=0;i<10000;i++){
		if(a[i]!=NULL){
			while(a[i]->next!=NULL){
				latest=a[i];
				deletenode(a,i);
			}
			//printf("%d",a[i]->data);
		}
		else{
			//printf("%d",a[i]);
		}
		//puts("");
	}
	puts(" ");
	int min=1000,count=0;
	for (int i = 0; i < 10000; i++)
		{
			if (a[i]!=NULL && a[i]->data%2==0)
			{
				count++;
				if (a[i]->data<min){
					min=a[i]->data;
				}
			}
		}
	if (count==0)
	{
		for (int i = 0; i < 10000; ++i)
		{
			if (a[i]!=NULL && a[i]->data<min )
			{
				min=a[i];
			}
		}
	}
	printf("Number Obtained after certain operations on odd and even: %d\n",min );	
	return 0;
}
