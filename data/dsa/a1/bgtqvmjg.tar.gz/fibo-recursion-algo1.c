#include<stdio.h>
int fibo(int n){
	if(n<2){
		return n;
	}
	else{
		return (fibo(n-1)+fibo(n-2))%100;
	}
}
int main(){
	int n;
	printf("Enter number: ");
	scanf("%d",&n);
	printf("Fibonacci%100 of number: ");
	printf("%d\n",fibo(n));
	return 0;
}
