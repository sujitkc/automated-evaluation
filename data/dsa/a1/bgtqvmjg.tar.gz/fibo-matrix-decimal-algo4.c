#include<stdio.h>
#include<math.h>
#include<stdlib.h>
void multiply(int f[2][2],int a[2][2]){
	int j,k,l;
	int s[2][2]={{0,0},{0,0}};
	for(j=0;j<2;j++){
		for(k=0;k<2;k++){
			for(l=0;l<2;l++){
				s[j][k]=s[j][k]+f[j][l]*a[l][k];
			}
		}
	}
	for(j=0;j<2;j++){
		for(k=0;k<2;k++){
			f[j][k]=s[j][k]%100;
		}
	}
}
void power(int f[2][2],int n){
	int y[2][2]={{1,0},{0,1}};
	while(n>0){
		if(n%2==1){
			multiply(y,f);
		}
		multiply(f,f);
		n=n/2;
	}
	int j,k;
	for(j=0;j<2;j++){
		for(k=0;k<2;k++){
			f[j][k]=y[j][k];
		}
	}
}
int fibo(int n)
{
  int f[2][2] = {{1,1},{1,0}};
  if (n == 0)
      return 0;
  power(f, n);
 
  return f[1][0];
}
int repitition(int n){
	int a=0;
	int b=1,c;
	int count=1;
	while(1){	
	       	c=(a + b)%n;
		a=b;
		b=c;
	    
	    if(a==0 && b==1){	
	        break;
		}
	    else{
		    count=count+1;
		}
		
	}
	return count;
}
int length(int n){
    int count1=0;
    int k=n;
    while (k > 0){
        k = k / 10;
        count1++;}
    return count1;
}
int addno(int x,int y){
	int len=length(x);
	int no=0,p=1;
	while(len){
		no=no+(x%10)*pow(10,p);
		x=x/10;
		p++;
		len--;
	}
	no=no+y;
	return no;
}
int remain(int a[],int n,int count){
	int rem=0,i;
	for(i=0;i<n;i++){
		if(rem<count){
			rem=addno(rem,a[i]);
			rem=rem%count;
		}
		else{
			rem=rem%count;
		}
	}
	return rem;
}
int main(){
	int n;
	printf("Enter the size of decimal number: ");
	scanf("%d",&n);
	int i,j;
	int a[n];
	for(i=0;i<n;i++){
		a[i]=rand()%10;
	}
	printf("Obtained random number: ");
	for(i=0;i<n;i++){
		printf("%d",a[i]);
	}
  	int r=repitition(100);
  	int k=remain(a,n,r);
  	printf("\nFibonacci%100 of number= ");
  	printf("%d\n", fibo(k));
	return 0;
}
