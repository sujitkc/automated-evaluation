#include<stdio.h>
#include<stdlib.h>

int fibo(int s)
{
	if(s==1)
	{
		return 0;
	}
	else if(s==2)
	{
		return 1;
	}
	else
	{
		return fibo(s-1)+fibo(s-2);
	}
}

main()
{
	int i,j,k,b;
	printf("\n Please enter the term number of fibonacci sequence to find");
	scanf("%d",&k);
	b=fibo(k); /*Actual answer*/
	b=b%100; /*Answer wanted*/
	printf("\n The required fibonacci term is %d",b);
}

