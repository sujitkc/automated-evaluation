#include<stdio.h>
#include<stdlib.h>
#include<time.h>

main()
{
	int i,j,k,b;
	printf("\n Please enter the size of the array");
	scanf("%d",&k);
	int a[k];
	srand(time(NULL));
    for(i=0;i<k;i++)
	{
		a[i]=rand()%10000;
	}
	printf("\nThe input array is\n");
	for(i=0;i<k;i++)
	{
		printf("%d\n",a[i]);
	}
	for(i=0;i<k;i++)
	{
		for(j=i;j<k;j++)
		{
			if(a[i]>a[j])
			{
				b=a[i];
				a[i]=a[j];
				a[j]=b;
			}
		}
	}
	printf("\nThe sorted array is\n");
	for(i=0;i<k;i++)
	{
		printf("%d\n",a[i]);
	}
	
}
