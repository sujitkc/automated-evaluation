#include<stdio.h>
#include<stdlib.h>
#include<time.h>

main()
{
	int i,j,k,b,c;
	printf("\n Please enter the size of the array");
	scanf("%d",&k);
	int a[k];
	srand(time(NULL));
    for(i=0;i<k;i++)
	{
		a[i]=rand()%10000;
	}
	printf("\nThe input array is\n");
	for(i=0;i<k;i++)
	{
		printf("%d\n",a[i]);
	}
	for(i=1;i<k;i++)
	{
		j=i-1;
		b=a[i];
		while(j>=0 && a[j]>b)
		{
			a[j+1]=a[j];
			j=j-1;
			a[j+1]=b;
		}
	}
	printf("\nThe sorted array is\n");
	for(i=0;i<k;i++)
	{
		printf("%d\n",a[i]);
	}
}
