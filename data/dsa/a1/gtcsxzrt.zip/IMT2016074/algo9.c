#include<stdio.h>
#include<stdlib.h>

main()
{
	int i,j,k,c;
	printf("\n Please enter the size of the array of fibonacci sequence");
	scanf("%d",&k);
	int a[k];
	a[0]=0;
	a[1]=1;
	for(i=2;i<k;i++)
	{
		a[i]=(a[i-1]+a[i-2]);
		a[i]=a[i]%100;
	}
	
	printf("\n Please enter the index in the array for which we have to find that fibonacci number");
	scanf("%d",&c);
	printf("\n The required term is %d",a[c]);
}
