#include<stdio.h>
#include<stdlib.h>
#include<time.h>

main()
{
	int i,j,k,b,c;
	printf("\n Please enter the size of the array");
	scanf("%d",&k);
	int a[k];
	srand(time(NULL));
    for(i=0;i<k;i++)
	{
		a[i]=rand()%10000;
	}
	printf("\nThe input array is\n");
	for(i=0;i<k;i++)
	{
		printf("%d\n",a[i]);
	}
	for(i=0;i<k;i++)
	{
		b=0;
		for(j=1;j<k-i+1;j++)
		{
			if(a[j]>a[b])
			{
				b=j;
			}
			if(k-1-i>b)
			{
				c=a[b];
				a[b]=a[k-1-i];
				a[k-1-i]=c;
			}
		}
    }
	printf("\nThe sorted array is\n");
	for(i=0;i<k;i++)
	{
		printf("%d\n",a[i]);
	}
}
