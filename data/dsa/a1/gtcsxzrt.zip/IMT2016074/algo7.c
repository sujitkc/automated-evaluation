#include<stdio.h>
#include<stdlib.h>

int findmax(int a[],int b)
{
	int i,j=a[0],k;
	for(i=0;i<b;i++)
	{
		if(a[i]>=j)
		{
			j=a[i];
			k=i;
		}
	}
	return k;
}

int findmin(int a[],int b)
{
	int i,j=a[0],k=0;
	for(i=0;i<b;i++)
	{
		if(a[i]<=j && a[i]>0)
		{
			j=a[i];
			k=i;
		}
	}
	return k;
}


main()
{
	int i,j,k,b,c,i1,j1,j2,i2,diff;
	printf("\n Please enter the size of the array");
	scanf("%d",&k);
	int a[k],b1[k];
	for(i=0;i<k;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("\nThe input array is\n");
	for(i=0;i<k;i++)
	{
		printf("%d\n",a[i]);
	}
	b1[0]=a[0];
	for(i=1;i<k;i++)
	{
		b1[i]=b1[i-1]*a[i];
	}
	i1=0;i2=0;j1=1;j2=1;int i3=0;
	
	printf("\nThe maximum sum is %d\n And the subsequence is\n",b1[findmax(b1,k)]);
	for(i=findmin(b1,k);i<=findmax(b1,k);i++)
	{
		printf("%d\t",a[i]);
	}
}
