#include<stdio.h>
#include<stdlib.h>
#include<time.h>

int partition(int a[],int i,int j,int p)
{
	int l,r,t,t1;
	l=i;r=j+1;
	for(t1=j;t1>i;t1--)
	{
		if(a[t1]>=a[i])
		{
			r=r-1;
			t=a[r];
			a[r]=a[t1];
			a[t1]=t;
			
		}
	}
	t=a[r-1];
	a[r-1]=a[i];
	a[i]=t;
	return r-1;
}

void quicks(int a[],int i,int j)
{
	int p,k;
	srand(time(NULL));
	
	p=a[i];
	if(j-i>0)
	{
		
		k=partition(a,i,j,p);
		quicks(a,i,k-1);
	    quicks(a,k+1,j);
	}
	
}

main()
{
	int i,j,k,c;
	printf("\n Please enter the size of the array");
	scanf("%d",&k);
	int a[k],b[k];
	srand(time(NULL));
    for(i=0;i<k;i++)
	{
		a[i]=rand()%1000;
	}
	printf("\nThe input array is\n");
	for(i=0;i<k;i++)
	{
		printf("%d\n",a[i]);
	}
	quicks(a,0,k-1);
	printf("\nThe sorted array is\n");
	for(i=0;i<k;i++)
	{
		printf("%d\n",a[i]);
	}
	
}
