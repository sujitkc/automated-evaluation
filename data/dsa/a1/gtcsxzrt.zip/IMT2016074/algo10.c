#include<stdio.h>
#include<stdlib.h>

main()
{
	int i,j,k,b,a,c;
	a=0;b=1;
	printf("\n Please enter the term number of fibonacci sequence to find");
	scanf("%d",&k);
	for(i=2;i<k;i++)
	{
		c=(a+b);
		a=b;
		b=c;
		c=c%100;
	}
	printf("\n The required  term is %d",c);
}
