#include<stdio.h>
#include<stdlib.h>
#include<time.h>


void merger(int a[],int b1[],int b,int e,int c)
{
	int l,r,a1;
	l=b;r=e+1;a1=0;
	while(l<=e && r<=c)
	{
		if(a[l]<a[r])
		{
			b1[a1]=a[l];
			a1++;l++;
		}
		else
		{
			b1[a1]=a[r];
			a1++;r++;
		}
	}
	while(l<=e)
	{
		b1[a1]=a[l];
		a1++;l++;
	}
	while(r<=c)
	{
		b1[a1]=a[r];
		a1++;r++;
	}
	a1=0;
	for(l=b;l<=c;++l)
	{
		a[l]=b1[a1];
		a1++;
	}
}

void merges(int a[],int b1[],int b,int c)
{
	int d,e;
	if(b==c-1)
	{
		if(a[b]>a[c])
		{
			d=a[b];
			a[b]=a[c];
			a[c]=d;
		}
   }
	else if(c>b+1)
		{
			e=(c+b)/2;
			merges(a,b1,b,e);
			merges(a,b1,e+1,c);
			merger(a,b1,b,e,c);
		}
	
}

main()
{
	int i,j,k,c;
	printf("\n Please enter the size of the array");
	scanf("%d",&k);
	int a[k],b[k];
	srand(time(NULL));
    for(i=0;i<k;i++)
	{
		a[i]=rand()%10000;
	}
	printf("\nThe input array is\n");
	for(i=0;i<k;i++)
	{
		printf("%d\n",a[i]);
	}
	merges(a,b,0,k-1);
	printf("\nThe sorted array is\n");
	for(i=0;i<k;i++)
	{
		printf("%d\n",a[i]);
	}
}
