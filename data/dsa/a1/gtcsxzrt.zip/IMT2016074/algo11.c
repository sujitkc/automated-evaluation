#include<stdio.h>
#include<stdlib.h>

void matrixmulti(int a[][2],int b[][2],int c1[][2],int c,int d)
{
	int i,j,k;
	for(i=0;i<c;i++)
	{
		for(j=0;j<2;j++)
		{
			for(k=0;k<d;k++)
			{
				c1[i][k]=c1[i][k]+a[i][j]*b[j][k];
			}
		}
	}
}

main()
{
	int a[2][2],b[2][1],c[2][1],c1[2][2],d1[2][2],i,j,k,i1,i2,j2;
	for(i=0;i<2;i++)
	{
		for(j=0;j<2;j++)
		{
			a[i][j]=1;
			c1[i][j]=1;
		}
		a[1][1]=0;c1[1][1]=0;
	}
	
	b[0][0]=1;b[1][0]=0;
	
	for(i=0;i<2;i++)
	{
		for(j=0;j<2;j++)
		{
			d1[i][j]=0;
			
		}
	}
	c[0][0]=1;c[1][0]=0;
	
	printf("\n Please enter the term number in the fibonacci series to be found (starting from number 0)");
	scanf("%d",&k);
	for(i=1;i<k;i++)
	{
		matrixmulti(a,c1,d1,2,2);
		for(i1=0;i1<2;i1++)
		{
			for(j=0;j<2;j++)
			{
				c1[i1][j]=d1[i1][j];
			}
		}
		
		for(i2=0;i2<2;i2++)
	{
		for(j2=0;j2<2;j2++)
		{
			d1[i2][j2]=0;
			
		}
	}
	
	}
	
	/*for(i=0;i<2;i++)
	{
		for(k=0;k<1;k++)
		{
			for(j=0;j<2;j++)
			{
				c[i][k]=c[i][k]+c1[i][j]*b[j][k];
			}
		}
	}*/
	
	for(i=0;i<2;i++)
	{
		for(j=0;j<2;j++)
		{
			c1[i][j]=c1[i][j]%100;
		}
	
	}
	
	if(k==0)
	{
		printf("\n The required term is 0");
	}
	else
	{
		printf("\n The required term is %d",c1[1][0]);
		
	}
	
	
	
	
}
