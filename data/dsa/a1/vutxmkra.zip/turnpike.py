from math import *
import random
D=[1,2,2,2,3,3,3,4,5,5,5,6,7,8,10]
#D=[1,1,1,2,2,3]
#D=[8,12,15,16,18,20,4,7,8,10,12,3,4,6,8,1,3,5,2,4,2]
#D=[1,1,1,1,1,1]
#D=[2,3,2,3,24,4,5,5,2,5,3,5,3,5,3,9,55,4,3,32]
#D=[11,10,9,8,7,6,6,5,5,4,3,2,2,1,1]
l=len(D)
n=int((1+sqrt(1+8*l))/2)
ans=[0 for i in range(n)]

def points(ans,num):
	a=[]
	a.append(num)
	for i in ans:
		if i!=0:
			a.append(abs(i-num))
	return a

def Try(D,ans,num):
	c=D[0:]
	for i in points(ans,num):
		if i not in c:
			return False
		else:
			c.remove(i)
	return True

def backtrack(D,ans,i,j):
	flag=0
	for x in ans[0:n-1]:
		if x!=0:
				flag=1
				break
		if flag!=1:
			flag=0
	
	if(j<n-1 and i>0 and flag==1):
		if ans[i-1]!=0:
		 Max=min(ans[j+1],max(ans)-ans[i-1])
		else:
			Max=ans[j+1]
		
		if Max==ans[j+1]:
			for x in points(ans,ans[j+1]):
					D.append(x)
			D.remove(0)
			ans[j+1]=0
			if Try(D,ans,max(ans)-Max):
					for x in points(ans,max(ans)-Max):
						D.remove(x)
					ans[i]=ans[n-1]-Max
					func(D,ans,i+1,j+1)
					
			else:
					backtrack(D,ans,i,j+1)
		else:
			for x in points(ans,ans[i-1]):
				D.append(x)
			D.remove(0)
			ans[i-1]=0
			backtrack(D,ans,i-1,j)
		
	if flag==0:
			print 'not possible'
			return

def func(D,ans,i,j):
	if len(D)==0:
		for x in ans[1:]:
			if x==0:
				print "not possible"
				return 0
		print ans
		return 1
	elif i>0 and j>0 and i<n and j<n:
		Max=max(D)
		if Try(D,ans,Max):
			for x in points(ans,Max):
				D.remove(x)
			ans[j]=Max
			func(D,ans,i,j-1)
		elif Try(D,ans,max(ans)-Max):
			for x in points(ans,max(ans)-Max):
				D.remove(x)
			ans[i]=ans[n-1]-Max
			func(D,ans,i+1,j)
		else:
			backtrack(D,ans,i,j)
	else:
		print "not possible"
		return 0
func(D,ans,1,n-1)


