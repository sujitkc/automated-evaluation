#include<stdio.h>
#include<string.h>

void MatrixMultiply(int A[2][2],int B[2][2],int m)
{int C[2][2]={{0,0},{0,0}};
int i,j,k,p,o;
for(i=0;i<2;i++)
   for(j=0;j<2;j++)
    for(k=0;k<2;k++)
     C[i][j]+=A[i][k]*B[k][j];

for(p=0;p<2;p++)
  for(o=0;o<2;o++)
   A[p][o]=C[p][o]%m;
}

int Power(char number[],int m)
{int x[2][2]={{1,1},{1,0}};
int y[2][2]={{1,0},{0,1}};
int l=strlen(number);
int i=l-1;
while(i>=0)
{if(number[i]=='1')MatrixMultiply(y,x,m);
  MatrixMultiply(x,x,m);
  i--;
}
return y[1][0];
}

void Reverse(char *a)
{int l=strlen(a);
int i;
for( i=0;i<l/2;i++)
{char temp=a[i];
  a[i]=a[l-i-1];
  a[l-i-1]=temp;
}
}

int Divide(char a[])
{int r=0;
int l=strlen(a);
Reverse(a);
int i=l-1;
while(i>=0)
{int c=a[i]-'0';
  a[i]=(10*r+c)/2+'0';
  r=(r*10+c)%2;
  i--;
}
while(a[--l]=='0')
  a[l]='\0';
Reverse(a);
return r;
}

int DecimalToBinary(char a[],int m)
{int l=strlen(a);
char binary_number[(int)(l*3.22+2)];
int i=0;
while(strlen(a)!=0)
  binary_number[i++]=Divide(a)+'0';
binary_number[i]='\0';
Reverse(binary_number);
return Power(binary_number,m);
}

int main()
{char n[1000];
scanf("%s",n);
printf("%d\n",DecimalToBinary(n,100));
}