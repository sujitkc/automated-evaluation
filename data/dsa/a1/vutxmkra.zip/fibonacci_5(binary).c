#include <stdio.h>
#include <string.h>
int a[2][2]={{1,1},{1,0}};
int y[2][2]={{1,0},{0,1}};
int half(long long int p[],long long int l)
{
long long int i,rem=0;
for(i=0;i<l;i++)
{
rem = 10*rem;
rem= rem + p[i];
p[i]=rem/2;
rem=rem%2;
}
if(p[0]==0)
{
if(p[1]!=0)
{
for(i=0;i<l;i++)
{
p[i]=p[i+1];
}
}
return 1;
}
return 0;
}
int rem(long long int p[],long long int l)
{
int i,rem=0;
for(i=0;i<l;i++)
{
rem=rem*10+p[i];
rem=rem%2;
}
return rem;
}
void mul()
{
int i,j,k,sum;
int c[2][2];
for(i=0;i<2;i++)
{
for(j=0;j<2;j++)
{
sum=0;
for(k=0;k<2;k++)
{
sum=((sum%100)+(y[i][k]*a[k][j])%100)%100;
}
c[i][j]=sum;
}
}
for(i=0;i<2;i++)
{
for(j=0;j<2;j++)
{
y[i][j]=c[i][j];
}
}
} 

int multiplication()
{
int i,j,k,sum;
int c[2][2];
for(i=0;i<2;i++)
{
for(j=0;j<2;j++)
{
sum=0;
for(k=0;k<2;k++)
{
sum=((sum%100)+(a[i][k]*a[k][j])%100)%100;
}
c[i][j]=sum;
}
}
for(i=0;i<2;i++)
{
for(j=0;j<2;j++)
{
a[i][j]=c[i][j];
}
}
return 0;
}
int power(long long int f[],long long int l)
{
int i,j,n,a;
for(i=l-1;i>=0;i--)
{
if(f[i]==1)
{
mul();
}
multiplication();
}
return 0;

}
int main()
{
long long int l,i;
long long int n=0;
long long int f[10000];
char s[10000];
scanf("%s",s);
l=strlen(s);
for(i=0;i<l;i++)
{
f[i]=s[i]-'0';
}
power(f,l);
printf("%d",y[1][0]);
return 0;
}

