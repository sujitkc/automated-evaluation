#include<stdio.h>
#include<math.h>
#include<stdlib.h>
long long int main()
{
	long long int n,k;
	long long int h,count= 0,i,sum = 0;
	int t;
	printf("Number :");
	scanf("%lld",&n);
	k=pow(10,6);
	long long int a[k];
	while(n/10!=0)
	{
		h=n%10;
		n=n/10;
		a[count]=h;
		count++;
	
	}
a[count]=n;
for(i=2;i<=count;i++)
{
	sum=sum+a[i];
	
}
sum = sum%3;
t= (sum*100)+(a[i]*10)+a[0];
printf("%d ",t);
}
