from math import *
D=[1,2,2,2,3,3,3,4,5,5,5,6,7,8,10]
n=int((1+sqrt(1+8*len(D)))/2)
l=[0 for i in range(0,n)]
j=1
p=n
k2=0
b=[]
g=0
a=[]
var=0
temp=0
def backtrack():
        global j,p,l,D,b,g,a,var,temp
        b=[]
        k=0
	if len(a)==0:
		print "It is Impossible"
		temp=1
		return
        m=a.pop()
        ix=l.index(m)
        if ix>=p:
                for i in range(1,j):
			D.append(abs(l[i]-m))
                for i in range(p+1,n):
                        D.append(abs(l[i]-m))
                b.append(m)
                D.append(m)
                m=l[p]
                l[p]=0
                p=p+1            
                c=D[:]
		for i in range(0,j):
                        if abs(l[n-1]-m-l[i]) not in c:
			        k=1
				break 
			else:
			    	c.remove(abs(l[n-1]-m-l[i]))
		for i in range(p,n):
		        if abs(l[n-1]-m-l[i]) not in c:
		    		k=1
		    		break
		    	else:
		    		c.remove(abs(l[n-1]-m-l[i]))
		if k==0:
		    	l[j]=l[n-1]-m
		    	j=j+1
                        a.append(l[n-1]-m)
		    	for i in range(0,j-1):
				D.remove(abs(l[n-1]-m-l[i]))
			for i in range(p,n):
				D.remove(abs(l[n-1]-m-l[i]))
                        func()
                else:
                        
                        backtrack()
        elif ix<j:
                for i in range(1,j-1):
			D.append(abs(l[i]-m))
                for i in range(p,n):
                        D.append(abs(l[i]-m))
                b.append(m)
                D.append(m)        
                l[ix]=0
                j=j-1
                backtrack()                      	 
def func():
	global j,p,l,k2,g,b,a,var,flag
	if temp==1:
		return
        m=0
	for i in D:
		if i>m and i not in b:
			m=i
	k=0
	c=D[:]
	for i in range(0,j):
		if abs(m-l[i]) not in c: 
			k=1
			break
		else:	
			 c.remove(abs(m-l[i]))
	for i in range(p,n):
		if abs(m-l[i]) not in c:
			k=1
			break
		else:
			c.remove(abs(m-l[i]))
	if k==0:
		l[p-1]=m
                a.append(m)
		p=p-1
		k2=1
		for i in range(0,j):
			D.remove(abs(m-l[i]))
		for i in range(p+1,n):
			D.remove(abs(m-l[i]))
	else:
		k=0
		c=D[:]
		for i in range(0,j):
			if abs(l[n-1]-m-l[i]) not in c:
				k=1
				break 
			else:
				c.remove(abs(l[n-1]-m-l[i]))
		for i in range(p,n):
			if abs(l[n-1]-m-l[i]) not in c:
				k=1
				break
			else:
				c.remove(abs(l[n-1]-m-l[i]))
		if k==0:
			l[j]=l[n-1]-m
                        a.append(l[n-1]-m)
			j=j+1
			k2=2
			for i in range(0,j-1):
				D.remove(abs(l[n-1]-m-l[i]))
			for i in range(p,n):
				D.remove(abs(l[n-1]-m-l[i]))
		else:
                        backtrack()
        if len(D)==0:
		count=0
		for i in l:
			if i==0:
				count=count+1
		if count>1:
			flag=1			
			print "It is Impossible"			
                return
        else:
                func()
func()
if temp==0:
	print l
