#include <stdio.h>
#include <stdlib.h>
void merge(int a[],int l,int m,int r)
{
	int b[r-l+1];
int x=m+1,k=l,temp[r-l+1],s=0;
	while(x<=r && k<=m)
	{
		if(a[x]<=a[k])
			{
			b[s++]=a[x++];
			}	
		else
			{
			b[s++]=a[k++];
			}
	}
while(x<=r)
{
	b[s++]=a[x++];
}
while(k<=m)
	{
			b[s++]=a[k++];
			}
for(int i=0;i<s;i++)
a[l+i]=b[i];
}

void sort(int a[],int l,int r)// dividing the array
{
if(l<r){
int m=(r+l)/2;
sort(a,l,m);
sort(a,m+1,r);

merge(a,l,m,r);
}
}
void print(int a[],int size)
{
int i;
for(i=0;i<size;i++)
	{
	printf("%d ",a[i]);
	}
	printf("/n");
}
int main()
{
int size,i;
scanf("%d",size);
int arr[size];
for(i=0;i<size;i++)
	{
		scanf("%d",&arr[i]);
	}
print(arr,size);
sort(arr,0,size-1);
printf("\n\n");
print(arr,size);
}
