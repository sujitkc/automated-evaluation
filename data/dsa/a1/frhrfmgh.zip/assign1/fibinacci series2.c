#include<stdio.h>
int fibinacci(int n);
int fibinacci(int n)
{
	
	
	if(n==0||n==1)
	{
		return n;
	}
	else
	{
		return fibinacci(n-1)+fibinacci(n-2);
	}
}
int main( int n)
{
	printf("%d",fibinacci(4));
}

