#include<stdio.h>
void quicksort(int a[], int first, int last)
{
    int pivot,temp, index1, index2;
    if(first<last)
    {
        pivot= first;
        index1 = first;
        index2 = last;
        while(index1<index2)
        {
            while(a[index1]<=a[pivot] && index1<last)
            {
                index1++;
            }
            while(a[index2]>a[pivot])
            {
                index2--;
            }
            if(index1<index2)
            {
                temp = a[index1];
                a[index1] = a[index2];
                a[index2] = temp;
            }
        temp = a[pivot];
        a[pivot] = a[index2];
        a[index2] = temp;
        quicksort(a, first, index2-1);
        quicksort(a, index2+1, last);
    }
}
}

int main()
{
    int array[100],n,i;
    printf("Enter the number of element you want to Sort : ");
    scanf("%d",&n);
    printf("Enter Elements in the list : ");
    for(i = 0; i < n; i++)
    {
        scanf("%d",&array[i]);
    }
    quicksort(array,0,n-1);
    printf("Sorted elements: ");
    for(i=0;i<n;i++)
    printf(" %d",array[i]);
    return 0;
}
