#include <stdio.h>
#include <stdlib.h>
int b[10];
void merge(int a[],int left,int mid,int right)
{
int p=mid+1,k=left,n=0,i;
	while(p<=right && k<=mid)
	{
		if(a[p]<=a[k])
			{
			b[n]=a[p];
			n++;
			p++;
			}	
		else
			{
			b[n]=a[k];
			n++;
			k++;
			}
	}
while(p<=right)
{
	b[n]=a[p];
	n++;
	p++;
}
while(k<=mid)
	{
			b[n]=a[k];
			n++;
			k++;
			}
for(i=0;i<n;i++)
a[left+i]=b[i];
}

void sort(int a[],int left,int right)
{
if(left<right)
{
int mid=(right+left)/2;
sort(a,left,mid);
sort(a,mid+1,right);

merge(a,left,mid,right);
}
}
void print(int a[],int size)
{
int i;
for(i=0;i<size;i++)
	{
	printf("%d\n ",a[i]);
	}
}
int main()
{
int size=9,arr[9],i;
for(i=0;i<size;i++)
	{
	arr[i]=rand()%18;
	}
	
print(arr,size);
sort(arr,0,8);
printf("\n\n");
print(b,size);
}

