#include<stdio.h>
#include<math.h>
void fibonacci(int t);

int main()
{
    long long int n,k;
    long long int p,count=0,i,sum=0;
    int t;
    printf("Enter the No:");
    scanf("%lld",&n);
    k=pow(10,6);
    long long int a[k];
    while(n/10!=0)
    {
    p=n%10;
    n=n/10;
    a[count]=p;
    count++;
    } 
    a[count]=n;
    for(i=2;i<=count;i++){
        sum=sum+a[i];
    }
    sum=sum%3;
    t=(sum*100)+(a[1]*10)+a[0];
      fibonacci(t+1);
      return 0;
}
void fibonacci(int t)
{
    long long int r;
    long long int a[t];
    a[0]=0;
    a[1]=1;
   for (r=2;r<t;++r)
    {
       a[r]=(a[r-1]+a[r-2])%100;
    }
    printf("%lld\n",a[t-1]);
}
