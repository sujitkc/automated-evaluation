#include<stdio.h>	
#include<string.h>
#include<math.h>
void half(char *s)
{
    char c[1001];
    int i,a=0,p=0,q=0;
    int n=strlen(s);
    for(i=0;i<1001;i++)
        c[i]='0';
    if(n==1 && s[0]<'2')
    {
        c[0]='0';
        q=1;
    }
    else
        for(i=0;i<n;i++)
        {
            a=s[i]-48;
            a=p*10+a;
            if(a<2)
            {
	        p=a;
	        if(i!=0)
	        {
  	        	c[q]='0';
		        q++;
	        }
         }
            else
            {
                if(q!=0||(a/2)!=0)
                {
                    c[q]=a/2+48;
                    q++;
                }
                if(a%2==1)
                    p=1;
                else
                    p=0;            
            }
        }
        c[q]='\0';
        strcpy(s,c);
}
void matrixmultiplication(int *A,int *B)
{
    int i,j,k;
    int RESULT[2][2]={{0,0},{0,0}};
    for(i=0;i<2;i++)
        for(j=0;j<2;j++)
            for(k=0;k<2;k++)
                RESULT[i][j]=RESULT[i][j]+(*((A+i*2)+k))*(*((B+k*2)+j));
    for(i=0;i<2;i++)
        for(j=0;j<2;j++)
           *((A+i*2)+j)=RESULT[i][j]%100;
}
int main()
{
    char s[1001];
    scanf("%s",s);
    int l;
    l=strlen(s);
    int i,p=0,q=0,x;
    char c[1001];
    int A[2][2]={{1,1},{1,0}};
    int I[2][2]={{1,0},{0,1}};
    int number=0;
    int m1=0;
    while(s[0]!='0')
    {
        if(s[strlen(s)-1]%2==1)
        matrixmultiplication((int *)I,(int *)A);
        matrixmultiplication((int *)A,(int *)A);
        half(s);       
    }
    printf("%d\n",I[1][0]);
    return 0;
}
