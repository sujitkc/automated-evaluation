#include <stdio.h>
#include<math.h>
int main()
{
    long long int i, n,p;
    p=pow(10,6);
    long long int a[p];
    printf("Enter the req number: ");
    scanf("%lld", &n);

    a[0]=0;
    a[1]=1;

    for (i=2;i<=p;++i)
    {
       a[i]=(a[i-1]+a[i-2])%100;
    }
    printf("%lld\n",a[n]);
    return 0;
}
