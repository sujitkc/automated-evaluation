#include<stdio.h>
#include<stdlib.h>
int partition(int a[],int l,int r);
void quicksort(int a[],int l,int r);
void swap(int a[],int i,int j)
{
	int temp=a[i];
	a[i]=a[j];
	a[j]=temp;
}

void quicksort(int a[],int l,int r)
{
	int pivot,p;
	if((r-l)>=0)
	{
		p=partition(a,l,r);
		quicksort(a,l,p-1);
		quicksort(a,p+1,r);

	}
}
int partition(int a[],int l,int r)
{
	int pivot=r,i=l,j=r;
	while(i<j)
		{
		while((a[i]<=a[pivot]&&(i<r)))
			{
				i++;
			}
		while((a[j]>a[pivot]))
			{
				j--;
			}
		if(i<j)
		{
		swap(a,i,j);
		i++;
		j--;			
		}
	}
	swap(a,i,pivot);
	return i;
}
main()
{
int size=1000000,arr[1000000],i;
for(i=0;i<size;i++)
	{
	arr[i]=rand()%1000000;
	}

quicksort(arr,0,size-1);
for(i=0;i<size;i++)
	{
	printf("\n%d",arr[i]);
	}
}
