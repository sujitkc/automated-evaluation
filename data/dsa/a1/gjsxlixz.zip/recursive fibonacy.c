#include<stdio.h>
#include<stdlib.h>
long long int recur(int n);
long long int recur(int n)
{
	if((n==0)||(n==1))
	{
		return n;
	}
	return recur(n-2)+recur(n-1);	
}


main()
{
int n;
scanf("%d",&n);
printf(" %lld ",recur(n));

}
