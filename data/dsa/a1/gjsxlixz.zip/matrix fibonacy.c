#include<stdio.h>

void multi(int a[][2],int b[][2])
{
	int c[2][2]={{0,0},{0,0}},i,j,k;
	
	for(i=0;i<2;i++)
	for(j=0;j<2;j++)
	for(k=0;k<2;k++)
	c[i][k]+=a[i][j]*b[j][k];
	for(i=0;i<2;i++)
	for(j=0;j<2;j++)
	a[i][j]=c[i][j];
}

main()
{
	int n,i;
	scanf("%d",&n);
	int a[2][2]={{1,1},{1,0}},a2[2][2]={{1,1},{1,0}};
	for(i=2;i<=n;i++)
	{
		multi(a,a2);
	}
	if((n==0))
	{
	printf("%d",0);	
	}
	else
	{
		printf("%d",a[1][0]);
	}
}
