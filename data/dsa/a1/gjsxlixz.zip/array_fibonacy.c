#include<stdio.h>
#include<stdlib.h>

main()
{
	int i,n,a[3];
	scanf("%d",&n);
	a[0]=0;
	a[1]=1;
	a[2]=1;
for(i=0;i<(n-2);i++)
{
	a[0]=a[1];
	a[1]=a[2];
	a[2]=a[1]+a[0];
}
printf("\nfibonacy=%d",a[2]);
}
