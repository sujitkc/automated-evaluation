#include<stdio.h>
#include<stdlib.h>
void mergesort(int a[100000],int i,int j);
void merge(int a[100000],int i,int k,int j);
void mergesort(int a[100000],int i,int j)
	{
		int t,k;
		if(i==j-1)
		{
			if(a[i]>a[j])
			{
			t=a[i];
			a[i]=a[j];
			a[j]=t;
			}
		}
		else
		{
			if(j>i+1)
			{
			k=(i+j)/2;
			mergesort(a,i,k);
			mergesort(a,k+1,j);
			merge(a,i,k,j);
			}
		}
	}
void merge(int a[100000],int i,int k,int j)
	{
		int l,r,p=0,b[j+1];
		l=i;
		r=k+1;
		while((l<=k)&&(r<=j))
		{
			if(a[l]<a[r])
			{
				b[p]=a[l];
				p++;
				l++;
			}
			else
			{
				b[p]=a[r];
				p++;
				r++;
			}
		}
		while(l<=k)
		{
			b[p]=a[l];
			l++;
			p++;
		}
		while(r<=j)
		{
			b[p]=a[r];
			r++;
			p++;
		}
		p=0;
		for(l=i;l<=j;l++)
		{
			a[l]=b[p];
			p++;
		}
	}
int main()
{
	int a[100000],b[100000],i,j;
	for(i=0;i<100000;i++)
	{
		a[i]=rand()%100000;
		b[i]=0;
	}
	i=0;
	j=100000;
	mergesort(a,i,j);
	for(i=0;i<100000;i++)
	{
		printf("%d",a[i]);
	}
	return 0;
}
