n=input("Give the total umber of points: ")
maxLimit=input("Enter the maximum distance: ")

from random import randint

def distance_set(S):
    A=list()
    for i in range(len(S)):
        for j in range(0,i):
            A.append(abs(S[j]-S[i]))
    A.sort()
    return A
def search_sol(A,a,n,start,end):
    if(len(A)==0):
        return True
    mx=max(A)
    rem=[]
    try:
        for i in range(start)+range(end,n):
            A.remove(abs(mx-a[i]))
            rem.append(abs(mx-a[i]))
        a[end-1]=mx
        sol=search_sol(A,a,n,start,end-1)
        if(sol):return True
    except:
        pass

    a[end-1]=0
    A.extend(rem)

    rem=[]
    mx=max(a)-mx
    try:
        for i in range(start)+range(end,n):
            A.remove(abs(mx-a[i]))
            rem.append(abs(mx-a[i]))
        a[start]=mx
        sol=search_sol(A,a,n,start+1,end)
        if(sol):return True
    except:
        pass

    a[start]=0
    A.extend(rem)

def solve(A,n,a):
    a[0]=0
    a[n-1]=max(A)
    A.remove(max(A))

    if search_sol(A,a,n,1,n-1):
        return True
    else:
        return False

def generate_points(n,maxLimit):
    S=range(n)

    for i in range(1,maxLimit):
        S[i%n]=i
    S[0]=0
    S[n-1]=maxLimit
    S.sort()
    return S



S=generate_points(n,maxLimit)
A=distance_set(S)
print "Original points are: " , S
print "distance set: ",A
a=[0 for _ in range(n)]

solve(A,n,a)

print "Reconstructed set is"
print a
