#include <stdio.h>

int fibbonacci(int n) {
   if(n == 0){
      return 0;
   } else if(n == 1) {
      return 1;
   } else {
      return (fibbonacci(n-1) + fibbonacci(n-2))%100;
   }
}

void main() {
   int n;
scanf("%d",&n);
   int i;
   printf("%d ",n);        
   }
}
