#include<stdio.h>
#include<math.h>
void power(int a[][2],int b[][2])
{
	int c[2][2]={{0,0},{0,0}};
	
	for(int i=0;i<2;i++)
	for(int j=0;j<2;j++)
	for(int k=0;k<2;k++)
	c[i][k]+=a[i][j]*b[j][k];
	for(int i=0;i<2;i++)
	for(int j=0;j<2;j++)
	a[i][j]=c[i][j];
}
int fib(int arr[],int n)
{
	int a[2][2]={{1,1},{1,0}},r[2][2]={{1,0},{0,1}};
	for(int i=0;i<n;i++)
	{
		if(arr[i]==1)
	{
			power(r,a);
	}
			power(a,a);
	}
	return r[1][0];	
}

int dec_2_bin(int n)
{	n=n-1;
	int s;
	if(n!=0)
	s=(log(n)/log(2))+1;
	else
	s=1;
	int arr[s];
	for(int i=0;i<s;i++)
	{
		arr[i]=n%2;
		n=n/2;
	}
	return fib(arr,s);
}
int main()
{
printf("%d",dec_2_bin(2));
}
