#include<stdio.h>
int fibonacci(){
    int n,m,k;
    int arr[100];
    arr[0]=0;
    arr[1]=1;
    for(k=2;k<6*n;k++){
    arr[k]=(arr[k-1]+arr[k-2])%m;
if ((arr[k]==1) && (arr[k-1]==0))
    return (k-1);    
    }
  return -1;
  }
int main()
{int n,m;
printf("Enter the index");
scanf("%d",&n);
printf("Enter the dividend");
scanf("%d",&m);
int arr[6*m];
int a;
a=fibonacci(arr,n,m);
if(c!=-1)printf("The %d th no. of the sequence is %d",n,f[n%c]);
else printf("The %d th no. of the sequence is %d",n,f[n]);
}

