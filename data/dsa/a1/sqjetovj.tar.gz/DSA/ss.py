a = [4,2,1,10,5,3,100]
def selectionSort(a):
	for i in range(len(a)):
		mini = min(a[i:]) 
		min_index = a[i:].index(mini) 
		a[i + min_index] = a[i] 
		a[i] = mini                  
	print a
selectionSort(a)

