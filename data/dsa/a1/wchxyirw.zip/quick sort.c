#include<stdio.h>
#include<stdlib.h>

void swap (int *a,int *b);
int random_pivot(int n,int arr[n],int i,int j);
int partition(int n,int arr[n],int i,int j,int p);
int rqs(int n,int arr[n],int i,int j);


int main()
{
  int i,n=100000,arr[n];

  for(i=0;i<n;i++){arr[i]=rand()%300;}

  rqs(n,arr,0,n-1);
return 0;
}



void swap (int *a,int *b)
        {
            int temp;
            temp=*a;
            *a=*b;
            *b=temp;
         }


int random_pivot(int n,int arr[n],int i,int j)      {return arr[i+rand()%(j-i+1)];}



int partition(int n,int arr[n],int i,int j,int p){
int a=i,b=j;
int f,k=-2;
while(a<b){
while(arr[a]<p){a++;}
while(arr[b]>=p&&b>=0){	if(k<0&&arr[b]==p){k=b;}			b--;}

      if(b>a){swap(&arr[a],&arr[b]);}
     else if(b<a&&arr[a]!=arr[k]){swap(&arr[a],&arr[k]);}
        }

return a;
}


int rqs(int n,int arr[n],int i,int j){

int p,k,temp;
p=random_pivot(n,arr,i,j);
if(i==j){return arr[n];}
if(j==i+1){if(arr[i]>arr[j]){swap(&arr[i],&arr[j]);}return arr[n];}
k=partition(n,arr,i,j,p);
if(k!=i){rqs(n,arr,i,k-1);}
if(k!=j){rqs(n,arr,k+1,j);}
return arr[n];
}
