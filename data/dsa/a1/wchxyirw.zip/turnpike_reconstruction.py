d=[1,2,2,2,3,3,3,4,5,5,5,6,7,8,10]
n=[0]
maximum=d.pop()
n.append(maximum)

def differance(num1,num2):    

    if num1-num2>0:        
        return num1-num2
    else:
        return num2-num1


def check_status(num):
 
    new_arr=[]
    for i in range(0,len(n)):
        temp=differance(n[i],num)
        for j in range(0,len(d)):
            if temp==d[j]:
                new_arr.append(d[j])
                d.remove(d[j])
                break

    if len(new_arr)==len(n):        
        n.append(num)
        return True
    else:
        d.extend(new_arr)
        return False



def pike(d):
    if len(d)==0:
        return True
    if len(n)==1:
        return False
    if check_status(max(d))==True:
        if pike(d)==False:
            N=n.pop()
            for i in n:
                d.append(differance(N,i))
        else:
           return True        
    if check_status(maximum-max(d))==True:
        return pike(d)
    

    return False    


if pike(d)==True:
    print n
else:
    print 'not possible'
