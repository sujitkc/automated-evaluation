#include<stdio.h>
int fib(int n)
{
int i,a=0,b=1,c=1;
if(n==0){return a;}
if(n==1){return b;}
if(n==2){return c;}
for(i=3;i<=n;i++){
    a=b;
    b=c;
    c=(a+b)%100;
}
return c;
}
int main()
{
printf("%d",fib(295739549374));
return 0;
}
