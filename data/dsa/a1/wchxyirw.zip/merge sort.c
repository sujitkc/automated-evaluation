#include<stdio.h>

void swap (int *a,int *b);
void merge(int n,int arr[n],int i,int k,int j);
int ms(int n,int arr[n],int i,int j);
int main()
{
int i,n=100000,arr[n];
for(i=0;i<n;i++){arr[i]=rand()%200;}
ms(n,arr,0,n-1);

return 0;
}


void merge(int n,int arr[n],int i,int k,int j){
int a=0,p=i,q=k+1,z,b[n];
while(p<=k&&q<=j){

if(arr[p]<arr[q]){b[a]=arr[p];a++;p++;}
else{b[a]=arr[q];a++;q++;}


}

while(p==k+1&&q<=j){b[a]=arr[q];a++;q++;}
while(q==j+1&&p<=k){b[a]=arr[p];a++;p++;}
z=0;
while(z!=a){arr[i]=b[z];
i++;z++;}


}




















void swap (int *a,int *b)
        {
            int temp;
            temp=*a;
            *a=*b;
            *b=temp;
         }



int ms(int n,int arr[n],int i,int j)
{

int k;
k=(i+j)/2;
if(i==j){return arr[n];}
if(i+1==j){if(arr[i]<=arr[j]){return arr[n];}
	else{ swap(&arr[i],&arr[j]);return arr[n];}}

ms(n,arr,i,k);
ms(n,arr,k+1,j);
merge(n,arr,i,k,j);
return arr[n];
}
