#include<stdio.h>
int is(int n,int arr[n]);
int main()
{
int i,n=500000,arr[n];
for(i=0;i<n;i++){arr[i]=rand()%200;}
is(n,arr);
    return 0;}

int is(int n,int arr[n])
{

int i,j,m;
for(i=1;i<n;i++){
        j=i-1;
        m=arr[i];
while(j>=0&&arr[j]>m){

    arr[j+1]=arr[j];
              j--;

}
arr[j+1]=m;

}
return arr[n];
}
