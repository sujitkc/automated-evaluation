#include<stdio.h>
#include<stdlib.h>
int period(int k);
int fib(int n,int k);
int remainder(int *arr,int n,int k);
int main()
{
int i,p,r,f,m=75,n=100000,arr[n];

for(i=0;i<n;i++){arr[i]=rand()%10;}

p=period(m);
r=remainder(arr,n,p);
f=fib(r,m);
printf("%d %d %d",p,r,f);
return 0;
}

int period(int k)
{
int i,a=0,b=1,c=1,d=2;
for(i=3;i<=(6*k);i++){

	a=b;
	b=c;
	c=d;
	d=(c+b)%k;

if(c==0&&d==1){return i;}
}}

int fib(int n,int k){

int i,a=0,b=1,c=1;
if(n==0){return 0;}
if(n==1){return 1;}
if(n==2){return 1;}
for(i=3;i<=n;i++){
a=b;
b=c;
c=(a+b)%k;
}
return c;
}

int remainder(int *arr,int n,int k){

int i=0,p=0;
while(i<n){

    while(p<=k&&i<n){

        p=p*10+arr[i];
        i++;
        }
    p=p%k;
}
return p;
}
