#include<stdio.h>
int ss(int n,int arr[n]);
void swap (int *a,int *b);
int main()
{
int i,n=500000,arr[n];

for(i=0;i<n;i++){arr[i]=rand()%200;}
     ss(n,arr);
    return 0;
}

void swap (int *a,int *b)
        {
            int temp;
            temp=*a;
            *a=*b;
            *b=temp;
         }

int ss(int n,int arr[n]){
int i,j;
for(i=0;i<n-1;i++){
int m=0;
for(j=0;j<n-i;j++){
if(arr[m]<arr[j]){m=j;}
}
if(m!=n-i-1){swap(&arr[m],&arr[n-i-1]);}
}
return arr[n];
}
