#include<stdio.h>
void multiply(int *mat1,int *mat2);
int fib(int *arr,int n);
int size(int n);
void binary(int *arr,int n);
int main()
{
int n=568773428;
int l=size(n);
int i,arr[l];
for(i=0;i<l;i++){arr[i]=0;}
for(i=l-1;i>=0;i--)
{
arr[i]=(n%2);
n=n/2;
}

printf("%d",fib(arr,l));
return 0;
}

int size(int n)
{
    int k=1,count=0;
    while(k<=n)
    {
        k=2*k;
        count++;

    }
    return count;
}








void multiply(int *mat1,int *mat2){


int newmat[4],i;

newmat[0]=(mat1[0]*mat2[0])+(mat1[1]*mat2[2]);
newmat[1]=(mat1[0]*mat2[1])+(mat1[1]*mat2[3]);
newmat[2]=(mat1[2]*mat2[0])+(mat1[3]*mat2[2]);
newmat[3]=(mat1[2]*mat2[1])+(mat1[3]*mat2[3]);


for(i=0;i<4;i++){mat1[i]=(newmat[i])%100;}
}

int fib(int *arr,int n){
int y[4]={1,0,0,1};
int x[4]={1,1,1,0};
int i=n-1;
while(i>=0){
if(arr[i]==1){multiply(y,x);}
multiply(x,x);
i--;
}
return y[2];
}
