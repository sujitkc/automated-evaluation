#include<stdio.h>
#include<stdlib.h>
struct Node{
int data;
struct Node *next;
};


struct Node* insert(struct Node *headnode,int data);
int operation(struct Node *lkl);


int main()
{
struct Node *new_head;
new_head=NULL;
int i,j,n;
n=10000;
struct Node *arr[n];
for(i=0;i<n;i++){arr[i]=NULL;}
for(i=0;i<10*n;i++){

    j=rand()%n;
    arr[j]=insert(arr[j],rand()%100);
}
for(i=0;i<n;i++){
    if(arr[i]!=NULL&&arr[i]->next==NULL){new_head=insert(new_head,arr[i]->data);}
    else if(arr[i]!=NULL){new_head=insert(new_head,operation(arr[i]));}
}
printf("%d\n",operation(new_head));

return 0;
}





struct Node* insert(struct Node *headnode,int data)
{

struct Node *newnode,*tempnode;

if(headnode==NULL){
headnode=(struct Node*)malloc(sizeof(struct Node));
headnode->data=data;
headnode->next=NULL;
return headnode;}

newnode=(struct Node*)malloc(sizeof(struct Node));
newnode->data=data;
newnode->next=NULL;
tempnode=headnode;

while(tempnode->next!=NULL){tempnode=tempnode->next;}
tempnode->next=newnode;
return headnode;
}




int operation(struct Node *lkl)
{

struct Node *nextnode;

nextnode=lkl->next;

while(nextnode!=NULL){
if(lkl->data%2==0&&nextnode->data%2==0)
    {
    if(lkl->data<nextnode->data){ nextnode=nextnode->next; lkl->next=nextnode;}
    else{lkl=nextnode; nextnode=nextnode->next;}
    }
else if(lkl->data%2!=0&&nextnode->data%2!=0){

    if(lkl->data>nextnode->data){ nextnode=nextnode->next; lkl->next=nextnode;}
    else{lkl=nextnode; nextnode=nextnode->next;}

    }
else{

    if(lkl->data%2!=0){lkl=nextnode; nextnode=nextnode->next;}
    else{nextnode=nextnode->next; lkl->next=nextnode;}
}
}
return lkl->data;
}
