#include<stdio.h>
void multiply(int *mat1,int *mat2);
int fib(int n);
int main()
{
 printf("%d\n",fib(6));
 return 0;
}

void multiply(int *mat1,int *mat2){


int newmat[4],i;

newmat[0]=(mat1[0]*mat2[0])+(mat1[1]*mat2[2]);
newmat[1]=(mat1[0]*mat2[1])+(mat1[1]*mat2[3]);
newmat[2]=(mat1[2]*mat2[0])+(mat1[3]*mat2[2]);
newmat[3]=(mat1[2]*mat2[1])+(mat1[3]*mat2[3]);


for(i=0;i<4;i++){mat1[i]=(newmat[i])%100;}
}


int fib(int n){

int y[4]={1,0,0,1};
int x[4]={1,1,1,0};
while(n!=0){
 if(n%2==1){multiply(y,x);}
 multiply(x,x);
 n=n/2;
}
return y[2];
}


