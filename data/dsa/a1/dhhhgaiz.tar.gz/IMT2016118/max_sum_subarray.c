#include<stdio.h>
int main()
{

  int a[1000],n,i,c[1000],x,y;
    printf("Enter no of elements:");
    scanf("%d",&n);
    printf("Enter array elements:");
    
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
        
       for(i=1;i<n;i++)
       {
         c[0] = a[0];
         c[i] =  a[i] + c[i-1];
       }
       int index1 = 0;
       for( i = 1; i < n; i++)
        {
            if(c[i] < c[index1])
            {
                index1 = i;
            }
        }
        x = index1;
        int index2 = 0;
        for( i = 1; i < n; i++)
        {
            if(c[i] > c[index2])
            {
                index2 = i;
            }
        }
        y = index2;

        for(i=x+1;i<y+1;i++)
        {
        	printf("%d ",a[i]);
        }
        return 0;

}