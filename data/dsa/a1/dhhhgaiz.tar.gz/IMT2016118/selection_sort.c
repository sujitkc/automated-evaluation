#include<stdio.h>
int main()
{
 int n,i,j,a[100],temp;
 printf("enter the size of array =  ");
 scanf("%d",&n);
 printf("enter the elements of the array \n");
   for(i=0;i<n;i++)
   {
     scanf("%d\n",&a[i]);
   }
   for(j=0;j<n-1;j++)
   {
     	for(i=j+1;i<n;i++)
	 {
	   if(a[i]>a[j])
	      {
                temp=a[i];
		a[i]=a[j];
		a[j]=temp;
	       }
          } 
    }
    for(i=0;i<n;i++)
    {
      printf("%d\n",a[i]);
    }
return 0;
}

