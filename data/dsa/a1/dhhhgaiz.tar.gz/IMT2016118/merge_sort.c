#include<stdio.h>

void sort (int arr[],int a1,int a2,int b1,int b2);
void merge(int arr[],int i, int j);

int main()
{
  int arr[30],n,i;
    printf("Enter no of elements:");
    scanf("%d",&n);
    printf("Enter array elements:");
    
    for(i=0;i<n;i++)
        scanf("%d",&arr[i]);
        
    merge(arr,0,n-1);
    
    printf("\nSorted array is :");
    for(i=0;i<n;i++)
        printf("%d ",arr[i]);
        
    return 0;
}

void sort (int arr[],int a1,int a2,int b1,int b2)
{
  int i,j,k;
  int temp[50];
  i = a1;
  j = b1;
  k = 0;
  while(i<=a2 && j<=b2)
  {
    if(arr[i] < arr[j])
    {
      temp[k] = arr[i];
      i = i+1;
      k = k+1;
    }
    else
    {
      temp[k] = arr[j];
      k = k+1;
      j = j+1; 
    }
  }
    while(i<=a2)
    {
      temp[k] = arr[i];
      i = i+1;
      k = k+1;
    }
    while(j<=b2)
    {
      temp[k] = arr[j];
      j = j+1;
      k = k+1;
    }
    for(i=a1,j=0;i<=b2;i++,j++)
    {
      arr[i] = temp[j];
    }
}

void merge(int arr[],int i, int j)
{
  
  if(i<j)
  {
    int mid = (i+j)/2;

    merge(arr,0,mid);
    merge(arr,mid+1,j);
    sort(arr,0,mid,mid+1,j);
  }
}