#include<stdio.h>
  int fib(int i);
  int main()
{
  int num,i;
  printf("enter the number : ");
  scanf("%d",&num);
  for(i=0;i<num;i++)
  {
    printf("%d\t\n",fib(i));
  }
return 0;
}
int fib(int i)
{
int num;

       if(i==0)
         {
           return 0;
         }
       if(i==1)
         {
	   return 1;
	 }    
           return (fib(i-2) + fib(i-1))%100;
         } 





