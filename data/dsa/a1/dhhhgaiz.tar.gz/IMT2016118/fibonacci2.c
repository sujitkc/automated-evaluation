#include<stdio.h>
int main()
{
	int i,n;
	int arr[10000];
	arr[0] = 0,arr[1] = 1;
	printf("enter the value of n : ");
	scanf("%d",&n);
	for(i=2;i<n;i++)
	{
		arr[i] = (arr[i-1] + arr[i-2])%100;
	}
	printf("%d",(arr[n-1] + arr[n-2])%100);
	return 0;
}
