#include<stdio.h>
int main()
{
	int a,b,c,i,n;
	a = 0;
	b = 1;
	c = a+b;
    printf("enter the value of n : ");
    scanf("%d",&n);
    for(i = 2;i<n;i++)
    {
      a = b;	
      b = c;
      c = (a+b)%100;
    }
    printf("%d\n",c);
    return 0;
}