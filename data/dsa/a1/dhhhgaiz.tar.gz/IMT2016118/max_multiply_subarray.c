#include<stdio.h>
int main()
{

  int a[1000],n,i,b,c,d,e,f,g,h;
    b = 0;
    printf("Enter no of elements:");
    scanf("%d",&n);
    printf("Enter array elements:");
    
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++)
    {
      if(a[i]<0)
      {
        b = b+1;
      }
    }
    d = b;

    if(d%2 == 0)
    {
      for(i=0;i<n;i++)
      {
        printf("%d",a[i]);
      }
    }
    else
    {
      for(i=0;i<n;i++)
      {
        if(a[i]<0)
        {
          c = i;
          break;
        }
      }
      for(i=n-1;i>0;i--)
      {
        if(a[i]<0)
        {
          d = i;
          break;
        }
      }
      for(i=c+1;i<n;i++)
      {
        f = 1;
        e = f*a[i];
        f = e;
      }
      g = e;
      for(i=0;i<d;i++)
      {
        f = 1;
        e = f*a[i];
        f = e;
      }
      h = e;

      if(g>h)
      {
        for(i=c+1;i<n;i++)
        {
          printf("%d ",a[i]);
        }
      }
      else
      {
        for(i=0;i<d;i++)
        {
          printf("%d ",a[i]);
        }
      } 
    }
        
}