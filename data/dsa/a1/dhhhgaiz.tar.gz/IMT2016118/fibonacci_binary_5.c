#include<stdio.h>
void multiply(int b[2][2],int a[2][2]){
	    int temp[2][2];
       	    temp[0][0] = b[0][0]*a[0][0] + b[0][1]*a[1][0];
	    temp[0][1] = b[0][0]*a[0][1] + b[0][1]*a[1][1];
	    temp[1][0] = b[1][0]*a[0][0] + b[1][1]*a[1][0];
	    temp[1][1] = b[1][0]*a[0][1] + b[1][1]*a[1][1];
	    b[0][0]=temp[0][0]%100;
	    b[0][1]=temp[0][1]%100;
	    b[1][0]=temp[1][0]%100;
	    b[1][1]=temp[1][1]%100;
}
int power(int b[2][2],int a[],int n){
	int y[2][2]={{1,0},{0,1}};
	int i=n-1;
	while(i>= 0){
		if(a[i]==1){
			multiply(y,b);
		}
		multiply(b,b);
		i=i-1;
	}
	int j,k;
	for(j=0;j<2;j++){
		for(k=0;k<2;k++){
			b[j][k]=y[j][k];
		}
	}
}
int fibo(int a[],int n)
{
  int b[2][2] = {{1,1},{1,0}};
  
  power(b, a,n);
	int i,j;

  return b[1][0];
}
int main(){
	int n;
	printf("Enter the number: ");
	scanf("%d",&n);
	int a[n],i;
	for(i=0;i<n;i++){
		a[i]=rand()%2;
	}
	printf("Obtained binary number: ");
	for(i=0;i<n;i++){
		printf("%d ",a[i]);}
  	printf("\nFibonacci of number%100 = %d\n", fibo(a,n));
	return 0;
}
