#include <stdio.h>
int linear(int n);
void main()
{
	int c;
	c=linear(999999);
	printf("%d ",c);
}

int linear(int n){
	int a=0;
	int b=1;
	int c=n;
	for(int i=0;i<n;++i){
		c=(a+b)%100;
		a=b;
		b=c;
	}
	return c;
}