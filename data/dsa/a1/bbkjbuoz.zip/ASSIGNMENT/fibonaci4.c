#include<stdio.h>
int multiply(int b[2][2]);
int fibonaci(int n);

int arr[2][2]={{1,1},{1,0}};


int main(){
  int n;
  printf("enter the position: ");
  scanf("%d",&n );
  printf("%d\n",fibonaci(n));
  return 0;
}



int fibonaci(int n){
  int arr[2][2]={{1,1},{1,0}};
  int q,i;
 if (n==1){return 0;}
 if (n==2){return 1;}
 if(n>2){
  for( i=0;i<n-2;i++){
    q=multiply(arr);
  }
}
  q=q%100;
    return q;
  }



int multiply(int b[2][2]){
  int c[2][2];
  int i=0,j=0;
  for(i=0;i<2;i++){
    for(j=0;j<2;j++){
      c[i][j]=(arr[i][0]*b[0][j])+(arr[i][1]*b[1][j]);
    }
  }
  for(i=0;i<2;i++){
    for(j=0;j<2;j++){
      arr[i][j]=c[i][j]%100;
    }
  }
  return arr[1][0];
}
