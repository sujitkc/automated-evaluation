#include <stdio.h>
int rec(int n);
void main(){
 int a=rec(100); 
 printf("%d",a);
}

int rec(int n){
	if(n<2){return n;}
	else {return (rec(n-1)+rec(n-2)%100);}
}