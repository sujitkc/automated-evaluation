#include<stdio.h>
int i(int n,int d){
  if(n==0){
    return 0;
  }
  int a=0,j,b=1,c;
  for(j=2;j<=n;j++){
    c=(a+b)%d;
    a=b;
    b=c;
  }
  return b;
}
int main()
{ int d;
  printf("enter the divisor\n");
  scanf("%d",&d);
  printf("enter the number\n");
  int n;
  scanf("%d",&n);
  int q=2;
  while(1==1){
    if(i(q,d)==i(0,d) && i(q+1,d)==i(1,d)){
      printf("periodicity is %d\n",q);
      break;
    }
    q=q+1;
  }
  while(n>q){
    n=n%q;
  }

  printf("%d\n",i(n,d));
  return 0;
}
