#include <stdio.h> 
void mergesort(int a[],int i,int j);
void merge(int a[],int i1,int j1,int j2);
int main()
{
    int a[1000000],i;
    int n=1000000;
    for(i=0;i<n;i++){
        a[i]=n-i;
    }
    mergesort(a,0,n-1);
    return 0;
}
 
void mergesort(int a[],int i,int j)
{
    int mid,temp;
     
    if(j=i-1)
    {
    	if(a[i]>a[j])
    	{
    		temp=a[i];
    		a[i]=a[j];
    		a[j]=temp;
    	}
     }   
    else if(j>i+1)
    {
        mid=(i+j)/2;
        mergesort(a,i,mid);   
        mergesort(a,mid+1,j); 
        merge(a,i,mid,j);
    }
}
 
void merge(int a[],int i1,int j1,int j2)
{
    int temp[1000000];    
    int i,j,k;
    i=i1; 
    j=j1+1; 
    k=0;
    
    while(i<=j1 && j<=j2)    
    {
        if(a[i]<a[j])
            temp[k++]=a[i++];
        else
            temp[k++]=a[j++];
    }
    
    while(i<=j1)   
        temp[k++]=a[i++];
        
    while(j<=j2)   
        temp[k++]=a[j++];
        
    
    for(i=i1,j=0;i<=j2;i++,j++)
        a[i]=temp[j];
}

 