#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *next;
};
void del(struct node **head ,int temp);
int main()
{
    int i,k,temp1,temp2,num1;
    struct node *a[10]={0},*temp,*t,*temp3,*p;
     for(i=0;i<20;i++)
     {
         temp=(struct node *)malloc(sizeof(struct node *));
         k=(rand()%10);
         temp->data=rand()%10;
         temp->next='\0';


      if(a[k]=='\0')
         {
             a[k]=temp;
         }
      else
        {  t=a[k];

            while(t->next!='\0')
            {

                     t= t->next;

                }
                t->next=temp;
            }}

            for(i=0;i<10;i++)
            {p=a[i];
                if(p!='\0')
                {while(p->next!='\0')
                {
                    printf("%d\t",p->data);
                    p=p->next;
                }
                printf("%d\n",p->data);
            }else
            printf("null space\n");
            }
            printf("=======================\n");


     for(i=0;i<10;i++)

     {

         if(a[i]!='\0')
         {
              while(a[i]->next!='\0')
             {

                 temp3=(struct node *)malloc(sizeof(struct node *));
                 temp3=a[i];
             while(temp3->next!='\0')
             {
                 temp1=temp3->data;

                 temp3=temp3->next;
                 temp2=temp3->data;

                 if(temp3->next!='\0')
                 {temp3=temp3->next;}
                 if(temp1%2==0 && temp2%2!=0)
                 {
                     del((a+i),temp1);
                 }
              else if( temp1%2!=0 && temp2%2==0 )
                    {del((a+i),temp2);}
                else if(temp1%2==0 && temp2%2==0)
             {if(temp1>temp2)
         del((a+i),temp2);
           else
               del((a+i),temp1);}
                 else{
                  if(temp1<temp2)
                del((a+i),temp2);
                else
              del((a+i),temp1);
}
             }

         }
     }}
     int index;

    for(i=0;i<10;i++)
            {p=a[i];
                if(p!='\0')
                {while(p->next!='\0')
                {
                    printf("%d\t",p->data);
                    p=p->next;
                }
                printf("%d\n",p->data);
            }else
            printf("null space\n");
            }
            printf("========================================\n");
     i=0;
     while(1)
     {
         if(a[i]!='\0')
         {
             temp1=a[i]->data;

             index=i;
             i++;

         while(i!=10)
         {

             if(a[i]!='\0')
             {
                 temp2=(a[i])->data;
if(temp1%2==0 && temp2%2!=0)
                 {
                     a[index]='\0';
                     break;
                 }
else if( temp1%2!=0 && temp2%2==0 )
{a[i]='\0';
break;}
else if(temp1%2==0 && temp2%2==0)
{if(temp1>temp2)
{a[i]='\0';
break;}
else
{a[index]='\0';
break;}}
                 else{
                  if(temp1<temp2)
{a[i]='\0';
break;}
else
{a[index]='\0';
break;
}}

             }i++;}
         }
         k=0;
         int c=0;
         while(i==10 || i==9)
         {  if(a[k]!='\0')
         {
             c++;

            printf("%d\n",a[k]->data);}
             k++;
             if(k==10)
             {
 printf("********\n");
             i=-1;
                break;}
         }

         if(c==1)
         {
             break;
         }
         i++;
         }

		 }

void del(struct node **head,int temp)
{struct node *prev,*temp1;
temp1=(struct node *)malloc(sizeof(struct node *));
    prev=(struct node *)malloc(sizeof(struct node *));
    int i;
prev=*head;
temp1=*head;
if(prev->data==temp)
{
    *head=prev->next;
    free(prev);
    return;
}
while(prev->data!=temp)
{  if(i!=0)
    temp1=temp1->next;
    prev=prev->next;
    i++;
}
temp1->next=prev->next;
}
