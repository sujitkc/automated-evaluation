#include <stdio.h>
void main(){
 int a[1000001];
 a[0]=0;
 a[1]=1;
 for (int i=2;i<1000001;i++){
 	a[i]=(a[i-1]+a[i-2])%100;
 }
 printf("%d",a[1000000]);
}
