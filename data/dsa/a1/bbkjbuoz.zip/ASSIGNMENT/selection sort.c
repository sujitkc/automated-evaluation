#include<stdio.h>
int main()
{
	int i,j,temps,arr[10];
	for(i=0;i<10;i++)
	{
		scanf("%d",arr+i);
	}
	
	
	for(i=0;i<10;i++)
	{
		for(j=i+1;j<10;j++)
		{
			if(arr[j]<arr[i])
			{
				temp=arr[j];
				arr[j]=arr[i];
				arr[i]=temp;
			}
		}
		
		
	}
	for(i=0;i<10;i++)
	{
		printf("%d  ",arr[i]);
	}
	return 0;
	
}
