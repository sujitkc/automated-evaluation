#include<stdio.h>
int main()
{
 int i,j,z,temp,arr[10];
 for(i=0;i<10;i++)
 {
  scanf("%d",arr+i);
 }
 for(i=0;i<10;i++)
 {
  for(j=0;j<(10-i);j++)
  {
   if (arr[j]>=arr[j+1])
   {
     temp=arr[j];
     arr[j]=arr[j+1];
     arr[j+1]=temp;
   }
  }
 }
 for(z=0;z<10;z++)
 {
  printf("%d\n",arr[z]);
 }
 return 0;
 }
