
import  math, itertools

def turnpike(L, n):

	max_element, L1, L2 = max(L), [], []

	sets = list(itertools.combinations(L, n - 2))
	
	
	
	for set_ in sets:

	
		L2.append(max_element)
		L2.append(0)
		for e in set_:
			L2.append(e)
	
		L2.sort()

	
		for i in range(n):
			for j in range(i + 1, n):
				L1.append(L2[j] - L2[i])
		L1.sort()

		
		if L == L1:
			return L2

		del L2[:]
		del L1[:]

	return None


if __name__ == "__main__":
        a = raw_input("enter the elements")
	
        L=map(int,a.split(" "))
        
        len_L = len(L)

	
        d = math.sqrt(1 + 8 * len_L)
        n = (1 + d) / 2

        solution = turnpike(L, int(n))
        if solution:
                print(' '.join(str(e) for e in solution))
