#include<stdio.h>
int fibonacci(int n)
{
	int a,b,c;
	a=0;
	b=1;
	int i;
	for(i=2;i<=n;i++)
	{
		c=a+b;
		a=b;
		b=c;
	}
	return c;
}
int main()
{
	int q;
	q=fibonacci(10);
	printf("%d ",q);
	return 0;
}
