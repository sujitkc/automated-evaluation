#include<stdio.h>

int partition(int a[],int p,int r)
{
	int temp1,temp2,x,i,j;
	x=a[r];
	i=p-1;
	for(j=p;j<r;j++)
	{
		if(a[j]<=x)
		{	i=i+1;
			temp1=a[i];
			a[i]=a[j];
			a[j]=temp1;
		}
	}
	temp2=a[i+1];
	a[i+1]=a[j];
	a[j]=temp2;
	return i;
	
	
}

void quicksort(int a[],int p,int r)
{int q;
	if(p<r)
	{
		q=partition(a,p,r);
		quicksort(a,p,q);
		quicksort(a,q+1,r);
		
	}
}
void printarray(int a[])
{
	int i;
	for(i=0;i<6;i++)
	{
		printf("%d ",a[i]);
	}
}

void main()
{
	int a[]={2,1,9,8,4};
	quicksort(a,0,5);
	printarray(a);
}

