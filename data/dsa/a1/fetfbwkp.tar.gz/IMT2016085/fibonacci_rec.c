#include<stdio.h>
int rec(int n)
{
	if(n<2)
		return n;
	else
		return (rec(n-1)+rec(n-2));	
}
int main()
{	int r;
	r=rec(10);
	printf("%d ",r);
	return 0;
}
