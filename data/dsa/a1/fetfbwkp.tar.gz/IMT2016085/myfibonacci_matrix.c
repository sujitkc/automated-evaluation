#include<stdio.h>
int fib(int n)
{	int a[2][2]={{1,1},{1,0}};
	if(n==0)
	return 0;
	else
	{
		if(n>=1)
		{
			power(a,n);
		}
	
	}
	return a[1][0];
}
void power(int a[2][2],int n)
{	int q;
	int m[2][2]={{1,1},{1,0}};
	int i;
	for(i=2;i<=n;i++)
	q=multiply(a,m);
}

int multiply(int a[2][2],int m[2][2])
{	
	int x=a[0][0]*m[0][0]+a[0][1]*m[1][0];
	int y=a[0][0]*m[0][1]+a[0][1]*m[1][1];
	int z=a[1][0]*m[0][0]+a[1][1]*m[1][0];
	int w=a[1][0]*m[0][1]+a[1][1]*m[1][1];
	
	a[0][0]=x;
	a[0][1]=y;
	a[1][0]=z;
	a[1][1]=w;
	return z;		
}	
	
int main()
{
	int n=3;
	printf("%d ",fib(n));
	return 0;
}
