#include<stdio.h>

int max_sequence(int a[],int n)
{
	int max_so_far=a[0];
	int curr_max=a[0];
	int i;
	for(i=1;i<n;i++)
	{
		curr_max=max(a[i],curr_max+a[i]);
		max_so_far=max(max_so_far,curr_max);
	}
	return max_so_far;
}

int max(int num1,int num2)
{
	if(num1>num2)
	return num1;
	else
	return num2;
}

int main()
{
	int a[]={-2,-3,4,5,-9,7,4,-1};
	printf("%d",max_sequence(a,8));
	return 0;
}
