#include<stdio.h>


//find rank


void findrank(int a[],int l,int r,int rank)
{
	int k;
	k=partition(a,l,r);
	if(rank-1<r-k)
	findrank(a,k+1,r,rank);
	if(rank-1>r-k)
	findrank(a,l,k,rank);
	
	if((rank-1)==(r-k))
	printf("%d ",a[k]);
}

//partiton

int partition(int a[],int l,int r)
{
	int i,j,temp1,temp2;
	int pivot=a[r];
	i=l-1;
	for(j=l;j<r;j++)
	{
		if(a[j]<=pivot)
		{
			i=i+1;
			temp1=a[i+1];
			a[i+1]=a[j];
			a[j]=temp1;
		}
	}
	temp2=a[i+1];
	a[i+1]=a[j];
	a[j]=temp2;
	return i+1;
}

//main function
int main()
{
	int a[]={9,4,1,3};
	findrank(a,0,3,1);
	return 0;
}
