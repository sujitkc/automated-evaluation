#include<stdio.h>
void BubbleSort(int arr[],int sizeofarr)
{
	for(int i = 0; i<sizeofarr; i++)
	{
		for(int j = 0; j<sizeofarr-1; j++)
		{
			if(arr[j] > arr[j+1])
			{
				int temp = arr[j];
				arr[j] = arr[j+1];
				arr[j+1] = temp;
			}
		}
	}
}
int main()
{
	int arr[] = {9,8,7,6,5,4,3,2,1,0};
	BubbleSort(arr,10);
	for(int i = 0; i<10; i++)
	{
		printf("%d ",arr[i]);
	}
	printf("\n");
}