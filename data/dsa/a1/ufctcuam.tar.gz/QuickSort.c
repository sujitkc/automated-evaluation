#include<stdio.h>
#include <stdlib.h>
int partition(int arr[],int left, int right, int p)
{
	int l = left;
	int r = right;
	int temp;
	while(l <= r)
	{
		while(l<=r && arr[l] <= p)
		{
			l++;
		}
		while(l<=r && arr[r] > p)
		{
			r--;
		}
		if(l<r)
		{
			temp = arr[l];
			arr[l] = arr[r];
			arr[r] = temp;
			l++;
			r--;
		}
	}
	return r;
}
void QuickSort(int arr[],int left,int right)
{
	int temp;
	if(right == left+1)
	{
		if(arr[right] < arr[left])
		{
			temp = arr[right];
			arr[right] = arr[left];
			arr[left] = temp; 
		}
		return;
	}
	else if(left >= right)
	{
		return;
	}
	int p  = arr[left + rand() % (right-left+1)];
	int k = partition(arr,left,right,p);
	QuickSort(arr,left,k);
	QuickSort(arr,k+1,right);
}
int main()
{
	int arr[10] = {10,9,8,7,6,5,4,3,2,1};
	QuickSort(arr,0,9);
	for(int i = 0; i<10; i++)
	{
		printf("%d ",arr[i]);
	}
	return 0;
}