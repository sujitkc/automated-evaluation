#include<stdio.h>
#include<math.h>
void Matrixmultiply(int a[2][2], int b[2][2], int x[2][2])
{
	int i,j,k;
	int c[2][2] = {{0,0},{0,0}};
	for(i = 0; i<2; i++)
	{
		for(j = 0; j<2; j++)
		{
			for(k = 0; k<2; k++)
			{
				c[i][j] += a[i][k] * b[k][j];
			}
			c[i][j] = c[i][j] % 100;
		}
	}
	for(int i  = 0; i<2; i++)
	{
		for(int j = 0 ;j<2; j++)
		{
			x[i][j] = c[i][j];
		}
	}
}
int Fibonacci(int binary[],int sizeofbin)
{
	int A[2][2] = {{1,1},{1,0}};
	int Answer[2][2] = {{1,0},{0,1}};
	int x = sizeofbin-1;
	while(x>=0)
	{
		if(binary[x] == 1)
		{
			Matrixmultiply(Answer,A,Answer);
		}
		Matrixmultiply(A,A,A);
		x--;
	}
	return Answer[1][0];
}
int main()
{
	int binary[] = {1,1,0,0};
	printf("%d\n",Fibonacci(binary,4));
}