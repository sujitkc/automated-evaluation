#include<stdio.h>
void SelectionSort(int arr[], int sizeofarr)
{
	int max,maxind = 0;
	for(int i = 0; i<sizeofarr-1; i++)
	{
		max = arr[0];
		for(int j = 1; j<sizeofarr-i; j++)
		{
			if(arr[j]>max)
			{
				max = arr[j];
				maxind = j;
			}
		}
		arr[maxind] = arr[sizeofarr-1-i];
		arr[sizeofarr-1-i] = max;	
	}
}
int main()
{
	int arr[10] = {9,8,7,6,5,4,3,2,1,0};
	SelectionSort(arr,10);
	for(int i = 0; i<10; i++)
	{
		printf("%d ",arr[i]);
	}
	printf("\n");
}