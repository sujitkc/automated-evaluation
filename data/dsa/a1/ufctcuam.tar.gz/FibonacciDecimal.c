#include<stdio.h>
#include<time.h>
void divideby2(int num[], int sizeofnum)
{
	for(int i = 0; i<sizeofnum; i++)
	{
		if(num[i]%2 == 1 && i!=sizeofnum-1)
		{
			num[i+1] = 10 + num[i+1];
		}
		num[i] = num[i]/2;
	}
}
void Matrixmultiply(int a[2][2], int b[2][2], int x[2][2])
{
	int i,j,k;
	int c[2][2] = {{0,0},{0,0}};
	for(i = 0; i<2; i++)
	{
		for(j = 0; j<2; j++)
		{
			for(k = 0; k<2; k++)
			{
				c[i][j] += a[i][k] * b[k][j];
			}
			c[i][j] = c[i][j] % 100;
		}
	}
	for(int i  = 0; i<2; i++)
	{
		for(int j = 0 ;j<2; j++)
		{
			x[i][j] = c[i][j];
		}
	}
}
int ifzero(int num[],int sizeofnum)
{
	for(int i = 0; i<sizeofnum; i++)
	{
		if(num[i] != 0)
		{
			return 1;
		}
	}
	return 0;
}
int Fibonacci(int n[],int sizeofnum)
{
	int A[2][2] = {{1,1},{1,0}};
	int Answer[2][2] = {{1,0},{0,1}};
	int x = 0;
	while(ifzero(n,sizeofnum) == 1)
	{
		if(n[sizeofnum-1]%2 == 1)
		{
			Matrixmultiply(Answer,A,Answer);
		}
		Matrixmultiply(A,A,A);
		divideby2(n,sizeofnum);
		x++;
	}
	return Answer[1][0];
}
int main()
{
	int num[2] = {1,2};
	printf("%d\n",Fibonacci(num,2));
}