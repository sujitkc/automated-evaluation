#include<stdio.h>
#include<stdlib.h>
void Merge(int arr[], int l, int mid, int r)
{
	int *temp = (int *)calloc(r+1-l,sizeof(int));
	int counter = 0;
	int left = l;
	int right = mid+1;
	while(left <= mid && right<=r)
	{
		if(arr[left] < arr[right])
		{
			temp[counter] = arr[left];
			left++;
		}
		else
		{
			temp[counter] = arr[right];
			right++;
		}
		counter++;
	}
	while(left < mid + 1)
	{
		temp[counter] = arr[left];
		left++;
		counter++;
	}
	while(right < r+1)
	{
		temp[counter] = arr[right];
		right++;
		counter++;
	}
	counter = l;
	while(counter <= r)
	{
		arr[counter] = temp[counter-l];
		counter++; 
	}
	return;
}
void Msort(int arr[], int l, int r)
{
	if(r == l+1)
	{
		if(arr[l] > arr[r])
		{
			int temp = arr[l];
			arr[l] = arr[r];
			arr[r] = temp;
		}
		return;
	}
	if(l == r)
	{
		return;
	}
	int mid = (l+r)/2;
	Msort(arr,l,mid);
	Msort(arr,mid+1,r);
	Merge(arr,l,mid,r);
}
int main()
{
	int arr[10] = {-1,7,9,4,6,1,2,8,3,0};
	Msort(arr,0,9);
	for(int i = 0; i<10; i++)
	{
		printf("%d ",arr[i]);
	}
} 