#include<stdio.h>
void InsertionSort(int arr[], int sizeofarr)
{
	int temp;
	for(int i = 1; i<sizeofarr; i++)
	{
		temp = arr[i];
		for(int j = i-1; j>=0; j--)
		{
			if(temp < arr[j])
			{
				arr[j+1] = arr[j];
			}
			if(j == 0 || temp>arr[j])
			{
				arr[j] = temp;
			}
		}
	}
}
int main()
{
	int arr[10] = {10,9,8,7,6,5,4,3,2,1};
	InsertionSort(arr,10);
	for(int i = 0; i<10; i++)
	{
		printf("%d ",arr[i]);
	}
}