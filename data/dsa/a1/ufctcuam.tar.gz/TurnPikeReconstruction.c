#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *nextptr;
};

void view(struct node *startptr)
{
	struct node *currptr;
	currptr = startptr;
	while(currptr != NULL)
	{
		printf("%d ",currptr->data);
		currptr = currptr->nextptr;
	}
	printf("\n");
}

void insert(int value,struct node **startptr)
{
	struct node *currptr,*prev,*new_node,*tempptr;
	if (*startptr == 0)
	{
		new_node=(struct node *)malloc(sizeof(struct node));
		new_node->data = value;
		new_node->nextptr = 0;
		*startptr = new_node;
		return;
	}
	currptr = *startptr;
	prev = *startptr;
	int flag = 0;
	if (currptr->data >= value)
	{
		new_node=(struct node *)malloc(sizeof(struct node));
		new_node->data = value;
		new_node->nextptr = currptr;
		*startptr = new_node;
		return;
	}
	while(currptr != 0)
	{
		if (currptr->data >= value)
		{
			new_node=(struct node *)malloc(sizeof(struct node));
			new_node->data = value;
			new_node->nextptr = currptr;
			prev->nextptr = new_node;
			return;
		}
		currptr = currptr->nextptr;
		if(flag == 1)
		{
			prev = prev->nextptr;
		}
		flag = 1;
	}
	new_node=(struct node *)malloc(sizeof(struct node));
	new_node->data = value;
	prev->nextptr = new_node;
	new_node->nextptr = 0;
}

void delete(int value, struct node **startptr)
{
	struct node *currptr,*prev,*tempptr;
	currptr = *startptr;
	prev = 0;
	if(currptr->data == value)
	{
		tempptr = currptr;
		*startptr = currptr->nextptr;
		free(tempptr);
		return;
	}
	while(currptr != 0)
	{
		if (currptr->data == value)
		{
			tempptr = currptr;
			prev->nextptr = currptr->nextptr;
			free(tempptr);
			return;
		}
		prev = currptr;
		currptr = currptr->nextptr;
	}
}

int findmax(struct node *start)
{
	struct node *curr;
	curr = start;
	while(1)
	{
		if(curr->nextptr == 0)
		{
			return curr->data;
		}
		else
		{
			curr = curr->nextptr;
		}
	}
}

int search(int value, struct node *start)
{
	struct node *curr;
	curr = start;
	while (curr->nextptr != 0)
	{
		if(curr->data == value)
		{
			return 1;
		}
		curr = curr->nextptr;
	}
	if(curr->data == value)
	{
		return 1;
	}
	return 0;
}

int possible(int arr[], struct node **start, int pos, int sizeofarr)
{
	int *deleted = (int*)calloc(sizeofarr-1,sizeof(int));
	int x = 0;
	for(int i = 0; i<sizeofarr; i++)
	{
		if(i == pos || arr[i] == -1)
		{
			continue;
		}
		else if(search(abs(arr[i] - arr[pos]),*start) == 0)
		{
			for(int j = 0;j<sizeofarr-1;j++)
			{
				if(deleted[j] != 0)
				{
					insert(deleted[j],start);
				}
			}
			return 0;
		}
		else
		{
			delete(abs(arr[i] - arr[pos]),start);
			deleted[x] = abs(arr[i] - arr[pos]);
			x++;
		}
	}
	return 1;
}

void insertall(struct node **start, int arr[], int pos, int sizeofarr)
{
	for(int i = 0; i<sizeofarr; i++)
	{
		if(i == pos || arr[i] == -1)
		{
			continue;
		}
		insert(abs(arr[i] - arr[pos]),start);
	}
}
int try(struct node **start, int arr[],int left,int right,int sizeofarr,int index,int order[]);

int backtrack(int arr[], struct node **start, int sizeofarr,int index,int order[],int left, int right)
{
	int todel = order[index-1];
	order[index-1] = 0;
	index--;
	if (index == 1)
	{
		return -1;
	}
	insertall(start,arr,todel,sizeofarr);
	arr[todel] = -1;
	if(arr[todel+1] == -1)
	{
		backtrack(arr,start,sizeofarr,index,order,left-1,right);
	}
	else
	{
		for(int i = 0;i<sizeofarr;i++)
		{
			if(arr[i] == -1)
			{
				left = i;
				break;
			}
		}
		arr[left] = arr[sizeofarr-1] - findmax(*start);
		if(possible(arr,start,left,sizeofarr) == 1)
		{
			order[index] =  left;
			try(start,arr,left,right,sizeofarr,index+1,order);
		}
		else
		{
			arr[left] = -1;
			backtrack(arr,start,sizeofarr,index,order,left,right+1);
		}
	}
}
int try(struct node **start, int arr[],int left,int right,int sizeofarr,int index,int order[])
{
	if (right - left == 1)
	{
		return 1;
	}
	arr[right-1] = findmax(*start);
	if(possible(arr,start,right-1,sizeofarr) == 1)
	{
		order[index] = right-1;
		try(start,arr,left,right-1,sizeofarr,index+1,order);
	}
	else
	{

		arr[right-1] = -1;
		arr[left+1] = arr[sizeofarr-1] - findmax(*start);
		if(possible(arr,start,left+1,sizeofarr) == 1)
		{
			order[index] = left+1;
			try(start,arr,left+1,right,sizeofarr,index+1,order);
		}
		else
		{
			arr[left+1] = -1;
			int ind = backtrack(arr,start,sizeofarr,index,order,left,right+1);
			if(ind == -1)
			{
				return -1;
			}
		}
	}

}

int main()
{
	int *order = (int*)calloc(10,sizeof(int));
	struct node *dstart = 0;
	printf("Enter number of elements: ");
	int n;
	scanf("%d",&n);
	int array[n];
	printf("Enter Numbers\n");
	for(int i = 0; i<n; i++)
	{
		scanf("%d",&array[i]);
	}
	for(int i = 0; i<n; i++)
	{
		for(int j = i+1; j<n; j++)
		{
			insert(array[j] - array[i],&dstart);
		}
	}
	printf("Distances = ");
	view(dstart);
	int arr[n];
	order[0] = n-1;
	for(int i = 0; i<n; i++)
	{
		arr[i] = -1;
	}
	arr[0] = 0;
	arr[n-1] = findmax(dstart);
	delete(arr[n-1],&dstart);
	if(try(&dstart,arr,0,n-1,n,1,order) == 1)
	{
		printf("Reconstructed numbers = ");
		for(int i = 0; i<n; i++)
		{
			printf("%d ",arr[i]);
		}
		printf("\n");
	}
	else
	{
		printf("No Solution\n");
	}
}