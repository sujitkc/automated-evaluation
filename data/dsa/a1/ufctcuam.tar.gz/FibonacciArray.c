#include<stdio.h>
int Fibonacci(int n)
{
	int arr[1000000] = {0,1};
	for(int i = 2; i<=n; i++)
	{
		arr[i] = (arr[i-1] + arr[i-2])%100;
	}
	return arr[n];
}
int main()
{
	printf("%d\n",Fibonacci(12));
}