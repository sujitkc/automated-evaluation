#include<stdio.h>
int Fibonacci(int n, int m,int period[])
{
	int i = 2,p = -1;
	while(i<31 && i<=n)
	{ 
		period[i] = (period[i-1] + period[i-2])%m;
		if(period[i] == 1 && period[i-1] == 0)
		{
			p = i-1;
			break;
		}
		i++;
	}
	if (p == -1)
	{
		return period[n];
	}
	return period[n%p];
}
int main()
{
	int m = 100;
	int n = 12;
	int period[31];
	period[0] = 0;
	period[1] = 1;
	printf("%d\n",Fibonacci(n,m,period));
}