#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *nextptr;
};
void insert(int value, struct node **startptr)
{
	struct node *new_node;
	new_node=(struct node *)malloc(sizeof(struct node));
	new_node->data = value;
	new_node->nextptr = *startptr;
	*startptr = new_node;
}

void delete(int value, struct node **startptr)
{
	struct node *currptr,*prev,*tempptr;
	currptr = *startptr;
	prev = 0;
	if(currptr->data == value)
	{
		tempptr = currptr;
		*startptr = currptr->nextptr;
		free(tempptr);
	}
	while(currptr != 0)
	{
		if (currptr->data == value)
		{
			tempptr = currptr;
			prev->nextptr = currptr->nextptr;
			free(tempptr);
			return;
		}
		prev = currptr;
		currptr = currptr->nextptr;
	}
}
void checkcond(int a, int b, struct node **startptr)
{
	if(a%2 == 0 && b%2 == 0)
	{
		if (b>a)
		{
			delete(b, startptr);
		}
		else
		{
			delete(a,startptr);
		}
	}
	else if(a%2 == 1 && b%2 == 1)
	{
		if (b<a)
		{
			delete(b, startptr);
		}
		else
		{
			delete(a,startptr);
		}	
	}
	else
	{
		if(a%2 == 1)
		{
			delete(a,startptr);
		}
		else
		{
			delete(b,startptr);
		}
	}
}
void compresshoriz(struct node **startptr)
{
	struct node *curr,*next,*temp1,*temp2;
	if(*startptr == 0)
	{
		return;
	}
	curr = *startptr;
	if(curr->nextptr == 0)
	{
		return;
	}
	next = curr->nextptr;
	while(1)
	{
		if(curr == 0 || next == 0)
		{
			return;
		}
		else
		{
			temp1 = curr;
			temp2 = next;
			checkcond(temp1->data, temp2->data, &curr);
			curr = next->nextptr;
			if(curr == 0)
			{
				curr = *startptr;
				next = curr->nextptr;
				continue;
			}
			next = curr->nextptr;
			if(next == 0)
			{
				curr = *startptr;
				next = curr->nextptr;
				continue;	
			}
		}
	}
}
int compressvert(struct node *arr[])
{
	int flag;
	struct node *temp;
	int a,b;
	do
	{
		flag = 0;
		for(int i = 0; i<4; i++)
		{
			if(arr[i] != 0)
			{
				a = arr[i]->data;
				for(int j = i+1; j<4; j++)
				{
					if(arr[j] != 0)
					{
						b = arr[j]->data;
						flag = 1;
						i = j;
						if(a%2 == 0 && b%2 == 0)
						{
							if (b>a)
							{
								temp = arr[j];
								free(temp);
								arr[j] = 0;
							}
							else
							{
								temp = arr[i];
								free(temp);
								arr[i] = 0;
							}
						}
						else if(a%2 == 1 && b%2 == 1)
						{
							if (b<a)
							{
								temp = arr[j];
								free(temp);
								arr[j] = 0;	
							}
							else
							{
								temp = arr[i];
								free(temp);
								arr[i] = 0;
							}	
						}
						else
						{
							if(a%2 == 1)
							{
								temp = arr[i];
								free(temp);
								arr[i] = 0;
							}
							else
							{
								temp = arr[j];
								free(temp);
								arr[j] = 0;
							}
						}

					}
				}
			}
		}	
	}
	while(flag == 1);
}
int main()
{
	int n,x;
	struct node * arr[4] = {0};
	for(int i = 0; i<6; i++)
	{ 
		n = rand();
		x = rand() % 4;
		printf("Number generated = %d, placed at index = %d\n",n,x);
		insert(n,&arr[x]);
	}
	for(int i = 0; i<4; i++)
	{
		compresshoriz(&arr[i]);
	}
	compressvert(arr);
	printf("\nAnswer is = \n\n");
	for(int i = 0; i<4; i++)
	{
		if(arr[i] == 0)
		{
			printf("NULL\n");
		}
		else
		{
			printf("%d\n",arr[i]->data);
			if(arr[i]->nextptr == 0)
			{
				printf("NULL\n");
			}
			else
			{
				printf("%d\n",arr[i]->nextptr->data);
			}
		}
	}
}
