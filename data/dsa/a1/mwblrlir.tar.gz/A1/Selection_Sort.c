/* Selection Sort - START */
typedef long long int lint;

void swap(int *p, int *q){
	if(p!=q){
		*p ^= *q;
		*q ^= *p;
		*p ^= *q;
	}
}

void selectionSort(int s[], lint n){
	lint max,i,j;
	for(j=0;j<n-1;j++){
		max=0;
		for(i=1;i<n-j;i++){
			if(s[max]<s[i]){
				max=i;
			}
		}
		swap(&s[i], &s[i+1]);
	}
}
/* Selection Sort - END */
