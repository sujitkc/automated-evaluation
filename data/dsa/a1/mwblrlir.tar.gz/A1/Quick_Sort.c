/* Randomized Quick Sort - START */
typedef long long int lint;

void swap(int *p, int *q){
	if(p!=q){
		*p ^= *q;
		*q ^= *p;
		*p ^= *q;
	}
}

lint randPivot(lint i, lint j){
	return i + (rand() % (j-i));
}

lint partition(int s[], lint i, lint j, lint p){
	lint l, r;
	int x = s[p];

	if(p != j-1){
		swap(&s[p], &s[j-1]);
	}

	for (l = i-1, r = i; r < j-1; r++){
		if(s[r] <= x){
			swap(&s[r], &s[++l]);
		}
	}

	swap(&s[++l], &s[j-1]);
	return l;
}

void randQuickSort(int s[], lint i, lint j){
	if(i >= j-1){
		return;
	}

	lint p = randPivot(i, j);
	lint k = partition(s, i, j, p);
	randQuickSort(s, i, k);
	randQuickSort(s, k+1, j);
}
/* Randomized Quick Sort - END */
