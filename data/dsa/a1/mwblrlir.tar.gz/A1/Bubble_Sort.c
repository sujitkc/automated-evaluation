/* Bubble Sort - START */
typedef long long int lint;

void swap(int *p, int *q){
 if(p!=q){
	 *p ^= *q;
	 *q ^= *p;
	 *p ^= *q;
 }
}

void bubbleSort(int s[], lint n){
	lint i,j;
	for(j=0; j<n-1; j++){
		for(i=0; i<n-1-j; i++){
			if(s[i]>s[i+1]){
				swap(&s[i], &s[i+1]);
			}
		}
	}
}
/* Bubble Sort - END */
