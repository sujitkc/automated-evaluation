/* This program uses an array of randomly generated linked lists to finally
condense it into one element. */ 

#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<limits.h>
#define ARRLEN 10000
#define MAXNO 100000

struct node{
	int data;
	struct node* next;
};

typedef struct node node;

void generateArrlist(node *arr[]);
node* newnode(int data, node *next);
void printArrlist(node *arr[]);
void condenseArrlist(node *arr[]);
void condList(node **head);
void delnode(node **head, node *todel);

int main(){
	srand(time(NULL));
	node *arrlist[ARRLEN] = {0};
	generateArrlist(arrlist);
	printArrlist(arrlist);
	condenseArrlist(arrlist);
	return 0;
}

void generateArrlist(node *arr[]){
	for(int i = 0, j = rand() % ARRLEN; i < MAXNO; i++, j = rand() % ARRLEN){
		arr[j] = newnode(1 + rand() % (INT_MAX - 1), arr[j]);
	}
}

node* newnode(int data, node *next){
	node *temp = NULL;
	if(!(temp = (node*)malloc(sizeof(node)))){
		printf("\n\nOverflow!");
		exit(1);
	}
	temp->data = data;
	temp->next = next;
	return temp;
}

void printArrlist(node *arr[]){
	node* temp=NULL;
	for(int i=0;i<ARRLEN;i++){
		temp=arr[i];
		printf("%d) ",i+1);
		while(temp){
			printf("%d ",temp->data);
			temp=temp->next;
		}
		printf("\n");
	}
	printf("\n");
}

void condenseArrlist(node *arr[]){
	for(int i = 0; i<ARRLEN; i++){
		while(arr[i] && arr[i]->next){
			condList(&arr[i]);
		}
	}

	printArrlist(arr);

	node *vertHead = NULL, *temp = NULL;
	for(int i = 0; i<ARRLEN; i++){
		if(arr[i]){
			if(!vertHead){
				vertHead = arr[i];
				temp = vertHead;
			}
			else{
				temp->next = arr[i];
				temp = temp->next;
			}
		}
	}

	while(vertHead->next){
		condList(&vertHead);
	}

	printf("Final Answer: %d\n",vertHead->data);
}

void condList(node** head){
	if((*head)->data % 2 && (*head)->next->data % 2){
		if((*head)->data < (*head)->next->data){
			delnode(head, (*head));
		}
		else{
			delnode(head, (*head)->next);
		}
	}
	else if(!((*head)->data % 2) && !((*head)->next->data % 2)){
		if((*head)->data > (*head)->next->data){
			delnode(head, (*head));
		}
		else{
			delnode(head, (*head)->next);
		}
	}
	else if((*head)->data % 2){
		delnode(head, (*head));
	}
	else{
		delnode(head, (*head)->next);
	}
}

void delnode(node **head, node *todel){
	if(*head == todel){
		*head = todel->next;
		free(todel);
		return;
	}
	(*head)->next = todel->next;
	free(todel);
}
