/* Tries to find the nth element of Fibonacci % 100 series using iterative logic
(array)*/

#include<stdio.h>
#include<stdlib.h>

int main(int argc, char const *argv[]) {
	int n,i;
	sscanf(argv[1], "%d", &n);
	int *arr = (int*) malloc(sizeof(int)*n);
	arr[0] = 0;
	arr[1] = 1;
	for(i = 2; i<n; i++){
		arr[i] = (arr[i-1] + arr[i-2])%100;
	}
	printf("%d\n",arr[n-1]);
	return 0;
}
