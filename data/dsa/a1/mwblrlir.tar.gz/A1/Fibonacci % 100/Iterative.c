/* Tries to find the nth element of Fibonacci % 100 series using iterative logic
(3 variables)*/

#include<stdio.h>

int main(int argc, char const *argv[]) {
	int n,i;
	sscanf(argv[1], "%d", &n);
	int prev2 = 0, prev1 = 1, curr = 0;
	for(i=2; i<n; i++){
		curr = (prev1 + prev2)%100;
		prev2 = prev1;
		prev1 = curr;
	}
	printf("%d\n",(n==2)?1:curr);
	return 0;
}
