/* Tries to find the nth element of Fibonacci % 100 series using recursive logic
*/

#include<stdio.h>

int fibonacci(int n){
	if(n == 1 || n == 0){
		return n;
	}
	return (fibonacci(n-1) + fibonacci(n-2)) % 100;
}

int main(int argc, char const *argv[]) {
	int n;
	sscanf(argv[1], "%d", &n);
	printf("%d\n", fibonacci(n-1));
	return 0;
}
