/* Tries to find the nth element of Fibonacci % 100 by using an array and also
finding the period */

#include<stdio.h>
#include<stdlib.h>

int main(int argc, char const *argv[]){
	int n,i;
	sscanf(argv[1], "%d", &n);
	int arr[700] = {0, 1}, s = 0;
	for(i = 2; i<n; i++){
		arr[i] = (arr[i-1] + arr[i-2]) % 100;
		if(arr[i] == 1 && !arr[i-1]){
			i--;
			break;
		}
	}
	n--;
	if(i < n){
		n %= i;
	}
	printf("%d\n", arr[n]);
	return 0;
}
