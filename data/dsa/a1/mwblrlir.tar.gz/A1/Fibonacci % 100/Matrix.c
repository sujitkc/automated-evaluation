/*This tries to find the nth term for very large n using matrices.*/

#include<stdio.h>
#include<string.h>
#include<stdlib.h>

typedef struct{
	int len, *n;
} bgint;

void divide(int n[], int *len){
	int i, carry = 0;
	for(i = (*len) - 1; i ; --i){
		carry = n[i] & 1;
		n[i-1] += carry*10;
		n[i] >>= 1;
	}
	n[0] >>= 1;
	if((*len)-1 && !n[(*len) - 1]){
		(*len)--;
	}
}

bgint* getBit(bgint dec){
	bgint *bin = (bgint*) malloc(sizeof(bgint));
	bin->n = (int*) malloc(4 * sizeof(int) * dec.len);
	bin->len = 0;
	int i;

	while(dec.len != 1 || (dec.n)[0]){
		(bin->n)[(bin->len)++] = (dec.n)[0] & 1;
		divide(dec.n, &dec.len);
	}

	for(i = 0; i < (bin->len)/2; ++i){
		(bin->n)[i] ^= (bin->n)[(bin->len)-1-i];
		(bin->n)[(bin->len)-1-i] ^= (bin->n)[i];
		(bin->n)[i] ^= (bin->n)[(bin->len)-1-i];
	}
	return bin;
}

void multMatrix(int a[][2], int b[][2]){
	int mul[2][2], i, j, k;
  for(i = 0; i < 2; ++i){
    for(j = 0; j < 2; ++j){
          mul[i][j] = 0;
          for(k = 0; k < 2; ++k)
              mul[i][j] = (mul[i][j] + a[i][k]*b[k][j])%100;
      }
  }

	for(i=0; i<2; ++i){
    for(j=0; j<2; ++j){
      a[i][j] = mul[i][j];
		}
	}
}

int getFibTerm(bgint *bin){
	int A[][2] = {{1,1}, {1,0}}, Ans[][2] = {{1,0}, {0,1}}, i;

	while((bin->len)){
		if((bin->n)[(bin->len)-1] & 1){
			multMatrix(Ans, A);
		}
		(bin->len)--;
		multMatrix(A, A);
	}

	return Ans[1][0];
}

int main(){
	char s[1001];
	scanf("%s", s);
	bgint dec;
	dec.len = strlen(s);
	dec.n = (int*) malloc(sizeof(int) * dec.len);
	int i;
	for(i = dec.len-1; s[i]; --i){
		dec.n[i] = s[dec.len-1-i] - 48;
	}

	bgint *bin = getBit(dec);

	printf("\n%d",getFibTerm(bin));
}
