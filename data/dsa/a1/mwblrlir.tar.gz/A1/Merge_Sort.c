/* Merge Sort - START */
typedef long long int lint;

void swap(int *p, int *q){
	if(p!=q){
		*p ^= *q;
		*q ^= *p;
		*p ^= *q;
	}
}

int b[MAXLEN];
void mergeArr(int s[], lint st, lint ed){
	lint n1=st, n2=(st+ed)/2, n3=0, k=(st+ed)/2;
	extern int b[];

	while(n1!=k && n2!=ed){
		if(s[n1]<=s[n2]){
			b[n3++]=s[n1++];
		}
		else{
			b[n3++]=s[n2++];
		}
	}

	while(n1!=k){
		b[n3++]=s[n1++];
	}

	while(n2!=ed){
		b[n3++]=s[n2++];
	}

	for(n3=0;st<ed;n3++,st++){
		s[st]=b[n3];
	}
}

void mergeSort(int s[], lint st, lint ed){
	if(st+1==ed){
		return;
	}

	lint k=(st+ed)/2;
	mergeSort(s,st,k);
	mergeSort(s,k,ed);
	mergeArr(s,st,ed);
}
/* Merge Sort - END */
