/* Insertion Sort - START */
typedef long long int lint;

void swap(int *p, int *q){
	if(p!=q){
		*p ^= *q;
		*q ^= *p;
		*p ^= *q;
	}
}

void insertionSort(int s[], lint beg, lint n){
	lint i,j;
	int t;
	for(j=beg+1;j<n;j++){
		t=s[j];
		i=j-1;
		while(i>=beg && s[i]>t){
			s[i+1]=s[i];
			i--;
		}
		s[i+1]=t;
	}
}
/* Insertion Sort - END */
