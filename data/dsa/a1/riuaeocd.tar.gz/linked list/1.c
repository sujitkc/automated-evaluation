#include <stdio.h>
#include <stdlib.h>
#include <time.h>

struct node
{
	int n;
	struct node * next;
};

void insert(struct node **sptr,int r)
{
	struct node *newnode = malloc(sizeof(struct node));
	newnode -> n = r;
	if(*sptr == NULL)
	{
		*sptr = newnode;
		(*sptr)->next = NULL;
	}
	else
	{
		struct node *currentnode;
		currentnode = (*sptr);
		while(currentnode ->next != NULL)
		{
			currentnode = currentnode -> next;
		}
		currentnode -> next = newnode;
		newnode -> next = NULL;
	}

}
void view(struct node **sptr)
{
	struct node *currentnode;
	currentnode = (*sptr);
	while(currentnode->next != NULL)
		{	
			if(currentnode-> n != 0 ){
				printf(" the last elemnt in linked list\n");
				printf("%d\n",currentnode-> n );
			}	
			currentnode = currentnode -> next;
		}

}



void delete(int d ,struct node **sptr)
{
	struct node *ptr = (*sptr);
	if ((*sptr) -> n == d)
	{
		(*sptr) = (*sptr) -> next;
		//free(*sptr);
	}
	else if (d == (*sptr) -> next -> n )
	{
		(*sptr) -> next = (*sptr) -> next -> next;
		//free(((*sptr)->next));
	}

}




void check(struct node **sptr)
{
	int a,b;
	a = (*sptr) -> n;
	b = (*sptr) -> next -> n;
	if (a%2 == 0 && b%2 != 0  )
		delete(b , sptr);
	else if (a%2 != 0 && b%2 == 0)
		delete(a , sptr);
	else if (a%2 != 0 && b%2 !=0) 
	{
		if (a<b)
			delete(a , sptr);
		else
			delete(b , sptr);
	}
	else if (a%2 == 0 && b%2==0 )
	{
		if(a<b)
			delete(b , sptr);
		else
			delete(a , sptr);
	}

}

int count(struct node **sptr)
{
	int count = 0;
	struct node *currentnode;
	currentnode = (*sptr);
	while(currentnode->next != NULL)
		{
			count++;
			currentnode = currentnode -> next;
		}

	return count;
}



int main()
{
	int elem=100,r,r2,r1,len = 100,c;
	time_t t1 = time(0);
	srand(t1);
	struct node *arr[len];
	for(int i=0;i<len;i++)
		arr[i] = NULL;
	struct node *sptr = NULL;
	for (int i = 0; i < len*elem; ++i)
	{
	r = rand();
	r2 = rand();
	insert(&arr[r%len],r2);
	}
	for (int i = 0; i < len; ++i)
	{
		c = count(&arr[i]);
		if (c>1)
		{
		for (int j = 0 ; j < c-1 ;j++)
		{

			check(&arr[i]);
		}
		}	
	}
	
	for (int i =0;i<len;i = i + 1)
		for(int j = 0; j< len ; j =j+1)
		{
		int a,b;
		a = arr[i] -> n;
		b = arr[j] -> n;
		if (a == 0 || b == 0 || a == b);
		else
			{
				if (a%2 == 0 && b%2 != 0  )
					arr[j] -> n = 0;
				else if (a%2 != 0 && b%2 == 0)
					arr[i] -> n = 0;
				else if (a%2 != 0 && b%2 !=0) 
				{
					if (a<b)
						arr[i] -> n = 0;
					else
						arr[j] -> n = 0;
				}
				else if (a%2 == 0 && b%2==0 )
				{
					if(a<b)
						arr[j] -> n= 0;
					else
						arr[i] -> n = 0;
				}
			}

		}
	for(int i=0;i<len;i++)
	{
		view(&arr[i]);
	}
}
