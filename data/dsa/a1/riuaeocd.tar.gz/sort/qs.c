#include<stdio.h>
#include<stdlib.h>
 void swap(int* a, int* b)
{
    int t = *a;
    *a = *b;
    *b = t;
}
void printArray(int arr[], int size)
{
    int i;
    for (i=0; i < size; i++)
        printf("%d ", arr[i]);
    printf("\n");
}

int partition (int arr[], int low, int high)
{
    int l,r;
    l = low;
    r = high;
	int pivot = arr[high]; 
    while(l <= r && arr[l]<= pivot)
        l++;
    while(l < r && arr[r] > pivot)
        r--;
    if(l < r)
        swap(&arr[l] , &arr[r]);
    l++;
    r--;
    return r;
}

void quickSort(int arr[], int low, int high)
{
    if (low < high)
    {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi);
        quickSort(arr, pi+1, high);
    }
    else
    	return;
}
int main()
{
    int arr[] = {9,7,1,2,3};
    int n = sizeof(arr)/sizeof(arr[0]);
    quickSort(arr, 0, n-1);
    printf("Sorted array: \n");
    printArray(arr, n);
    return 0;
}