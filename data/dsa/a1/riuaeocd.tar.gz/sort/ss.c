#include <stdio.h>
void swap(int *a, int *b)
{
    int temp;
    temp = *a;
    *a = *b;
    *b = temp;
}
void selectionSort(int arr[], int size)
{
    int i, j;
    for (i = 0 ;  i < size;i++)
    {
        for (j = i ; j < size; j++)
        {
            if (arr[i] > arr[j])
                swap(&arr[i], &arr[j]);
 
        }
    }
}

int main()
{
    int  i, size =10;
    int array[10] =  {1,4,2,3,5,6,7,8,9,10};
    selectionSort(array, 10); 
    for (i = 0; i < size;i++)
        printf(" %d ", array[i]);
    return 0;
 
}