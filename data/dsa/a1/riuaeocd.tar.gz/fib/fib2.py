a = 1000
list = []
for i in range(a):
	list.append(0)
list[0] = 0
list [1] = 1
for n in range(2,a):
	list[n] = (list[n-1] + list[n-2])%100
print list[100]
