a = 0
b = 1
c = 20
for i in range(c):
	c = (a+b)%100
	a = b
	b = c
	print c
