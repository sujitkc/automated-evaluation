a = 100000
m = 20
list = []
for i in range(a):
	list.append(0)
list[0] = 0
list [1] = 1
d = 6*m+1
for n in range(2,d):
	list[n] = (list[n-1] + list[n-2])%m

for i in range(1,d):
	if (list[i]== 0 and list[i+1]==1):
		period = i
		print "period",
		print period
		break
b = a%period
print list[b]

