#include <stdio.h>
#include <stdlib.h>

void half(int *arr)
{
	int carry=0;
	for(int i=0;i<sizeof(arr)/2;i++)
	{
		if(arr[i]%2==0)
		{
			if(carry==1)
			{
				arr[i]=(10+arr[i])/2;
				carry=0;
			}
			else
			{
				arr[i]/=2;	
			}
		}
		else
		{
			if(carry==1)
			{
				arr[i]=(10+arr[i])/2;
				carry=1;
			}
			else
			{
				arr[i]/=2;	
				carry=1;
			}			
		}
	}
}

int isnotEmpty(int *arr)
{
	int count=0;
	for(int i=0;i<sizeof(arr)/2;i++)
	{
		if(arr[i]!=0)
		{
			count=1;
		}
	}
	if(count==1)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}


int main()
{
	// NUM is the nth term of fib series
	int n[4]={0,0,1,2};
	int size=sizeof(n)/sizeof(int);

	int x[2][2]={{1,1},{1,0}};
	int y[2][2]={{1,0},{0,1}};
	int e,f,g,h;

	while(isnotEmpty(n)==1)
	{
		if((n[size-1])%2==1)
		{
			e = y[0][0] * x[0][0] + y[0][1] * x[1][0];
			f = y[0][0] * x[0][1] + y[0][1] * x[1][1];
			g = y[1][0] * x[0][0] + y[1][1] * x[1][0];
			h = y[1][0] * x[0][1] + y[1][1] * x[1][1];
			y[0][0] = e%100;
			y[0][1] = f%100;
			y[1][0] = g%100;
			y[1][1] = h%100;
		}

		e = x[0][0] * x[0][0] + x[0][1] * x[1][0];
		f = x[0][0] * x[0][1] + x[0][1] * x[1][1];
		g = x[1][0] * x[0][0] + x[1][1] * x[1][0];
		h = x[1][0] * x[0][1] + x[1][1] * x[1][1];
		x[0][0] = e%100;
		x[0][1] = f%100;
		x[1][0] = g%100;
		x[1][1] = h%100;
		half(n);
	}

	printf("%d\n",y[1][1] );
}