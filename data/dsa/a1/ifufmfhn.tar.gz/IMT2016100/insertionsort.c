#include <stdio.h>
void Swap(int *a ,int *b){
	int temp;
	temp =*a;
	*a=*b;
	*b=temp;
} 
void InsertionSort(int *a ,int size){
	int i,j;

	for(i=1;i<size;i++){
		j=i-1;
		while( j<i && j>=0){
			if (a[j]>a[j+1]){
				Swap(&a[j+1],&a[j]);
			}
			j--;
		}	
	}
}
int main()
{
	int i,n;
	n=5;
	int a[n];
	for(i=0;i<n;i++)
		a[i]=n-i;
	InsertionSort(a,n);
	for (int i = 0; i < n; ++i)
	{
		printf(" %d,",a[i]);
	}
	return 0;
}
