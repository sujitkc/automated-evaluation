
#include<stdio.h>

struct node 
{
int data;
struct node *next;
};

struct node *insert(int data,struct node *top)
{
struct node *new=malloc(sizeof(struct node));
new->data=data;
new->next=top;
return new;
}
void print(struct node *top)
{
while(top!=NULL)
{
printf("%d  ",top->data);
top=top->next;
}
printf("\n");
}


struct node *minimizelink(struct node *top)
{
if(top->next==NULL||top==NULL)
return top;
else
{
struct node *curr = top,*prev=NULL;
while (curr!=NULL&&curr->next!=NULL)
{
struct node *next2=curr->next->next;
if(curr->data%2==0&&curr->next->data%2==0)
{
if(curr->data>curr->next->data)
{
if(prev==NULL)
{
top=curr->next;
}
else 
prev->next=curr->next;
prev=curr->next;
}
else
{
if(prev==NULL)
curr->next=curr->next->next;
else
prev->next=curr->next->next;
prev=curr->next;
}
}
else if(curr->data%2==1&&curr->next->data%2==1)
{
if(curr->data<curr->next->data)
{
if(prev==NULL)
{
top=curr->next;
}
else 
prev->next=curr->next;
prev=curr->next;
}
else
{
if(prev==NULL)
curr->next=curr->next->next;
else
prev->next=curr->next->next;
prev=curr->next;
}
}
else
{
if(curr->data%2==1)
{
if(prev==NULL)
{
top=curr->next;
}
else 
prev->next=curr->next;
prev=curr->next;
}
else
{
if(prev==NULL)
curr->next=curr->next->next;
else
prev->next=curr->next->next;
prev=curr->next;
}
}
curr=next2;
}
return minimizelink(top);
}
}

void main()
{
struct node *arr[10000];
for(int i=0;i<10000;i++)
{
arr[i]=NULL;
}
for(long int x=0;x<100000;x++)
{
int y=rand()%10000;
arr[y]=insert(rand(),arr[y]);
}
for(int i=0;i<10000;i++)
{ if(arr[i]!=NULL)
{
arr[i]=minimizelink(arr[i]);
}
}

struct node *top=NULL,*last=NULL;
for(int i=0;i<10000-1;i++)
{
if(arr[i]!=NULL)
{
if(top==NULL)
{
top=arr[i];
last=arr[i];
}
else
{
last->next=arr[i];
last=arr[i];
}
}
}
top=minimizelink(top);
printf("%d",top->data);
}

