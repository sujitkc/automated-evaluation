#include<stdio.h>
int power(int x,int y)
{
      int k=1;
      int n=1;
      while(k<=y)
      {
                 n=n*x;
                  k++;
                  }
                  }
int fib(int n)
{
  int a = 0, b = 1, c, i;
  if( n == 0)
    return a;
  else if(n==1)
    return b;
  else
  while(n>=2)
  {
     c = (a + b)%100;
     a = b;
     b = c;
     n--;  
  }
 
  return b;
}
int main()
{ 
int a[1000],p=300,n,t,i,count=0;
scanf("%d",&n);
for(i=0;i<n;i++)
{
printf("%d",a[i]);
}
for(i=0;i<n;i++)
{

t=power(a[i],(n-1-i));

count=count+t%300;
}
printf("%d",fib(count));
return 0;
}



