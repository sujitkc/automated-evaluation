#include <stdio.h>
void Swap(int *a ,int *b){
	int temp;
	temp =*a;
	*a=*b;
	*b=temp;
} 
void BubbleSort(int *a ,int size){
	int i,j;
	for (i=0;i<size-1;i++){
		for (j=0;j<size-i-1;j++){
			if (a[j]>a[j+1])
				Swap(&a[j],&a[j+1]);
		}
	}
}
int main()
{
	int i,n;
	n=2;
	int a[n];
	for(i=0;i<n;i++){
		a[i]=n-i;}
	BubbleSort(a,n);
	for (int i = 0; i < n; ++i)
	{
		printf(" %d,",a[i]);
	}
	return 0;
}
