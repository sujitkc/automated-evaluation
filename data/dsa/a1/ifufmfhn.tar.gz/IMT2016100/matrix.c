#include<stdio.h>
void multiplication(int F[2][2], int x[2][2]);
void power(int F[2][2], int n);
int fib(int n)
{
  int F[2][2] = {{1,1},{1,0}};
  if (n<2)
      printf("invalid");
  power(F, n);
 
  return F[0][1];
}

 void multiply(int F[2][2], int x[2][2])
{
   
   int a,b,c,d;
   a =  F[0][0]*x[0][0] + F[0][1]*x[1][0];
   b =  F[0][0]*x[0][1] + F[0][1]*x[1][1];
   c =  F[1][0]*x[0][0] + F[1][1]*x[1][0];
   d =  F[1][0]*x[0][1] + F[1][1]*x[1][1];
 
  F[0][0] = (a)%100;
  F[0][1] = (b)%100;
  F[1][0] = (c)%100;
  F[1][1] = (d)%100;
}
 
void power(int F[2][2], int n)
{
 int i,ans[2][2]={{1,0},{0,1}};
  int x[2][2] = {{1,1},{1,0}};
  while(n>=1)
{
	if(n%2==1){
			multiply(ans,x);}
	multiply(x,x);
	n=n/2;
}
F[0][0]=ans[0][0];
F[0][1]=ans[0][1];
F[1][0]=ans[1][0];
F[1][1]=ans[1][1];

			
}
 int main()
{
  int n =4;
  printf("%d",fib(n));
return 0;
  
}
