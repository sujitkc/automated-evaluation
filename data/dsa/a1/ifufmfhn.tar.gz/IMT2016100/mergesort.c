#include<stdio.h>
void Swap(int *a ,int *b){
	int temp;
	temp =*a;
	*a=*b;
	*b=temp;
} 
void merge(int *a,int p,int q,int r)
{
	int b=0;
	int n2=p;
	int n1=r+1;
	int l[100];
	while(n1<q && n2<r){
		if(a[n2]<a[n1]){
			l[b++]=a[n2];
			n2++;
		}
		else{
			l[b++]=a[n1];
			n2++;
		}
	}
	while(n2<q){l[b++]=a[n2];n2++;}
	while(n1<p){l[b++]=a[n1];n1++;}
	int j=0;
	for(b=p;b<r;b++){
		a[b]=l[j++];
	}
	
	
}
void mergesort(int *a,int p,int r)
{
	
	int q;
	
	if(q<=p-1){
		if(a[p]>a[q]){
			Swap(&a[p],&a[q]);
		}
		return;
	}
			
	if(q>p+1)
	{
		q=(p+r)/2;
	  	mergesort(a,p,q);
		mergesort(a,q+1,r);
		merge(a,p,q,r);
	
	}

}
int main()
{
	int t;
	long int n;
	n=10;
	int a[n];
	for(t=0;t<n;t++){
		a[t]=n-t;}


        mergesort(a,0,n);
	for (t=n-1;t>=0;t--)
		{
			printf(" %d",a[t]);}

	
		
	return 0;
}




     
     
