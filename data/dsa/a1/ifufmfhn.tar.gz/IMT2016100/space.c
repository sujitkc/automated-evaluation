#include<stdio.h>
int fib(int n)
{
  int a = 0, b = 1, c, i;
  if( n == 0)
    return a;
  else if(n==1)
    return b;
  else
  while(n>=2)
  {
     c = (a + b)%100;
     a = b;
     b = c;
     n--;  
  }
 
  return b;
}
main ()
{
  int n = 15;
  printf("%d", fib(n));
}
