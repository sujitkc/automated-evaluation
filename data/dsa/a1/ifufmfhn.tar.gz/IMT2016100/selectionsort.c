#include <stdio.h>
void Swap(int *a ,int *b){
	int temp;
	temp =*a;
	*a=*b;
	*b=temp;
}
int max(int *x,int k)
{
	int t,i,pos;
	t=x[0];
	pos=0;
	for(i=1;i<=k;i++)
        {
		if(x[i]>t){
			t=x[i];
			pos=i;
		}
	}
	return(pos);
}
void SelectionSort(int *x ,int s){
	int c,d;
	c=s-1;
	while(c>=0){
		d=max(x,c);
		Swap(&x[d],&x[c]);
		c--;
	}
}
int main()
{
	int i,n=10;
	int a[n];
	for(i=n-1;i>=0;i--){
		a[i]=n-i;
	}

	SelectionSort(a,n);
	for (int i = 0; i < n; i++)
	{
		printf(" %d,",a[i]);
	}
return 0;
}
