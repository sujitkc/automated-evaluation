#include<stdio.h>
#include<stdlib.h>
int fib(int n){

int a,b,temp,c,i;
if (n==0){
return 0;
}

if (n==1){

return 1;}

else{
   a=0;
   b=1;
   c=0;
   for(i=0;i<n-1;i++){
       c=(a+b)%100;
       a=b;
       b=c;


   }
return c;
}


}
int main()
{  int n;
    printf("enter the value\n");
    scanf("%d",&n);
    printf("%d",fib(n));
    return 0;

}





