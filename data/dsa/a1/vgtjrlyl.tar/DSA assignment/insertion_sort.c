#include<stdio.h>
#include<stdlib.h>
int main()
{
int k,j,value,n=100000;
int a[n];
srand(time(NULL));
for(k=0;k<n;k++){
    a[k]=rand()%n;
}
for(k=1;k<n;k++){
    j=k;
    value=a[k];
    while(j>0 && a[j-1]>value){
        a[j]=a[j-1];
        j=j-1;
    }
    a[j]=value;
}
for(k=1;k<n;k++){
    printf("%d\n",a[k]);
}
return 0;
}

