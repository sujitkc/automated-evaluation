#include<stdio.h>
int fib(int n){
    int arr[n],i;
    arr[0]=0;
    arr[1]=1;
    for(i=2;i<n;i++){
        arr[i]=(arr[i-1]+arr[i-2])%100;
    }
  return (arr[n-1]+arr[n-2])%100;
}
int main(){
int n=7;
printf("%d",fib(n));
return 0;

}
