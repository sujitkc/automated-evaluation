#include<stdio.h>
#include<stdlib.h>
main(){
	int i,j,a[10000],temp,minp;
	int n=10000;
	srand(time(NULL));
	for(i=0;i<n;i++){
		a[i]=rand()%n;
	}
	int min;
	for(i=0;i<n;i++){
		min=a[i];
		for(j=i;j<n;j++){
			if(min>a[j]){
				min=a[j];
				minp=j;
			}
		}
		a[minp]=a[i];
		a[i]=min;
	}

	for(i=0;i<n;i++){
		printf("%d\n",a[i]);
	}

}
