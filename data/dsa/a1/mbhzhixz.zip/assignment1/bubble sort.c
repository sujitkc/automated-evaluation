#include<stdio.h>
int bubblesort(int arr[100000],int n){
	int i,j,k,flag;
	for(j=0;j<n;j++){
		flag=0;
	    for(i=0;i<n-1;i++){
		 if(arr[i]>arr[i+1]){
			k=arr[i];
			arr[i]=arr[i+1];
			arr[i+1]=k;
			flag=1;	
		 }
	}  
		 if(flag==0){
		 	break;
		 }	
	}
}
int main(){
	int i,j,flag,k,arr[100000];
	for(i=0;i<100000;i++){
		arr[i]=i%10000;
	}
	bubblesort(arr,100000);
	for(i=0;i<1000;i++){
		printf("%d\n",arr[i]);
	}
}
