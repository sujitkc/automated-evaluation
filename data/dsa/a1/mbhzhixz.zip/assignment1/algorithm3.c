#include<stdio.h>
//works fine for 10^9
int main(){
	long long int a,b,c,n,i;
	a=0;
	b=1;
	scanf("%llu",&n);
	c=n;
	if(n<2){
		printf("%d",n);
		return 0;
	}
	for(i=2;i<=n;++i){
		c=(a+b)%100;
		a=b;
		b=c;
	}
	printf("%llu",b);
}
