def MM (A, B):
    C = [[0 for row in range(len(A))] for col in range(len(B[0]))]
    for i in range(len(A)):
        for j in range(len(B[0])):
            for k in range(len(B)):
                C[i][j] += A[i][k]*B[k][j]
            C[i][j]=C[i][j]%100
    return C
def power(X,a):
    y=[[1,0],[0,1]]
    k=[[1,0],[0,1]]
    i=0
    k=X
    while(i<a-1):
        k=MM(X,y)
        y=k
        i=i+1
    print  k
    print "F("+str(a)+")="+str(k[1][0]%100)
N=[]
a=input()
X=[[1,1],[1,0]]
power(X,a)
while(a!=0):
    if(a%2==0):
        N.insert(0,0)
    else:
        N.insert(0,1)
    a=a/2
print N

