#include<stdio.h>
int linear(int n,int m){
	int f[1000],i,p,k,r=0;
	f[0]=0;
	f[1]=1;
	for(i=2;i<=n;i++){
		f[i]=((f[i-1]+f[i-2])%m);
	}
	printf("%u\n",f[n]);	
}
int main(){
    int p=1,i,r=0;
	i=0;
	int N[1000];
	for(i=0;i<1000;i++){
		N[i]=i%10;
	}
	for(i=0;i<1000;i++){
		printf("%d\t",N[i]);
	}
	printf("\n");
	i=0;
	while(i<1000){
		r=(N[i]*p)+r;
		r=r%300;
		i=i+1;
		p=p*10;
	}
	printf("%d\n",r);
	linear(r,100);	
}
