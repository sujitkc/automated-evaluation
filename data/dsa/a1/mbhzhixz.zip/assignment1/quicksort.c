#include<stdio.h>
int partition(int A[100000],int p,int r){
	int x,k,i,j;
	x=A[r];
	i=p-1;
	for(j=p;j<=r-1;j++){
		if(A[j]<=x){
			i=i+1;
			k=A[j];
		    A[j]=A[i];
		    A[i]=k;
		}
	}
	k=A[r];
	A[r]=A[i+1];
	A[i+1]=k;
	return i+1;
}
int Quicksort(int A[100000],int p,int r){
	int q;
	if(p<r){
		q=partition(A,p,r);
		Quicksort(A,p,q-1);
		Quicksort(A,q+1,r);
	}
}

int main(){
	int arr[100000],i;
	for(i=0;i<100000;i++){
		arr[i]=i%10000;
	}
	Quicksort(arr,0,100000);
	for(i=0;i<1000;i++){
		printf("%d\t",arr[i]);
	}
}
