#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int main()
{
  srand(time(NULL));
  int a=0,b=1,c=0,i=0;
  int p;
  int A[1000];
  for(i=0;i<1000;i++)
    A[i]=rand()%10;
  while(1==1)
  {
    c=(a+b)%100;
    a=b;
    b=c;
    if(i!=1){
	   if(a==0 && b==1){
        break;
       }
   }
    i++;
  }
  p=i+1;
  int r=0;
  for(i=0;i<1000;i++)
      r=(r + A[i]*10) % p;
  for(i=2;i<r ;i++)
  {
    c=(a+b)%100;
    a=b;
    b=c;

  }
  for(i=0;i<1000;i++){
		printf("%d\t",A[i]);
	}
	printf("\n%d\n",r);
  printf("%d\n",c);
}
