def MM (A, B):
    C = [[0 for row in range(len(A))] for col in range(len(B[0]))]
    for i in range(len(A)):
        for j in range(len(B[0])):
            for k in range(len(B)):
                C[i][j] += A[i][k]*B[k][j]
            C[i][j]=C[i][j]%100
    return C
def power(X,a):
    y=[[1,0],[0,1]]
    k=[[1,0],[0,1]]
    i=0
    while(i<a-1):
        k=MM(X,y)
        y=k
        i=i+1
    print  k
    print "F("+str(a)+")="+str(k[1][0]%100)
    
l=int(input("Enter the number of binary bits :"))
N=[input() for i in range(0,l)]
i=l
n=0
a=0
while(i>0):
    a=(N[i-1]*(2**n))+a
    i=i-1
    n=n+1
X=[[1,1],[1,0]]
print a
power(X,a)
print N

