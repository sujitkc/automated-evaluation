#include<stdio.h>
int insertionsort(int arr[100000],int n){
	int i,k,j;
	for(i=0;i<n;i++){
		k=arr[i];
		j=i;
		while(j>0 && arr[j-1]>k){
			arr[j]=arr[j-1];
			j=j-1;
		}
		arr[j]=k;
	}
}
int main(){
	int i,j,k,arr[100000];
	for(i=0;i<100000;i++){
		arr[i]=i%10000;
	}
	insertionsort(arr,100000);
	for(i=0;i<1000;i++){
		printf("%d\t",arr[i]);
	}
}
