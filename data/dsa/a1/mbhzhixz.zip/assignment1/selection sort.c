#include<stdio.h>
int selectionsort(int arr[100000],int n){
	int i,j,k,min=0;
	for(i=0;i<n;i++){
		min=i;
		for(j=i+1;j<n;j++){
			if(arr[j]<arr[min]){
				min=j;
			}
		}
		if (min!=i){
			k=arr[i];
			arr[i]=arr[min];
			arr[min]=k;
		}
	}
}
int main(){
	int i,j,k,min=0;
	int arr[100000];
	for(i=0;i<100000;i++){
		arr[i]=i%10000;
	}
	selectionsort(arr,100000);
	for(i=0;i<1000;i++){
		printf("%d\t",arr[i]);
	}
}
