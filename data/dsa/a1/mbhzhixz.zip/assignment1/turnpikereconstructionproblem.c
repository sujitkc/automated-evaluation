#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int common[100];
int maximum(int arr[100],int n){
	int i,max=arr[0];
	for(i=1;i<n;i++){
		if(arr[i]>max){
			max=arr[i];
		}
	}
	return max;
}
int dele(int arr[100],int n,int del){
	int i,k;
	for(i=0;i<n;i++){
		if(arr[i]==del){
			for(k=i; k<n; k++)
        {
            arr[k] = arr[k+1];
        }
        n--;
		}
	}
}
int bubblesort(int arr[100],int n){
	int i,j,k,c;
	for(j=0;j<n;j++){
		c=0;
	    for(i=0;i<n-1;i++){
		 if(arr[i]>arr[i+1]){
			k=arr[i];
			arr[i]=arr[i+1];
			arr[i+1]=k;
			c=1;	
		 }
	}  
		 if(c==0){
		 	break;
		 }	
	}
}
int main(){
	int s[7]={0,3,5,6,8,10};
	int d[100];
	int i,j,k=0;
	for(i=0;i<7;i++){
		for(j=i+1;j<6;j++){
			d[k]=s[j]-s[i];
			k++;
		}
	}
	for(i=0;i<k;i++){
		printf("%d,",d[i]);
	}
	printf("\n");
	bubblesort(d,k);
	for(i=0;i<k;i++){
		printf("%d,",d[i]);
	}
	int n=((1+sqrt(1+8*k))/2);
	printf("\n%d\n",n);
	int final[n];
	final[0]=0;
	final[n-1]=maximum(d,k);
	dele(d,k,maximum(d,k));
	printf("\n");
	for(i=0;i<k-1;i++){
		printf("%d,",d[i]);
	}
	
}
