#include<stdio.h>
#include<time.h>
#include<stdlib.h>
struct node{
    int value;
    struct node *next;
};

struct node *Insert(struct node *head,int x){
	struct node *temp=(struct node *)malloc(sizeof(struct node));
	int i;
	temp->value=x;
	temp->next=head;
	head=temp;
	return head;
}

void Delete(struct node *head){
	struct node *temp=head;
	int i;
	struct node *temp2=temp->next;
	temp->next=temp2->next;
	free(temp2);
}

void Print(struct node *head){
	struct node *temp=head;
	while(temp!=NULL){
		printf("%d-->",temp->value);
		temp=temp->next;
	}
	printf("NULL\n");
}

void main(){
    struct node *arr[100],*ptr,*l;
    int i,temporaryindex,number,count;
    //initiating all the linked list in the array to NULL
    for(i=0;i<100;i++){
        arr[i]=NULL;
    }
    for(i=0;i<100;i++){
        temporaryindex=rand()%100;
        number=rand()%100;
        arr[temporaryindex]=Insert(arr[temporaryindex],number);
    }
    for(i=0;i<100;i++){
    	printf("\n%d :",i);
        ptr=arr[i];
        Print(arr[i]);
        while(ptr!=NULL && ptr->next!=NULL ){
            if(ptr->value%2==0 && (ptr->next)->value%2==0){
                if((ptr->value)>((ptr->next)->value)){
                    if(ptr==arr[i]){
                        arr[i]=ptr->next;
                    }
                    else{
                        Delete(ptr);
                    }
                }
                else{
                    ptr->next=(ptr->next)->next;
                }
            }
            else if(ptr->value%2==1 && (ptr->next)->value%2==1){
                if(ptr->value>(ptr->next)->value){
                    ptr->next=(ptr->next)->next;
                }
                else{
                    if(ptr==arr[i]){
                        arr[i]=ptr->next;
                    }
                    else{
                        Delete(ptr);
                    }
                }
            }
            else if(ptr->value%2==1 && (ptr->next)->value%2==0){
                    if(ptr==arr[i]){
                        arr[i]=ptr->next;
                    }
                    else{
                        Delete(ptr);
                    }
                }
            else if(ptr->value%2==0 && (ptr->next)->value%2==1){
                    ptr->next=(ptr->next)->next;
                }
            if(ptr->next!=NULL){
                ptr=ptr->next;
            }
            else{
                l=arr[i];
                count=0;
                while(l!=NULL){
                    count++;
                    l=l->next;
                }
                if(count>1){
                    ptr=arr[i];
                }
            }
        }
    }
    printf("\n");
    int j;
    count=0;
    for(i=0;i<100;i++){
        if (arr[i]!=NULL){
            count++;
        }
    }
    for(i=0;i<100;i++){
        if(arr[i]!=NULL)
            printf("%d\n",arr[i]->value);
    }
    while (count>=1){
    if (count!=1){
        for(i=0;i<99;i++){
        if(arr[i]!=NULL){
            for(j=i+1;j<100;j++){
                if (arr[j]!=NULL){
                printf("\ncomparing %d  and  %d\n",arr[i]->value,arr[j]->value);
                if(arr[j]->value%2==0 && arr[i]->value%2==0){
                    if(arr[j]->value>arr[i]->value){
                        arr[j]=NULL;
                    }
                    else{
                        arr[i]=NULL;
                    }
                }
                else if(arr[j]->value%2==1 && arr[i]->value%2==1){
                    if(arr[j]->value>arr[i]->value){
                        arr[i]=NULL;
                    }
                    else{
                        arr[j]=NULL;
                    }
                }
                else if(arr[j]->value%2==1 && arr[i]->value%2==0){
                        arr[j]=NULL;
                }
                else{
                        arr[i]=NULL;
                }
                count--;
                i=j+1;
                break;
        }}}}
        }
        else{
            for(i=0;i<100;i++){
                if(arr[i]!=NULL){
                    printf("after all comparisions answer is %d",arr[i]->value);
                }
            }
            count--;
        }
    }
}


