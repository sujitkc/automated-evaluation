#include<stdio.h>
int merge(int A[100000],int p,int q,int r){
	int n1=q-p+1;
	int n2=r-q;
	int L[100000],R[100000],i,j,k;
	for(i=1;i<=n1;i++){
		L[i]=A[p+i-1];
	}
	for(j=1;j<=n2;j++){
		R[j]=A[q+j];
	}
	L[n1+1]=1000000;
	R[n2+1]=1000000;
	i=1;
	j=1;
	for(k=p;k<=r;k++){
		if(L[i]<=R[j]){
		A[k]=L[i];
		i++;
	}
	else{
	    A[k]=R[j];
		j++;	
	}
	}
	
}
int  mergesort(int A[100000],int p,int r){
	if(p<r){
		int q;
		q=(p+r)/2;
		mergesort(A,p,q);
		mergesort(A,q+1,r);
		merge(A,p,q,r);
	}
}
int main(){
	int arr[100000],i;
	for(i=0;i<100000;i++){
		arr[i]=i%10000;
	}
	mergesort(arr,0,100000);
	for(i=0;i<1000;i++){
		printf("%d\t",arr[i]);
	}
}
