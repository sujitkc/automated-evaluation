#include<stdio.h>
int rec(int n){
	if(n<2){
		return n;
	}
	else{
		return((rec(n-1)+rec(n-2))%100);
	}
}
int main(){
	printf("%d",rec(36));
}
/*
Output for 40:
sh-4.2$ time a.out                                                                                                                                                                  
55                                                                                                                                                                                  
real    0m1.026s                                                                                                                                                                    
user    0m1.024s                                                                                                                                                                    
sys     0m0.002s

//
Output for 39:                                                                                                                                                                    
sh-4.2$ gcc main.c                                                                                                                                                                  
sh-4.2$ time a.out                                                                                                                                                                  
86                                                                                                                                                                                  
real    0m0.752s                                                                                                                                                                    
user    0m0.752s                                                                                                                                                                    
sys     0m0.001s
*/
