PSEUDO-CODE

int a = 0;
int b =1;
int c = n;
for(i=2; i<=n; i++)
   {
	c = (a+b)%100;
	a=b;
	b=c;
   }
return c;