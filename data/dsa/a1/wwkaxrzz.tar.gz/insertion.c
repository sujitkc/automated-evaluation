PSEUDO-CODE

insertionsort(arr, n)
{
    for i = 1 -> n-1
    {
	val = arr[i]
	hole = i
	while(hole > 0 && arr[hole-1] > val)
	{
	    arr[hole] = arr[hole-1]
	    hole = hole-1
	}
	arr[hole] = val
    }
}