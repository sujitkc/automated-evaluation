quicksort(arr[], start, end)
{
    if(start < end)
    {
	pindex = partition(arr[], start, end)	//assigning the index of the pivot.
    	quicksort(arr[], start, pindex-1)
    	quicksort(arr[], pindex+1, end)
    }
}

partition(arr[], start, end)
{
    pivot = arr[end]
    pindex = start
    for i = start -> end-1
    {
	if(arr[i] <= pivot)
	{
	    swap(arr[i], arr[pindex])
	    pindex++
	}
    }
    swap(arr[pindex], arr[end])
    return pindex
}