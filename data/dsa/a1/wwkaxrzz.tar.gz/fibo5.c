#include <stdio.h>

#include <stdlib.h>

#include <string.h>


void MM(int a[2][2],int b[2][2])

{	
	
	int ans[2][2]={0};

	for(int i=0;i<2;i++)

	{
	
		for (int j=0;j<2;j++)

		{
	
			int sum=0;

			for(int k=0;k<2;k++)

			{
	
				sum=sum+(a[i][k]*b[k][j]);

			}
			
			ans[i][j]=sum%100;

		}
	
	}
	
	for(int i=0;i<2;i++)
	
	{

		for(int j=0;j<2;j++)

			a[i][j]=ans[i][j];

	}

}



int power(int arr[2][2],int N[4])

{ 	
	int i=4-1;

	int y[2][2];

	y[0][0]=y[1][1]=1;

	y[0][1]=y[1][0]=0;

	for(int i=0;i<2;i++)

	{

		for(int j=0;j<2;j++)

			printf("%d ",y[i][j]);
 	
	}
	
	while(i>=0)

	{
	
		if(N[i]==1)
	
	{
		
	MM(y,arr);

		}

	MM(arr,arr);

	i-=1;
	}

	for(int i=0;i<2;i++)

	{
	
	for(int j=0;j<2;j++)

		printf("%d ",y[i][j]);
 	}
}


int main()
{

  int inp[4];

  for(int i=0;i<4;i++)

	scanf("%d",&inp[i]);

	int A[2][2];

	A[0][1]=A[0][0]=A[1][0]=1;

	A[1][1]=0;

	power(A,inp);

}