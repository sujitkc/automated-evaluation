merge(larr, rarr, arr)
{
   nlarr = length of larr
   nrarr = length of rarr
   i = j = k = 0
   while(i < nlarr && j < nrarr)
   {
	if(larr[i] <= rarr[j])
	{
	   arr[k] = larr[i]
	   i++
	}   
	else
	{    
	   arr[k] = rarr[j]
	   j++
	}
	k++
    }
    while(i < nlarr)
    {
	arr[k] = larr[i]
	i++
	k++
    }
    while(j < nrarr)
    {
	arr[k] = rarr[j]
	j++
	k++
}

mergesort(arr)
{
    n = length of arr
    if(n<2)
    	return
    mid = n/2
    larr -> array of size(mid)
    rarr -> array of size(n - mid)
    for i= 0 -> mid - 1
	larr[i] = arr[i]
    for i = mid -> n-1
	right[i-mid] = arr[i]
    mergesort(larr)
    mergesort(rarr)
    merge(larr, rarr, arr)
}
