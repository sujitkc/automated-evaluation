Pseudo code

selectionsort(arr, n)		//n - number of elements
{
    for i = 0 -> n-2		//the number of passes will be n-1 because in the last pass, all the elements will be sorted.
    {
	iMIN = i		//iMIN stores in the index of the lowest element. [This will run n-1 times as this is a necessary cond.]
	for j = i+1 -> n-1	//loop for searching the element which is lower than the current minimum
	{
	   if(arr[j] < arr[iMIN])
		iMIN = j 
	}
	temp = arr[i]
	arr[i] = arr[iMIN]
	arr[iMIN = temp
    }
}
