#include<stdio.h>
int fun(int n){
	if(n<2){
		return n;
	}
	else{
		return (fun(n-1)+fun(n-2))%100;
	}
}

int main(){
	int a;
	printf("Enter element:");
	scanf("%d",&a);
	printf("%d",fun(a));
	return 0;
}
