#include<stdio.h>
int partition(int a[],int x,int y){
	int t;
	int k=y;
	for(int i=y; i>=x; i--){
		if(a[i]>a[x]){
			t=a[i];
			a[i]=a[k];
			a[k]=t;
			k-=1;
		}
	}
	t=a[x];
	a[x]=a[k];
	a[k]=t;
	return k;
	
}
void quicksort(int a[],int x,int y){
	if(x-y>=0){
		return;
	}
	else{
	int k=partition(a,x,y);
	quicksort(a,x,k-1);
	quicksort(a,k+1,y);
	}
}
int main(){
	int n,i;
	printf("Enter total elements:");
	scanf("%d",&n);
	printf("\nEnter Elements:");
	int a[n],t;
	for(i=0; i<n; i++){
		scanf("%d",&a[i]);
	}
	quicksort(a,0,n-1);
	for(i=0; i<n; i++){
		printf("%d\t",a[i]);
	}
}

