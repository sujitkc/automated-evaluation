#include<stdio.h>
#include <stdlib.h>
struct node{
	int data;
	struct node *next;
}*current,*newnode;
node *a[10]={0};
int b[10];
void deletenode(int i){
	struct node *temp1;
	temp1=current->next;
	if(current->data%2==0 and temp1->data%2==0){
		if(current->data>temp1->data){
			a[i]=temp1;
			free(current);
		}
		else{
			current->next=temp1->next;
			free(temp1);
		}
	}
	else if(current->data%2!=0 and temp1->data%2!=0){
		if(current->data<temp1->data){
			a[i]=temp1;
			free(current);
		}
		else{
			current->next=temp1->next;
			free(temp1);
		}
	}
	else{
		if(current->data%2!=0){
			a[i]=temp1;
			free(current);
		}
		else{
			current->next=temp1->next;
			free(temp1);
		}
	}
}
int main(){
	int i,k;
	for(i=0; i<20; i++){
		k=rand()%10;
		newnode = (struct node*)malloc(sizeof(struct node));
   		newnode->data = rand()%5;
		newnode->next=0;
		if(a[k]==0){
			a[k]=newnode;
		}
		else{
			current=a[k];
			while(1){
				if(current->next==0){
					current->next=newnode;
					break;
				}
				current=current->next;
			}
		}
				
	}
	int count=0;
	for(i=0; i<10; i++){
		if(a[i]!=0){
			b[count]=i;
			count++;
			current=a[i];
				printf("Index no.= %d :",i);
			while(current!=0){
				printf("%d ",current->data);
				current=current->next;
			}
			printf("\n");
		}
	}
	
	for(i=0; i<10; i++){
		if(a[i]!=0){
			while(a[i]->next!=0){
				current=a[i];
				deletenode(i);
			}
		}
	}
	
	printf("\n\n");
	for(i=0; i<10; i++){
		if(a[i]!=0){
			current=a[i];
				printf("Index no.= %d :",i);
			while(current!=0){
				printf("%d ",current->data);
				current=current->next;
			}
			printf("\n");
		}
	}
		k=0;
		int c[10],t=0;
		for(i=0; i<count; i++){
			if(a[b[i]]->data%2!=0){
				k++;
			}
			else{
				c[t]=a[b[i]]->data;
				t++;
			}
	}
	int s=a[b[0]]->data;
	if(k==count){
		for(i=0; i<count; i++){
			if(a[b[i]]->data>s){
				s=a[b[i]]->data;
			}
		}
		printf("Element : %d",s);
	}
	else{
		s=c[0];
		for(i=0; i<t; i++){
				if(a[b[i]]->data<s){
				s=a[b[i]]->data;
			}
		}
		printf("\nFinally Element left: %d",s);
	}
	
	return 0;
}
	
	
