#include <stdio.h>
int main(){
	int n,i;
	printf("Enter total elements:");
	scanf("%d",&n);
	printf("\nEnter Elements:");
	int a[n],t,j,k;
	for(i=0; i<n; i++){
		scanf("%d",&a[i]);
	}
	for(i=0; i<n-1; i++){
		t=a[i];
		for(j=i+1; j<n; j++){
			if(t>a[j]){
				t=a[j];
				k=j;
			}
		}
		if(t!=a[i]){
			a[k]=a[i];
			a[i]=t;
		}
	}
	printf("\n");
	for(i=0; i<n; i++){
		printf("%d\t",a[i]);
	}
	return 0;
}

