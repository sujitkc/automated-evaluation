#include<stdio.h>
int main(){
	long long int i,n,c;
	printf("Enter Element:");
	scanf("%lld",&n);
	int a=0;
	int b=1;
	for(i=2; i<n+1; i++){
		c=(a+b)%100;
		a=b;
		b=c;
	}
	printf("%lld",c);
}
