#include<stdio.h>
void merge(int a[],int i,int k,int j){
	int b[j]={0},x;
	for(x=i; x<=j; x++){
		b[x]=a[x];
	}
	int y;
	x=i,y=k+1;
	int t=i;
	while(x<=k && y<=j){
		if(b[x]>b[y]){
			a[t]=b[y];
			y++;
		}
		else{
			a[t]=b[x];
			x++;
		}
		t++;
	}
	while(x<=k){
		a[t]=b[x];
		x++;
		t++;
	}
	while(y<=j){
		a[t]=b[y];
		y++;
		t++;
	}
}
void inversion(int a[],int i,int j){
	if(j<i+1){
		return;
	}
	else{
		int k=(i+j)/2;
		inversion(a,i,k);
		inversion(a,k+1,j);
		merge(a,i,k,j);
	}
}

int main(){
	int n;
	printf("Total elements:");
	scanf("%d",&n);
	int i,j,a[n];
	printf("Enter elements:");
	for(i=0; i<n; i++){
		scanf("%d",&a[i]);
	}
	inversion(a,0,n-1);
	for(i=0; i<n; i++){
		printf("%d\t",a[i]);
	}
}
