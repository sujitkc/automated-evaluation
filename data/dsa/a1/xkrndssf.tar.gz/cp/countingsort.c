#include<stdio.h>
#include<stdlib.h>
int main(){
	int n;
	printf("Total Elements:");
	scanf("%d",&n);
	int a[n],i;
	printf("Enter elements:");
	for(i=0; i<n; i++){
		scanf("%d",&a[i]);
	}
	int b[10]={0};
	for(i=0; i<n; i++){
		b[a[i]]+=1;
	}
	int c[n]={0};
	for(i=1; i<10; i++){
		b[i]+=b[i-1];
	}
	for(i=0; i<n; i++){
		c[b[a[i]]-1]=a[i];
		b[a[i]]--;
	}
	for(i=0; i<n; i++){
		printf("%d\t",c[i]);
	}
	
	
}
