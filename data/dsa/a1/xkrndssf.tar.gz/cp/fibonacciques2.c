#include <stdio.h>
int main(){
	int i,n;
	printf("Enter element:");
	scanf("%d",&n);
	int a[n];
	a[0]=0;
	a[1]=1;
	for(i=2; i<n+1; i++){
		a[i]=(a[i-1]+a[i-2])%100;
	}
	printf("%d",a[n]);
}
