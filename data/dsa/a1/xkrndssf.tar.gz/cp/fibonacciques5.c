#include<stdio.h>
#include<stdlib.h>
void matrixmul(int a[2][2],int b[2][2]){
	int c[2][2],x=0,i,j;
	int k;
	for(i=0; i<2; i++){
		for(j=0; j<2; j++){
			for(k=0; k<2; k++){
				x+=a[i][k]*b[k][j];	     	
			}
			c[i][j]=x%100;
			x=0;
		}
	}
	for(i=0; i<2; i++){
		for(j=0; j<2; j++){
			a[i][j]=c[i][j];
		}
	}
}
int main(){
	int arr[10000],i,j;
	for(i=0; i<10000; i++){
		arr[i]=rand()%2;
	}
	i=9999;
	int x[2][2]={{1,1},{1,0}};
	int y[2][2]={{1,0},{0,1}};
	while(i>=0){
		if(arr[i]==1){
			matrixmul(y,x);
		}
		matrixmul(x,x);
		i--;
	}
	for(i=0; i<2; i++){
		for(j=0; j<2; j++){
			printf("%d\t",y[i][j]);
		}
	}
	printf("%d",y[0][1]);
}
