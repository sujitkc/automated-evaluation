#include <stdio.h>
#include <stdlib.h>
typedef struct Node NODE;
struct Node
{
  int x;
  struct Node * nextptr;
};
void insert(NODE ** sptr,int x)
{
	NODE * newptr=malloc(sizeof(NODE));
	newptr->x=x;
	newptr->nextptr=*sptr;
	*sptr=newptr;
}
void hdelete(NODE ** sptr)
{
	if(*sptr==NULL)
		return;
	NODE * ptr=*sptr;
	NODE * newptr=ptr->nextptr;
	NODE * prevptr=*sptr;
	if(newptr==NULL)
		return;
	while(newptr!=NULL)
	{
		while(ptr!=NULL&&newptr!=NULL)
		{
  			if((ptr)->x%2==0&&(newptr)->x%2==0)
  			{
				if((ptr)->x>(newptr)->x)
				{
					NODE * temp=ptr;
				    if(prevptr==*sptr&&*sptr==ptr)
					{
						*sptr=newptr;
						prevptr=*sptr;
					}
					else{
						prevptr->nextptr=newptr;
						prevptr=newptr;
					}
					ptr=newptr->nextptr;
					if(ptr!=NULL)
						newptr=ptr->nextptr;
					else
						newptr=NULL;
					free(temp);
				}
				else{
					NODE * temp=newptr;
    				ptr->nextptr=newptr->nextptr;
					prevptr=ptr;
					ptr=ptr->nextptr;
					if(ptr!=NULL)
						newptr=ptr->nextptr;
					else
						newptr=NULL;
					free(temp);
				}
			}
			else if((ptr)->x%2==1&&(newptr)->x%2==1){
				if((ptr)->x<(newptr)->x){
					NODE * temp=ptr;
    				if(prevptr==*sptr&&*sptr==ptr){
						*sptr=newptr;
						prevptr=*sptr;
					}
					else{
						prevptr->nextptr=newptr;
						prevptr=newptr;
					}
					ptr=newptr->nextptr;
					if(ptr!=NULL)
						newptr=ptr->nextptr;
					else
						newptr=NULL;
					free(temp);
				}
				else{
					NODE * temp=newptr;
    				ptr->nextptr=newptr->nextptr;
					if(prevptr!=*sptr)
						prevptr=ptr;
					ptr=ptr->nextptr;
					if(ptr!=NULL)
						newptr=ptr->nextptr;
					else
						newptr=NULL;
					free(temp);
				}
			}
			else if((ptr)->x%2==1&&(newptr)->x%2==0)
  			{
				NODE * temp=ptr;
    			if(prevptr==*sptr&&*sptr==ptr)
				{
					*sptr=newptr;
					prevptr=*sptr;
				}
				else
				{
					prevptr->nextptr=newptr;
					prevptr=newptr;
				}
				ptr=newptr->nextptr;
				if(ptr!=NULL)
					newptr=ptr->nextptr;
				else
					newptr=NULL;
				free(temp);
			}
			else if(ptr->x%2==0&&newptr->x%2==1)
			{
				NODE * temp=newptr;
    			ptr->nextptr=newptr->nextptr;
				prevptr=ptr;
				ptr=ptr->nextptr;
				if(ptr!=NULL)
					newptr=ptr->nextptr;
				else
					newptr=NULL;
				free(temp);
			}
}
	 	ptr=*sptr;
		newptr=ptr->nextptr;
		prevptr=*sptr;
	}
}	
int main()
{
  	int l=5;
  	int n,k;
  	NODE *arr[l];
	for(k=0;k<l;k++)
		arr[k]=NULL;  	
	printf("Enter the value of n:\n");
  	scanf("%d",&n);
  	while(n>0)
  	{
		k=rand()%l;
		int x;
		x=rand()%1000;
    	insert(&arr[k],x);
    	n--;
  	}
	for(k=0;k<l;k++)
		hdelete(&arr[k]);
	printf("After Horizontal deletion\n");
	for(k=0;k<l;k++)
  	{
		NODE * temp=arr[k];
  		while(temp)
  		{
  	  		printf("%d ",temp->x);
  	  		temp=temp->nextptr;
  		}
  		printf("\n");
	}
	int k1=1,c=l+1,c1;
	while(c!=l-1)
	{
		c=0;
		for(k=0;k<l-1;k++)
		{
			k1=k+1;
			while(arr[k]==NULL)
			{
				k++;
				k1++;
			}
			while(arr[k1]==NULL)
				k1++;
			if(k>l-1||k1>l-1)
				break;
			if(arr[k]->x%2==0&&arr[k1]->x%2==0)
			{
				if(arr[k]->x>arr[k1]->x)
					arr[k]=NULL;
				else
					arr[k1]=NULL;
			}
			else if(arr[k]->x%2==1&&arr[k1]->x%2==1)
			{
				if(arr[k]->x<arr[k1]->x)
					arr[k]=NULL;
				else
					arr[k1]=NULL;
			}
			else if(arr[k]->x%2==1&&arr[k1]->x%2==0)
				arr[k]=NULL;
			else if(arr[k]->x%2==0&&arr[k1]->x%2==1)
				arr[k1]=NULL;
			k=k1;
			}
			int lp1;
			for(lp1=0;lp1<l;lp1++)
			{
				if(arr[lp1]==NULL)
					c++;
				else
					c1=arr[lp1]->x;
			}
		}
		printf("After Vertical Deletion : ");
		for(k=0;k<l;k++)
				if(arr[k]!=NULL)
						printf("%d\n",arr[k]->x);
	return 0;
}
