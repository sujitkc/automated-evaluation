#include <stdio.h>
int matrixmulti (int m1[2][2], int m2[2][2]);
int power (int m1[2][2], int n);
int fibo(int n){
	int m1[2][2]={{1,1},{1,0}};
	power(m1,n-1);
	return m1[0][0];
}
int matrixmulti (int m1[2][2], int m2[2][2]){
	int x = m1[0][0]*m2[0][0]+m1[0][1]*m2[1][0];
	int y = m1[0][0]*m2[0][1]+m1[0][1]*m2[1][1];
	int z = m1[1][0]*m2[0][0]+m1[1][1]*m2[1][0];
	int w = m1[1][0]*m2[0][1]+m1[1][1]*m2[1][1];
	m1[0][0] = x;
	m1[0][1] = y;
	m1[1][0] = z;
	m1[1][1] = w;
}
int power (int m1[2][2], int n){
	int i, m2[2][2]={{1,1},{1,0}};
	for (i=0;i<n-1;i++){
		matrixmulti(m1,m2);
	}
}			
int main(){
	int n;
	printf("enter the fibonacci number\n");
	scanf("%d", &n);
	printf("%d", fibo(n));
	}
	
 	
	
	
	






