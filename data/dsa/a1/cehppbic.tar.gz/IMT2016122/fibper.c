#include <stdio.h>
void main(){
	int i, a=0, b=1, c, n;
	scanf("%d", &n);
	for (i=0;i<6*n;i++){
		c=(a+b)%10;
		printf("%d\n", c);
		a=b;
		b=c;
		if (c==1 && b==0){
			break;
		}
	}
	printf("%d\n", i);
}