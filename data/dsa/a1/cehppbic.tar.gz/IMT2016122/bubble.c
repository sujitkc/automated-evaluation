#include <stdio.h>
#include <stdlib.h>
void main(){
	int l, i, j, k, arr[10]={4,5,3,1,9,7,8,10,6};
	for (i=0;i<9;i++){
		for (j=0;j<9-i;j++){
			if (arr[j]>arr[j+1]){
				k=arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=k;
			}
		}
	}
	for (l=0;l<9;l++){
		printf("%d", arr[l]);
	}
}