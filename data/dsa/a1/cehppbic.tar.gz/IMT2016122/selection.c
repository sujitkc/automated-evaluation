#include <stdio.h>
void main (){
	int temp, minindex, i, j, arr[10]={5,6,3,2,8,7,1,9,4,10};
	for (i=0;i<10;i++){
		minindex=i;
		for (j=i+1;j<10;j++){
			if (arr[j]<arr[minindex]){
				minindex=j;
			}
		temp=arr[minindex];
		arr[minindex]=arr[i];
		arr[i]=temp;
		}
	}
	for (i=0;i<10;i++){
		printf("%d ", arr[i]);
	}
}