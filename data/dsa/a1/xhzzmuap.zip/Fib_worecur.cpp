#include <iostream>
using namespace std;

int main() {
	int i, n=15, a=0, b=1, m=1000;
	for(i=1;i<=n/2;i++){
		a=(a+b)%m;
		b=(b+a)%m;
	}
	if(n%2==0)
	cout<<a;
	if(n%2!=0)
	cout<<b;
	return 0;
}
