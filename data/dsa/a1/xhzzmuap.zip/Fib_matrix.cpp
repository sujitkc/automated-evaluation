#include <iostream>
using namespace std;
void matmul(int*a, int*b){
	int c[4], i, d[4];
	for(i=0;i<4;i++){
		c[i]=a[i];
		d[i]=b[i];
	}
	a[0]=c[0]*d[0]+c[1]*d[2];
	a[1]=c[0]*d[1]+c[1]*d[3];
	a[2]=c[2]*d[0]+c[3]*d[2];
	a[3]=c[2]*d[1]+c[3]*d[3];
}
int main() {
	int a[4], n=15, c[4], i=n, b[4];
	a[0]=a[1]=a[2]=c[0]=c[1]=c[2]=b[0]=b[1]=b[2]=1;
	a[3]=c[3]=b[3]=0;
	while(n>1){
		matmul(a, a);
		if(n%2!=0)
			matmul(b,c);
		n/=2;
	}
	if(b[0]!=1)
		matmul(a,b);
	cout<<i<<" : "<<a[0]<<endl;
	return 0;
}
