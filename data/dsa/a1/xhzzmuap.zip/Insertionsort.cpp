#include <iostream>
#include <algorithm>
#include <time.h>
using namespace std;

int main() {
	const int n=15;
	int a[n], i, j;
	srand(time(NULL));
	for(i=0;i<n;i++)
		a[i]=rand()%n;
	cout<<"Input  : ";
	for(i=0;i<n;i++)
		cout<<a[i]<<" ";
	for(i=1;i<n;i++){
		for(j=i-1;j>=0;j--)
			if(a[j]<a[i])
				break;
		int x=a[i], k;
		for(k=i-1;k>j;k--)
			a[k+1]=a[k];
		a[k+1]=x;
	}
	cout<<"\nOutput : ";
	for(i=0;i<n;i++)
		cout<<a[i]<<" ";
	return 0;
}
