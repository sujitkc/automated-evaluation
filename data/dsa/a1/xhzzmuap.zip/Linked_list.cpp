#include<iostream>
#include<algorithm>
#include<time.h>
using namespace std;
struct Node{
	int v;
	Node*p;
};

int main(){
	int n=15, bol=1, odd=0, even=100000, i, j, k, x;
	Node*f[n], *tmp;
	srand(time(NULL));
	for(i=0;i<n;i++){
		f[i]=0;
		x=rand()%10;
		tmp=f[i];
		cout<<x<<" nos. : ";
		for(j=0;j<x;j++){
			Node*q=new Node;
			(q->v)=rand();
			/*if(q->v%2==0)
				q->v+=1;*/
			cout<<q->v<<" ";
			q->p=0;
			if(tmp==0){
				tmp=q;
				f[i]=q;
			}
			else
				tmp->p=q;
			if((q->v)%2==0){
				bol=0;
				if((q->v)<even)
					even=(q->v);
			}
			else if((q->v)>odd)
				odd=(q->v);
		}
		cout<<endl;
	}
	if(bol)
		cout<<odd;
	else
		cout<<even;
	for(i=0;i<n;i++){
		Node*tmp=f[i];
		if(tmp!=0 && ((bol==0 && tmp->v==even) || (bol==1 && tmp->v==odd))){
			bol=2;
			//cout<<tmp->v;
			f[i]=f[i]->p;
			delete(tmp);
			tmp=f[i];
		}
		while(tmp!=0){
			Node*q=tmp->p;
			if(q!=0 && ((bol==0 && q->v==even) || (bol==1 && q->v==odd))){
				bol=2;
				//cout<<q->v;
			}
			else if(q!=0){
				tmp->p=q->p;
				delete(q);
				q=0;
			}
			//if(tmp==f[i])
			tmp=tmp->p;
		}
	}
}
