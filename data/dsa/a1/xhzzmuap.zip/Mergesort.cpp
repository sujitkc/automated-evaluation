#include <iostream>
#include <algorithm>
#include <time.h>
using namespace std;
void merge(int*a, int l, int m, int r){
	int l1[m+1-l], r1[r-m], i, j, k=0;
	for(i=l;i<=m;i++){
		l1[k]=a[i];
		k++;
	}
	k=0;
	for(i=m+1;i<=r;i++){
		r1[k]=a[i];
		k++;
	}
	i=0;
	j=0;
	k=l;
	while(i<m+1-l && j<r-m){
		if(l1[i]<r1[j]){
			a[k]=l1[i];
			i++;
		}
		else{
			a[k]=r1[j];
			j++;
		}
		k++;
	}
	while(i<m+1-l){
		a[k]=l1[i];
		i++;
		k++;
	}
	while(j<r-m){
		a[k]=r1[j];
		j++;
		k++;
	}
}
void mergesort(int*a, int l, int r){
	int m=(l+r)/2;
	if(l<r){
		mergesort(a, l, m);
		mergesort(a, m+1, r);
		merge(a, l, m, r);
	}
}
int main() {
	const int n=15;
	int a[n], i, j;
	srand(time(NULL));
	for(i=0;i<n;i++)
		a[i]=rand();
	cout<<"Input  : ";
	for(i=0;i<n;i++)
		cout<<a[i]<<" ";
	cout<<endl;
	mergesort(a, 0, n-1);
	cout<<"\nOutput : ";
	for(i=0;i<n;i++)
		cout<<a[i]<<" ";
	return 0;
}
