import math

def check(n, p, d, l):
    d1=d[:]
    l1=l[:]
    try :
        for x in l1:
            if x!=None:
                d1.remove(int(math.fabs(n-x)))
        l1[p]=n
        return True, l1, d1
    except:
        return False, l, d
    
def find(d, l):
    if len(d)==0:
        return True,l,d
    fp=None
    bp=None
    dl=len(d)
    ll=len(l)
    
    for x in xrange(ll):
        if fp==None and l[x]==None:
            fp=x
        if bp==None and l[ll-1-x]==None:
            bp=ll-1-x
            
    for x in xrange(dl):
        sf, lf, df=check(d[x], fp, d, l)
        if sf:
            break
        
    for x in xrange(dl):
        sb, lb, db=check(d[dl-1-x], bp, d, l)
        if sb:
            break
        
    if sf:
        s, laf1, daf1=find(df, lf)
        if s:
            return True, laf1, daf1
        
    if sb:
        s, lab1, dab1=find(db, lb)        
        if s:
            return True, lab1, dab1
    return False, l, d

if __name__=="__main__":
    d=[int(x) for x in raw_input().split(',')]
    n=int((1+((1+(8*len(d)))**0.5))/2)
    a=[None]*n
    a[0]=0
    a[n-1]=d.pop()
    s, a, d=find(d, a)
    if s:
        print a
    else:
        print "does not exist"
