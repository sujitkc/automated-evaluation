#include <iostream>
#include <algorithm>
#include <time.h>
using namespace std;

int main() {
	const int n=15;
	int a[n], i, j;
	srand(time(NULL));
	for(i=0;i<n;i++)
		a[i]=rand()%n;
	cout<<"Input  : ";
	for(i=0;i<n;i++)
		cout<<a[i]<<" ";
	for(i=0;i<n;i++){
		int x=n, l=i;
		for(j=i;j<n;j++)
			if(a[j]<x){
				x=a[j];
				l=j;
			}
		swap(a[i], a[l]);
	}
	cout<<"\nOutput : ";
	for(i=0;i<n;i++)
		cout<<a[i]<<" ";
	return 0;
}
