#include <iostream>
using namespace std;
int m=1000;
int fib(int a){
	if(a==0)
		return 0;
	else if(a==1)
		return 1;
	else
		return (fib(a-1)+fib(a-2))%m;
}
int main() {
	int a=15;
	a=fib(a);
	cout<<a;
	return 0;
}
