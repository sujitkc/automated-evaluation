#include <iostream>
using namespace std;

int main() {
	int i, n=15, m=10, a[6*m+1];
	a[0]=0;
	a[1]=1;
	for(i=2;i<n;i++){
		a[i]=(a[i-1]+a[i-2])%m;
		if(a[i-1]==0 && a[i]==1){
			cout<<a[(n-1)%(i-1)];
			break;
		}
		else if(i==n-1)
			cout<<a[i];
	}
	return 0;
}
