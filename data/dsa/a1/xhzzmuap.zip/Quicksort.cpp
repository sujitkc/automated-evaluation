#include <iostream>
#include <algorithm>
#include <time.h>
using namespace std;

void quicksort(int*a, int l, int r){
	int m=a[(l+r)/2], z, l1=l, r1=r, i;
	while(l<=r){
		if(a[r]>m)
			r--;
		else if(a[l]<m)
			l++;
		else{
			z=a[l];
			a[l]=a[r];
			a[r]=z;
			l++;
			r--;
		}
	}
	if(l1<r)
		quicksort(a, l1, r);
	if(r1>l)
		quicksort(a, l, r1);
}
int main() {
	const int n=15;
	int a[n], i, j;
	srand(time(NULL));
	for(i=0;i<n;i++)
		a[i]=rand()%n;
	cout<<"Input  : ";
	for(i=0;i<n;i++)
		cout<<a[i]<<" ";
	cout<<endl;
	quicksort(a, 0, n-1);
	cout<<"\nOutput : ";
	for(i=0;i<n;i++)
		cout<<a[i]<<" ";
	return 0;
}
