#include <iostream>
#include <algorithm>
#include <time.h>
using namespace std;

int main() {
	const int n=15;
	int a[n], i, j;
	srand(time(NULL));
	for(i=0;i<n;i++)
		a[i]=rand()%n;
	cout<<"Input  : ";
	for(i=0;i<n;i++)
		cout<<a[i]<<" ";
	for(i=0;i<n;i++)
		for(j=0;j<n-1;j++)
			if(a[j]>a[j+1])
				swap(a[j], a[j+1]);
	cout<<"\nOutput : ";
	for(i=0;i<n;i++)
		cout<<a[i]<<" ";
	return 0;
}
