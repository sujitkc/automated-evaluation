#include<stdio.h>
#include<stdlib.h>

int linear(int n)
{
	int a,b,c;
if(n==1)
return 0;
a=0;
b=1;
c=1;
for(int i=3;i<n;i++)
{
	a=b;
	b=c;
	c=(a+b)%100;
}
return c;
}
main()
{
int n;
	scanf("%d",&n);	
printf("\nfibonacy=%d",linear(n));
}
