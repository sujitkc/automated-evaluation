#include <stdio.h>
#include <stdlib.h>

void print(int a[],int size)
{
int i;
for(i=0;i<size;i++)
	{
	printf("%d ",a[i]);
	}
	printf("\n");
}
void sort(int a[],int l,int r)// dividing the array
{
for(int i=l+1;i<=r;i++)
{
	int pos=i,var=a[i];
	if(a[i]<a[i-1])
	{
	for(int j=0;j<i;j++)
	{
		if(a[j]>a[i])
		{
			pos=j;
			break;
		}
	}
	for(int j=i;j>pos;j--)
	a[j]=a[j-1];
	a[pos]=var;
}
	printf("pos= %d ,",pos);
	print(a,10);
}
//print(a,10);
}
int main()
{
int size,i;
scanf("%d",size);
int arr[size];
for(i=0;i<size;i++)
	{
		scanf("%d",&arr[i]);
	}
print(arr,size);
sort(arr,0,size-1);
printf("\n\n");
print(arr,size);
}

