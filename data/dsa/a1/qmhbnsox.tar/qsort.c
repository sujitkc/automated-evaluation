#include<stdio.h>
void printit(int a[],int n)
{
	for(int i=0;i<n;i++)
	printf("%d ",a[i]);
	printf(" ");
}

void swap(int a[],int i,int j)
{
	int temp=a[i];
	a[i]=a[j];
	a[j]=temp;
}


void qsort(int a[],int l,int h)
{
	int pi=h,i=l,j=l;
	for(;i<h;i++)
	if(a[i]<=a[pi])
	{
	swap(a,i,j);
	j++;
	}
	swap(a,j,pi);
	pi=j;
	if(l!=pi)
	{
		qsort(a,l,pi-1);
	}
	if(h!=pi)
	{
		qsort(a,pi+1,h);
	}
	
}

int main()
{
	
int size,i;
scanf("%d",size);
int arr[size];
for(i=0;i<size;i++)
	{
		scanf("%d",&arr[i]);
	}
print(arr,size);
qsort(arr,0,size-1);
printf("\n\n");
print(arr,size);
}
