#include<stdio.h>

void multi(int a[][2],int b[][2])
{
	int c[2][2]={{0,0},{0,0}};
	
	for(int i=0;i<2;i++)
	for(int j=0;j<2;j++)
	for(int k=0;k<2;k++)
	c[i][k]+=a[i][j]*b[j][k];
	for(int i=0;i<2;i++)
	for(int j=0;j<2;j++)
	a[i][j]=c[i][j];
}

main()
{
	int n;
	scanf("%d",&n);
	int a[2][2]={{1,1},{1,0}},a2[2][2]={{1,1},{1,0}};
	for(int i=2;i<n;i++)
	{
		multi(a,a2);
	}
printf("%d",a[1][0]);
}


