#include<stdio.h>
#include<stdlib.h>
long long int recur(int n);
long long int recur(int n)
{
	if((n==1)||(n==2))
	{
		return n-1;
	}
	return recur(n-2)+recur(n-1);	
}


main()
{
int n;
scanf("%d",&n);
printf(" %lld ",recur(n));

}
