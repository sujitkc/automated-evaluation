#include <stdio.h>
#include <stdlib.h>
void sort(int a[],int l,int r)// dividing the array
{
for(int x=l;x<=r;x++)
{
	int	min=a[x],pos=x;
	for(int y=x+1;y<=r;y++)
	{
		if(min>a[y])
		{
			pos=y;
			min=a[y];
			
		}
	}
	a[pos]=a[x];
	a[x]=min;
	
}
}
void print(int a[],int size)
{
int i;
for(i=0;i<size;i++)
	{
	printf("%d ",a[i]);
	}
	printf("/n");
}
int main()
{
int size,i;
scanf("%d",size);
int arr[size];
for(i=0;i<size;i++)
	{
		scanf("%d",&arr[i]);
	}
print(arr,size);
sort(arr,0,size-1);
printf("\n\n");
print(arr,size);
}
