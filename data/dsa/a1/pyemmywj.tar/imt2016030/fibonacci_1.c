#include <stdio.h>
#include<math.h>
int main()
{
    long long int i, n,k;
    k=pow(10,6);
    long long int a[k];
    printf("Enter the number required: ");
    scanf("%lld", &n);
    a[0]=0
    a[1]=1;

    for (i = 2; i <=k ; ++i)
    {
       a[i]=(a[i-1]+a[i-2])%100;
    }
    printf("%lld\n",a[n]);
    return 0;
}