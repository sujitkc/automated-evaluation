#include<stdio.h>
#define MAX 50

void mergeSort(int a[],int low,int mid,int high);
void partition(int a[],int low,int high);

int main(){
   
   int i,j,a[10000],temp;
	int n=10000;
	srand(time(NULL));
	for(i=0;i<n;i++){
		a[i]=rand()%n;
	}

    partition(a,0,n-1);

    for(i=0;i<n;i++){
         printf("%d ",a[i]);
    }

   return 0;
}

void partition(int a[],int low,int high){

    int mid;

    if(low<high){
         mid=(low+high)/2;
         partition(a,low,mid);
         partition(a,mid+1,high);
         mergeSort(a,low,mid,high);
    }
}

void mergeSort(int a[],int low,int mid,int high){

    int i,m,k,l,temp[MAX];

    l=low;
    i=low;
    m=mid+1;

    while((l<=mid)&&(m<=high)){

         if(a[l]<=a[m]){
             temp[i]=a[l];
             l++;
         }
         else{
             temp[i]=a[m];
             m++;
         }
         i++;
    }

    if(l>mid){
         for(k=m;k<=high;k++){
             temp[i]=a[k];
             i++;
         }
    }
    else{
         for(k=l;k<=mid;k++){
             temp[i]=a[k];
             i++;
         }
    }
   
    for(k=low;k<=high;k++){
         a[k]=temp[k];
    }
}
