#include<stdio.h>
#include<stdlib.h>
struct node 
{
int data;
struct node *next;
};

struct node *insert(int data,struct node *t)
{
struct node *new=malloc(sizeof(struct node));
new->data=data;
new->next=t;
return new;
}
void print(struct node *t)
{
while(t!=NULL)
{
printf("%d  ",t->data);
t=t->next;
}
printf("\n");
}
struct node *minimizelink(struct node *t)
{
if(t->next==NULL||t==NULL)
return t;
else
{
struct node *curr = t,*prev=NULL;

while (curr!=NULL&&curr->next!=NULL)
{
struct node *next2=curr->next->next;
if(curr->data%2==0&&curr->next->data%2==0)
{
if(curr->data>curr->next->data)
{
if(prev==NULL)
{
t=curr->next;
}
else 
prev->next=curr->next;
prev=curr->next;
}
else
{
if(prev==NULL)
curr->next=curr->next->next;
else
prev->next=curr->next->next;
prev=curr->next;
}
}
else if(curr->data%2==1&&curr->next->data%2==1)
{
if(curr->data<curr->next->data)
{
if(prev==NULL)
{
t=curr->next;
}
else 
prev->next=curr->next;
prev=curr->next;
}
else
{
if(prev==NULL)
curr->next=curr->next->next;
else
prev->next=curr->next->next;
prev=curr->next;
}

}
else
{
if(curr->data%2==1)
{
if(prev==NULL)
{
t=curr->next;
}
else 
prev->next=curr->next;
prev=curr->next;
}
else
{
if(prev==NULL)
curr->next=curr->next->next;
else
prev->next=curr->next->next;
prev=curr->next;
}
}
curr=next2;
}
return minimizelink(t);
}

}

void main()
{
struct node *arr[10000];
for(int i=0;i<10000;i++)
{
arr[i]=NULL;
}
for(long int x=0;x<100000;x++)
{
int y=rand()%10000;
arr[y]=insert(rand(),arr[y]);
}
for(int i=0;i<10000;i++)
{ if(arr[i]!=NULL)
{
arr[i]=minimizelink(arr[i]);
}
}
//linking all list
struct node *t=NULL,*last=NULL;
for(int i=0;i<10000-1;i++)
{
if(arr[i]!=NULL)
{
if(t==NULL)
{
t=arr[i];
last=arr[i];
}
else
{
last->next=arr[i];
last=arr[i];
}
}
}
t=minimizelink(t);
printf("%d",t->data);
}