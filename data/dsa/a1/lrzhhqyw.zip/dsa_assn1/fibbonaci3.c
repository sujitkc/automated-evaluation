#include<stdio.h>


int fibbonacci(int n) {
  a=0;
  b=1;
  c=n;
  for(int i=2;i<=n;i++)
  {
    c=(a+b)%m;
    a=b;
    b=c;
   }
  return c;
}

int main(){
int n,m,a,b,c;
scanf("%d %d",&n,&m);


for(i = 0;i<n;i++) {
      printf("%d ",fibbonacci(i));
}
return 0;

}