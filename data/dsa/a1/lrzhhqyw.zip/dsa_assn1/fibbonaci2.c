#include<stdio.h>


int f(int n) {
   f(0)=0;
   f(1)=1;
   for(int i=2;i<=n;i++)
   {
     f(n)=((f(n-1)+f(n-2))%m);
    }
}

int main(){
int n,m;
scanf("%d %d",&n,&m);


for(i = 0;i<n;i++) {
      printf("%d ",f(i));
}
return 0;
}