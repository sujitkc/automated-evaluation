#include<stdio.h>
int main(){
	int n;
	printf("enter the size of the array");
	scanf("%d",&n);
	int a[n];
	int i,j,temp,m;
	printf("enter the array");
	for(i=0; i<n;i++)
	{
		scanf("%d", &a[i]);
	}


	for(j=0;j<n-1;++j)
	{
		m=j;
		for(i=j+1;i<n;++i)
		{
			if (a[i]<a[m])
			{
			 m=i;
			}
		}
		if(m!=j)
		{ 
			  temp=a[j];
			  a[j]=a[m];
			  a[m]=temp;
		}



	}


	for(i=0;i<n;i++)
	{
		printf("%d  ",a[i]);
	}
}

