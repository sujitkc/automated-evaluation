#include<stdio.h>
#include<stdlib.h>
#include<time.h>
void swap(int *a, int i, int j)
{
	int temp;
	temp=*(a+i);
	*(a+i)=*(a+j);
	*(a+j)=temp;
}
void print(int a[], int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		printf("%d	",a[i]);
	}
	printf("\n");
}
int partition( int *arr, int l, int r)
{
	srand(time(NULL));
	int pi= l+ rand()%(r+1-l);
	int p= *(arr+pi);
	swap(arr,pi,r);
	pi = r;
	int i = l-1;
	for(int j=l; j<=r-1; j++)
	{
		if(*(arr+j) <= p)
		{
			i = i+1;
			swap(arr,i,j);
		}
	}
	swap(arr,i+1,pi);
	return i+1;
}
void quick_sort(int *a,int i, int j)
{
	int k;
	if(i<j)
	{
		k=partition(a,i,j);
		quick_sort(a,i,k-1);
		quick_sort(a,k+1,j);
	}
	else
		return;
}
void main()
{
	int n=10,i,r;
	int a[n];
	srand(time(NULL));
	for(i=0;i<n;i++)
	{
		r=rand()%100+1;
		a[i]=r;
	}
	printf("\nUnsorted:	\n");
	print(a,n);
	quick_sort(a,0,n-1);
	printf("\nSorted:	\n");
	print(a,n);
}
