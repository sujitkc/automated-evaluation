#include<stdio.h>
#include<stdlib.h>
#include<time.h>
struct node{
	int num;
	struct node *next;
};
int check_smaller(int num1, int num2)
{
	if(num1>num2)
		return num2;
	else
		return num1;
}
int check_larger(int num1, int num2)
{
	if(num1>num2)
		return num1;
	else
		return num2;
}
int check_odd(int num1, int num2)
{
	if(num1%2==1)
		return num1;
	else
		return num2;
}
void add_node(struct node **a, int r)
{
	struct node *t,*sptr;
	t=malloc(sizeof(struct node));
	t->num=r;
	t->next=NULL;
	sptr=*a;
	if (*a==NULL)
	{
		*a=t;
	}
	else
	{
		while(sptr->next!=NULL)
		{
			sptr=sptr->next;
		}
		sptr->next=t;
	}
}
void display(struct node **a)
{
	struct node *sptr;
	sptr=*a;
		if(sptr==NULL)
			return;
		while(sptr->next!=NULL)
		{
			printf("%d ",sptr->num);
			sptr=sptr->next;
		}
		
		printf("%d\n",sptr->num);
}
int operate_on_list(struct node *a, struct node *b,struct node **c)
{
	struct node *zero, *one,*two;
	int t;
	zero=b;
	one=two=*c;
	if(one==NULL||one->next==NULL)
	{
		return 0;
	}
	else
	{
		two=two->next;
		int num1=one->num, num2=two->num;
		if(num1%2==0&&num2%2==0)
			t = check_larger(num1, num2);
		if(num1%2==1&&num2%2==1)
			t = check_smaller(num1, num2);
		if((num1%2==0&&num2%2==1)||(num1%2==1&&num2%2==0))
			t = check_odd(num1, num2);
		//printf("%d	",t);
		if (one->num==t)
			{
				if(zero==one)
				{
					*c=two;
					free(one);
					zero=two;
					two=two->next;
					operate_on_list(two,zero,c);
				}
				else
				{
					zero->next=two;
					free(one);
					two=two->next;
					zero=zero->next;
					operate_on_list(two,zero,c);
				}
			}
		else
			{
				if(zero==one)
				{
					one->next=two->next;
					free(two);
					one=one->next;
					operate_on_list(one,zero,c);
				}
				else
				{
				one->next=two->next;
				free(two);
				one=one->next;
				zero=zero->next;
				operate_on_list(one,zero,c);
				}
			}
	}	
	
}
void operate_on_array(struct node **b,int count, int t)
{
	struct node * one,*two;
	struct node **c;
	one=(*b);
	while(one==NULL&&count<(t-1))
	{
		count++;
		b++;
		one=(*b);
	}
	if(count==(t-1))
	{
		return;
	}
	c=b+1;
	count++;
	two=(*c);
	while(two==NULL&&count<(t-1))
	{
		count++;
		c++;
		two=(*c);
	}
	if(one==NULL||two==NULL)
		return;
	int num1=one->num, num2=two->num,k;
	if(num1%2==0&&num2%2==0)
		k = check_larger(num1, num2);
	if(num1%2==1&&num2%2==1)
		k = check_smaller(num1, num2);
	if((num1%2==0&&num2%2==1)||(num1%2==1&&num2%2==0))
		k = check_odd(num1, num2);
	if(one->num==k)
	{
		(*b)=NULL;
		if(count<(t-1))
		{
			c=c+1;
			count++;
			operate_on_array(c,count,t);
		}
		else
			return;
	}
	else
	{
		(*c)=NULL;
		if(count<(t-1))
		{
			c=c+1;
			count++;
			operate_on_array(c,count,t);
		}
		else
			return;
	}
}
int check(struct node **a, int t)
{
	struct node *cpt;
	int count=0, null=0;
	while(count<t)
	{
		if((*a)==NULL)
		{
			null++;
		}
		count++;
		a++;
	}
	return null;
}
int main()
{
	int t=10000;
	struct node * a[t];
	int n=100000,j;
	for(j=0;j<t;j++)
	{
		a[j]=NULL;
	}
	srand(time(NULL));
	for(j=0;j<n;j++)
	{
		int r = rand()%n+1;
		int i= rand()%t;
		add_node(&a[i], r);
	}
	for(j=0;j<t;j++)
	{
		display(&a[j]);
	}
	for(j=0;j<t;j++)
	{
		while(a[j]!=NULL&&a[j]->next!=NULL)
			operate_on_list(a[j],a[j],&a[j]);
	}
	printf("Pre-final:\n");
	for(j=0;j<t;j++)
	{
		display(&a[j]);
	}
	while(check(a,t)!=(t-1))
		operate_on_array(a,0,t);
	printf("Final:\n");
	for(j=0;j<t;j++)
	{
		display(&a[j]);
	}
}
