#include<stdio.h>
#include<stdlib.h>
#include<time.h>
void swap(int *a, int i, int j)
{
	int temp;
	temp=*(a+i);
	*(a+i)=*(a+j);
	*(a+j)=temp;
}
void print(int a[], int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		printf("%d	",a[i]);
	}
	printf("\n");
}
void selection_sort(int *a, int n)
{
	int i,j, min,temp;
	for(i=0;i<(n-1);i++)
	{
		min=i;
		for(j=i;j<n;j++)
		{
			if(*(a+j)<*(a+min))
			{
				min=j;
			}
		}
		if(i!=min)
		{
			swap(a,i,min);
		}
	}
}
void main()
{
	int n=10,i,r;
	int a[n];
	srand(time(NULL));
	for(i=0;i<n;i++)
	{
		r=rand()%100+1;
		a[i]=r;
	}
	printf("\nUnsorted:	\n");
	print(a,n);
	selection_sort(a,n);
	printf("\nSorted:	\n");
	print(a,n);
}
