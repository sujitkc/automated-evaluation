#include<stdio.h>
#include<stdlib.h>
int algo_2(int n, int k)
{
	int f[n],i;
	f[0]=0;
	f[1]=1;
	for(i=2;i<=n;++i)
	{
		f[i]=(f[i-1] + f[i-2])%k;
	}
	return f[n];
}
void main()
{
	int n,k,i;
	printf("Enter n and k\n");
	scanf("%d%d",&n,&k);
	printf("%d\n",algo_2(n,k));
}
