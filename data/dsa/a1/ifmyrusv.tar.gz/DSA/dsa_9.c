#include<stdio.h>
#include<stdlib.h>
int algo_3(int n, int k)
{
	int a,b,c,i;
	a=0, b=1;
	for(i=2;i<=n;++i)
	{
		c=(a+b)%k;
		a=b;
		b=c;
	}
	return c;
	
}
void main()
{
	int n,k,i;
	printf("Enter n and k\n");
	scanf("%d%d",&n,&k);
	printf("%d\n",algo_3(n,k));
}
