#include<stdio.h>
#include<stdlib.h>
int algo_1(int n, int k)
{
	if(n==0)
		return 0;
	if(n==1)
		return 1;
	else
		return ((algo_1(n-1,k)+algo_1(n-2,k))%k);
}
void main()
{
	int n,k,i;
	printf("Enter n and k\n");
	scanf("%d%d",&n,&k);
	printf("%d\n",algo_1(n,k));
}
