#include<stdio.h>
#include<stdlib.h>
#include<time.h>
void swap(int *a, int i, int j)
{
	int temp;
	temp=*(a+i);
	*(a+i)=*(a+j);
	*(a+j)=temp;
}
void print(int a[], int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		printf("%d	",a[i]);
	}
	printf("\n");
}
void bubble_sort(int *a,int n)
{
	int j;
	while(n>0)
	{
		for(j=0;j<(n-1);j++)
		{
			if(*(a+j)>*(a+j+1))
			{
				swap(a,j,j+1);
			}
		}
		n--;
	}
}
void main()
{
	int n=10,i,r;
	int a[n];
	srand(time(NULL));
	for(i=0;i<n;i++)
	{
		r=rand()%100+1;
		a[i]=r;
	}
	printf("\nUnsorted:	\n");
	print(a,n);
	bubble_sort(a,n);
	printf("\nSorted:	\n");
	print(a,n);
}
