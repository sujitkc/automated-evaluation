#include<stdio.h>
#include<stdlib.h>
#include<time.h>
void swap(int *a, int i, int j)
{
	int temp;
	temp=*(a+i);
	*(a+i)=*(a+j);
	*(a+j)=temp;
}
void print(int a[], int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		printf("%d	",a[i]);
	}
	printf("\n");
}
void merge( int *a, int i, int k, int j)
{
	int l=i, r=k+1, x=0, b[j-i+1];
	while(l<=k&&r<=j)
	{
		if(*(a+l)<*(a+r))
		{
			*(b+x)=*(a+l);
			x++;
			l++;
		}
		else
		{
			*(b+x)=*(a+r);
			x++;
			r++;
		}
	}
	while(l<=k)
	{
		*(b+x)=*(a+l);
		x++;
		l++;
	}
	while(r<=j)
	{
		*(b+x)=*(a+r);
		x++;
		r++;
	}
	x=0;
	for(l=i;l<=j;l++)
	{
		*(a+l)=*(b+x);
		x++;
	}
}
void merge_sort(int *a,int i, int j)
{
	int k;
	if(i<j)
	{
		k=(i+j)/2;
		merge_sort(a,i,k);
		merge_sort(a,k+1,j);
		merge(a,i,k,j);
	}
}
void main()
{
	int n=10,i,r;
	int a[n];
	srand(time(NULL));
	for(i=0;i<n;i++)
	{
		r=rand()%100+1;
		a[i]=r;
	}
	printf("\nUnsorted:	\n");
	print(a,n);
	merge_sort(a,0,n-1);
	printf("\nSorted:	\n");
	print(a,n);
}
