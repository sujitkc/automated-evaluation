#include<stdio.h>
#include<stdlib.h>
#include<time.h>
void swap(int *a, int i, int j)
{
	int temp;
	temp=*(a+i);
	*(a+i)=*(a+j);
	*(a+j)=temp;
}
void print(int a[], int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		printf("%d	",a[i]);
	}
	printf("\n");
}
void insertion_sort(int *a, int n)
{
	int i,j;
	for(i=0;i<n;i++)
	{
		j=i;
		while(j>0)
		{
			if(*(a+j)<*(a+j-1))
			{
				swap(a,j,j-1);
			}
			j--;
		}
	}
}
void main()
{
	int n=10,i,r;
	int a[n];
	srand(time(NULL));
	for(i=0;i<n;i++)
	{
		r=rand()%100+1;
		a[i]=r;
	}
	printf("\nUnsorted:	\n");
	print(a,n);
	insertion_sort(a,n);
	printf("\nSorted:	\n");
	print(a,n);
}
