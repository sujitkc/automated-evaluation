#include<stdio.h>
#include<stdlib.h>
int algo_4(int n, int k)
{
	int a,b,c,i;
	a=0, b=1;
	if(n==0)
		return 0;
	if(n==1)
		return 1;
	for(i=2;i<=n;++i)
	{
		c=(a+b)%k;
		a=b;
		b=c;
	}
	return c;
	
}
int period(int n, int k)
{
	int a,b,c,i,p;
	a=0, b=1,p=0;
	do
	{
		c=(a+b)%k;
		a=b;
		b=c;
		p++;
	}while(a!=0||b!=1);
	while(n>p)
	{
		n=n%(p);
	}
	algo_4(n,k);
}
void main()
{
	int n,k,i;
	printf("Enter n and k\n");
	scanf("%d%d",&n,&k);
	printf("%d\n",period(n,k));
}
