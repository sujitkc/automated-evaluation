#include<stdio.h>
#include<stdlib.h>
#include<math.h>

void Multi2();
void Multi1();

int F[2][2]={{1,1},{1,0}};
int M[2][2]={{1,1},{1,0}};
int count1(int *arr1,int l);
int count(char *n);

main()
{
  char n[20];
  int i,j;
  printf("Enter the value of n:\n");
  scanf("%s",n);
  for(j=1;j<strlen(n);j++)
   {
       if(n[j]=='1')
         Multi2();
       else if(n[j]=='0')
         Multi1();
   }
  printf("%d\n",F[1][0]);
}
/*
void fib(int *arr)
{
    int i=1;
    int F[2][2]={{1,1},{1,0}};
    if(arr[i]==1)
     {
        F;
     }
    power(F,n-1);
    return F[0][0];
}

void power(int n)
{
    int M[2][2]={{1,1},{1,0}};
    int i;
    for(i=2;i<=n;i++)
        Multi(F,M);
}
*/
int count(char *n)
{
    int c=0,i;
    for(i=0;i<strlen(n);i++)
     {
      if(n[i]>'1')
        c++;
     }
     return c;
}

int count1(int *arr1,int l)
{
    int c=0,i;
    for(i=0;i<l;i++)
     {
      if(arr1[i]>0)
        c++;
     }
     return c;
}

void Multi1()
{
  int x =  F[0][0]*F[0][0] + F[0][1]*F[1][0];
  int y =  F[0][0]*F[0][1] + F[0][1]*F[1][1];
  int z =  F[1][0]*F[0][0] + F[1][1]*F[1][0];
  int w =  F[1][0]*F[0][1] + F[1][1]*F[1][1];

    F[0][0]=x%100;
    F[0][1]=y%100;
    F[1][0]=z%100;
    F[1][1]=w%100;

}

void Multi2()
{
  int x =  F[0][0]*F[0][0] + F[0][1]*F[1][0];
  int y =  F[0][0]*F[0][1] + F[0][1]*F[1][1];
  int z =  F[1][0]*F[0][0] + F[1][1]*F[1][0];
  int w =  F[1][0]*F[0][1] + F[1][1]*F[1][1];

    F[0][0]=x%100;
    F[0][1]=y%100;
    F[1][0]=z%100;
    F[1][1]=w%100;
x =  F[0][0]*M[0][0] + F[0][1]*M[1][0];
y =  F[0][0]*M[0][1] + F[0][1]*M[1][1];
z =  F[1][0]*M[0][0] + F[1][1]*M[1][0];
w =  F[1][0]*M[0][1] + F[1][1]*M[1][1];

    F[0][0]=x%100;
    F[0][1]=y%100;
    F[1][0]=z%100;
    F[1][1]=w%100;
}
