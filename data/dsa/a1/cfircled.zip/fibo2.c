#include<stdio.h>
#include<stdlib.h>

main()
{
    int n,m;
    printf("Enter the value of n and m:\n");
    scanf("%d %d",&n,&m);
    int arr[6*m];
    int i;
    arr[0]=0;
    arr[1]=1;
    arr[2]=1;
    for(i=3;i<6*m;i++){
      arr[i]=(arr[i-1]+arr[i-2])%m;
      if(arr[i]==1&&arr[i-1]==0){
            printf("%d \n",i-1);
            break;
      }
    }




}
