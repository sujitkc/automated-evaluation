#include<stdio.h>
#include<stdlib.h>

main()
{
    int a,b,c,n,i;
    printf("Enter the value of n:\n");
    scanf("%d",&n);
    i=3;
    a=1;
    b=1;
    while(i!=n+1)
    {
      c=(a+b)%100;
      i++;
      a=b;
      b=c;
    }
    printf("%d\n",c);
}
