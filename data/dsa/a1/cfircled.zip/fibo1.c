#include<stdio.h>
#include<stdlib.h>
int F(int n);

int F(int n)
{
    if(n==1||n==2)
        return 1;
    else
        return (F(n-1)+F(n-2))%100;
}

main()
{
    int n;
    printf("Enter the value of n:\n");
    scanf("%d",&n);
    printf("The answer is %d:\n",F(n));
}
