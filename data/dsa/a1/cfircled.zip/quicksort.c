#include<stdio.h>
#include<stdlib.h>

void quick_sort(int low,int high);
int partition(int low,int high,int pivot_index);
int arr[10]={10,9,8,8,6,4,5,3,2,1};

void quick_sort(int low,int high)
{
    int pi;
    if(low<=high)
    {
        int pivot_index=low+rand() % (high-low+1);
        int pivot=arr[pivot_index];
        pi=partition(low,high,pivot_index);
        quick_sort(low,pi-1);
        quick_sort(pi+1,high);
    }
}

int partition(int low,int high,int pivot_index)
{
    int leftpointer=low,rightpointer=high;
   while(1)
   {
    while(arr[leftpointer]<arr[pivot_index])
        leftpointer++;
    while(arr[rightpointer]>arr[pivot_index])
        rightpointer--;
    if(leftpointer>=rightpointer)
        return;
    // swap
    int temp=arr[rightpointer];
    arr[rightpointer]=arr[leftpointer];
    arr[leftpointer]=temp;
    //
   }
// again swap
    int flag;
    flag=arr[leftpointer];
    arr[leftpointer]=arr[pivot_index];
    arr[pivot_index]=flag;
    return leftpointer;
}

main()
{
    int i;
    quick_sort(0,9);
    for(i=0;i<10;i++)
        printf("%d ",arr[i]);
}
