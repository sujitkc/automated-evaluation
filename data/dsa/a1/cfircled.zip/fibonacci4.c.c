#include <stdio.h>
int fibonacci(int n,int m);
int main()
{
  int m,n;
  printf("Enter the fibonacci number you like:\n");
  scanf("%d",&n);
  printf("Enter m\n");
  scanf("%d",&m);
  printf("%d\n",fibonacci(n,m));
}
int fibonacci(int n,int m){
  if(n==1 || n==2){
    return n-1;
  }
  else{
    int a=0;
    int b=1;
    int c,i;
    for(i=3;i<=n;i++){
      c=(a+b)%m;
      a=b;
      b=c;
    }
    return c;
  }
}
