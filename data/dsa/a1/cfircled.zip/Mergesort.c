#include<stdio.h>
#include<stdlib.h>
void Merge(int *arr,int i,int k,int j);
void Merge_sort(int *arr,int i,int j);
int B[100000];
main()
{
 int i,j;
 int arr[100000];
 for(i=0;i<100000;i++)
  {
    arr[i]=rand()% 10000;
  }
  // Merge sort
  Merge_sort(arr,0,9999);

  for(i=0;i<100;i++)
    printf("%d ",arr[i]);
}

void Merge_sort(int *arr,int i,int j)
{
    if(j==i+1)
    {
        int temp;
        if(arr[i]>arr[j]){
        temp=arr[i];
        arr[i]=arr[j];
        arr[j]=temp;}
    }

    else if(j>i+1)
    {
        int k=(i+j)/2;
        Merge_sort(arr,i,k);
        Merge_sort(arr,k+1,j);
        Merge(arr,i,k,j);
    }
}

void Merge(int *arr,int i,int k,int j)
{
  int l=i,r=k+1,a=0;
  while(l<=k && r<=j)
  {
      if(arr[l]<arr[r])
         B[a++]=arr[l++];
      else
         B[a++]=arr[r++];
  }
  while(l<=k)
    B[a++]=arr[l++];
  while(r<=j)
    B[a++]=arr[r++];

  a=0;
  l=i;
  while(l<=j)
  {
      arr[l++]=B[a++];
  }
}



