#include<stdio.h>
int main(){
	int n,i;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
	 i=0;
	int im=i;
	int j=0;
	int jm=j;
	int s=0;
	int m=0;
	while(j<n){
		s=s+a[j];
		if(m<s){
			m=s;
			im=i+1;
			jm=j;
		}
		if(s<0){
			i=j;
			s=0;
		}
		j=j+1;
	}
	printf("%d",m);

}