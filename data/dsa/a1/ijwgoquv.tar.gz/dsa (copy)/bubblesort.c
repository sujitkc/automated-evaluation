#include<stdio.h>
void bubble_sort(int[], int);
 
void main() {
   int num;
   scanf("%d",&num);
   int arr[num],i,k;
   for (i = 0; i < num; i++)
      scanf("%d", &arr[i]);
   bubble_sort(arr, num);
    for (k = 0; k < num; k++) {
         printf("%d",arr[k]);
      }
}
 
void bubble_sort(int a[], int num) {
   int i, j, k, temp;
 
    for (i = 1; i < num; i++) {
      for (j = 0; j < num - 1; j++) {
         if (a[j] > a[j+1]) {
            temp = a[j];
            a[j] = a[j+1];
            a[j+1] = temp;
         }
      }
   }
}