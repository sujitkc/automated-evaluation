#include<stdio.h>
#include<stdlib.h>
void multiply(int a[2][2],int b[2][2]){
	int c[2][2],x=0,i,j;
	int k;
	for(i=0; i<2; i++){
		for(j=0; j<2; j++){
			for(k=0; k<2; k++){
				x+=a[i][k]*b[k][j];	     	
			}
			c[i][j]=x%100;
			x=0;
		}
	}
	for(i=0; i<2; i++){
		for(j=0; j<2; j++){
			a[i][j]=c[i][j];
		}
	}
}
int main(){
	int n;
	int arr[1000],i,j;
	for(i=0; i<n; i++){
		arr[i]=rand()%2;
	}
	i=999;
	int x[2][2]={{1,1},{1,0}};
	int y[2][2]={{1,0},{0,1}};
	while(i>=0){
		if(arr[i]==1){
			multiply(y,x);
		}
		multiply(x,x);
		i--;
	}
	for(i=0; i<2; i++){
		for(j=0; j<2; j++){
			printf("%d\t",y[i][j]);
		}
	}
}