#include<stdio.h>
int mergesort(int a[],int,int);
int merge(int a[],int,int,int);
int main(){
	int n,i;
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
	mergesort(a,0,n-1);
	for(i=0;i<n;i++){
		printf("%d",a[i]);
	}
}
int mergesort(int a[],int x,int y){
	if(x<y){
		int m=(x+y)/2;
		mergesort(a,x,m);
		mergesort(a,m+1,y);
		merge(a,x,m,y);
	}

}
int merge(int a[],int l,int m,int r){
	int n1=m-l+1;
	int i,j,k;
	int n2=r-m;
	int b[n1],c[n2];
	for(i=0;i<n1;i++){
		b[i]=a[l+i];
	}
	for(j=0;j<n2;j++){
		c[j]=a[m+1+j];
	}
	 i=0;
	 j=0;
	 k=l;
	while(i<n1&&j<n2){
		if(b[i]<=c[j]){
			a[k]=b[i];
			i++;
		}
		else{
			a[k]=c[j];
			j++;
		}
		k++;
	}
	while(i<n1){
		a[k]=b[i];
		i++;
		k++;
	}
	while(j<n2){
		a[k]=c[j];
		j++;
		k++;
	}
}