#include<stdio.h>
int dp(int);
int main(){
    int n,k;
    scanf("%d",&n);
    k=dp(n);
    printf("%d",k);
}
int dp(int n){
int f[n],i;
f[0]=0;
f[1]=1;
for(i=2;i<=n;++i)
    f[i]=(f[i-1]+f[i-2])%100;
return f[n];
}
