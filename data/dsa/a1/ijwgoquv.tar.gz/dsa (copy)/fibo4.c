#include<stdio.h>
#include<stdlib.h>
int main(){
	int a[1000],i;
	int b[300];
	for(i=0; i<1000; i++){
		a[i]=rand()%10;
	}
	int x=a[999]+a[998]*10+a[997]*100;
	i=996;
	while(i>=0){
		x+=a[i]*100;
		x=x%300;
		i--;
	}
	b[0]=0,b[1]=1;
	for(i=2; i<300; i++){
		b[i]=(b[i-1]+b[i-2])%100;
	}
		printf("%d\t",b[x]);
}
