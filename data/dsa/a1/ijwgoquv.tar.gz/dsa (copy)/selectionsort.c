#include<stdio.h>
int minimum(int ,int);
int main(){
int n,i,j,t,k;
scanf("%d",&n);
int a[n];
for(i=0;i<n;i++){
    scanf("%d",&a[i]);
}
k=n;
i=0;
while(k>0){
    a[i]=minimum(n,i);
    i++;
    k--;
}
for(i=0;i<n;i++){
    printf("%d",a[i]);
}
return 0;
}
int minimum(int n,int k){
    int a[n],i;
int min=a[0];
for(i=k;i<n;++i){
        if (a[i]<min)
            min=a[i];
}
return min;
}
