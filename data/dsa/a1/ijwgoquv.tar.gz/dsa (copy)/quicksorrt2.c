#include<stdio.h>
void quick_sort(int a[],int,int);
int partition(int a[],int,int);
int main(){
    int m,n,i;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    int p=0,r=n-1;
    quick_sort(a,p,r);
    for(i=0;i<n;i++){
        printf("%d ",a[i]);
    }
    return 0;

}
void quick_sort(int a[],int p,int r){
int q,i;
if(p<r){
q=partition(a,p,r);
quick_sort(a,p,q-1);
quick_sort(a,q+1,r);
}
}
int partition(int a[],int p,int r){
int i=r+1;
int j,temp;
int x=a[p];
for(j=r;j>=p+1;j--){
    if (a[j]>=x){
        i=i-1;
        temp = a[i];
        a[i]=a[j];
        a[j] = temp;
    }
}
      temp = a[i-1];
      a[i-1] = a[p];
      a[p] = temp;
      return i-1;
}


