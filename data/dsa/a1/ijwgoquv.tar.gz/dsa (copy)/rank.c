#include<stdio.h>
int partition(int a[],int,int);
int findrank(int a[],int,int,int);
int main(){
	int n,i,p,r,t,m;
	scanf("%d%d",&n,&m);
	int a[n];
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);

	}
	p=0;
	r=n-1;
	t=findrank(a,p,r,m);
	printf("%d",t);
}

int partition(int a[],int p,int r){
	int i=r+1;
	int x=a[p],j,temp,temp1;
	for(j=r;j>p;j--){
		if(a[j]>=x){
			i=i-1;
			temp=a[i];
			a[i]=a[j];
			a[j]=temp;
		}

	}
	temp=a[i-1];
	a[i-1]=a[p];
	a[p]=temp;
	return i-1;
}

int findrank(int a[],int i,int j,int r){
	int p=a[i];
	int k=partition(a,i,j);
	if(r==j+1-k){
		return p;
	}
	else if(r<j+1-k){
		findrank(a,k+1,j,r);
	}
	else{
		findrank(a,i,k-1,r-j-1+k);
	}
}

