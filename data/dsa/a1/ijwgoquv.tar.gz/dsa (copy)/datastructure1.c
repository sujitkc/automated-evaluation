#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node*next;
    }*np,*latest;
    struct node *a[1000]={0};

void deletenode(int b){
    struct node *temp1;
    temp1=latest->next;
    if(temp1->data%2==0 && latest->data%2==0){
        if(latest->data>temp1->data){
            a[b]=temp1;
            free(latest);
        }
        else{
            latest->next=temp1->next;
            free(temp1);
        }
    }
    else if(temp1->data%2!=0 && latest->data%2!=0){
        if(latest->data<temp1->data){
            a[b]=temp1;
            free(latest);
        }
        else{
            latest->next=temp1->next;
            free(temp1);
        }
    }
    else{
        if(latest->data%2==0){
                latest->next=temp1->next;
                 free(temp1);
        }
        else{
            a[b]=temp1;
            free(latest);
        }
    }

}
int main(){
    int n,i,k,t=0,b[10000];
    printf("input number of nodes:");
    scanf("%d",&n);
    for(i=0;i<n;i++){
        k=rand()%10;
        np=(struct node *)malloc(sizeof(struct node));
        np->data=rand()%10;
        np->next=0;
        if(a[k]==0){
            a[k]=np;
        }
        else{
            latest=a[k];
            while(1){
                if(latest->next==0){
                    latest->next=np;
                    break;
                }
                latest=latest->next;
            }
        }
    }
    for(i=0;i<10;i++){
        if (a[i]!=0){
            latest=a[i];
            while(latest!=0){
                printf("%d ",latest->data);
                latest=latest->next;
            }}
            else{
                printf("%d",a[i]);
                }
            printf("\n");
        }
        printf("\n\n");
         for(i=0;i<10;i++){
        if (a[i]!=0){
                b[t]=i;
                t++;
            while(a[i]->next!=0){
                    latest=a[i];
                    deletenode(i);
               }
               printf("%d",a[i]->data);
               }
            else{
                printf("%d",a[i]);
                }
            printf("\n");

        }
        int min=1000;
        for(i=0;i<t;i++)
        {
            if(a[b[i]]->data%2==0 && a[b[i]]->data!=0){
                if(min>a[b[i]]->data){
                    min=a[b[i]]->data;
                }
            }
        }
        printf("\n\n%d",min);


        }




