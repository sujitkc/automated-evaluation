//insertionsort 
#include <stdio.h>
int main()
{
int n,i,j,k;
printf("Enter the size of the array");
scanf("%d", &n);
int a[n];
printf("Enter the array");
for(i=0;i<n;i++)
{	
	scanf("%d",&a[i]);
}
int temp;

for(i=1;i<n;i++)
{
	j=i;
	while(j>0 && a[j-1]>a[j])
		{
			temp = a[j-1];
			a[j-1]=a[j];
			a[j]=temp;
			j=j-1;
		}
}
printf("The sorted array is : ");
for(i=0;i<n;i++)
	{
		printf("%d ", a[i]);
	}
}
			
