//creating an array of linked list 
//comparing adjacent elements and deleting if they are odd and even delete odd; both odd delete smaller num; both even delete bigger number
#include <stdio.h>
#include<stdlib.h>
struct node{							
	int data;
	struct node* next;
	}*start = NULL;
struct node* create()						//creating a node
{
	int ch;
	struct node* start=NULL;
	do
	{
		struct node *new_node,*current;
		new_node=(struct node *)malloc(sizeof(struct node));
		printf("\nEnter the data : ");
		scanf("%d",&new_node->data);
		new_node->next=NULL;
	if(start==NULL)
		{
		start=new_node;
		current=new_node;
		}
	else
		{
		current->next=new_node;
		current=new_node;
		}
	printf("\nDo you want to create another enter 1 for yes and 0 for no: ");
	scanf("%d",&ch);
	}
	while(ch!=0);
return start;
}
int deletenode( struct node *Node )					//deleting a node
	{
		struct node *temp = Node->next;
		if (temp==NULL)return -1;//error
		Node->data = temp->data;
		Node->next = temp->next;
		free(temp);
		return 0;
	}
void printLL(struct node * head){					//printing the linked list
		struct node* temp=head;
		while(temp){
		printf("%d ",temp->data );
		temp=temp->next;
	}
	printf("\n");
}
void simplify(struct node *arr[],int n){		//reducing the linked list 
	struct node* pointer;
	int i;
	for(i=0;i<n;i++)
	{
		pointer = arr[i];
		while(pointer!=NULL&&pointer->next !=NULL)
		{
			int a=pointer->data;
			int b=(pointer->next)->data;
			if(a%2==0 && b%2==1)
				{
					int e=deletenode(pointer->next);
				if(e==-1){
					free(pointer->next);
					pointer->next=NULL;
					}
				}
			if(a%2==1 && b%2==0)
				{
					deletenode(pointer);
				}
			if(a%2==0 && b%2==0)
				{
					if(a>b)
						deletenode(pointer);
					else
					{
						int e=deletenode(pointer->next);
						if(e==-1){
							free(pointer->next);
							pointer->next=NULL;
							}
					}
				}
			if(a%2==1 && b%2==1)
			{
					if(a>b){
						int e=deletenode(pointer->next);
						if(e==-1){
									free(pointer->next);
									pointer->next=NULL;
								}
							}
					else
						deletenode(pointer);
			}
		}
	}
}
int main(void) {
struct node*arr[2];
int i;
for(i=0;i<2;i++)		//creating an array of linked lists
	{
		arr[i]=create();
	}
printf("\n" );
for(i=0;i<2;i++)		//printing the array of linked list
	{
		printLL(arr[i]);
	}
printf("\n" );
simplify(arr,2);
for(i=0;i<2;i++)		//printing the simplified array of linked list
	{
		printLL(arr[i]);
	}
struct node *final=NULL;
struct node *temp;
for(i=0;i<2;i++)
	{
		if(arr[i]!=NULL){
		if(final==NULL){
		final=arr[i];
		}
	else{
		temp=final;
	while(final->next){
	temp=temp->next;
	}
		temp->next=arr[i];
	}
		arr[i]->next=NULL;
		}
}
printf("\n");
printLL(final);
printf("\n");
simplify(&final,1);
printf("Final answer: %d\n",final->data );
}
// 1 1 5 1 3 0 6 1 7 1 8 0



