//exponential time linear space algo
#include <stdio.h>
 
int main(void) {
int n,i;	
	int rec(int n)
		{
			if(n<2)
				return n;
			else
				return (rec(n-1)+rec(n-2))%100;
		}
n=12;
for(i=0;i<=n;i++)
{
printf("%d ",rec(i));
}
	return 0;
}
