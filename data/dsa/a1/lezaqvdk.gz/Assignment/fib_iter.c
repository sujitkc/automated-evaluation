//linear time linear space algo
#include <stdio.h>

int main(void) {
	
int i;
	int dp(int n){
		int f[n];
		f[0]=0;
		f[1]=1;
		if(n>=2)
		{
			for(i=2;i<=n;i++)
			 {f[n] = ((f[n-1]+f[n-2])%100);}
		}
		return f[n];
		
	}

for(i=0;i<=12;i++)
{
	printf("%d ",dp(i));
	}
	return 0;
}
