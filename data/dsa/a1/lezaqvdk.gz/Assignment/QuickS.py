#quicksort
import random
def partition(ali,first,last):
    pivot = ali[first]

    left=first +1
    right=last

    done = False

    while not done:
        while (left<=right and ali[left]<pivot):
            left = left +1
        while (ali[right]>pivot and right>=left):
            right = right-1
        if right<left:
            done = True
        else:
            temp = ali[left]
            ali[left]=ali[right]
            ali[right]=temp

    temp = ali[first]
    ali[first] = ali[right]
    ali[right] = temp

    return right
def qsh(ali,first,last):
    if first<last:
        split = partition(ali,first,last)

        qsh(ali,first,split-1)
        qsh(ali,split+1,last)

def quicksort(ali):
    qsh(ali,0,len(ali)-1)

ali=random.sample(range(0,2000), 100)
quicksort(ali)
print(ali)


            
