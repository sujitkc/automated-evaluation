//bubblesort 
#include <stdio.h>
int main()
{
int n,i,j,k,temp;

printf("Enter the size of the array\n");
scanf("%d", &n);
int a[n];
printf("Enter the array");
for(i=0;i<n;i++)
{
scanf("%d", &a[i]);
}

for(i=0;i<n-1;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if (a[i]>a[j])
			{	
				temp = a[i];
				a[i] = a[j];
				a[j] = temp;
			}
		}
	}
printf("\nThe Sorted array is : ");
for(k=0;k<n;k++)
{
printf("%d ", a[k]);

}
}
	
