//finding the periodicity of fib seq with an m;
#include <stdio.h>
int main(){
int i,a,b,c,m;
puts("for f(n)=f(n-1)+f(n-2) % m enter m");
scanf("%d",&m);
a=0;
	b=1;
	c=0;
for(i=0;i<(6*m+1);i++){
	
	
	c=(a+b)%m;
	a=b;
	b=c;
	printf("%d ",c);
	
	if(a==0 && b==1)
	{break;}
		
	}
printf("the periodicity of the sequence is %d", i+2);
return 0;
}
