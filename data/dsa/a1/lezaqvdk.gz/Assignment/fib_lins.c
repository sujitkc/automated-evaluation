//linear time constant space for fib sequence
#include <stdio.h>

int main(void) {
	int i,n,a,b,c;
	
	int linear(int n){
		a=0;
		b=1;
		c=n;
		for(i=2;i<=n;++i)
		{
			c=(a+b)%100;
			a=b;
			b=c;
			
		}
		return c;
	}
	scanf("%d", &n);
	for(i=0;i<=n;i++)
	{
		printf("%d ", linear(i));
	}
	return 0;
}
