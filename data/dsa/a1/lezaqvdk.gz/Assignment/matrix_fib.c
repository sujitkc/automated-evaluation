//solving fib in matrix form

#include <stdio.h>
#include <math.h>
void multiply(int a[2][2],int b[2][2]){
	int x = a[0][0]*b[0][0] + a[0][1]*b[1][0];
	int y = a[0][0]*b[0][1] + a[0][1]*b[1][1];
	int z = a[1][0]*b[0][0] + a[1][0]*b[1][0];
	int w = a[1][0]*b[0][1] + a[1][0]*b[1][1];
	
	a[0][0] = x;
	a[0][1] = y;
	a[1][0] = z;
	a[1][1] = w;
}
void power1(int a[2][2],int n){
	int b[2][2]={{1,1},{1,0}};
	int i;
	for(i=0;i<n;i++)
		{
			multiply(a,b);
		}
}	
int fib(int n){
	int a[2][2]={{1,1},{1,0}};
	if (n==0)
		return 0;
	if (n==1)
		return 1;
	else 
		power1(a,n-2);
		if (a[0][0]>100)
		return a[0][0]%100;
	else return a[0][0];
	}

long decimaltobinary(long n)
	{
		int reminder;
		long binary =0, i=1;
		while(n!=0)
			{
				reminder = n%2;
				n=n/2;
				binary = binary + (reminder*i);
				i=i*10;
				}
		return binary;
}
long binarytodecimal(long n){
	int reminder;
	long decimal=0,i=0;
	while(n!=0)
	{
		reminder = n%10;
		n=n/10;
		decimal = decimal + (reminder*pow(2,i));
		++i;
	}
	return decimal;
}

int main() {
	long k,l,m,p;
	printf("Enter the binary n\n");
scanf("%ld",&k);
int n= binarytodecimal(k);
int i;
for(i=0;i<=n;i++)

	{printf("%d ",fib(i));}
printf("\n enter the decimal n\n");
scanf("%ld",&l);
m=decimaltobinary(l);
p=binarytodecimal(m);
for(i=0;i<=p;i++)
	{printf("%d ",fib(i));}


	return 0;
}
