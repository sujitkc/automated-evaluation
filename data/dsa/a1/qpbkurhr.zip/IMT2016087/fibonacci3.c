#include <stdio.h>
int main(){
	int a,b,c;
	int n=27;
	a=0;
	b=1;
	c=0;
	for (int i = 2; i < n+1; ++i)
	{
		/* code */
		c=(a+b)%100;
		a=b;
		b=c;
	}
	printf("%d",c);
}