#include <stdio.h>
void MM(int a[2][2],int b[2][2]){
	int i,j,k;
	int c[2][2]={{0,0},{0,0}};
	for (i = 0; i < 2; ++i){
		for (j = 0; j <2 ; ++j){
			for(k=0;k<2;k++){
				c[i][j]+=a[i][k]*b[k][j];
			}
		}
	}
	for (i = 0; i < 2; ++i){
		for (j = 0; j <2 ; ++j){	
		a[i][j]=c[i][j]%100;
		}
}
}



int main(){
	int a[2][2]={{1,1},{1,0}},a1[2][2]={{1,1},{1,0}};
	int k,i;
	for(i=2;i<=100;i++)
	{
		MM(a,a1);
	}
	printf("%d\n",a[1][0]);
	return 0;
}