#include <stdio.h>
void Swap(int *a ,int *b){
	int temp;
	temp =*a;
	*a=*b;
	*b=temp;
}
int max(int *a,int size){
	int i;
	int b=a[0];
	int c=0;
	for(i=0;i<size;++i){
		if(b<=a[i+1]){
			b=a[i+1];
			c=i+1;}			
	}
	return c;
}
void SelectionSort(int *a ,int size){
	int j,k;
	j=size;
	while(j>0){
		k=max(a,j);
		Swap(&a[k],&a[j]);
		j--;
	}
}
int main()
{
	/* code */
	int i,n;
	n=10;
	int a[n];
	for(i=0;i<n;i++)
		a[i]=1;
	SelectionSort(a,n);
	for (int i = 0; i < n; ++i)
	{
		printf(" %d,",a[i]);
	}
	return 0;
}