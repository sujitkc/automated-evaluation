#include <stdio.h>
#include <stdlib.h>
#include <time.h>
void Swap(int *a ,int *b){
	int temp;
	temp =*a;
	*a=*b;
	*b=temp;
}
int Partition(int *a,int i,int j){
	int x=a[j];
	int p,r;
	r=i;
	p=i;
	while(p<j){
		if(a[p]<=x){
			Swap(&a[p],&a[r]);
			r++;
		}
		p++;
	}
	Swap(&a[r],&a[j]);
	return r;
}
int RandomisedPartition(int *a,int i,int j){
	int q;
	q=(i+(rand()%(j-i+1)));
	Swap(&a[q],&a[j]);
	return Partition(a,i,j);
}
void QuickSort(int *a,int i,int j){
	if(i<j){
		int q;
		q=RandomisedPartition(a,i,j);
		QuickSort(a,i,q-1);
		QuickSort(a,q+1,j);
	}
}
int main()
{
	
	int i,n;
	n=5;
	int a[6]={6,4,2,3,6,1};
	QuickSort(a,0,n-1);
	for (int i = 0; i < n; ++i)
	{
		printf(" %d,",a[i]);
	}
	return 0;
}