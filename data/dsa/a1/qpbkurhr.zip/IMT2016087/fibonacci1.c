#include <stdio.h>
int Fib(int n){
	if (n<2)
		return n;
	else
		return (Fib(n-1)+Fib(n-2))%100;	
	
}
int main()
{
	int k;
	k=Fib(27);
	printf("%d",k);
}