#include <stdio.h>
void Swap(int *a ,int *b){
	int temp;
	temp =*a;
	*a=*b;
	*b=temp;
} 

void Merge(int *a,int i1,int k1,int j1){
	int i,j,k;
	int temp[1000000];
	i=i1;
	k=0;
	j=k1+1;
	while(i<=k1 && j<=j1)
	{
		if (a[i]<a[j])
		{
			temp[k]=a[i];
			i++;
			k++;
		}
		else
		{
			temp[k]=a[j];
			j++;
			k++;
		}
	}
	while(i<k1+1)
	{
		temp[k]=a[i];
		
		i++;
		k++;
	}
	while(j<j1+1)
	{
		temp[k]=a[j];
		j++;
		k++;
	}
	for(i=i1,j=0;i<j1+1;i++,j++)
		a[i]=temp[j];
}
void MergeSort(int *a ,int initial,int final)
{
	int k=(initial+final)/2;
	
	if(initial<final){
		
		MergeSort(a,initial,k);
		MergeSort(a,k+1,final);
		Merge(a,initial,k,final);

	}
}	
int main()
{
	/* code */
	int i,n;
	n=1000000;
	int a[n];
	for(i=0;i<n;i++)
		a[i]=n-i;
	MergeSort(a,0,n-1);
	for (int i = 0; i < n; ++i)
	{
		printf(" %d,",a[i]);
	}
	return 0;
}