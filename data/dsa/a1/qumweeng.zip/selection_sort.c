#include <stdio.h>

void SelectionSort(int *arr, int arr_len)
{
	int i, j, temp;
	for(i=0;i<arr_len;i++)
	{
		for(j=i+1;j<arr_len;j++)
		{
			if(arr[i]>arr[j])
			{
				temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
		}
	}
}

void main()
{
	int i, arr[20];
	for(i=0;i<5;i++)
	{
		scanf("%d", &arr[i]);
	}
	SelectionSort(arr, 5);
	for(i=0;i<4;i++)
	{
		printf("%d ", arr[i]);
	}
	printf("%d\n", arr[4]);
}