import random
def mm(A, B):
	if all(len(A[i])==len(A[i+1]) for i in xrange(len(A)-1))==True and all(len(B[i])==len(B[i+1]) for i in xrange(len(B)-1))==True and len(A[0])==len(B):
		C = [[] for i in xrange(len(A))]
		for i in xrange(len(A)):
			for j in xrange(len(B[0])):
				s = 0
				for k in xrange(len(B)):
					s+=A[i][k]*B[k][j];
				C[i].append(s)
		t = []
		for i in C:
			p = C.index(i)
			l = [j%100 for j in i]
			C.pop(p)
			C.insert(p, l)
		return C
	else:
		return "Invalid pair of matrices"
def power(A, n):
	I = [[1, 0], [0, 1]]
	for i in xrange(len(n)):
		if i==len(n)-1:
			A = mm(A, I)
		else:
			if n[i]==1:
				A = mm(A, A)
			if n[i]==0:
				A = mm(A, mm(A, A))
	return A

A = [[1, 1], [1, 0]]
n = []
for i in xrange(1000000):
	n.append(random.randint(0, 1))
print power(A, n)[1][0]