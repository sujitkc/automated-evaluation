#include <stdio.h>

int rec(int n)
{
	int a=0, b=1, c, i;
	if(n<2)
	{
		if(n==0)
		{
			return a;
		}
		else if(n==1)
		{
			return b;
		}
		else
		{
			return -1;
		}
	}
	else
	{
		for(i=2;i<=n;i++)
		{
			c = (a+b)%100;
			a = b;
			b = c;
		}
	}
	return b;
}

void main()
{
	int n;
	scanf("%d", &n);
	printf("%d\n", rec(n));
}