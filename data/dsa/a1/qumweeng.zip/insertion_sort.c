#include <stdio.h>

void InsersionSort(int *arr, int arr_len)
{
	int i, j, temp;
	for(i=0;i<arr_len;i++)
	{
		temp = arr[i];
		j = i-1;
		while(j>=0 && arr[j]>temp)
		{
			arr[j+1] = arr[j];
			j--;
		}
		arr[j+1] = temp;
	}
}

void main()
{
	int i, arr[20];
	for(i=0;i<5;i++)
	{
		scanf("%d", &arr[i]);
	}
	InsersionSort(arr, 5);
	for(i=0;i<4;i++)
	{
		printf("%d ", arr[i]);
	}
	printf("%d\n", arr[4]);
}