#include <stdio.h>

void QuickSort(int *arr, int a, int b)
{
	if(a>=b)
	{
		return;
	}
	int pivot = arr[a];
	int i=a, j, temp;
	for(j=a+1;j<=b;j++)
	{
		if(arr[j]<pivot)
		{
			i++;
			temp = arr[i];
			arr[i] = arr[j];
			arr[j] = temp;
		}
	}
	temp = arr[i];
	arr[i] = arr[a];
	arr[a] = temp;
	QuickSort(arr, a, i-1);
	QuickSort(arr, i+1, b);
}

void main()
{
	int n, i, arr[10000];
	scanf("%d", &n);
	for(i=0;i<n;i++)
	{
		scanf("%d", &arr[i]);
	}
	QuickSort(arr, 0, n-1);
	for (i=0;i<n-1;i++)
	{
		printf("%d ", arr[i]);
	}
	printf("%d\n", arr[n-1]);
}