#include <stdio.h>

void main()
{
	int n, i, a=0, b=1, c, p, count=0;
	for(i=2;i<=1000000;i++)
	{
		c = (a+b)%100;
		a = b;
		b = c;
		count++;
		if(a==0 && b==1)
		{
			p = count;
			break;
		}
	}
	scanf("%d", &n);
	if(n<0)
	{
		printf("Invalid input\n");
	}
	else if(n%p==0)
	{
		printf("%d\n", a);
	}
	else if(n%p==1)
	{
		printf("%d\n", b);
	}
	else
	{
		for(i=2;i<=n%p;i++)
		{
			c = (a+b)%100;
			a = b;
			b = c;
		}
		printf("%d\n", c);
	}
}