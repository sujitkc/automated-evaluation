#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct Node
{
	long int data;
	struct Node *next;
}node;

void insert(node *head, long int data)
{
	while(head->next!=NULL)
	{
		head = head->next;
	}
	head->next = (node *)malloc(sizeof(node));
	head = head->next;
	head->data = data;
	head->next = NULL;
}
void delete(node *head, long int key)
{
	while(head->next!=NULL && head->next->data!=key)
	{
		head = head->next;
	}
	if(head->next==NULL)
	{
		printf("Element %d is absent", key);
	}
	node *temp;
	temp = head->next;
	head->next = temp->next;
	free(temp);
}
long int length(node *head)
{
	long int count = 0;
	while(head->next!=NULL)
	{
		head = head->next;
		count++;
	}
	return count;
}
void reduce(node *head)
{
	if(length(head)==0)
	{
		printf("The linked list is empty.");
	}
	else if(length(head)==1)
	{
		return;
	}
	else if(length(head)==2)
	{
		if((head->next->data)%2==0 && (head->next->next->data)%2!=0)
		{
			delete(head, head->next->next->data);
		}
		else if((head->next->data)%2!=0 && (head->next->next->data)%2==0)
		{
			delete(head, (head->next->data));
		}
		else if((head->next->data)%2==0 && (head->next->next->data)%2==0)
		{
			if((head->next->data)>(head->next->next->data))
			{
				delete(head, (head->next->data));
			}
			else if((head->next->data)<(head->next->next->data))
			{
				delete(head, (head->next->next->data));
			}
			else
			{
				delete(head, (head->next->next->data));
			}
		}
		else
		{
			if((head->next->data)<(head->next->next->data))
			{
				delete(head, (head->next->data));
			}
			else if((head->next->data)>(head->next->next->data))
			{
				delete(head, (head->next->next->data));
			}
			else
			{
				delete(head, (head->next->next->data));
			}
		}
	}
	else
	{
		node *temp;
		long int i;
		/*while(head->next->next!=NULL)
		{
			head = head->next;
		}*/
		temp = head;
		for(i=0;i<length(head)-1;i++)
		{
			/*for(j=0;j<length(head)-i-1;j++)
			{
				head = head->next;
			}*/
			while(head->next->next->next!=NULL)
			{
				head = head->next;
			}
			reduce(head);
			head = temp;
		}
		reduce(head);
	}
}
void print(node *head)
{
	if(head==NULL)
	{
		return;
	}
	printf("%d ", head->data);
	print(head->next);
}

void main()
{
	node *start, *temp, *aol[10000];
	long int m, n, i;
	start = (node *)malloc(sizeof(node));
	srand(time(NULL));
	for(i=0;i<10000;i++)
	{
		aol[i] = (node *)malloc(sizeof(node));
	}
	for(i=0;i<1000000;i++)
	{
		m = rand()%10000;
		n = rand()%1000000;
		insert(aol[m], n);
	}
	for(i=0;i<10000;i++)
	{
		reduce(aol[i]);
		insert(start, aol[i]->next->data);
	}
	reduce(start);
	print(start->next);
	printf("\n");
}