#include <stdio.h>
#include <time.h>

void Merge(int *arr, int i, int k, int j)
{
	int p, l=i, r=k+1, a=0, temp_arr[j-i+1];
	while(l<=k && r<=j)
	{
		if(arr[l]<arr[r])
		{
			temp_arr[a++] = arr[l++];
		}
		else
		{
			temp_arr[a++] = arr[r++];
		}
	}
	while(l<=k)
	{
		temp_arr[a++] = arr[l++];
	}
	while(r<=j)
	{
		temp_arr[a++] = arr[r++];
	}
	for(p=0;p<a;p++)
	{
		arr[p+i] = temp_arr[p];
	}
}
void MergeSort(int *arr, int l, int r)
{
	int mid = (l+r)/2;
	if(l<r)
	{
		MergeSort(arr, l, mid);
		MergeSort(arr, mid+1, r);
		Merge(arr, l, mid, r);
	}
}
void main()
{
	//clock_t start = clock();
	int number_of_elements;
	scanf("%d",&number_of_elements);
	int array[number_of_elements]; 
	int iter;
	for(iter = 0;iter < number_of_elements;iter++)
	{
		scanf("%d",&array[iter]);
	}
	MergeSort(array,0,number_of_elements-1); 
	for(iter = 0;iter < number_of_elements;iter++)
	{
		printf("%d ",array[iter]);
	}
	printf("\n");
	//clock_t end = clock();
	//double time_spent = (double)(end-start) / CLOCKS_PER_SEC;
	//printf("%lF", time_spent);
}