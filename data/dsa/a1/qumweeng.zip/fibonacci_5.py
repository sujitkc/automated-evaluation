import random
def mm(A, B):
	C = [[] for i in xrange(len(A))]
	for i in xrange(len(A)):
		for j in xrange(len(B[0])):
			s = 0
			for k in xrange(len(B)):
				s+=A[i][k]*B[k][j];
			C[i].append(s)
	t = []
	for i in C:
		p = C.index(i)
		l = [j%100 for j in i]
		C.pop(p)
		C.insert(p, l)
	return C
def power(A, n):
	if n==1:
		return A
	elif n==2:
		return mm(A, A)
	else:
		if n%2==0:
			return power(power(A, 2), n/2)
		else:
			return mm(A, power(power(A, 2), n/2))

A = [[1, 1], [1, 0]]
l = []
s = 0
for i in xrange(1000000):
	l.append(random.randint(0, 9))
	s+=l[i]*(10**i)
print power(A, s)[1][0]