#include <stdio.h>

void BubbleSort(int *arr, int arr_len)
{
	int i, swapped, temp;
	do
	{
		swapped = 0;
		for(i=0;i<arr_len-1;i++)
		{
			if(arr[i]>arr[i+1])
			{
				temp = arr[i];
				arr[i] = arr[i+1];
				arr[i+1] = temp;
				swapped = 1;
			}
		}
	}while(swapped);
}

int main()
{
	int i, arr[20];
	for(i=0;i<5;i++)
	{
		scanf("%d", &arr[i]);
	}
	BubbleSort(arr, 5);
	for(i=0;i<4;i++)
	{
		printf("%d ", arr[i]);
	}
	printf("%d\n", arr[4]);

	return 0;
}