#include<stdio.h>
#include<stdlib.h>
void QuickSort(int A[],int start,int end);
int Partition(int A[],int start,int end);
int main(){
  int i,j,A[]={4,8,6,9,3,12,5,1,2,7},n=10,s;
  QuickSort(A,0,10);
  for(s=0;s<n;s++){
    printf("%d,",A[s]);
  }
  return 0;
}
void QuickSort(int A[],int start,int end){
  int pIndex;
  if(start<end){
    pIndex = Partition(A,start,end);
    QuickSort(A,start,pIndex-1);
    QuickSort(A,pIndex+1,end);
  }
}
int Partition(int A[],int start,int end){
  int pivot = A[end],i,temp;
  int pIndex = start;
  for(i=start;i<=end-1;i++){
    if(A[i]<=pivot){
      temp = A[pIndex];
      A[pIndex] = A[i];
      A[i] = temp;
      pIndex++;
    }
  }
  temp = A[end];
  A[end] = A[pIndex];
  A[pIndex] = temp;
 return pIndex;
}
