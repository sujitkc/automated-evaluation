#include<stdio.h>
int fib(int n,int d);
int fib(int n,int d){
  int a=0,b=1,c,i;
  if(n==0){
    return a;
  }
  for(i=2;i<=n;i++){
    c = a + b;
    a = b;
    b = c;
  }
  return b%d;
}
int main(){
  int n,d,m=2;
  printf("enter the divisor: ");
  scanf("%d",&d);
  printf("enter a number: ");
  scanf("%d",&n);
  while(1==1){
    if(fib(m,d)==fib(0,d) && fib(m+1,d)==fib(1,d)){
      break;
    }
    m++;
  }
  n=n%m;
  printf("%d\n",fib(n,d));
  return 0;
}
