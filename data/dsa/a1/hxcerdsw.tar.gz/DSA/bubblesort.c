#include<stdio.h>
#include<stdlib.h>
int main(){
  int i,j,A[]={4,8,6,9,3,12,5,1,2,7},x,k,l,m,r=10,flag,temp;
  /*for(i=0;i<r;i++){
    x = rand();
    A[i] = x;
  }*/

  for(l=1;l<=r-1;l++){
    //flag = 0;
    for(m=0;m<=r-2;m++){
      if(A[m]>A[m+1]){
        temp = A[m];
        A[m] = A[m+1];
        A[m+1] = temp;
      //  flag = 1;
      }
      //if(flag ==0){break;}
    }
  }
  for(j=0;j<r;j++){
    printf("%d,",A[j]);
  }
  return 0;
}
