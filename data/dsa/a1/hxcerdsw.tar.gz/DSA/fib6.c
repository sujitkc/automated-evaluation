#include<stdio.h>
int fib(int n);
void Multiply(int F[2][2],int M[2][2]);
void Power(int F[2][2],int n);
int main(){
  int n,m,base=1,DV=0;
  printf("enter a number in binary: ");
  scanf("%d",&n);
  while(n>0){
    m = n%10;
    DV = DV + base*m;
    base = base*2;
    n=n/10;
  }
  printf("%d\n",fib(DV));
}
int fib(int n){
  int F[2][2]={{1,1},{1,0}};
  if(n==0){
    return 0;
  }
  Power(F,n-1);
  return F[0][0]%100;
}
void Multiply(int F[2][2],int M[2][2]){
  int a =  F[0][0]*M[0][0] + F[0][1]*M[1][0];
  int b =  F[0][0]*M[0][1] + F[0][1]*M[1][1];
  int c =  F[1][0]*M[0][0] + F[1][1]*M[1][0];
  int d =  F[1][0]*M[0][1] + F[1][1]*M[1][1];

  F[0][0] = a;
  F[0][1] = b;
  F[1][0] = c;
  F[1][1] = d;
}
void Power(int F[2][2],int n){
  int i,M[2][2]={{1,1},{1,0}};
  for(i=2;i<=n;i++){
    Multiply(F,M);
  }
}
