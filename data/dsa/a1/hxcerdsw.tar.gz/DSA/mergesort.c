#include<stdio.h>
#include<stdlib.h>
void Merge(int L[],int R[],int A[],int nL,int nR);
void MergeSort(int A[],int n);
int main(){
  int i,j,A[]={4,8,6,9,3,12,5,1,2,7},n=10,s;
  MergeSort(A,n);
  for(s=0;s<n;s++){
    printf("%d,",A[s]);
  }
  return 0;
}
void Merge(int L[],int R[],int A[],int nL,int nR){
  int i=0,j=0,k=0;
  while(i<nL && j<nR){
    if(L[i]<=R[j]){
      A[k] = L[i];
      i++;
    }
    else{
      A[k] = R[j];
      j++;
    }
    k++;
  }
  while(i<nL){
    A[k] = L[i];
    i++;
    k++;
  }
  while(j<nR){
    A[k] = R[j];
    j++;
    k++;
  }
}
void MergeSort(int A[],int n){
  if(n<2){return;}
  int mid = n/2,left[mid],right[n-mid],i,j;
  for(i=0;i<=mid-1;i++){
    left[i] = A[i];
  }
  for(j=mid;j<=n-1;j++){
    right[j-mid] = A[j];
  }
  MergeSort(left,mid);
  MergeSort(right,n-mid);
  Merge(left,right,A,mid,n-mid);
}
