#include<stdio.h>
#include <stdlib.h>
int main(){
  int i,j,temp,n=10,min,A[]={4,8,6,9,3,12,5,1,2,7},l,x,m;
  /*for(l=0;l<n;l++){
    x = rand();
    A[l] = x;
  }*/
  for(i=0;i<=n-2;i++){
    min = i;
    for(j=i+1;j<=n-1;j++){
      if(A[j]<A[min]){
        min = j;
      }
    }
    temp = A[min];
    A[min] = A[i];
    A[i] = temp;
  }
  for(m=0;m<n;m++){
    printf("%d,",A[m]);
  }
  return 0;
}
