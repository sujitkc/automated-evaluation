#include<stdio.h>
#include<stdlib.h>
int main(){
  int i,j,n=10,A[]={4,8,6,9,3,12,5,1,2,7},v,h;
  /*for(d=0;d<n;d++){
    x = rand();
    A[d] = x;
  }*/
  for(i=1;i<=n-1;i++){
    v = A[i];
    h = i;
    while(h>0 && A[h-1]>v){
      A[h] = A[h-1];
      h = h-1;
    }
    A[h] = v;
  }
  for(j=0;j<n;j++){
    printf("%d,",A[j]);
  }
  return 0;
}
