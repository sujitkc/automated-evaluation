//Modified FIB 3//iterative algo
#include <stdio.h>
int main()
{
    int i, n, t1 = 0, t2 = 1, nextTerm = 0;
    printf("Enter the number of terms: ");
    scanf("%d", &n);
    for (i=3;i<= n;++i)
    {
        nextTerm=(t1+t2)%100;
        t1=t2;
        t2=nextTerm;
    }
        printf("%d ", nextTerm);
    return 0;
}
