#include<stdio.h>
#include<string.h>
int division_(int *arr,int divisor,int n)
{
  int new[n];
  int rem;
  for(int i=0;i<=n-1;i++)
  {
    new[i]=arr[i]/divisor;
    rem=arr[i]%divisor;
    arr[i+1]=rem*10+arr[i+1];
  }
  return rem;
}
int Get_period(int m)
{
  int a=0,b=1,c=a+b;
  for(int i=0;i<m*m;i++)
  {
    c=(a+b)%m;
    a=b;
    b=c;
    if(a==0 && b==1)
    {
      return i+1;
    }
  }
}
int get_modulo_number(int *arr,int m,int n,int x)
{
  int remainder_=division_(arr,x,n);
  printf("remainder %d\n",remainder_);
  int a=0,b=1;
  int c;
  for(int i=1;i<remainder_;i++)
  {
    c=(a+b)%100;
    a=b;
    b=c;
  }
  return c%m;
}
int main()
{
  char chararr[1000000];
  printf("Enter number-\n");
  scanf("%s",chararr);
  int n;
  n=strlen(chararr);
  int arr[n];
  for(int i=0;i<n;i++)
  {
    arr[i]=chararr[i]-48;
  }
  printf("Enter number m modulo:\n");
  int m;
  scanf("%d",&m);
  int x;
  x=Get_period(m);
  printf("Period is %d\n",x);
  arr[n-1]=arr[n-1]-1;
  printf("Answer %d\n",get_modulo_number(arr,m,n,x));
}
