//MODIFIED FIB 1//Recursion
#include<stdio.h>
#include<time.h>
int rec(int);
int main()
{
  clock_t start,end;
  double cpu_time_used;
  start=clock();
  int num;
  printf("Enter number of terms in Modified Fibonacci series-");
  scanf("%d",&num);
  //for(int i=0;i<num;i++)
  printf("%d ",rec(num-1));
  end=clock();
  cpu_time_used = ((double) (end - start)) /CLOCKS_PER_SEC;
  printf("time=%lf\n",cpu_time_used);

}
int rec(int n)
{
  if(n<2)
    return n;
  else
  {
    return ((rec(n-1)+rec(n-2))%100);
  }
}
