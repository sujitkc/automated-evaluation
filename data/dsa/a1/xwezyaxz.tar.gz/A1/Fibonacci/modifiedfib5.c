#include<stdio.h>
#include<math.h>
#include<string.h>
void mm(int *M,int *F){
	int row=2,col=2,i,j,k,p=0;
	int m[2][2];
	for(i=0;i<row;i++){
		for(j=0;j<col;j++){
			p=0;
			for(k=0;k<col;k++){
				p+= (*((M+i*col)+k) * *((F+k*col)+j));
			}
			m[i][j]=p;
		}
	}
	for(i=0;i<row;i++){
		for(j=0;j<col;j++){
			*((M+i*col)+j)=m[i][j]%100;
		}
	}
}
void div(int *n,int len){
	int carry=0,num,i;
	for(i=0;i<len;i++){
		num=(*(n+i)+carry*10)/2;
		carry=(*(n+i))%2;
		*(n+i)=num;
	}
}
int main(){
	int M[2][2]={{1,0},{0,1}};
	int F[2][2]={{1,1},{1,0}};
	char s[1000];
	printf("Enter the value of n:\n");
	scanf("%s",s);
	int i;
	int n[strlen(s)];
	for(i=0;i<strlen(s);i++){
		n[i]=s[i]-48;
	}
	int flag1=1;
	while(flag1){
		if(n[strlen(s)-1]%2==1){
			mm((int *)M,(int *)F);
		}
		mm((int *)F,(int *)F);
		div(n,strlen(s));
		for(i=0;i<strlen(s);i++){
			if(n[i]!=0){
				flag1=1;
				break;
			}
			flag1=0;
		}
	}
	printf("%d\n",M[1][0]);
}
