#include<stdio.h>
int Selection_sort(int*,int);
void Print(int*,int);
int swap(int*,int*);
int main()
{
  int n;
  scanf("%d",&n);
  int arr[n];
  for(int i=0;i<n;i++)
  scanf("%d",&arr[i]);
  Selection_sort(arr,n);
  Print(arr,n);
}
int swap(int *a,int *b)
{
  int tmp;
  tmp=*a;
  *a=*b;
  *b=tmp;
}
void Print(int *arr,int n)
{
  for (size_t i = 0; i < n; i++){
    printf("%d\n",arr[i] );
  }
}
int Selection_sort(int *arr,int n)
{
  int i,j,min_index;
  for(i=0;i<n-1;i++)
  {
  //  printf("i=%d\n",i);
    min_index=i;
    for(j=i+1;j<n;j++)
    {
    //  printf("j=%d\n",j);
      if(arr[j]<arr[min_index])
      {
      min_index=j;
    }
  }
      swap(&arr[min_index],&arr[i]);
}
}
