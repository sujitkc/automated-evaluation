#include<stdio.h>
void Quicksort(int*,int,int);
int Partition(int*,int,int);
void swap(int*,int*);
int main()
{
  int n;
  scanf("%d",&n);
  int arr[n];
  for(int i=0;i<n;i++)
  {
    scanf("%d",&arr[i]);
  }
  Quicksort(arr,0,n-1);
  for(int i=0;i<n;i++)
  {
    printf("%d ",arr[i]);
  }
  printf("\n");

}
void Quicksort(int *arr,int start,int end)
{
  //printf("quicksort");
  int partition_index;
  if(start<end)
  {
    partition_index=Partition(arr,start,end);
    Quicksort(arr,start,partition_index-1);
    Quicksort(arr,partition_index+1,end);
  }
}
int Partition(int *arr,int start,int end)
{
  int i;
  int pivot=arr[end];
  int partition_index=start;
  for(i=start;i<=end-1;i++)
  {
    if(arr[i]<=pivot)
    {
      swap(&arr[i],&arr[partition_index]);
      partition_index=partition_index+1;
    }
  }
    swap(&arr[partition_index],&arr[end]);
    return partition_index;
  }
void swap(int *a,int *b)
{
  int temp;
  temp=*a;
  *a=*b;
  *b=temp;
}
