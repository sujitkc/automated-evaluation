#include<stdio.h>
void Insertion_sort(int*,int);
int main()
{
  int n;
  scanf("%d",&n);
  int arr[n],i;
  for(i=0;i<n;i++)
    scanf("%d",&arr[i]);
  Insertion_sort(arr,n);
  printf("Sorted array is-\n");
  for(i=0;i<n;i++)
  {
    printf("%d ",arr[i]);
  }
}
void Insertion_sort(int *arr,int n)
{
  int value,hole,i;
  for(i=1;i<n-1;i++)
  {
    value=arr[i];
    hole=i;
    while(hole>0 && arr[hole-1]>value)
    {
      arr[hole]=arr[hole-1];
      hole--;
    }
    arr[hole]=value;
  }
}
