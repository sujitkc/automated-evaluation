import math
D=[1,2,2,2,3,3,3,4,5,5,5,6,7,8,10]
#D=[2,5,7,9,14,18,19,22,23,30,32,3,5,7,12,16,17,20,21,28,30,2,4,9,13,14,17,18,25,27,2,7,11,12,15,16,23,25,5,9,10,13,14,21,23,4,5,8,9,16,18,1,4,5,12,14,3,4,11,13,1,8,10,7,9,2]
#D=[1,3,6,9,10,13,14,16,18,2,5,8,9,12,13,15,17,3,6,7,10,11,13,15,3,4,7,8,10,12,1,4,5,7,9,3,4,6,8,1,3,5,2,4,2,3,5,7,8,11,12,15,18,20,21]
X=[]
length=len(D)
n=int((1+math.sqrt(1+8*length))/2)
k=0
while(k<n):
    X.append(0)
    k=k+1
def turnpike(D,n,X):
    X[0]=0
    X[n-1]=max(D)
    D.remove(max(D))
    if backtrack(D,X,n,1,n-1):
        return True
    else:
        return False
def backtrack(D,X,n,left,right):
    if not D:
        return True
    max_distance=max(D)
    deleted_distances=[]
    try:
        for i in range(left)+range(right,n):
            D.remove(abs(max_distance-X[i]))
            deleted_distances.append(abs(max_distance-X[i]))
        X[right-1]=max_distance
        flag=backtrack(D,X,n,left,right-1)
        if(flag):return True
    except:
        pass
    X[right-1]=0
    D.extend(deleted_distances)

    deleted_distances=[]
    max_distance=max(X)-max_distance
    try:
        for i in range(left)+range(right,n):
            D.remove(abs(max_distance-X[i]))
            deleted_distances.append(abs(max_distance-X[i]))
        X[left]=max_distance
        flag=backtrack(D,X,n,left+1,right)
        if(flag):return True
    except:
        pass
    X[left]=0
    D.extend(deleted_distances)
turnpike(D,n,X)
print "Reconstructed points are",X
print D
