#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *next;
};
struct node add(struct node **headptr,int value)
{
  struct node *cptr,*prevptr=NULL,*newptr;
  cptr=*headptr;
  newptr=malloc(sizeof(struct node));
	newptr->data=value;
	newptr->next=NULL;
  while(cptr!=NULL)
  {
    prevptr=cptr;
    cptr=cptr->next;
  }
  if(prevptr==NULL)
  {
    *headptr=newptr;
  }
  else{
    prevptr->next=newptr;
  }
  return **headptr;
}
void view(struct node **headptr)
{
	struct node *crtptr;
	crtptr=*headptr;
	while(crtptr!=NULL)
	{
		printf("%d ",crtptr->data);
		crtptr=crtptr->next;
	}

}
int main()
{
	int n, x;
	struct node *head;
	head=NULL;
	struct node *arr[10]={0};
	for(int i=0;i<15;i++)
	{
		x = rand()%10;
		n = rand()%50;
		add(&arr[x],n);
	}
  for(int i=0;i<10;i++)
	{
		view(&arr[i]);
		printf("0\n");
	}
  for(int i=0;i<10;i++)
  {
    while(1)
    {
      struct node *cptr;
      cptr=arr[i];
      if(arr[i]->next==0 || cptr==NULL)
      {
        break;
      }
      if((cptr->data%2)==0 && ((cptr->next)->data)%2!=0)
      {
        cptr->next=(cptr->next)->next;
      }
      else if((cptr->data%2)!=0 && ((cptr->next)->data)%2!=0)
      {
        if((cptr->data)<(cptr->next)->data)
        {
          arr[i]=cptr->next;
        }
        else
        {
          cptr->next=(cptr->next)->next;
        }
      }
      else if((cptr->data%2)==0 && ((cptr->next)->data)%2==0)
        {
          if((cptr->data)>=(cptr->next)->data)
          {
            arr[i]=cptr->next;
          }
          else
          {
            cptr->next=(cptr->next)->next;
          }
        }
      else if((cptr->data%2)!=0 && ((cptr->next)->data)%2==0)
      {
        arr[i]=cptr->next;
      }
    }
  }
  printf("Then\n");
	for(int i=0;i<10;i++)
	{
		view(&arr[i]);

		printf("0\n");
	}

	for(int i=0;i<10;i++)
	{
		if(arr[i]==0)
			continue;
		else
			add(&head,arr[i]->data);
	}
  for(int i=0;i<10;i++)
  {
    while(1)
    {
      struct node *cptr;
      cptr=arr[i];
      if(arr[i]->next==0 || cptr==NULL)
      {
        break;
      }
      if((cptr->data%2)==0 && ((cptr->next)->data)%2!=0)
      {
        cptr->next=(cptr->next)->next;
      }
      else if((cptr->data%2)!=0 && ((cptr->next)->data)%2!=0)
      {
        if((cptr->data)<(cptr->next)->data)
        {
          arr[i]=cptr->next;
        }
        else
        {
          cptr->next=(cptr->next)->next;
        }
      }
      else if((cptr->data%2)==0 && ((cptr->next)->data)%2==0)
        {
          if((cptr->data)>=(cptr->next)->data)
          {
            arr[i]=cptr->next;
          }
          else
          {
            cptr->next=(cptr->next)->next;
          }
        }
      else if((cptr->data%2)!=0 && ((cptr->next)->data)%2==0)
      {
        arr[i]=cptr->next;
      }
    }
  }

		printf("Atlast\n%d",head->data);

	return 0;
}
