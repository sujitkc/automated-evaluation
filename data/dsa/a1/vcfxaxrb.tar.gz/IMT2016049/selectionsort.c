#include <stdio.h>
int main (){
	int x, p, i, j,n;
	printf("enter number of elements.\n");
	scanf("%d",&n);
	int a[n];
	printf("enter %d elements.\n",n);
	for(i=0;i<n;i++){
        scanf("%d",&a[i]);
	}
	for (i=0;i<n;i++){
		p=i;
		for (j=i+1;j<n;j++){
			if (a[j]<a[p]){
				p=j;
			}
		}
		x=a[p];
		a[p]=a[i];
		a[i]=x;
	}
	for (i=0;i<n;i++){
		printf("%d ", a[i]);
	}
	return 0;
}
