#include<stdio.h>
int main(){
	int n;
	printf("enter the number: ");
	scanf("%d",&n);
	int i,a[n+1];
	a[0]=0;	
	a[1]=1;	
	for(i=2;i<n+1;i++)
	{
		a[i]=a[i-1]+a[i-2];
	}
	printf("%d",a[n]);
}