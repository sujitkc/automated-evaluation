#include<stdio.h>

int main(){
	int n;
	printf("enter the number.\n");
	scanf("%d",&n);
	int i,a=0,b=1,c;
	if (n==0)
		printf("0");	
	for(i=2;i<n+1;i++){
		c=a+b;
		a=b;
		b=c;

	}
	printf("%d",b);
	return 0;
}