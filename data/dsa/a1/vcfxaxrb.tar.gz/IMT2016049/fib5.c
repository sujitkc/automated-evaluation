#include<stdio.h>

int fib(int a[], int n, int m){
	a[0]=0; a[1]=1;
	int i;
	for(i=2;i<6*m+1;i++){
		a[i]=(a[i-1]+a[i-2])%m;
		if((a[i]==1) && (a[i-1]==0)){
			return (i-1);
		}
	}
	return -1;
}
int main(){
	int n,m;
	printf("Enter the number\n ");
	scanf("%d",&n);

	printf("Enter the value of the modulus\n ");
	scanf("%d",&m);
	int a[6*m];
	int c;
	c=fib(a,n,m);
	if (c!= -1)	printf("The %dth number is %d",n,a[n%c]);
	else printf("The %dth number of is %d",n,a[n]);
}
