#include<stdio.h>
int main()
{
int A[50],i,j,temp,n;
printf("enter total numbers in list\n");
scanf("%d",&n);
printf("enter array elements\n");
for(i=0;i<n;i++)
	scanf("%d",&A[i]);
for(i=0;i<n;i++)
	{
		for(j=0;j<n-i-1;j++)
			if(A[j]>A[j+1])
			{
				temp=A[j];
				A[j]=A[j+1];
				A[j+1]=temp;
			}
	}
printf("the sorted elements are\n");
for(i=0;i<n;i++)
	printf("%d\n",A[i]);
}
