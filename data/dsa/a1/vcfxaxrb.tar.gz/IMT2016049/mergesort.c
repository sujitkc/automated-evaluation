#include<stdio.h>

void merge(int a[],int i, int mid, int j){
    int x[j-i+1];
    int l=i,r=mid+1,m=0;

    while(l<=mid && r<=j){
        if(a[l]<a[r])
            x[m++]=a[l++];
        else
            x[m++]=a[r++];
    }

    while(l<=mid){
        x[m]=a[l];
        m++;
        l++;
        }
    while(r<=j){
        x[m]=a[r];
        m++;
        r++;
        }
    for(l=i,r=0;l<=j;l++,r++)
        a[l]=x[r];
}




void sort(int a[], int l, int h){
	if(l<h){
		int m;
	m= (l+h)/2;
	sort(a,l,m);
	sort(a,m+1,h);
	merge(a,l,m,h);
	}
}


int main(){
	int n;
	printf("enter number of elements.\n");
	scanf("%d",&n);
	int a[n],k;
	printf("enter %d elements.\n",n);
	for(k=0;k<n;k++){
		scanf("%d",&a[k]);
	}
	sort(a,0,n-1);
	printf("sorted elements are\n");
	for(k=0;k<n;k++){
		printf("%d ",a[k]);
	}

	return 0;
}
