print("enter the elements.\n")
#use space in between elements because split function has been used.
a=map(int,raw_input().split( ))

def partition(a,i,t):
	p = a[i]
	l = i+1
	r= t
	const= False
	while not const:
		while l<= r and a[l]<= p:
			l+=1
		while r>=l and a[r]>= p:
			r-=1
		if r<l:
			const = True
		else:
			x= a[l]
			a[l]=a[r]
			a[r]=x
	x=a[i]
	a[i]=a[r]
	a[r]=x
	return r

def	sort(a,i,t):
	if i<t:
		p= partition(a,i,t)
		sort(a,i,p-1)
		sort(a,p+1,t)
	return a			

a = sort(a,0,len(a)-1)
print(a)