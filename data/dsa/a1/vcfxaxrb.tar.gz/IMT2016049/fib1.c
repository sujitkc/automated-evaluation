#include<stdio.h>
int fibbo(int);
int main()
{
	int i=0,fib;
	fib=fibbo(i);
	while (fib<50)
	{printf("%d\t",fib);
	i++;
	fib=fibbo(i);
	}
}
int fibbo(int x)
{if(x==0)
return(0);
else if(x==1)
return(1);
else
return(fibbo(x-1)+fibbo(x-2));
}
