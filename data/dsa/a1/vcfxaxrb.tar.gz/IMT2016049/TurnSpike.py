
from random import randint

n=input("Number of points: ")
maxLimit=input("Enter max Distance: ")



def generate_points(n,maxLimit):
    S=range(n)

    for i in range(1,maxLimit):
        S[i%n]=i
    S[0]=0
    S[n-1]=maxLimit
    S.sort()
    return S

def distance_set(S):
    D=list()
    for i in range(len(S)):
        for j in range(0,i):
            D.append(abs(S[j]-S[i]))
    D.sort()
    return D



def solve(D,n,X):
    X[0]=0
    X[n-1]=max(D)
    D.remove(max(D))

    if searchSoln(D,X,n,1,n-1):
        return True
    else:
        return False

def searchSoln(D,X,n,start,end):
    if(len(D)==0):
        return True
    mx=max(D)
    removed=[]
    try:
        for i in range(start)+range(end,n):
            D.remove(abs(mx-X[i]))
            removed.append(abs(mx-X[i]))
        X[end-1]=mx
        solved=searchSoln(D,X,n,start,end-1)
        if(solved):return True
    except:
        pass

    X[end-1]=0
    D.extend(removed)

    removed=[]
    mx=max(X)-mx
    try:
        for i in range(start)+range(end,n):
            D.remove(abs(mx-X[i]))
            removed.append(abs(mx-X[i]))
        X[start]=mx
        solved=searchSoln(D,X,n,start+1,end)
        if(solved):return True
    except:
        pass

    X[start]=0
    D.extend(removed)


S=generate_points(n,maxLimit)
D=distance_set(S)
print "OriginalPoints: " , S
print "DistanceSet: ",D
X=[0 for _ in range(n)]

solve(D,n,X)

print "Reconstructed Set:"
print X
