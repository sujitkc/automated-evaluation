#include <stdio.h>
int rect(int n)
{
	if(n<2)
	{
		return n;
	}
	else
	{
		return rect(n-1)+rect(n-2);
	}
}
int main()
{
	printf("%d",rect(1000));
}
