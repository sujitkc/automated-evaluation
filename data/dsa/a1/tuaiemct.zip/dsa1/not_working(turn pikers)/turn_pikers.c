#include <stdio.h>
#include <stdlib.h>
#include <math.h>
struct node
{
    int data;
    struct node *next;
}*head;
void swap(int *p,int *q)
{
    int temp;
    temp=*p;
    *p=*q;
    *q=temp;
    
}
void add_node()
{
    stuct node *new_node,*temp;
    temp=head;
    new_node=(struct node*)malloc(sizeof(struct node));
    new_node->next=NULL;
    if(head==NULL)
    {
        head=new_node;
    }
    else
    {
        while(temp->next!=NULL)
        {
            temp=temp->next;
        }
    temp->next=new_node;
    }
}
void delete(int n)
{
    struct node *temp,*temp2;
    temp=head;
    if(head=NULL)
        {
        }
    else if(head->next=NULL)
        {
            head=NULL;
        }
    else
        {
            while(temp->data!=n)
                {
                    temp=temp->next;
                    temp2=temp->next;
                }
            temp->next=temp2->next;
            free(temp2);
    }
}
int num_nodes()
{
    struct node *temp;
    temp=head;
    int n=0;
    while(temp->next!=NULL)
    {
        n=n+1;
        temp=temp->next;
    }
    return n;
}
/*
void max_linkedlist()
{
 inr x=-1;
 n=num_node;
 while(temp->next!=NULL)
    {
    if(temp->data>x)
        {
        x=temp->data;
        }
        temp=temp->next;
    }
 return x;
}*/
// assuming the array to be sorted.
void check(int n)// n is the number of nodes initially;
    {
        int k=(1+pow(1+8*n))/2,i=0,c;
        int arr[k];
        for(i=0;i<k;i++)
            {
                arr[i]=-1;
            }
        struct node *temp;
        temp=head;
        while(temp->next!=NULL)
            {
                temp=temp->next;
            }
        arr[0]=0;//arr[0]=0.
        arr[k-1]=temp->data;
        del(arr[0]);
        del(arr[k-1]);
        r=k-2;
        while(1)
        {
            int max;
            max=arr[r];//
          //  m=0;
            for(i=k-1;i>r,i--)
            {
                del(arr[r]-arr[k-2]);
            }
            
            
            
            
            r--;
            for(i=0;i<k;i++)
                {
                    if(arr[i]!=-1)
                    {
                        c++;
                    }
                }
            if(c==k)
                {
                    printf("such a list exits and the list is :\n")
                    for(i=0;i<k;i++)
                    {
                        printf("%d",arr[i]);
                    }
                    break;
                }
        }
    }

int main()
{
    printf("1-cerate the list of numbers\n2-check whether such a turnpiker is possible with list");
    scanf("%d",&n);
    if(n!=0 || n!=1)
    {
        printf("only 1 or 2")
        while(1)
        {
            scanf("%d",n);
            if(n==1 || n==0)
            {
                break;
            }
    }
    switch(n)
        {
        case(1)
            {
                add_node();
                break;
            }
        case(2)
            {    check();
                break;
  
            }
        }
}
