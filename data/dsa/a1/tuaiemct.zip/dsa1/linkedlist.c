#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data ;
    struct node *next;
};
void add_node(struct node **ptr,int n)
{
    struct node *temp,*new_ptr;
    temp=*ptr;
    if (*ptr==NULL)
    {
        *ptr=(struct node*)malloc(1*sizeof(struct node));
        (*ptr)->data=n;
        (*ptr)->next=NULL;
    }
    else
    {
        temp=*ptr;
        while((temp->next)!=NULL)
        {
            temp=temp->next;
        }
        new_ptr=(struct node*)malloc(1*sizeof(struct node));
        temp->next=new_ptr;
        new_ptr->next=NULL;
        new_ptr->data=n;
    }
}
void display(struct node **ptr)
{
    struct node *temp=*ptr;
    if(temp == NULL)
        printf("");
    while(temp!=NULL)
    {
        printf("%d -> ",temp->data);
        temp=temp->next;
    }
   printf("NULL");
}
void del(struct node **p,int n)
{
    struct node *q,*head;
    head=*p;
    if((*p)->data==n)
    {
        *p=(*p)->next;
        free(head);
    }
    else
    {
        q=(*p)->next;
        while(q!=NULL)
        {
            if(q->data==n)
            {
                head->next=q->next;
                free(q);
                break;
            }
            q=q->next;
            head=head->next;
        }
    }
}
int main()
{
    int i,j,c;
    struct node *arr[10];
    struct node *head;
    for(i=0;i<10;i++)
    {
        arr[i]=NULL;
    }
    for (i=0;i<20;i++)
    {
        c=rand()%10;
        j=rand()%20;
        add_node(&arr[c],j);
    }
    printf("BEFORE DELETING\n");
    for(i=0;i<10;i++)
    {
        display(&arr[i]);
        printf("\n");
    }
   for(i=0;i<10;i++)
    {
        struct node *p,*q,*temp;
        int n=0,k=0,x,y,j;
        temp=arr[i];
        if(temp==NULL)
            n=0;
        else
        {
            n=1;
            while(temp->next!=NULL)
            {
                temp=temp->next;//no of nodes
                n++;
            }
        }
        while(1)
        {
           p=arr[i];
           if(n==0 || n==1)
           {
               break;
           }
            else
            {
            for(j=0;j<k;j++)
            {
                p=p->next;
            }
                if(p->next!=NULL){
            q=p->next;
            x=p->data;
            y=q->data;
            if(x%2==0 && y%2!=0)
                {
                    del(&arr[i],y);
                }
            else if(x%2!=0 && y%2==0)
                {
                    
                    del(&arr[i],x);
                }
            if(x%2==0 && y%2==0)
                {
                    if(x>y)
                    {
                        del(&arr[i],x);
                    }
                    else
                    {
                        del(&arr[i],y);
                    }
                }
            if(x%2!=0 && y%2!=0)
            {
                if(x>y)
                {
                    del(&arr[i],y);
                }
                else
                {
                    del(&arr[i],x);
                }
            }
            n=n-1;
                    k=k+1;}
            if(p->next==NULL || (p->next)->next==NULL)
            {
                k=0;
            }
            }
        }
    }
    printf("\nAFTER DELETING\n");
   for(i=0;i<10;i++)
    {
        display(&arr[i]);
        printf("\n");
    }
}










