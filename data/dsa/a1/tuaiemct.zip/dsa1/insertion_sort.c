#include<stdio.h>
#include<stdlib.h>
int main()
{
int arr[1000000],i,j=1,t,n=1000000;
for(i=0;i<1000000;i++)
	{
	arr[i]=rand();
	}
for(i=1;i<n;i++)
{
j=1;
t=arr[i];
while(t<arr[i-j])
{
arr[i-j+1]=arr[i-j];
j++;
}
arr[i-j+1]=t;
}
for(i=0;i<1000000;i++)
	{
	printf("%d\n",arr[i]);
	}

}

