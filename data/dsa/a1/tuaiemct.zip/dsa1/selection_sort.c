#include<stdio.h>
#include<stdlib.h>
int main()
{
int arr[1000000],i,j;
for(i=0;i<1000000;i++)
	{
	arr[i]=rand();
	}
int n=1000000,m=-100,t,p;
for(i=0;i<n-1;i++)
	{
	for(j=0;j<=n-i-1;j++)
		{
		if(arr[j]>m)
			{
			m=arr[j];
			p=j;
			}
		}
	t=arr[n-i-1];
	arr[n-i-1]=m;
	arr[p]=t;
	m=-100;
	}
for(i=0;i<1000000;i++)
	{
	printf("%d\n",arr[i]);
	} 

}

