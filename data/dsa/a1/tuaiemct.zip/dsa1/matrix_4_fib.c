#include <stdio.h>
void mm(int a[2][2],int b[2][2])
{
	int i,j,k,sum;
	int c[2][2];
	for (i = 0; i <= 1; i++)
	 {
	      for (j = 0; j <= 1; j++) 	
	      {
        	 sum = 0;
        	 for (k = 0; k <= 1; k++)
		 {
        	    sum = sum + a[i][k] * b[k][j];
       		 }
         	c[i][j] = sum;
              }
         } 
 a[0][0]=c[0][0];
 a[0][1]=c[0][1];
 a[1][0]=c[1][0];
 a[1][1]=c[1][1];
}
void power(int a[2][2],int n)
{
int i,j;
int arr1[100];
int y[2][2]={{1,0},{0,1}};
while(n!=0)
{
if(n%2==1)//n is odd number
{
mm(y,a);
mm(a,a);
}
else
{
mm(a,a);
}
n=n/2;
}
for(i=0;i<2;i++)
	{
	for(j=0;j<2;j++)
		{
		printf("%d ",y[i][j]);
		}
		printf("\n");
	}

} 
int main()
{
int n;
printf("enter a decimal number:");
scanf("%d",&n);
int arr2[2][2]={{1,1},{1,0}};
power(arr2,n);
}

