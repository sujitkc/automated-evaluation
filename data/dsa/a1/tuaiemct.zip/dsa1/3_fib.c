#include <stdio.h>
#include <stdlib.h>
int rect(int n)
{
    if(n<2)
    {
        return n;
    }
    else
    {
        return rect(n-1)+rect(n-2);
    }
}

int reminder_300(int a[],int n)// n=no of elements in the array
{
    int i,j;
    for(i=0;i<n;i++)
    {
        int k=i;
            int l=a[i]*100+a[i+1]*10+a[i+2];
        if(l>300)
        {
            int m=l%300;
            if(i+2==n-1)
                {
                    return m;
                    break;
                }
            for(j=0;j<3;j++)
                {
                    a[k+2]=m%10;
                    m=m/10;
                    k--;
                }
        }
        else if(l<300)
        {
            int y=a[i]*1000+a[i+1]*100+a[i+2]*10+a[i+3];
            int m=y%300;
            if(i+3==n-1)
                {
                    return m;
                    break;
                }
            for(j=0;j<3;j++)
                {
                    a[k+3]=m%10;
                    m=m/10;
                    k--;
                }
            
        }
    }
    return 0;

}
int main()
{
    int arr[10],i;
    for(i=0;i<10;i++)
    {
        arr[i]=rand()%10;
    }
    for(i=0;i<10;i++)
    {
        printf("%d",arr[i]);
    }
    
    int l=reminder_300(arr,10);
    //printf("\n\n%d",l);
     printf("%d",rect(l));

    return 0;
}
