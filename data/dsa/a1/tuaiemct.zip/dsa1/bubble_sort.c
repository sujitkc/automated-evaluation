#include<stdio.h>
#include<stdlib.h>
void swap(int *p,int *q)
	{
	int t;
	t=*p;
	*p=*q;
	*q=t;
	}
int main()
{
int arr[1000000],i,j;
for(i=0;i<1000000;i++)
	{
	arr[i]=rand();
	}
int n=1000000;
for(i=0;i<n-1;i++)
	{
	for(j=0;j<n-i-1;j++)
	{
	if(arr[j]>arr[j+1])
	{
	swap(&arr[j],&arr[j+1]);
	}
	}		
	}
for(i=0;i<1000000;i++)
	{
	printf("%d\n",arr[i]);
	} 

}
