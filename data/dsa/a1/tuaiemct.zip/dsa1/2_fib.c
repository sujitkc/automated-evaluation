#include <stdio.h>
int main()
{
int i,s=0;
for(i=0;i<1001;i++)
	{
		s=s+i;	
	}
printf("%d",s);
}
