#include<stdio.h>
#include<stdlib.h>
void print(int arr[])
{
	int i;
	for(i=0;i<10;i++)
	{
	printf("%d  ",arr[i]);
	}
}
void swap(int *p,int *q)
{
int t;
t=*p;
*p=*q;
*q=t;
}
int partition(int a[],int i,int j)
{
int p=a[j];
int p_index=i,k;
	for(k=i;k<j;k++)
	{
		if(a[k]<p)
		{
		swap(&a[k],&a[p_index]);
		p_index+=1;
		}
	}
swap(&a[p_index],&a[j]);
return p_index;
}
void quick_sort(int arr[],int i,int j)
{
	if(i<j)
	{
	int index_p;
	index_p=partition(arr,i,j);
	// recursion
	quick_sort(arr,i,index_p-1);
	quick_sort(arr,index_p+1,j);
	}
}
int main()
{
int arr[100],i;
	for(i=0;i<10;i++)
	{
	arr[i]=rand()%30;
	}
print(arr);
printf("\n");
//partition(arr,0,9);
quick_sort(arr,0,9);
print(arr);
}
