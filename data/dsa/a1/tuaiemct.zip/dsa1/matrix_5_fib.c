#include <stdio.h>
void mm(int a[2][2],int b[2][2])
{
	int i,j,k,sum;
	int c[2][2];
	for (i = 0; i <= 1; i++)
	 {
	      for (j = 0; j <= 1; j++) 	
	      {
        	 sum = 0;
        	 for (k = 0; k <= 1; k++)
		 {
        	    sum = sum + a[i][k] * b[k][j];
       		 }
         	c[i][j] = sum;
              }
         } 
 a[0][0]=c[0][0];
 a[0][1]=c[0][1];
 a[1][0]=c[1][0];
 a[1][1]=c[1][1];
}
void divide_by_2(int arr1[],int n)
{
int i,k;
for(i=0;i<n;i++)
	{
	if(arr1[i]%2==1)
		{
		arr1[i]=arr1[i]/2;
		arr1[i+1]=arr1[i+1]+10;
		}
	else
		{
		arr1[i]=arr1[i]/2;
		}
	}

for(i=0;i<n;i++)
	{printf("%d ",arr1[i]);}
	printf("\n");
}

void power(int a[2][2],int arr1[],int n)
{
int i,j;
int y[2][2]={{1,0},{0,1}};
while(arr1[n-1]!=0)
	{
	if(arr1[n-1]%2==1)// odd number
		{
		mm(y,a);
		mm(a,a);		
		}
	else
		{
		mm(a,a);
		}
	divide_by_2(arr1,n);
	}
//mm(y,a);
for(i=0;i<2;i++)
	{
	for(j=0;j<2;j++)
		{
		printf("%d ",y[i][j]);
		}
		printf("\n");
	}

} 
int main()
{
int n,i,arr1[1000000];
printf("enter no of digits of the decimal number:");
scanf("%d",&n);
printf("enter the number:");
for(i=0;i<n;i++)
{
scanf("%d",&arr1[i]);
}

int arr2[2][2]={{1,1},{1,0}};
power(arr2,arr1,n);
}

