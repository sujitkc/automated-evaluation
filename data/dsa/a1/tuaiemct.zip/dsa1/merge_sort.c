#include <stdio.h>
#include <stdlib.h>
int b[10];
void merge(int a[],int l,int m,int r)
{
//int x=m+1,k=l,s=0;
//	while(x<=r && k<=m)

int i=0,j=0,k=0,x=l,y=m+1;
	while(y<=r && x<=m )
	{
		if(a[x]<=a[y])
			{
			b[k]=a[x];
			x++;
			}	
		else
			{
			b[k]=a[y];
			y++;
			}
		k++;
	}
	while(y<=r)
		{
		b[k]=a[y];
		y++;
		k++;
		}
	while(x<=m)
		{
		b[k]=a[x];
		x++;
		k++;
		}
for(i=0;i<k;i++)
{
a[l+i]=b[i];
}
}

void sort(int a[],int l,int r)// dividing the array
{
if(l<r){
int m=(r+l)/2;
sort(a,l,m);
sort(a,m+1,r);

merge(a,l,m,r);
}
}
void print(int a[],int size)
{
int i;
for(i=0;i<size;i++)
	{
	printf("%d\n ",a[i]);
	}
}
int main()
{
int size=10,arr[10],i;
for(i=0;i<size;i++)
	{
	arr[i]=rand()%20;
	}
print(arr,size);
sort(arr,0,9);
printf("\n\n");
print(b,size);
}
