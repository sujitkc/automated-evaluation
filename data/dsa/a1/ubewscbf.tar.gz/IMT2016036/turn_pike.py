import math
def find(d,lens,fin,k=1,j=1):
    gun=0
    for i in fin:
        if i==None:
            gun=1
    if gun==0:
        global commo
        if fin not in commo:
            print "yesss"
            print fin,"this is it"
            commo.append(fin)
        return
    te=[]
    for i in d:
        te.append(i)
    tef=[]
    for i in fin:
        tef.append(i)

    tef[len(tef)-1-k]=max(te)
    r=1
    for i in range(len(tef)):
        if tef[i]!=None:
            if i!=len(tef)-1-k:
                try:
                    te.remove(abs(tef[len(tef)-1-k]-tef[i]))
                except:
                    r=0
                    break

    if r==1:
        find(te,lens,tef,k+1,j)
    r=1
    for i in range(len(d)):
        if abs(d[i]-max(fin))==max(d):
            index=i
            no=d[i]
            break
    try:
        fin[j]=no
    except:
        r=0
    if r==1:
        for i in range(len(fin)):
            if fin[i]!=None:
                if i!=j:
                    try:
                        d.remove(abs(no-fin[i]))
                    except:
                        r=0
                        break

    if r==1:
        find(d,lens,fin,k,j+1)
