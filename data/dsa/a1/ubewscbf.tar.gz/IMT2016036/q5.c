#include<stdio.h>
#include<stdlib.h>

int *atob(int *,int );
int *matmul(int *);
int main()
{
printf("enter the size of array\n");
int n,*bar=NULL,i;
scanf("%d",&n);
int arr[n+1];
printf("enter the numbers\n");
for(i=0;i<n;i++)
{
	scanf("%d",arr+i);
}
*(arr+n) = -1;
bar = atob(arr,n-1);
int r11=2,r12=1,r21=1,r22=1;
int c=0,d=1,c1,d1;
int a[4] = {1,1,1,0},*bb = NULL,ff;
for(i = 0 ; i < 10000; i++)
{
	c1 = c;
	d1 = d;
	if (*(bar + i ) == -1)
	{ 
		break;
        }
	if ( * ( bar + i ) == 1)
	{
	c = ((c1 * a[0] )+(d1 * a[2]))%100;
	d = ((c1 * a[1] )+(d1 * a[3]))%100;
	}
 bb = matmul(a);
for ( ff = 0 ; ff < 4; ff++)
	{
		*(a + ff ) = *( bb + ff);
	}

}
printf("and the value is %d\n",c);
return 0;
}

int *dtob(int n)
{
 int *a;
 a = malloc(sizeof(int)*10000);
 int x = 0,i;
 for(i=0;i<10000;i++)
 { 
   x = n % 2;
   *(a+i) = x;
   n = n / 2;
   if ( n == 0)
   {
     *(a+i+1) = -1;
     break;
   }
  }
  return a;
}
int *matmul(int *b)
{

	int *c = NULL;
	c = malloc(sizeof(int)*4);
	c[0] = ((b[0]*b[0])+(b[1]*b[2]))%100;
	c[1] =  ((b[0]*b[1])+(b[1]*b[3]))%100;
	c[2] = ((b[2]*b[0])+(b[3]*b[2]))%100;
        c[3] = ((b[2]*b[1])+(b[3]*b[3]))%100;
	return c;
}

int *atob(int *a,int n)   /*n is last element index*/
{
	int i,j,k=0;
	int *b = NULL,count=0,check=0;
	b = malloc(sizeof(int)*250);
	int i1,ck=0;

	while(k != 250)
	{
		for(i1=0;i1<=n;i1++)
		{
			if (( *(a+i1) ) != 0)
			{
				break;
			}
			if ( i1 == n)
			{
				ck = 1;
			}

		}
		if ( (ck == 1) && (k!= 0))
		{
			break;
		}
		check = 0;
		if ((*(a+(n))%2) == 0)
		{
			
			*(b+count) = 0;
			count += 1;
		}
		else
		{
			*(b+count) = 1;
			count += 1;
		}
		for(j=0;j<=n;j++)
		{
			*(a+j) = check + *(a+j);
			check = (*(a+j))%2;
			check = check * 10;
			*(a+j) = *(a+j) / 2;
			if (*(a+j) == 0)
			{
			}
		}
		k += 1;
	}
	*(b+count) = -1;
	b = realloc(b,sizeof(int) *(count + 2));
	return b;
}
