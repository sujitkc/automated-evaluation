#include <stdio.h>
 
int main()
{
  int   c, d, t;
  int array[10]={8,7,2,4,9,12,3,7,2,13};
 
 
 
  
 
 
  for (c = 1 ; c <10; c++) {
    d = c;
 
    while ( d > 0 && array[d] < array[d-1]) {
      t          = array[d];
      array[d]   = array[d-1];
      array[d-1] = t;
 
      d--;
    }
  }
 
  printf("Sorted list in ascending order:\n");
 
  for (c = 0; c <10; c++) {
    printf("%d\n", array[c]);
  }
 
  return 0;
}
