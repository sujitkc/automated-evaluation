import random 
def mm (a, b):
    c = [[0 for row in range(len(a))] for col in range(len(b[0]))]
    for i in range(len(a)):
        for j in range(len(b[0])):
            for k in range(len(b)):
                c[i][j] += a[i][k]*b[k][j]
   	for i in range (0,2):
		for j in range (0,2):
			c[i][j]=c[i][j]%100
    return c


def divide(n,a):
	for i in range(len(n)):
		if(i!=len(n)-1):
			if (n[i]%a==0):
				n[i]=n[i]/a
			else:
				n[i+1]=(n[i]%a)*10+n[i+1]	
				n[i]=n[i]/a
		elif (i==len(n)-1):
					n[i]=n[i]/a
	return n			

def check(number):
	a=0
	for i in range(len(number)):
		if number[i]==0:
			a=a+1
	if (a==len(number)):
			return True
	else :
			return False

def power (x,n):
	y=[[1,0],[0,1]]
	while(not check(n)):
		if(n[-1]%2==0):
			y=mm(y,x)
		x=mm(x,x)
		n=divide(n,2)
	return y	

d=[[1,1],[1,0]]
number=[]
for i in range (0,1000):
	number.append(random.randint(0,9))

e=power(d,number)
print e[1][0]
