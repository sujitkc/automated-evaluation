a=[]
a.append(0)
a.append(1)
for i in range(2,1000001):   
	a.append(0)
 	a[i]=((a[i-1]+a[i-2])%100)   
print a[1000000]       
   
