import random
a=0
b=1
for i in range (600) :
	c=(a+b)%100
	a=b
	b=c
	if(i!=1 and a==0 and b==1):
		break
period=i+1

number=[]		
for i in range (0,1000000):
	number.append(random.randint(0,9))

m=number

remainder=0
for i in range (len(number)):
 	remainder = (remainder * 10 + number[i] ) % period
print remainder
a=0
b=1
for i in range (2,remainder) :
	c=(a+b)%100
	a=b
	b=c
print a	


