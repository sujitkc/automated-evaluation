#include <stdio.h>
void quick_sort(int arr[],int i, int j);
int partition(int arr[],int start,int end); ;
int main()
{
    int a[1000000],i;
    int n=1000000;
    for(i=0;i<n;i++)
        a[i]=n-i;
        
    quick_sort(a,0,n-1);
    for(i=0;i<1000000;i++)
        printf("%d ",a[i]);
    
    return 0;        
} 

void quick_sort(int arr[],int i, int j){
  if(i<j){
    int p=i+rand()%(j-i+1);
    int k=partition(arr,i,j);
    quick_sort(arr,i,k-1);
    quick_sort(arr,k+1,j);
  }
}

int partition(int arr[],int start,int end)
{

  int r=start+rand()%(end-start+1);
  int i=start-1;
  int p=arr[r];
  int temp ;
  temp=arr[r];
  arr[r]=arr[end];
  arr[end]=temp;
  for(int m=start;m<end;m++)
  {
    if(arr[m]<p)
    {
      i+=1;
      temp=arr[i];
      arr[i]=arr[m];
      arr[m]=temp;
  
    }
  }
  temp=arr[i+1];
  arr[i+1]=arr[end];
  arr[end]=temp;
  return i+1;
}