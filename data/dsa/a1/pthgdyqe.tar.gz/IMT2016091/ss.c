#include <stdio.h>
void main()
{
	int arr[1000000];
	int temp,n=1000000;
	int i,j;
	for (i=n;i>0;i--){
		arr[n-i]=i;}
	for (i=0;i<n-1;i++){
		for (j=i+1;j<n;j++){
			if(arr[i]>arr[j]){
				temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
		}
	}	
    for(i=0;i<n;i++){
   		printf("%d\n",arr[i]);
   }
}