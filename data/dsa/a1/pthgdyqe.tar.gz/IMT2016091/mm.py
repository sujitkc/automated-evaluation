def mm (a, b):
    c = [[0 for row in range(len(a))] for col in range(len(b[0]))]
    for i in range(len(a)):
        for j in range(len(b[0])):
            for k in range(len(b)):
                c[i][j] += a[i][k]*b[k][j]
   	for i in range (0,2):
		for j in range (0,2):
			c[i][j]=c[i][j]%100
    return c

def power (x,n):
	y=[[1,0],[0,1]]
	if(n==0): 
		return y
	elif(n%2==0) :
		return power(mm(x,x),n/2)
	else :
		return mm(x,power(mm(x,x),n/2))

d=[[1,1],[1,0]]
e=power(d,1000000)
print e[1][0]