def linear(n) :
	a=0 
	b=1 
	c=n 
	for i in range (2,n):
		c=(a+b)%100 
		a=b 
		b=c 
	return a

c=linear(245) 
print c


