import random
def mm (a, b):
    c = [[0 for row in range(len(a))] for col in range(len(b[0]))]
    for i in range(len(a)):
        for j in range(len(b[0])):
            for k in range(len(b)):
                c[i][j] += a[i][k]*b[k][j]
   	for i in range (0,2):
		for j in range (0,2):
			c[i][j]=c[i][j]%100
    return c

def power (x,n):
	y=[[1,0],[0,1]]
	for i in range(0,len(n)):
		if(i==len(n)-1): 
			x=mm(x,y)
		elif(n[i]==1):
			x=mm(x,x)
		elif(n[i]==0):
			x=mm(x,mm(x,x))
	return x
d=[[1,1],[1,0]]
number=[]
for i in range (0,1000000):
	number.append(random.randint(0,1))

e=power(d,number)
print e[1][0]
