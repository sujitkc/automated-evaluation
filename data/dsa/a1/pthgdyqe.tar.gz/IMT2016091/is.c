#include <stdio.h>
void main()
{
	int arr[1000000];
	int temp,n=1000000;
	int i,j;
	for (i=n;i>0;i--){
		arr[n-i]=i;}
 for(i=0;i<n;i++){
 	j=0;
 	while(j<=i){
 		if(arr[j]>arr[i]){
 			temp=arr[j];
 			arr[j]=arr[i];
 			arr[i]=temp;
 		}
 	j=j+1;	
 	}
 }
 for(i=0;i<n;i++){
   		printf("%d\n",arr[i]);
   }
}