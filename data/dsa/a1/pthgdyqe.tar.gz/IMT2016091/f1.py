import sys
sys.setrecursionlimit(100000)
def rec(n) :
	if(n<2) :
		return n     
	else  :
		return (rec(n-1)+rec(n-2)%100)     

a=rec(36)    
print a  
  

