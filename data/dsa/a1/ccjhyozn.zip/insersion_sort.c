#include <stdio.h>
void insertionSort(int ar_size, int *  ar) {
    int j,t,k,i;
    for(j=1;j<ar_size;j++){
        t=ar[j];
        for(k=j-1;k>=0;k--){
            if(ar[k]<t){
                ar[k+1]=t;
                break;
            }
            else{
                ar[k+1]=ar[k];
            }
        }
        if(k==-1){
            ar[0]=t;
        }

        
    }


}
int main(void) {
   
   int ar_size,i;
    scanf("%d", &ar_size);
    int ar[ar_size], ar_i;
    for(ar_i = 0; ar_i < ar_size; ar_i++) { 
       scanf("%d", &ar[ar_i]); 
    }

	insertionSort(ar_size, ar);
	for(i=0;i<ar_size;i++){
            printf("%d ",ar[i]);
        }
   
   return 0;
}

