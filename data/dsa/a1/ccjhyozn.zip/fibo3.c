#include<stdio.h>
void main(){
	int n=1,i,e,f,g,h,s;
	/*printf(" 1-normal no.\n 2-large no.\n");
	scanf("%d",&n);*/
	if (n==1)
		scanf("%d",&n);
	/*if(n==2){
		printf("enter no. of digits of input");
		scanf("%d",&n);
		int ar[n];
		for(i=0;i<n;i++){
			ar[i]=rand()%10;
			printf("%d",ar[i]);
			if(i<n-2){
				s=s+ar[i];
			}
		}
			n=(s%3)*100+ar[n-2]*10+ar[n-1];
	}*/
	int a[2][2],b[2][2];
	a[0][0]=1;
	a[0][1]=1;
	a[1][0]=1;
	a[1][1]=0;
	b[0][0]=1;
	b[0][1]=1;
	b[1][0]=1;
	b[1][1]=0;
	for(i=1;i<n;i++){
		e=(b[0][0]*a[0][0]+b[0][1]*a[1][0])%100;
		f=(b[0][0]*a[0][1]+b[0][1]*a[1][1])%100;
		g=(b[1][0]*a[0][0]+b[1][1]*a[1][0])%100;
		h=(b[1][0]*a[0][1]+b[1][1]*a[1][1])%100;
		b[0][0]=e;
		b[0][1]=f;
		b[1][0]=g;
		b[1][1]=h;
	}
	printf("\n%d",b[1][0]);
}
