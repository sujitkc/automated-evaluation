n=input("Enter size of array")
l=[]
print "Enter elements"
for i in range(n):
    l.append(input())
l.sort()
p=[]
m=[]
p.append(0)
p.append(l[n-1])
l.pop(n-1)
for i in l:
    o=0
    del m[:]
    for j in p:
        if abs(i-j) in l:
            m.append(abs(i-j))
        else:
            o=1
    if o==0:
        p.append(i)
        print p
        for i in m:
            l.remove(i)
p.sort()
print p
