
#include<stdio.h>
void mulm(int arr[][2],int arr2[][2],int ans[][2]){
    ans[0][0]=0;
    ans[0][1]=0;
    ans[1][0]=0;
    ans[1][1]=0;
    int i,j,k;
    for(i=0;i<2;i++){
        for(j=0;j<2;j++){
            for(k=0;k<2;k++){
                ans[i][j]=ans[i][j]+(arr[i][k]*arr2[k][j]);
            }
        }
        ans[i][j]=ans[i][j]%100;
    }
}
void powerm(int arr[][2],int *n,int y[][2]){
    y[0][0]=1;
    y[0][1]=0;
    y[1][0]=0;
    y[1][1]=1;
    int temp[2][2];
    int i=999;
    while(i>=0){
        if(n[i]%2==1){
            mulm(y,arr,temp);
            y[0][0]=temp[0][0]%100;
            y[0][1]=temp[0][1]%100;
            y[1][0]=temp[1][0]%100;
            y[1][1]=temp[1][1]%100;
        }
        mulm(arr,arr,temp);
        arr[0][0]=temp[0][0]%100;
        arr[0][1]=temp[0][1]%100;
        arr[1][0]=temp[1][0]%100;
        arr[1][1]=temp[1][1]%100;
        i--;
    }

}
int addno(int x,int y){
    int tem,count=0;
    tem=x;
    while(tem){
        count++;
        tem=tem/10;

    }
    int no=0,tr=1;
    while(count){
        no=no+(x%10)*pow(10,tr);
        x=x/10;
        count--;
        tr++;
    }
    no=no+y;
    return no;
}
int final_ans(int *n){
    int arr[2][2];
    arr[0][0]=1;
    arr[0][1]=1;
    arr[1][0]=1;
    arr[1][1]=0;
    int fin[2][2];
    powerm(arr,n,fin);
    return fin[1][0];

}
int main(){
    int count=0,a,b,c,i;
    int no;
    scanf("%d",&no);
    a=1;
    b=2;
    count=2;
    while(1){
        if(a==0 && b==1){
            break;
        }
        c=(a+b)%no;
        a=b;
        b=c;
        count++;


    }
    printf("%d",count);
    int end=999;
    int po=1;
    int cur=0;
    int arr[1000];
    for(i=0;i<1000;i++){
        arr[i]=rand()%2;
    }
    int g;

    printf("\nfinal is %d\n",final_ans(arr));

}
