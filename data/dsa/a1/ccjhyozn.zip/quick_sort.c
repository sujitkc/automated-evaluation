#include <stdio.h>
void quickSort(int start,int ar_size, int *ar) {
	int i;
    int pv=ar[start],t,k=0;
    for(i=start;i<ar_size;i++){
        t=ar[i];
        if(t<pv){
            k=i;
            while(ar[k-1]>=pv && k>0){
                ar[k]=ar[k-1];
                k--;
            }
            ar[k]=t;
        }
    
    
    }
	while(ar[k]<pv)k++;
    
    if(k-start-1>0){
    	quickSort(start,k,ar);
	}
	if(ar_size-k-2>0){
    	quickSort(k+1,ar_size,ar);
	}
}
int main(void) {
   int ar_size;
   scanf("%d", &ar_size);
   int ar[ar_size], i;
   for(i = 0; i < ar_size; i++) { 
      scanf("%d", &ar[i]); 
   }

   quickSort(0,ar_size, ar);
   for(i = 0; i < ar_size; i++) { 
      printf("%d ", ar[i]); 
   }
   
   return 0;
}


