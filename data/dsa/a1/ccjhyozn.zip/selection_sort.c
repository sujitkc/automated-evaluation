#include<stdio.h>
void main(){
	int n,i,j,k,t;
	scanf("%d",&n);
	int ar[n];
	for(i=0;i<n;i++){
		scanf("%d",&ar[i]);
	}
	for(i=0;i<n;i++){
		t=ar[i];
		k=i;
		for(j=i+1;j<n;j++){
			if(t>ar[j]){
				t=ar[j];
				k=j;
			}
		}
		ar[k]=ar[i];
		ar[i]=t;
	}
	for(i=0;i<n;i++){
		printf("%d ",ar[i]);
	}
}
