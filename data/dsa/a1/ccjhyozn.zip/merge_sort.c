#include<stdio.h>
void merge_sort(int n,int *ar){
	int i, m=n/2;
	int a[m],b[n-m];
	for(i=0;i<n;i++){
		if(i<m)
			a[i]=ar[i];
		else
			b[i-m]=ar[i];
	}
	if(m==2){
		if(a[0]>a[1]){
			int temp1;
			temp1=a[0];
			a[0]=a[1];
			a[1]=temp1;
		}
	}
	if(n-m==2){
		if(b[0]>b[1]){
			int temp2;
			temp2=b[0];
			b[0]=b[1];
			b[1]=temp2;
		}
	}
	if(m>2){
		merge_sort(m,a);
		}
	if(n-m>2){
		merge_sort(n-m,b);
		}
	int o=0,p=0,k = 0;
    while (o < m && p < n-m)
    {
        if (a[o]<=b[p])
        {
            ar[k] = a[o];
            o++;
        }
        else
        {
            ar[k]=b[p];
            p++;
        }
        k++;
    }
    while (o < m)
    {
        ar[k] = a[o];
        o++;
        k++;
    }
 
    while (p < n-m)
    {
        ar[k] = b[p];
        p++;
        k++;
    }
}

	
	

void main(){
	int i,n;
	printf("Enter no. of elements");
	scanf("%d",&n);
	int d[n];
	for(i=0;i<n;i++){
		/*scanf("%d",&d[i]);*/
		d[i]=rand()%10000;
		printf("%d ",d[i]);
	}
	printf("\n");
	merge_sort(n,d);
	for(i=0;i<n;i++)
		printf("%d ",d[i]);
}
