#include<stdio.h>
int rec(int i){
	if(i==0)
		return 0;
	else if(i==1)
		return 1;
	else{
		return (rec(i-1)+rec(i-2))%100;
	}
		
}
void main(){
	int n;
	scanf("%d",&n);
	printf("%d",rec(n));
}
