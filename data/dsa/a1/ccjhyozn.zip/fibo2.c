#include<stdio.h>
void main(){
	int n;
	scanf("%d",&n);
	int i,a=0,b=1,c;
	for(i=0;i<n;i++){
		c=(a+b)%100;
		a=b;
		b=c;
	}
	printf("%d",c);
}
