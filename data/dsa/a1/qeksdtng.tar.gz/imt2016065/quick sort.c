#include<stdio.h>
#include<stdlib.h>
void quick_sort(int a[],int i,int j);
int partition(int a[],int i,int j,int p);
int main()
{
	int n,i,j,temp;
	printf("enter the length of list\n");
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	temp=rand()%6;
	quick_sort(a,0,n-1);
	for(i=0;i<n;i++)
	{
		printf("%d\t",a[i]);
	}
}
void quick_sort(int a[],int i,int j)
{
	int p,k,t;
	if(j>i)
	{
	
		p=a[j];
		k=partition(a,i,j,p);
		quick_sort(a,i,k-1);
		quick_sort(a,k+1,j);
	}
}
int partition(int a[],int i,int j,int p)
{
	int l,r,t;
	l=i;
	r=j;
	while(l<=r)
	{
		while(a[l]<p)
		{
			l++;
		}
		while(r>0 && a[r]>=p)
		{
			r--;
		}
		if(l>=r)
		{
			break;
		}
		else
		{
			t=a[l];
			a[l]=a[r];
			a[r]=t;
		}
	}
	t=a[l];
	a[l]=a[j];
	a[j]=t;
	return l;
}
