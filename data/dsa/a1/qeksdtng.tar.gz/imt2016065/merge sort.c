#include<stdio.h>
int merge(int left[],int right[],int a[],int mid,int rem,int n);
int mergesort(int a[],int n);
int main()
{
	int n,i,j,temp;
	printf("enter the length of list\n");
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	mergesort(a,n);
	for(i=0;i<n;i++)
	{
		printf("%d\t",a[i]);
	}
}
int merge(int left[],int right[],int a[],int mid,int rem,int n)
{
	int i=0,j=0,k=0;
	while(i<mid && j<rem)
	{
		if(left[i]<=right[j])
		{
			a[k]=left[i];
			i++;
		}
		else
		{
			a[k]=right[j];
			j++;
		}
		k++;
	}
	while(i<mid)
	{
		a[k]=left[i];
		i++;
		k++;
		
	}
	while(j<rem)
	{
		a[k]=right[j];
		j++;
		k++;
		
	}
	return a;

}
int mergesort(int a[],int n)
{
	int i;
	if(n<2)
	{return a;}
	else
	{
	int mid=n/2;
	int rem=n-mid;
	int left[mid];
	int right[rem];
	for(i=0;i<mid;i++)
	{
		left[i]=a[i];
	}
	for(i=mid;i<n;i++)
	{
		right[i-mid]=a[i];
	}
	mergesort(left,mid);
	mergesort(right,rem);
	merge(left,right,a,mid,rem,n);
	}
	return a;
}
