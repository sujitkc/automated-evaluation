#include<stdio.h>
int arr(int n)
{
	int i,f[n];
	f[0]=0;
	f[1]=1;
	if(n>1)
	{
	
	for(i=2;i<n;i++)
	{
		f[i]=(f[i-1]+f[i-2])%100;
	}
	return (f[n-1]+f[n-2])%100;
	}
	else
	{return n;
	}
}
int main()
{
	printf("%d",arr(40));
}
