#include<stdio.h>
void multiply(int f[2][2],int a[2][2])
{
	int i,j,k;
	int s[2][2]={{0,0},{0,0}};
	for(i=0;i<2;i++)
	{
		for(j=0;j<2;j++)
		{
			for(k=0;k<2;k++)
			{
				s[i][j]=s[i][j]+(f[i][k]*a[k][j]);	
			}
		}	
	}
	for(i=0;i<2;i++)
	{
		for(j=0;j<2;j++)
		{
			f[i][j]=s[i][j]%100;
		}
	}
}
int power(int f[2][2],int a[],int n)
{
	int y[2][2]={{1,0},{0,1}};
	int i=n-1;
	while(i>=0)
	{
		if(a[i]==1)
		{
			multiply(y,f);
		}
		multiply(f,f);
		i--;
	}
	int j,k;
	for(j=0;j<2;j++)
	{
		for(k=0;k<2;k++)
		{
			f[j][k]=y[j][k];
		}
	}
}
int fibo(int a[],int n)
{
	int f[2][2] = {{1,1},{1,0}};
	
	power(f,a,n);
	return f[1][0];
	
	
}
int main()
{
	int n;
	printf("enter the no of digits in binary: ");
	scanf("%d",&n);
	int a[n],i;
	for(i=0;i<n;i++)
	{
		a[i]=rand()%2;
	}
	printf("the binary number is: \n");
	for(i=0;i<n;i++)
	{
		printf("%d ",a[i]);
	}
	printf("\nThe answer of this binary number is:\n%d",fibo(a,n));
	return 0;
}
