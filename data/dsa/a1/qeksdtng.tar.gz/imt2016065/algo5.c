#include<stdio.h>
void multiply(int f[2][2],int a[2][2])
{
	int i,j,k;
	int s[2][2]={{0,0},{0,0}};
	for(i=0;i<2;i++)
	{
		for(j=0;j<2;j++)
		{
			for(k=0;k<2;k++)
			{
				s[i][j]=s[i][j]+(f[i][k]*a[k][j]);	
			}
		}	
	}
	for(i=0;i<2;i++)
	{
		for(j=0;j<2;j++)
		{
			f[i][j]=s[i][j]%100;
		}
	}
}
int power(int f[2][2],int n)
{
	int y[2][2]={{1,0},{0,1}};
	int i;
	while(n>0)
	{
		if(n%2==1)
		{
			multiply(y,f);
		}
		multiply(f,f);
		n=n/2;
	}
	int j,k;
	for(j=0;j<2;j++)
	{
		for(k=0;k<2;k++)
		{
			f[j][k]=y[j][k];
		}
	}
}
int fibo(int n)
{
	int f[2][2]={{1,1},{1,0}};
	if(n == 0)
	{
		return 0;
	}
	power(f,n);
	return f[1][0];
}
int main()
{
	int n;
	printf("enter the value of n:   ");
	scanf("%d",&n);
	printf("the answer is: %d",fibo(n));
}
