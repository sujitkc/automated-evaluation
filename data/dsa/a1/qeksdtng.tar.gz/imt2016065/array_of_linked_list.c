#include<stdio.h>
#include<stdlib.h>
struct node{
	int data;
	struct node *next;
};
int main()
{
	int i;
	struct node * arr[21];
	for (i=0;i<21;i++)
	{
		arr[i]=NULL;
	}
	int a,num,row;
	struct node * temp,*ptr,*l,*current;
	
	for(i=0;i<20;i++)
	{
		row=rand()%20;
		num=rand()%10;
		if(arr[row]==NULL)
		{
			arr[row]=malloc(sizeof(struct node));
			arr[row]->data=num;
			arr[row]->next=NULL;
			
		}
		else
		{
			temp=malloc(sizeof(struct node));
			temp->data=num;
			temp->next=arr[row];
			arr[row]=temp;
		}
	}
		
	for(i=0;i<20;i++)
		{
			ptr=arr[i];
			while(ptr!=NULL)
			{
				printf("%d\t",ptr->data);
				ptr=ptr->next;
				
			}
			printf("\n");
		}
	//printf("\n\n\n\n");//
	
	for(i=0;i<2;i++)
	{
		l=arr[i];
		if(l!=NULL)
		{
			while(l!=NULL && l->next!=NULL)
			{
				if(l->data%2==0 && (l->next)->data%2==0)
				{
					if(l->data >= (l->next)->data)
					{
						arr[i]=l->next;
					}
					else
					{
						l->next=(l->next)->next;
					}
				}
				else if(l->data%2!=0 && (l->next)->data%2!=0)
				{
					if(l->data <= (l->next)->data)
					{
						arr[i]=l->next;
					}
					else
					{
						l->next=(l->next)->next;
					}
				
				}
				else if(l->data%2!=0 && (l->next)->data%2==0)
				{
					arr[i]=l->next;
					
				}
				else
				{
					l->next=(l->next)->next;
				}
			}
		}
	}
	for(i=0;i<20;i++)
		{
			current=arr[i];
			while(current!=NULL)
			{
				printf("%d\t",current->data);
				current=current->next;
				
			}
			printf("\n");
		}	
	
}
