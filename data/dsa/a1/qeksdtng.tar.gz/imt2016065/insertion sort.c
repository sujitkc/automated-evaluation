#include<stdio.h>
int insertion_sort(int a[],int n)
{
	int i,j,t,temp;
	for(i=1;i<n;i++)
	{
		t=a[i];
		j=i-1;
		while(j>=0 && a[j]<t)
		{
			a[j+1]=a[j];
			j--;
			
		}
		a[j+1]=t;
		
	}
	return a[n];
}
int main()
{
	int n,i,j,temp;
	printf("enter the length of list");
	scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	insertion_sort(a,n);
	for(i=0;i<n;i++)
	{
		printf("%d\t",a[i]);
	}
	
}
