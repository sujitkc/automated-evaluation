#include<stdio.h>
int cons(int n)
{
	int a,b,c,i;
	a=0;
	b=1;
	
	for(i=1;i<n;i++)
	{
		c=(a+b)%100;
		a=b;
		b=c;
	}
	return c;
}
int main()
{
	printf("%d",cons(12));
}
