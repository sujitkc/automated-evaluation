#include<stdio.h>
void Multiply(int a[2][2], int b[2][2])
{
  int x =  a[0][0]*b[0][0] + a[0][1]*b[1][0];
  int y =  a[0][0]*b[0][1] + a[0][1]*b[1][1];
  int z =  a[1][0]*b[0][0] + a[1][1]*b[1][0];
  int w =  a[1][0]*b[0][1] + a[1][1]*b[1][1];
 
  a[0][0] = x;
  a[0][1] = y;
  a[1][0] = z;
  a[1][1] = w;
}

int fib(int arr[],int n)
{
	int a[2][2]={{1,1},{1,0}},p[2][2]={{1,0},{0,1}};
	for(int i=0;i<n;i++)
	{
	if(arr[i]==1)
	{
	Multiply(p,a);
	}
	Multiply(a,a);
	}
	return p[1][0];	
}

int dec_to_bin(int n)
{	n=n-1;
	int size;
	if(n!=0)
	size=(log(n)/log(2))+1;
	else
	size=1;
	int ar[size];
	for(int i=0;i<size;i++)
	{
		ar[i]=n%2;
		n=n/2;
	}
	return fib(ar,size);
}
main()
{
printf("%d",dec_to_bin(8));
}
