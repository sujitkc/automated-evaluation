import math
def check_pos(node,pos,d,l):
    d_copy=d[:]
    l_copy=l[:]
    #print node,pos,d,l
    try :
        for x in l_copy:
            if x!=None:
                d_copy.remove(int(math.fabs(node-x)))
        l_copy[pos]=node
        return True,l_copy,d_copy
    except:
        return False,l,d
def find(d,l):
    if len(d)==0:
        return True,l,d
    fpos=None
    bpos=None
    lend=len(d)
    lenl=len(l)
    for x in xrange(lenl):
        if fpos==None and l[x]==None:
            fpos=x
        if bpos==None and l[lenl-1-x]==None:
            bpos=lenl-1-x
    for x in xrange(lend):
        statusf,lf,df=check_pos(d[x],fpos,d,l)
        if statusf:
            print d[x]
            break
    print statusf,lf,df
    for x in xrange(lend):
        statusb,lb,db=check_pos(d[lend-1-x],bpos,d,l)
        if statusb:
            print d[lend-1-x]
            break
    print statusb,lb,db
    if statusb:
        status,lab,dab=find(db,lb)        
        if status:
            return True,lab,dab
    if statusf:
        status,laf,daf=find(df,lf)
        if status:
            return True,laf,daf
    return False,l,d
if __name__=="__main__":
    d=[int(x) for x in raw_input().split(',')]
    n=int((1+((1+(8*len(d)))**0.5))/2)
    l=[None]*n
    l[0]=0
    l[n-1]=d.pop()
    status,l,d=find(d,l)
    if status:
        print l
    else:
        print "does not exist"
