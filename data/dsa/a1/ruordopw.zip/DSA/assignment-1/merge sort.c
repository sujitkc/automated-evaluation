#include<stdio.h>
#include<stdlib.h>

void mergeSort(int a[],int low,int mid,int high);
void partition(int a[],int low,int high);
int MAX = 100;
int main(){
    
    int merge[MAX],i,n;

    printf("Enter the size of array : ");
    scanf("%d",&n);

    printf("Enter the elements : ");
    for(i=0;i<n;i++){
         scanf("%d",&merge[i]);
    }

    partition(merge,0,n-1);

    printf("After merge sorting elements are: ");
    for(i=0;i<n;i++){
         printf("%d ",merge[i]);
    }

   return 0;
}

void partition(int a[],int low,int high){

    int mid;

    if(low<high){
         mid=(low+high)/2;
         partition(a,low,mid);
         partition(a,mid+1,high);
         mergeSort(a,low,mid,high);
    }
}

void mergeSort(int a[],int low,int mid,int high){

    int i,m,k,l,temp[MAX];

    l=low;
    i=low;
    m=mid+1;

    while((l<=mid)&&(m<=high)){

         if(a[l]<=a[m]){
             temp[i]=a[l];
             l++;
         }
         else{
             temp[i]=a[m];
             m++;
         }
         i++;
    }

    if(l>mid){
         for(k=m;k<=high;k++){
             temp[i]=a[k];
             i++;
         }
    }
    else{     
         for(k=l;k<=mid;k++){
             temp[i]=a[k];
             i++;
         }
    }
   
    for(k=low;k<=high;k++){
         a[k]=temp[k];
    }
}



