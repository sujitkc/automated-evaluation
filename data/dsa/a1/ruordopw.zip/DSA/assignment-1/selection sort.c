#include<stdio.h>
#include<stdlib.h>

void main()
{
int a[100];
int size,n,i=0,j=0,min=0,temp;

printf("\nEnter size of Array");
scanf("%d",&size);

printf("\nEnter Elements");
for(i=0;i<size;i++)
{
scanf("%d",&n);
a[i]=n;
}

for(i=0;i<size;i++)
{
min=i;
for(j=i+1;j<size;j++)
{
if(a[j]<a[min])
min=j;
}
temp=a[min];
a[min]=a[i];
a[i]=temp;
}

for(i=0;i<size;i++)
{
printf("%d ", a[i] );
}
getch();
}
