#include<stdio.h>

void main()
{
	int a=0,b=1 ,c,i,n;
	scanf("%d",&n);
	if(n==0)
		{printf("fibonacci's nth element is 0");}
	else if(n==1)
	{
		printf("fibonacci's nth element is 1");
	}
	else
		for(i=0;i<n-2;i++)
		{
		c=(a+b)%100;
		a=b;
		b=c;
		}
	printf("the nth element of the fibonacci series : %d\n",c );
}