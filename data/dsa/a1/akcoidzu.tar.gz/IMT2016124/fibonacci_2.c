#include<stdio.h>

void main()
{
	int A[100],i,n;
	A[1]=0;
	A[2]=1;
	scanf("%d",&n);
	if(n==0)
		{printf("fibonacci's nth element is 0\n");}
	else if(n==1)
	{
		printf("fibonacci's nth element is 1\n");
	}
	else
		{
			for(i=3;i<=n;i++)
			{
			A[i] = (A[i-1]+A[i-2])%100;
			}

		printf("fibonacci 's nth element is %d\n",A[n]);
	    }
}