#include<stdio.h>

void multiply(int f[2][2],int A[2][2])
{
	int j,k,l;
	int s[2][2]={{0,0},{0,0}};
	for(j=0;j<2;j++)
	{
		for(k=0;k<2;k++)
		{
			for(l=0;l<2;l++)
			{
				s[j][k]=s[j][k]+f[j][l]*A[l][k];
			}
		}
	}
	for(j=0;j<2;j++)
	{
		for(k=0;k<2;k++)
		{
			f[j][k]=s[j][k]%100;
		}
	}
}

int power(int f[2][2],int A[],int n)
{
	int y[2][2]={{1,0},{0,1}};
	int i=n-1;
	while(i>= 0)
	{
		if(A[i]==1)
		{
			multiply(y,f);
		}
		multiply(f,f);
		i--;
	}
	int j,k;
	for(j=0;j<2;j++)
	{
		for(k=0;k<2;k++)
		{
			f[j][k]=y[j][k];
		}
	}
}

int fibonacci(int A[],int n)
{
  int f[2][2] = {{1,1},{1,0}};
  
  power(f, A,n);
	int i,j;

  return f[1][0];
}
int main(){
	int n;
	printf("Enter the number of digits of binary: ");
	scanf("%d",&n);
	int A[n],i;
	for(i=0;i<n;i++)
	{
		A[i]=rand()%2;
	}
	printf("Obtained binary number: ");
	for(i=0;i<n;i++)
	{
		printf("%d ",A[i]);
	}
  	printf("\nFibonacci of number = %d", fibonacci(A,n));
	return 0;
}
