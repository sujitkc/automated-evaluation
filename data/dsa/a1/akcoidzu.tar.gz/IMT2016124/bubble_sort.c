#include<stdio.h>

void main()
{
   int A[10],i,j,temp;
   for(i=0;i<=4;i++)
   {
   	scanf("%d",&A[i]);
    
   }
   for(j=4;j>=0;j--)
   {
   	for(i=0;i<=j;i++)
    {
   	if(A[i]<A[i+1])
   	{
   	temp = A[i];
   	A[i] = A[i+1];
   	A[i+1] = temp;
    }
    }
   }
   for(i=0;i<=4;i++)
   {
   	printf("%d\n",A[i]);
    
   }
   printf("\n\n");

}