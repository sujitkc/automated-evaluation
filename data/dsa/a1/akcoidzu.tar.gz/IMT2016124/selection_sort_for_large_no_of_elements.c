#include<stdio.h>

void main()
{
   int i,j,A[100000];
   long int min=100000000000;

   for(i=0;i<100000;i++)
   {
       A[i]=rand();
       
   }
   for(j=0;j<100000;j++)
   {
   	for(i=j;i<100000;i++)
   	{  
   		if(A[i]<min)
   		{
   			min=A[i];
   			A[i]=A[j];
   			A[j]=min;
   		}

   	}
      min=100000000000;
   }
   for(i=0;i<100000;i++)
   {
     printf("%d\n",A[i]);

   }
   
}
