#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define numberCount 100000

void QuickSort(int arr[], int start, int end);
int Partition(int arr[], int start, int end);
void swap(int* a, int* b);
void inputGenerator(int arr[]);


int main()
{
    int arr[numberCount];
    QuickSort(arr,0,numberCount-1);

    /*for(int i = 0; i<11; i++)
        printf("%d ", arr[i]);*/
    printf("\n\nDONE!!\n\n");
}


void QuickSort(int arr[], int start, int end)
{
    if(start>=end)
        return;
    int partitionIndex = Partition(arr,start,end);
    QuickSort(arr, start, partitionIndex-1);
    QuickSort(arr, partitionIndex+1,end);
}


int Partition(int arr[], int start, int end)
{
    int pivot = arr[end];
    int index = start;

    for(int i = start;i <end; i++)
    {
        if(arr[i] <= pivot)
        {
            swap(arr+i,arr+index);
            index+=1;
        }
    }
    swap(arr+index,arr+end);
    return index;
}

void swap(int* a, int* b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}


void inputGenerator(int arr[])
{
    srand ( time(NULL) );
    for(int i = 0; i < numberCount; i++)
    {
        *(arr+i) = rand()%100000;
    }
}

