#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define numberCount 1000000

void insertionSort(int arr[], int n);
void inputGenerator(int arr[]);



int main()
{
    int arr[numberCount];
    inputGenerator(arr);
    insertionSort(arr, numberCount);
    for(int i = 0; i<numberCount; i++)
        printf("%d ", *(arr+i));
}

void insertionSort(int arr[], int n)
{
    int j,val;
    for(int i = 1; i < n; i++)
    {
        val = *(arr+i);
        j = i-1;

        while(j >= 0 && *(arr+j) > val)
        {
            *(arr+j+1)=*(arr+j);
            j -= 1;
        }
        *(arr+j+1)=val;

    }
}

void inputGenerator(int arr[])
{
    srand ( time(NULL) );
    for(int i = 0; i < numberCount; i++)
    {
        *(arr+i) = rand();
    }
}

