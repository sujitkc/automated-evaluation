#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define numberCount 1000000

void inputGenerator(int arr[]);
void mergeSort(int arr[], int l, int r);
void merge(int arr[], int l, int m, int r);



int main()
{
    int arr[numberCount];
    inputGenerator(arr);


    mergeSort(arr,0,numberCount-1);

    /*for(int i = 0; i<numberCount; i++)
        printf("%d ", *(arr+i)); */
    
    printf("\nDONE!!\n");
}



void inputGenerator(int arr[])
{
    srand ( time(NULL) );
    for(int i = 0; i < numberCount; i++)
        *(arr+i) = rand();
}


void mergeSort(int arr[], int l, int r) 
{
    if (l < r)   
    {
        int m = l+(r-l)/2;
        mergeSort(arr, l, m);
        mergeSort(arr, m+1, r);
        merge(arr, l, m, r);
    }
}


void merge(int arr[], int l, int m, int r)
{
     int T = r - l + 1;
     int nL = m - l + 1;
     int nR = T - nL;

     int left[nL];
     int right[nR];

     for(int i=0;i<nL;i++)
         left[i]=arr[l+i];

     for(int j=0;j<nR;j++)
        right[j]=arr[m+1+j];


     int i,j,k;
     i=j=0;
     k=l;
     while(i<nL && j<nR)
     {
         if(left[i]<=right[j])
         {
             arr[k]=left[i];
             k++;
             i++;

         }
         else
         {


             arr[k]=right[j];
             k++;
             j++;
         }
     }
     while(i<nL)
     {
         arr[k]=left[i];
         k++;
         i++;
     }
     while(j<nR)
     {
         arr[k]=right[j];
         k++;
         j++;
     }
}

