#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define numberCount 1000000

void inputGenerator(int arr[]);
void SelectionSort(int arr[], int n);
void swap(int* a, int* b);


int main()
{
    int arr[numberCount];
    inputGenerator(arr);
    SelectionSort(arr,numberCount);

    for(int i = 0; i<numberCount;i++)
        printf("%d ", arr[i]);
}


void inputGenerator(int arr[])
{
    srand ( time(NULL) );
    for(int i = 0; i < numberCount; i++)
        *(arr+i) = rand();
}


void SelectionSort(int arr[], int n)
{
    int max_index;

    for(int i = n-1; i > 0; i--)
    {
        max_index =  i;
        for(int j = 0; j<i; j++)
        {
            if(arr[j] > arr[max_index])
                max_index = j;
        }
        swap(arr+i, arr+max_index);
    }
}


void swap(int* a, int* b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}

