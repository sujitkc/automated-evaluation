#include <stdio.h>

int main()
{
    int n;
    while(1)
    {
	printf("Enter the value of n: ");
	scanf("%d", &n);
	printf("%d\n", fib(n));
    }
}

int fib(int n)
{
    if(n < 1)
	return -1;
    int a = 0;
    int b = 1;
    int c = a + b;
    if(n == 1)
        return a;
    if(n == 2)
        return b;
    for(int i = 2; i < n; i++)
    {
        a = b;
        b = c;
        c = a + b;
    }
    return b;
}
