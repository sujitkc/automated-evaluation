#include <stdio.h>

void Multiply(int M1[2][2], int M2[2][2])
{
    int a = M1[0][0]*M2[0][0] + M1[0][1]*M2[1][0];
    int b = M1[0][0]*M2[0][1] + M1[0][1]*M2[1][1];
    int c = M1[1][0]*M2[0][0] + M1[1][1]*M2[1][0];
    int d = M1[1][0]*M2[0][1] + M1[1][1]*M2[1][1];

    M1[0][0] = a;
    M1[0][1] = b;
    M1[1][0] = c;
    M1[1][1] = d;
}

void pow(int M[2][2], int n)
{
    int Y[2][2] = {{1,0},{0,1}};
    while(n > 0)
    {
        if(n%2 == 1)
            Multiply(Y,M);

        Multiply(M,M);
        n = n/2;

    }
    M[0][0] = Y[0][0];
    M[0][1] = Y[0][1];
    M[1][0] = Y[1][0];
    M[1][1] = Y[1][1];
}

int fib(int n)
{
    if(n < 1)
	return -1;
    if(n == 1)
        return 0;
    int I[2][2] = {{1,1},{1,0}};
    pow(I, n-1);
    return I[0][1];
}

int main()
{
    int n;
    while(1)
    {
    printf("Enter the value of n: ");
    scanf("%d", &n);

    printf("%d\n", fib(n));
    }
}
