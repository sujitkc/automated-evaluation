#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define arr_size 1000000

struct Node
{
    int data;
    struct Node* next;
};

int track = 0;

void VertiShrink(struct Node** head);
void Push(struct Node** head, int value);
int Length(struct Node* head);
void Shrink(struct Node** head);
void deleteNode(struct Node **startptr,int deletedata);
void printLinkedList(struct Node* head);




int main()
{
    struct Node* arr[arr_size] = {NULL};
    int n, val;

    srand ( time(NULL) );

    for(int i = 0; i < arr_size; i++)
    {
        n = rand() % arr_size;
        val = rand();
        Push((arr + n), val);
    }

    for(int i = 0; i < arr_size; i++)
    {
        printLinkedList(*(arr+i));
        printf("\n");    
    }
        


    struct Node* Vertical = NULL;
    int value;
    struct Node* current;
    int count = 0;
    for(int i=0;i<arr_size;i++)
    {
        
        Shrink(arr+i);
        current = *(arr+i);
        if(current!=NULL)
        {
            value = current -> data;
            Push(&Vertical,value);
            count += 1;  
        }
    }
    
    //printf("\n\n%d\n\n", count);

    while(1)
    {
        if(track > 0)
            break;
        VertiShrink(&Vertical);
    }
    printf("After shrinking vertically, the element that is left is: ");
    printLinkedList(Vertical);

    track = 0;    


}


void Push(struct Node** head, int value)
{
    struct Node* newNode = malloc(sizeof(struct Node));
    newNode -> data = value;
    newNode -> next = *head;
    *head = newNode;
}

int Length(struct Node* head)
{
    struct Node* current = head;
    int len = 0;

    while(current != NULL)
    {
        len++;
        current = current -> next;
    }

    return len;
}



void Shrink(struct Node **head)
{
    if(*head == NULL)
        return;

    while(Length(*head) > 1)
    {
        struct Node *current = *head;
        while(1)
        {
            int var1 = current -> data;
            if(current -> next != NULL)
            {
                current = current -> next;
                int var2 = current -> data;
                if(var1%2 == 0 && var2%2 == 0)
                {
                    if(var1 < var2)
                        deleteNode(head, var1);
                    else
                        deleteNode(head, var2);
                }

                else if(var1%2 == 1 && var2%2 == 1)
                {
                    if(var1 > var2)
                        deleteNode(head, var1);
                    else
                        deleteNode(head, var2);
                }

                else
                {
                    if(var1%2 == 1)
                        deleteNode(head,var1);
                    else
                        deleteNode(head,var2);
                }
            }
            else
                break;

            if(current -> next != NULL)
                current = current -> next;
            else
                break;
        }

    }
  
}


void deleteNode(struct Node **head,int deletedata)
{
    struct Node *current = *head;
    if(*head == NULL)
    {
        printf("There are no elements in the linked list\n");
        return;
    }
    else if((*head)->data==deletedata)
        *head=(*head)->next;


    else
    {
        while(current->next!=NULL )
        {
            if(current->next->data==deletedata)
            {
                free(current->next);
                current->next=current->next->next;
                return;
            }
            if(current->next!=NULL)
                current=current->next;
        }

        if(current->next==NULL)
            printf("The element doesn't exist in the linked list\n");
        else
        {
            free(current->next);
            current->next=current->next->next;
        }
    }
}




void printLinkedList(struct Node* head)
{

    struct Node* current;
    current = head;
    //if(current == NULL)
        //printf("\n\nNo elements in the linked list\n\n");

    if(current != NULL)
    {
        while(current != NULL)
        {
            printf("%d ", current -> data);
            current = current -> next;
        }
    }
    else
    {
        printf("NULL");
    }
}



void VertiShrink(struct Node** head)
{
    struct Node* current = *head;

    if(current == NULL || current -> next == NULL)
    {
        track += 1;
        return;
    }

    if((current -> data) % 2 ==0 && (current -> next -> data) % 2 == 0)
    {
        if((current -> data) > (current -> next -> data))
        {
            deleteNode(head, current-> next -> data);
        }
        else
            deleteNode(head, current -> data);
        return;
    }

    if((current -> data) % 2 ==1 && (current -> next -> data) % 2 == 1)
    {
        if((current -> data) > (current -> next -> data))
        {
            deleteNode(head, current -> data);
        }
        else
            deleteNode(head, current -> next -> data);
        return;
    }

    if((current -> data) % 2 ==0 && (current -> next -> data) % 2 == 1)
    {
        deleteNode(head, current -> next -> data);
        return;
    }
}
