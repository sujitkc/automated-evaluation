#include <stdio.h>

int per(int m);


int main()
{
    while(1)
    {
	printf("Enter the value of m: ");
        int m;
        scanf("%d", &m);
	printf("Enter the value of n: ");
        int n;
        scanf("%d", &n);
        int period = per(m)-1;

        int arr[period];

        arr[0]=0%m;
        arr[1]=1%m;

        for(int i=2;i<period;i++)
        {
            arr[i]=(arr[i-1]+arr[i-2])%m;
        }
        printf("%d\n",arr[n%m-1]);
    }


    return 0;
}


int per(int m)
{
    int fib[6*m+1];

    fib[0]=0;
    fib[1]=1;

    for(int i=2;i<6*m+1;i++)
    {
        fib[i]=(fib[i-1]+fib[i-2])%m;
        if(fib[i]%m==1 && fib[i-1]%m==0)
            return i;
    }
    return -1;
}
