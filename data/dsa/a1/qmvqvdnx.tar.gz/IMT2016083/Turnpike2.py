import math

class Node:
    def __init__(self, value, D, X, leftChild, rightChild, parent):
        self.value = value
        self.distances = D
        self.points = X
        self.parent = parent
        self.leftChild = leftChild
        self.rightChild = rightChild

    def check(self):
        k = []
        for i in self.distances:
            k.append(i)
        for i in self.points:
            if(abs(i-self.value) not in k): 
                return False
            k.remove(abs(i-self.value))
        return True

    def change(self):
        for i in self.points:
            self.distances.remove(abs(i-self.value))

    def assign(self):
        self.points.append(self.value)
        
def check(value,distances, points):
    d  = []
    for i in distances:
        d.append(i)
    for i in points:
        if(abs(i-value) not in d):
            return False
        else:
            d.remove(abs(i-value))
    return True
 


def generateDistances(head, maxval, n):
    #print head.distances
    #print head.points
    if(len(head.distances) == 0):
        print "No such points exit"
        return
    if(head.rightChild == None and head.leftChild == None):
        if(check(max(head.distances),head.distances, head.points)):
            disttemp=[]
            for i in head.distances:
                disttemp.append(i)
            pointtemp=[]
            for i in head.points:
                pointtemp.append(i)
            head.rightChild = Node(max(head.distances),disttemp, pointtemp, None, None, head)
            head.rightChild.change()
            head.rightChild.assign()
            head.rightChild.points.sort()
            if(len(head.rightChild.points)==n and len(head.rightChild.distances) == 0):
                print "The points exist!",
                print head.rightChild.points,
                print "&",
                print sorted(map(lambda x: maxval-x, head.rightChild.points))  
                exit()
            
            generateDistances(head.rightChild, maxval, n)
        else:
            head.rightChild = 1
            generateDistances(head, maxval,n)
    
    elif(head.rightChild != None and head.leftChild == None):
        if(check(maxval-max(head.distances), head.distances, head.points)):
            disttemp=[]
            for i in head.distances:
                disttemp.append(i)
            pointtemp=[]
            for i in head.points:
                pointtemp.append(i)
            head.leftChild = Node(maxval-max(head.distances),disttemp,pointtemp, None, None, head)      
            head.leftChild.change()
            head.leftChild.assign()
            head.leftChild.points.sort()

            if(len(head.leftChild.points)==n and len(head.leftChild.distances) == 0):
                print "The points exist!",
                print head.leftChild.points,
                print "&",
                print sorted(map(lambda x: maxval-x, head.leftChild.points))
                exit()
    
            generateDistances(head.leftChild, maxval, n)
        else:
            head.leftChild = 1
            if(head.parent == None):
                print "No such points exists"
                exit()
            generateDistances(head.parent,maxval, n)

    elif(head.rightChild != None and head.leftChild != None):
        if(head.parent == None):
            print "No such points exist"
            exit()  
        print "up ",
        #if(head.parent.rightChild == None or head.parent.leftChild == None):
        generateDistances(head.parent, maxval, n)



#For testing
def distanceGenerator(l):
    d=[]
    for i in range(1,len(l)):
        for j in range(i):
            d.append(abs(l[i]-l[j]))
    return d

def calculateNumberOfPoints(D):
    x = len(D)
    y = math.sqrt(1+8*x)
    if(y == int(y)):
        return (1+y)/2
    else:
        return -1
if __name__ == "__main__":
    #For testing
    '''
    print "Enter the points"
    points = map(int, raw_input().split(' '))
    n=len(points)
    D = distanceGenerator(points)
    X=[0, max(D)]
    D.sort()
    m=max(D)'''

    print "Enter the distances"
    D = map(int, raw_input().split(' '))

    n = calculateNumberOfPoints(D)
    if(n == -1):
        print "Invalid set of distances"
        exit()
    else:

        X=[0, max(D)]
        D.sort()
        m=max(D)

        D.remove(max(D))

        father = Node(m, D, X, None, None, None)    



        generateDistances(father,m, n)
    
        

    