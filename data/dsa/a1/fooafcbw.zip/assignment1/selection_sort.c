#include<stdio.h>
#include<stdlib.h>
main(){
	int i,j,arr[10000],temp,minp;
	int n=10000;
	srand(time(NULL));
	for(i=0;i<n;i++){
		arr[i]=rand()%n;
	}
	int min;
	for(i=0;i<n;i++){
		min=arr[i];
		for(j=i;j<n;j++){
			if(min>arr[j]){
				min=arr[j];
				minp=j;
			}
		}
		arr[minp]=arr[i];
		arr[i]=min;
	}
	
	for(i=0;i<n;i++){
		printf("%d\n",arr[i]);
	}
	
}
