#include<stdio.h>
int main(){

  int i,j,a[10000],temp;
	int n=10000;
	srand(time(NULL));
	for(i=0;i<n;i++){
		a[i]=rand()%n;
	}
  for(i=1;i<n;i++){
      temp=a[i];
      j=i-1;
      while((temp<a[j])&&(j>=0)){
      a[j+1]=a[j];
          j=j-1;
      }
      a[j+1]=temp;
  }

  for(i=0;i<n;i++)
      printf(" %d ",a[i]);

  return 0;
}
