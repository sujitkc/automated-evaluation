#include<stdio.h>
#include<stdlib.h>
struct node
{
	int value;
	struct node *nextptr;
};
void add(int num,struct node **head)
{
    struct node *new;
    new=malloc(sizeof(struct node));
    new->value=num;
    new->nextptr=*head;
    *head=new;
}
void Delete1(struct node **head,struct node**currentptr)
{
	 struct node *temp;
	 temp=*currentptr;
	 if(*head==*currentptr)
	 {
                                
		*currentptr=(*currentptr)->nextptr;
        *head=*currentptr;
        free(temp);			
	}
   else
   {
        struct node *prev;
        prev=*head;
        while(prev->nextptr!=*currentptr)
          prev=prev->nextptr;
        prev->nextptr=(*currentptr)->nextptr;
        *currentptr=(*currentptr)->nextptr;
        free(temp);
   }
}
void Delete2(struct node **head,struct node**currentptr)
{
	struct node *temp;
			temp=(*currentptr)->nextptr;
			(*currentptr)->nextptr=temp->nextptr;
			if(temp->nextptr!=NULL)
				*currentptr=temp->nextptr;
			free(temp);
}
int main()
{
	long int n=10,l=5,x;//n:no. of nodes l:len of arraylist
	struct node * arr[l];
	for(x=0;x<l;x++)
		arr[x]=NULL;
	int i,j;
	while(n>0)
	{
		n--;
		i=rand()%l;
		j=rand();
		add(j,&arr[i]);
	}
    struct node *cur;
    for(x=0;x<l;x++)
    {
        cur=arr[x];
        while(cur)
        {
            printf("%d ",cur->value);
            cur=cur->nextptr;
        }
        printf("\n");
    }
    for(x=0;x<l;x++)
    {
        struct node **head;
        head=&arr[x];
        
        while(*head&&(*head)->nextptr)
        {
            
            struct node *currentptr;
            currentptr=*head;
            while(currentptr->nextptr)
            {
                
                if(currentptr->value%2==0&&currentptr->nextptr->value%2==0)
                    if(currentptr->value>=currentptr->nextptr->value)
                        Delete1(head,&currentptr);
                    
                    else
						Delete2(head,&currentptr);
                    
                }
								else if(currentptr->value%2!=0&&currentptr->nextptr->value%2!=0)
										if(currentptr->value<=currentptr->nextptr->value)
											Delete1(head,&currentptr);
										
										else
											Delete2(head,&currentptr);
										
								
								else if((currentptr->value%2==0&&currentptr->nextptr->value%2!=0)||(currentptr->value%2!=0&&currentptr->nextptr->value%2==0))
										if(currentptr->value%2!=0)
											Delete1(head,&currentptr);
										
										else
											Delete2(head,&currentptr);
										
								
            }       
        }
    }
		struct node *startptr;
		startptr=malloc(sizeof(struct node));
		startptr=NULL;
		for(x=l-1;x>=0;x--)
		{
				if(arr[x])
					add(arr[x]->value,&startptr);
		}
		while(startptr&&startptr->nextptr)
		{
				struct node *here;
				here=startptr;
				while(here->nextptr)
				{
						if(here->value%2==0&&here->nextptr->value%2==0)
						{
                   
                    if(here->value>=here->nextptr->value)
                    {
                        Delete1(&startptr,&here);
                    }
                    else
                    {
						Delete2(&startptr,&here);
                    }
                }
								else if(here->value%2!=0&&here->nextptr->value%2!=0){
										if(here->value<=here->nextptr->value){
												Delete1(&startptr,&here);
										}
										else{
												Delete2(&startptr,&here);
										}
								}
								else if((here->value%2==0&&here->nextptr->value%2!=0)||(here->value%2!=0&&here->nextptr->value%2==0)){
										if(here->value%2!=0){
												Delete1(&startptr,&here);
										}
										else{
												Delete2(&startptr,&here);
										}
								}
				}
		}
    struct node *currentptr;
		currentptr=startptr;
		while(currentptr){
				printf("*%d*\n",currentptr->value);
				currentptr=currentptr->nextptr;
		}
}
