#include<stdio.h>
int main()
{
	int n,temp;
	printf("enter the no. of elements\n");
	scanf("%d",&n);
	int i, arr[1000];
	for(i=0;i<n;i++)
		scanf("%d",&arr[i]);
	int j;
	for(j=0;j<n;++j)
    for(i=j+1;i<n;++i)
     {
         if(arr[j]>arr[i])  
          {
             temp=arr[j];
             arr[j]=arr[i]; 
             arr[i]=temp;
         }
    }
    for(i=0;i<n;++i)
        printf("%d  ",arr[i]);
    return 0;	
}