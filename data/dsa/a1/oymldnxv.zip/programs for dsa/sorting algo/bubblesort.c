#include<stdio.h>
int main()
{
	int n,a[10000],i,j;
	printf("enter n\n");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<n-1;++i)
		for(j=0;j<n-i-1;++j)
		{
			if(a[i]>a[j])
			{
				int t;
				t=a[i];
				a[i]=a[j];
				a[j]=t;
			}
		}
		return 0;
}