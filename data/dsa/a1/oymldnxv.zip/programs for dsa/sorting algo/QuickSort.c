#include<stdio.h>
#include<stdlib.h>
void Swap(int *a, int *b)
{
	int temp;
	temp=*a;
	*a=*b;
	*b=temp;
}
int Randompivot(int a[], int left, int right)
{
	int p;
	p=left+ rand()%(right-left+1);
	printf("the pivot is %d", *(a+p));
	return *(a+p);
}
int Partition(int a[],int left, int right)
{
	int p_r;
	p_r=Randompivot(a,left,right);
	Swap(&p_r,&a[right]);
	int i,j;
	i=left-1;
	for(j=left;j<right;j++)
	{
		if(a[j]<=a[right])
		{
			i++;
			Swap(&a[i],&a[j]);
		}
	}
	Swap(&a[i+1],&a[right]);
	return i+1;

}
void RecQuickSort(int a[],int left, int right)
{
	if(left<right)
	{
		int p;
		p=Partition(a,left,right);
		RecQuickSort(a,left,p);
		RecQuickSort(a,p+1,right);
	}
}
int main()
{
	int n,i;
	printf("enter the number of elements\n");
	scanf("%d",&n);
	int a[1000];
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	RecQuickSort(a,0,n-1);
	for(i=0;i<n;i++)
		printf("%d ",a[i]);
	printf("\n");
	return 0;
}