#include<stdio.h>
int Mod_fib_algo2(int *arr, int n)
{
	if(n<2)
		{
			if(n==0)
			{

				*(arr)=0;
				return *(arr);
			}
			else
			{
				*(arr)=0;
				*(arr+1)=1;
				return *(arr+1);
			}

		}
	else
	{
		*(arr)=0;
		*(arr+1)=1;
		*(arr+n)= (Mod_fib_algo2(arr,n-2)+Mod_fib_algo2(arr,n-1))%100;
		return *(arr+n);
	}
}
int main()
{
	int n,result,i;
	scanf("%d",&n);
	int arr[1000];
	for(i=0;i<=n;i++)
		arr[i]=0;
	int p;
	p=Mod_fib_algo2(arr,n);
	printf("%d\n",arr[n]);
	return 0;
}