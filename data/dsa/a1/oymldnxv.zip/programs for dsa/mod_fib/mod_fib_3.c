#include<stdio.h>
int Mod_fib_algo3(int n)
{
	if(n<2)
		return n;
	else
	{
		int a,b,c;
		a=0;
		b=1;
		c=n;
		int i;
		for(i=2;i<=n;i++)
		{
			c=(a+b)%100;
			a=b;
			b=c;
		}
		return c;
	}
}
int main()
{
	int n;
	scanf("%d",&n);
	int result;
	result=Mod_fib_algo3(n);
	printf("%d\n",result);
}