#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void print(int *a, int p)
{
	int i;
	for(i=0;i<p;i++)
		printf("%d",a[i]);
}
int divide(int *num, int no_digits)
{
	int i=0,b=0,c=0;
	for(i=0;i<no_digits;i++)
		if(num[i]==0) c++;
	if(c==no_digits)
		return 0;
	for(i=0;i<no_digits;i++)
	{
		if(num[i]<2&&b==0)
		{
			b=b*10+num[i]%2;
			num[i]=0;
		}
		else
		{
			if(b!=0)
			{
				b=b*10+num[i];
				int k=(b)%2;
				num[i]=b/2;
				b=k;
			}
			else
			{
				b=num[i]%2;
				num[i]=num[i]/2;
			}
		}
	}
	return 1;
}
int divide_bin(int *num, int no_digits)
{
	int i=0,b=0,c=0;
	for(i=0;i<no_digits;i++)
		if(num[i]==0) c++;
	if(c==no_digits)
		return 0;
	for(i=no_digits;i>0;i--)
	{
		num[i]=num[i-1];
	}
	num[i]=0;
	return 1;
}
void mat_mult(int (*a)[2], int b[2][2])
{
	int p1,p2,p3,p4;
	p1=a[0][0]*b[0][0]+a[0][1]*b[1][0];
	p2=a[0][0]*b[0][1]+a[0][1]*b[1][1];
	p3=a[1][0]*b[0][0]+a[1][1]*b[1][0];
	p4=a[1][0]*b[0][1]+a[1][1]*b[1][1];
	a[0][0]=p1%100;
	a[0][1]=p2%100;
	a[1][0]=p3%100;
	a[1][1]=p4%100;
}

int main_dec(int* arr, int no_digits)
{
	int a[2][2]={{1,1},{1,0}},y[2][2]={{1,0},{0,1}};
	do
	{
		if ((arr[no_digits-1])%2==1)
		{
			mat_mult(y,a);
		}
		mat_mult(a,a);
	}while(divide(arr,no_digits)==1);
	return y[1][0];
}
int main_bin(int* arr, int no_digits)
{
	int a[2][2]={{1,1},{1,0}},y[2][2]={{1,0},{0,1}};
	do
	{
		if (arr[no_digits-1]==1)
		{
			mat_mult(y,a);
		}
		mat_mult(a,a);
	}while(divide_bin(arr,no_digits)==1);
	return y[1][0];
}

void input_as_string_decimal()
{
	int no_digits;
	printf("Enter number of digits\n");
	scanf("%d",&no_digits);
	char str[no_digits];
	printf("Enter the number\n");
	scanf("%s",str);
	int i=0, num[no_digits];
	while(i<no_digits)
	{
		num[i]=str[i]-'0';
		i++;
	}
	printf("%d\n",main_dec(num,no_digits));
	
}
void input_as_string_binary()
{
	int no_digits;
	printf("Enter number of digits\n");
	scanf("%d",&no_digits);
	char str[no_digits];
	printf("Enter the number\n");
	scanf("%s",str);
	int i,num[no_digits];
	i=0;
	while(i<no_digits)
	{
		num[i]=str[i]-'0';
		i++;
	}
	printf("%d\n",main_bin(num,no_digits));
	
}
int main()
{
	printf("Press 1 for giving input as a decimal string and 2 if the input is being given in binary form\n");
	int option;
	scanf("%d",&option);
	if(option==1 || option==2)
	{ 	if (option==1)
			input_as_string_decimal();
		else
			input_as_string_binary();
	}
	else
		printf("invalid option\n");
	return 0;
}
