#include<stdio.h>
int Rec_algo1(int n)
{
	if (n==0 || n==1)
		return n;
	else
		return ((Rec_algo1(n-1)+Rec_algo1(n-2))%100);
}
int main()
{
	int n;
	printf("enter n\n");
	scanf("%d",&n);
	int result;
	result=Rec_algo1(n);
	printf("%d\n",result);
	return 0;
}