#include<stdio.h>
void swap(int *a,int *b)
{
    int t=*a;
    *a=*b;
    *b=t;
}
int Findrank(int arr[],int i,int j,int n)
{
    int pos=rand()%(j-i+1);
    int p=arr[i+pos];
    swap(&arr[i+pos],&arr[j]);
    int k=i-1,k1;
    for(k1=i;k1<j;k1++)
    {
        if(arr[k1]<=p)
        {
            k++;
            swap(&arr[k],&arr[k1]);
        }
    }
    swap(&arr[k+1],&arr[j]);
    return k+1-i;
}
int Func(int arr[],int i,int j,int n,int r)
{
	if(i<=j)
    	{
		int k=Findrank(arr,i,j,n);
    		if(j-i+1-k==r)
			return arr[i+k];
		else if (r<j-i+1-k)
			Func(arr,i+k+1,j,n,r);
		else
			Func(arr,i,i+k-1,n,r-(j-i+1)+k);
	}
}
int main() 
{
    int n;
    scanf("%d",&n);
    int a[n];
    int i;
    for(i=0;i<n;i++)
        scanf("%d",&a[i]);
    printf("Ans=%d\n",Func(a,0,n-1,n,4));  
    return 0;
}
