#include<stdio.h>
int main()
{
	long long int n;
	printf("Enter the value of n:\n");
	scanf("%lld",&n);
	long long int a=0;
	long long int b=1;
	long long int c,i;
	if (n==0)
		c=0;
	else
		c=1;
	for(i=2;i<=n;i++)
	{
		c=(a+b)%100;
		a=b;
		b=c;		
	}
	printf("F(%lld) is %lld\n",n,c);
}
	

