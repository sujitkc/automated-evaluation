from math import *
D=[1,2,2,2,3,3,3,4,5,5,5,6,7,8,10]
#D=[8,12,15,16,18,20,4,7,8,10,12,3,4,6,8,1,3,5,2,4,2]
#D=[1,1,1,2,2,3]
#D=[1,1,1,1,1,1]
#D=[11,10,9,8,7,6,6,5,5,4,3,2,2,1]
#D=[2,3,2,3,24,4,5,5,2,5,3,5,3,5,3,9,55,4,3,32]
#D=[1,3,6,9,10,13,14,16,18,2,5,8,9,12,13,15,17,3,6,7,10,11,13,15,3,4,7,8,10,12,1,4,5,7,9,3,4,6,8,1,3,5,2,4,2,3,5,7,8,11,12,15,18,20,21]
#D=[3,4,10,17,1,7,14,6,13,7]
#D=[2,5,7,9,14,18,19,22,23,30,32,3,5,7,12,16,17,20,21,28,30,2,4,9,13,14,17,18,25,27,2,7,11,12,15,16,23,25,5,9,10,13,14,21,23,4,5,8,9,16,18,1,4,5,12,14,3,4,11,13,1,8,10,7,9,2]
#D=[7,6,7,6,5,10,9,2,3,8,6,7,1,1,6]
n=int((1+sqrt(1+8*len(D)))/2)
l=[0 for i in range(0,n)]
j=1
j1=n
k2=0
b=[]
g=0
a=[]
var=0
flag=0
def backtrack():
        global j,j1,l,D,b,g,a,var,flag
        b=[]
        k=0
	if len(a)==0:
		print "Impossible"
		flag=1
		return
        m=a.pop()
        ix=l.index(m)
        if ix>=j1:
                for i in range(1,j):
			D.append(abs(l[i]-m))
                for i in range(j1+1,n):
                        D.append(abs(l[i]-m))
                b.append(m)
                D.append(m)
                m=l[j1]
                l[j1]=0
                j1=j1+1            
                c=D[:]
		for i in range(0,j):
                        if abs(l[n-1]-m-l[i]) not in c:
			        k=1
				break 
			else:
			    	c.remove(abs(l[n-1]-m-l[i]))
		for i in range(j1,n):
		        if abs(l[n-1]-m-l[i]) not in c:
		    		k=1
		    		break
		    	else:
		    		c.remove(abs(l[n-1]-m-l[i]))
		if k==0:
		    	l[j]=l[n-1]-m
		    	j=j+1
                        a.append(l[n-1]-m)
		    	for i in range(0,j-1):
				D.remove(abs(l[n-1]-m-l[i]))
			for i in range(j1,n):
				D.remove(abs(l[n-1]-m-l[i]))
                        func()
                else:
                        
                        backtrack()
        elif ix<j:
                for i in range(1,j-1):
			D.append(abs(l[i]-m))
                for i in range(j1,n):
                        D.append(abs(l[i]-m))
                b.append(m)
                D.append(m)        
                l[ix]=0
                j=j-1
                backtrack()                      	 
def func():
	global j,j1,l,k2,g,b,a,var,flag
	if flag==1:
		return
        m=0
	for i in D:
		if i>m and i not in b:
			m=i
	k=0
	c=D[:]
	for i in range(0,j):
		if abs(m-l[i]) not in c: 
			k=1
			break
		else:	
			 c.remove(abs(m-l[i]))
	for i in range(j1,n):
		if abs(m-l[i]) not in c:
			k=1
			break
		else:
			c.remove(abs(m-l[i]))
	if k==0:
		l[j1-1]=m
                a.append(m)
		j1=j1-1
		k2=1
		for i in range(0,j):
			D.remove(abs(m-l[i]))
		for i in range(j1+1,n):
			D.remove(abs(m-l[i]))
	else:
		k=0
		c=D[:]
		for i in range(0,j):
			if abs(l[n-1]-m-l[i]) not in c:
				k=1
				break 
			else:
				c.remove(abs(l[n-1]-m-l[i]))
		for i in range(j1,n):
			if abs(l[n-1]-m-l[i]) not in c:
				k=1
				break
			else:
				c.remove(abs(l[n-1]-m-l[i]))
		if k==0:
			l[j]=l[n-1]-m
                        a.append(l[n-1]-m)
			j=j+1
			k2=2
			for i in range(0,j-1):
				D.remove(abs(l[n-1]-m-l[i]))
			for i in range(j1,n):
				D.remove(abs(l[n-1]-m-l[i]))
		else:
                        backtrack()
        if len(D)==0:
		count=0
		for i in l:
			if i==0:
				count=count+1
		if count>1:
			flag=1			
			print "Impossible"			
                return
        else:
                func()
func()
if flag==0:
	print l
