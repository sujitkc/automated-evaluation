#include<stdio.h>
int rec(int n)
{
	if(n<2)
		return n;
	else
		return (rec(n-1)+rec(n-2))%100;	
}
int main()
{
	int n;
	printf("Enter the value of n:\n");
	scanf("%d",&n);
	printf("F(%d) is %d\n",n,rec(n));
	return 0;
}

