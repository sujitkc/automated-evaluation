#include<stdio.h>
void swap(int *a,int *b)
{
    int t=*a;
    *a=*b;
    *b=t;
}
int partition(int arr[],int i,int j,int n)
{
    int pos=rand()%(j-i+1);
    int p=arr[i+pos];
 	swap(&arr[i+pos],&arr[j]);
    int k=i-1,k1;
    for(k1=i;k1<j;k1++)
    {
        if(arr[k1]<=p)
        {
            k++;
            swap(&arr[k],&arr[k1]);
        }
    }
    swap(&arr[k+1],&arr[j]);
    return k+1;
}
void quicksort(int arr[],int i,int j,int n)
{
    if(i<j)
    {
        int pi=partition(arr,i,j,n);
        quicksort(arr,i,pi-1,n);
        quicksort(arr,pi+1,j,n); 
    }
}
int main() 
{
    int n;
	printf("Enter the size of array:\n");
    scanf("%d",&n);
    int a[n];
    int i;
	printf("Enter the elements of array:\n");
    for(i=0;i<n;i++)
        scanf("%d",&a[i]);
    quicksort(a,0,n-1,n);
	printf("Sorted array is:\n");
    for(i=0;i<n;i++)
		printf("%d ",a[i]);
	printf("\n");  
    return 0;
}
