#include<stdio.h>
#include<string.h>
#include<math.h>
int divide(int *n, int l,int p)
{
	int c=0,num,i;
	for(i=0;i<l;i++)
	{
		num=(*(n+i)+c*10)/p;
		c=(c*10+*(n+i))%p;
		*(n+i)=num;
	}
	return c;
}
int main()
{
	char s[10001];
	printf("Enter the number:\n");
	scanf("%s",s);
	int no[strlen(s)],i,m,p;
	printf("Enter the value of m:\n");
	scanf("%d",&m);
	for(i=0;i<strlen(s);i++)
		no[i]=s[i]-48;
	int n=strlen(s);
	int num=0;
	int a=0;
	int b=1;
	int c;
	for(i=2;i<=m*m+1;i++)
	{
		c=(a+b)%m;
		a=b;
		b=c;
		if(a==0&&b==1)
		{
			p=i-1;
			break;
		}		
	}
	int r=divide(no,n,p);
	if (r==0||r==1)
	{
		printf("F(%d) is %d",r,r);		
	}
	else
		for(i=2;i<=r;i++)
		{
			c=(a+b)%m;
			a=b;
			b=c;
		}
	printf("F(%s) is %d\n",s,c);
	return 0;
}	
