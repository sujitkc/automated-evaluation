#include<stdio.h>
int dp(int n)
{
	int f[n];
	f[0]=0;
	f[1]=1;
	int i; 
	for(i=2;i<=n;i++)
	{
		f[i]=(f[i-1]+f[i-2])%100;
	}
	return f[n];
}
int main()
{
	int n;
	printf("Enter the value of n:\n");
	scanf("%d",&n);
	printf("F(%d) is %d\n",n,dp(n));
}
