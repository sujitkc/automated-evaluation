#include<stdio.h>
#include<string.h>
#include<math.h>
void half(char *s)
{
    char d[1001];
    int i,x=0,c=0,k=0;
    int n=strlen(s);
    for(i=0;i<1001;i++)
        d[i]='0';
    if(n==1&&s[0]<'2')
    {
        d[0]='0';
        k=1;
    }
    else
        for(i=0;i<n;i++)
        {
            x=s[i]-48;
            x=c*10+x;
            if(x<2)
            {
		        c=x;
		        if(i!=0)
		        {
			        d[k]='0';
			        k++;
		        }
	        }
            else
            {
                if(k!=0||(x/2)!=0)
                {
                    d[k]=x/2+48;
                    k++;
                }
                if(x%2==1)
                    c=1;
                else
                    c=0;            
            }
        }
        d[k]='\0';
        strcpy(s,d);
}
void mm(int *A,int *X)
{
    int i,j,k;
    int M[2][2]={{0,0},{0,0}};
    for(i=0;i<2;i++)
        for(j=0;j<2;j++)
            for(k=0;k<2;k++)
                M[i][j]=M[i][j]+(*((A+i*2)+k))*(*((X+k*2)+j));
    for(i=0;i<2;i++)
        for(j=0;j<2;j++)
           *((A+i*2)+j)=M[i][j]%100;
}
int main()
{
    char s[1001];
    printf("Enter the value of n:\n");
    scanf("%s",s);
    int n;
    n=strlen(s);
    int i,c=0,k=0,x;
    char d[1001];
    int A[2][2]={{1,1},{1,0}};
    int I[2][2]={{1,0},{0,1}};
    int num=0;
	int m1=0;
    printf("F(%s) is ",s);
    while(s[0]!='0')
    {
        if(s[strlen(s)-1]%2==1)
            mm((int *)I,(int *)A);
        mm((int *)A,(int *)A);
        half(s);
    }
	printf("%d\n",I[1][0]);
    return 0;
}
