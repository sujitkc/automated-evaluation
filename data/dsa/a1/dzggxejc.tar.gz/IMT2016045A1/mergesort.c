#include<stdio.h>
#include<string.h>
void Merge(int A[],int i,int k,int j)
{
	int l=i,r=k+1,a=0;
	int B[j-i+1];
	while(l<=k&&r<=j)
	{
		if(*(A+l)<= *(A+r))
		{
			B[a]=*(A+l);
			a++;
			l++;
		}
		else
		{
			B[a]= (*(A+r));
			a++;
			r++;
		}
	}
	while(l<=k)
	{
		B[a]=*(A+l);
		l++;
		a++;
	}
	while(r<=j)
	{
		B[a]=*(A+r);
		r++;
		a++;
	}
	a=0;l=i;
	for(l=i;l<=j;l++)
	{	
		*(A+l)=B[a];
		a++;
	}
}
void MS(int A[],int i,int j)
{
	int x;
	if(j<=i+1)
	{
		if(*(A+i)>*(A+j))
		{
			int temp=*(A+i);
			*(A+i)=*(A+j);
			*(A+j)=temp;
		}
	}
	else
	{
		int k=(i+j)/2;
		MS(A,i,k);
		MS(A,k+1,j);
		Merge(A,i,k,j);
	}
}
int main()
{
	int n,i;
	printf("Enter the size of array:\n");
	scanf("%d",&n);
	int A[n];
	printf("Enter the elements of array:\n");
	for(i=0;i<n;i++)
		scanf("%d",&A[i]);
	MS(A,0,n-1);
	printf("Sorted array is:\n");
	for(i=0;i<n;i++)
		printf("%d ",A[i]);
	printf("\n");
	return 0;
}
