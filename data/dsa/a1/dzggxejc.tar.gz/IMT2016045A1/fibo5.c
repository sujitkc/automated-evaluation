#include<stdio.h>
#include<string.h>
#include<math.h>
void mm(int *A,int *X)
{
    int i,j,k;
    int M[2][2]={{0,0},{0,0}};
    for(i=0;i<2;i++)
        for(j=0;j<2;j++)
            for(k=0;k<2;k++)
                M[i][j]=M[i][j]+(*((A+i*2)+k))*(*((X+k*2)+j));
    for(i=0;i<2;i++)
        for(j=0;j<2;j++)
           *((A+i*2)+j)=M[i][j]%100;
}	
int main()
{
    char b[1001];
    printf("Enter the number in binary:\n");
    scanf("%s",b);
    int i,c=0,k=0,x;
    char d[1001];
    int A[2][2]={{1,1},{1,0}};
    int I[2][2]={{1,0},{0,1}};
    int num=0;
    int m1=0;	
    i=strlen(b)-1;
    while(i>=0)
    {
        if(b[i]=='1')
            mm((int *)I,(int *)A);
        mm((int *)A,(int *)A);
        i--;
    }
	printf("%d\n",I[1][0]);
    return 0;
}
