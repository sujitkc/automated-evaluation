#include<stdio.h>
#include<stdlib.h>

void selection(int *arr,int n){
	int i,j;
	for(i=0;i<n-1;i++){
		int m=0;
		for(j=1;j<n-i;j++){
			if(arr[j]>arr[m])
				m=j;
		}
		int t=arr[m];
		arr[m]=arr[n-1-i];
		arr[n-1-i]=t;
		
	}
}

int main(){
	int n;
	printf("enter the number of elements: ");
	scanf("%d",&n);
	int i,a[n];
	printf("enter the elements: ");
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	
	selection(a,n);
	printf("sorted array is : ");
	for(i=0;i<n;i++)
		printf("%d ",a[i]);
}


