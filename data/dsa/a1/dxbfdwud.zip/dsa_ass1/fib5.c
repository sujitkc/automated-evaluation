#include<stdio.h>
#include<stdlib.h>

void mm(int one[2][2],int two[2][2]){
	int i,j,k,thr[2][2];
	
	for(i=0;i<2;i++)
      for(j=0;j<2;j++)
           thr[i][j]=0;
           
    for(i=0;i<2;i++){ 
    	for(j=0;j<2;j++){ 
			int sum=0;
        	for(k=0;k<2;k++)
            	sum=sum+one[i][k]*two[k][j];
        	thr[i][j]=sum;
     	 }
    }
    
   for(i=0;i<2;i++)
      for(j=0;j<2;j++)
           one[i][j]=thr[i][j]; 
	
}

void decimaltobin(int *a,int s,int *bi,int m){
	int i,j;
	while(only(a,s)!=1){
		for(i=m-1;i>=0;i++){
			if(a[s-1]%2==0)
				bi[i]=0;
			else
				bi[i]=1;
	
		for(j=0;j<s-1;j++){
			int t=a[j]/2;
			int h=(a[j]%2)*10;
			a[j+1]=h+a[j+1];
			a[j]=t;
				
			}
		}
	}
}


int only(int *a,int s){
	int i,flag=0;
	for(i=0;i<s-1;i++){
		if(a[i]!=0){
			flag=1;
			break;
		}
	}
	if(flag==0 && a[s-1]==1)
		return 1;
	else
		return 0;
}


int power1(int *bi,int m,int a[2][2]){
	int y[2][2]={{1,0},{0,1}};
	int i=m-1;
	while(i>=0){
		if(bi[i]==1)
			mm(y,a);
		mm(a,a);
		i--;
	}	
	return y[1][0];
}
int main(){
	int s,i;
	printf("enter the length of the digit : ");
	scanf("%d",&s);
	int a[s];
	printf("enter the digit ");
	for (i = 0; i<s;++i){
		scanf("%d",a[i]);
	}
	
	int m=s*3.322+1;
	int bi[m];
	
	decimaltobin(a,s,bi,m);
	int arr[2][2]={{1,1},{1,0}};
	int c = power1(bi,m,arr);
	
	printf("fibonacci of a given number is : %d",c);


	return 0;
}
