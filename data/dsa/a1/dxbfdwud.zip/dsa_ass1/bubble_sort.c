#include<stdio.h>
#include<stdlib.h>

void bubble(int *arr,int n){
	int i,j;
	for(i=0;i<n-1;i++){
		for(j=0;j<n-1-i;j++){
			if(arr[j]>arr[j+1]){
				int temp=arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=temp;
			}
		}
	}
}

int main(){
	int n;
	printf("enter the number of elements: ");
	scanf("%d",&n);
	int i,a[n];
	printf("enter the elements: ");
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	
	bubble(a,n);
	printf("sorted array is : ");
	for(i=0;i<n;i++)
		printf("%d ",a[i]);
}


