#include<stdio.h>
#include<stdlib.h>

void insertion(int *arr,int n){
	int i,j;
	for(i=1;i<n;i++){
		int t=arr[i];
		j=i-1;
		while(j>=0 && arr[j]>t){
			arr[j+1]=arr[j];
			j--;
		}
		arr[j+1]=t;
	}
}

int main(){
	int n;
	printf("enter the number of elements: ");
	scanf("%d",&n);
	int i,a[n];
	printf("enter the elements: ");
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	
	insertion(a,n);
	printf("sorted array is : ");
	for(i=0;i<n;i++)
		printf("%d ",a[i]);
}


