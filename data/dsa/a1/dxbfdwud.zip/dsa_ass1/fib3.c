#include<stdio.h>
#include<stdlib.h>

int fib(int n){
	int a=0,b=1,c=(a+b)%100,i;
	for(i=2;i<n;i++){
		a=b;
		b=c;
		c=(a+b)%100;
	}
	return c;
}

int main(){
	int n;
	printf("enter a number : ");
	scanf("%d",&n);
	int hold=fib(n);
	printf("nth fibonacci number is : %d",hold);
}
