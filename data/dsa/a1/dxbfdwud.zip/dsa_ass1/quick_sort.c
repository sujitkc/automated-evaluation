#include<stdio.h>
#include<stdlib.h>

void quicksort(int *a,int i,int j){
	int h;
	if(j<=i);
	
	else{
		int p=randompivot(a,i,j);
		int k=partition(a,i,j,p);
		printf("pivot : %d\n",p);
		printf("partition index :%d\n",k);
		
		for(h=i;h<=j;h++)
			printf("%d ",a[h]); 
		printf("\n");
		quicksort(a,i,k);
		for(h=i;h<=j;h++)
			printf("%d ",a[h]);
		printf("\n"); 
		quicksort(a,k+1,j);
		for(h=i;h<=j;h++)
			printf("%d ",a[h]); 
		printf("\n");
	}
}

int randompivot(int *a,int i,int j){
	
	
		int h=rand() % (j+1-i)+i;
	
	return a[h];
}

int partition(int *a,int i,int j,int p){
	int l=i,r=j;
	while(l<=r){
	
		while( a[l]<=p)
			l++;
		while(a[r]>p)
			r--;
		if(l<r){
			int t=a[l];
			a[l]=a[r];
			a[r]=t;
		}
		if(l==r){
			l++;
			r--;
		}
	
		
	}
	printf("%d %d \n",l, r);
	return r;
}

int main(){
	int n;
	printf("enter the number of elements: ");
	scanf("%d",&n);
	int i,a[n];
	printf("enter the elements: ");
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	
	quicksort(a,0,n-1);
	printf("sorted array is : ");
	for(i=0;i<n;i++)
		printf("%d ",a[i]);
}
