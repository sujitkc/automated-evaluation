#include<stdio.h>
#include<stdlib.h>

int fib(int n){
	int i,arr[n+1];
	arr[0]=0;
	arr[1]=1;
	for(i=2;i<=n;i++)
		arr[i]=(arr[i-1] + arr[i-2])%100;
	return arr[n];
	
}

int main(){
	int n;
	printf("enter a number : ");
	scanf("%d",&n);
	int hold=fib(n);
	printf("nth fibonacci number is : %d",hold);
}
