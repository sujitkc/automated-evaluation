#include<stdio.h>
#include<stdlib.h>

struct node{
	int val;
	struct node *next;
};

struct arr{
	struct node *head;
}a[10000];

void add_ele(){
	int i;
	for(i=0;i<10000;i++)
		a[i].head=NULL;
	
	for(i=1;i<=1000000;i++){
		int index=rand() % 10000;
		int ele = rand() % 1000;
		struct node *curr=(struct node *)malloc(sizeof(struct node));
		curr->val=ele;
		curr->next=NULL;
		if(a[index].head==NULL)
			a[index].head=curr;
		else{
			struct node *new;
			new=a[index].head;
			while(new->next!=NULL)
				new=new->next;
			new->next=curr;
		}
			
	}
	
}


void reduce(){
	int i;
	for(i=0;i<10000;i++){
		if(a[i].head!=NULL) {
			if(a[i].head->next!=NULL){
				int flag=0;
				struct node *new;
				new=a[i].head;
				while(new!=NULL){
					if(new->val%2==0){
						flag=1;
						break;
					}
					else 
						new=new->next;
				}
				
				if(flag==1){
					int max=new->val;
					struct node *max_node;
					max_node=new;
					while(new!=NULL){
						if( new->val%2==0 && new->val>max){
							max=new->val;
							max_node=new;
							new=new->next;
							
						}
						else
							new=new->next;
							
					}
					a[i].head=max_node;
					a[i].head->next=NULL;
					
				}
				
				else{
					struct node *min_node;
					struct node *new1;
					new1=a[i].head;
					min_node=a[i].head;
					int min=a[i].head->val;
					while(new1!=NULL){
						if( new1->val<min){
							min=new1->val;
							min_node=new1;
							new1=new1->next;
							
						}
						else
							new1=new1->next;
							
					}
					
					a[i].head=min_node;
					a[i].head->next=NULL;
						
				}
				
				
			}
		}
	}
}

int final_ele(){
	int i;
	int min=10000,max=-1;
	for(i=0;i<10000;i++){
		if(a[i].head!=NULL) {
			if(a[i].head->val%2==0 && a[i].head->val>max){
				max=a[i].head->val;
			}
			else if(a[i].head->val%2!=0 && a[i].head->val<min){
				min=a[i].head->val;
			}
		}
	}
	
	if(max!=-1)
		return max;
	else 
		return min;

}

int main(){
	add_ele();
	reduce();
	int b=final_ele();
	printf("final  no is : %d",b);
	return 0;
}
		
	
	
	





