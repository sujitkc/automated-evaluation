import math

n=input("enter the number of elements in d : ")
i=0
d=[]
while i<n:
    d.append(input())
    i=i+1

c=2*n
m=int((1+math.sqrt(1+4*c))/2)
maxx=max(d)
xd={}
x=[0,maxx]
d.remove(maxx)
mx=max(d)
x2=[]

def turn_pike1(d,x,xd,x2,mx,m,maxx):
    print x, d
    print mx
    if len(x)==m and len(d)==0:
        x=x.sort()
        return x
    else:
        
        d1=[]
        flag=0
        for i in x:
            a=abs(mx-i)
            if a in d:
                d.remove(a)
                d1.append(a)
            else:
                flag=1
                break

        if flag==0:
            xd[mx]=d1
            x.append(mx)
            d2=[]
            for i in d:
                if i not in x2 and i not in x:
                    d2.append(i)
            turn_pike1(d,x,xd,x2,max(d2),m,maxx)
            
        else:
            for i in d1:
                d.append(i)
            if maxx-mx in xd.keys():
                if xd[maxx-mx]==-1:
                    xd[mx]=-1
            if maxx-mx in xd.keys() and mx in xd.keys():
                if xd[maxx-mx]==-1 and xd[mx]==-1:
                    del xd[mx]
                    del xd[maxx-mx]
                    l=len(x)-1
                    h=[]
                    if x[l] in xd.keys():
                        print type(xd[x[l]])
                        for k in xd[x[l]]:
                            h.append(k)
                    for j in h:
                        d.append(j)

                    l=len(x)-1
                    x2.append(x[l])
                    if len(x)>2:
                        x.remove(x[l])
                    else:
                        return 0
                
                    d2=[]
                    for i in d:
                        if i not in x2:
                            d2.append(i)

                    turn_pike1(d,x,xd,x2,max(d2),m,maxx)
                
            xd[mx]=-1
            if (xd[mx]==-1 and maxx-mx not in xd.keys()) or (xd[mx]==-1 and xd[maxx-mx]!=-1):
                turn_pike1(d,x,xd,x2,maxx-mx,m,maxx)

        
x1=turn_pike1(d,x,xd,x2,mx,m,maxx)
if x1==0:
    print "np solution"
else:
    print x1


    
     
    
