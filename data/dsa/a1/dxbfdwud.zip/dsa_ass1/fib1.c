#include<stdio.h>
#include<stdlib.h>

int fib(int n){
	if(n<2)
		return n;
	else
		return (fib(n-1) + fib(n-2))%100;
}

int main(){
	int n;
	printf("enter a number : ");
	scanf("%d",&n);
	int hold=fib(n);
	printf("nth fibonacci number is : %d",hold);
	
}
