#include<stdio.h>

int m,linear(int );

void main(){
	printf("enter the number");
	scanf("%d",&m);
	printf("%d",linear(m));
}


int linear(int n){
	int a = 0;
	int b = 1;
	int c = n;
	int i;
	for(i=2;i<=n;i++){
		c=(a+b)%100;
		a=b;
		b=c;	
	}
	return c;
}
