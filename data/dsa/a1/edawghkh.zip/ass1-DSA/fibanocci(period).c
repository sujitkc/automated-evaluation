#include<stdio.h>
#include<stdlib.h>

int linear(int,int),reminder(int array[],int ),find_period(int),i,d;


void main(){
	srand(time(NULL));
	int array[1000];
	for(i=0;i<1000;i++){
		array[i] = rand()%10;
	}
	printf("enter the number");
	scanf("%d",&d);
	int period = find_period(d);
	int r=reminder(array,period);
	printf("%d",linear(r,d));
}


int linear(int n,int m){
	int a = 0;
	int b = 1;
	int c = n;
	int i;
	for(i=2;i<=n;i++){
		c=(a+b)%m;
		a=b;
		b=c;	
	}
	return c;
}

int find_period(int d){
  int i=2,a,b;
  a=linear(2,d);
  for(i=3;i<=6*d;i++){
    b=linear(i,d);
    if(a==0 && b==1) break;
    a=b;
  }
//  printf("%d",i-1);
  return i-1;

}

int reminder(int array[], int n){
	int i,m;
	int remainder1=0;
	m=sizeof(array)/sizeof(int);
	for(i=0;i<m;i++){
		remainder1 = (remainder1*10 + array[i])%n;
	}
	return remainder1 ;
}




