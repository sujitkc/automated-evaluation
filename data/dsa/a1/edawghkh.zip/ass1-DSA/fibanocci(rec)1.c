#include<stdio.h>

int rec(int  ),m;

void main(){
	printf("enter the number");
	scanf("%d",&m);
	printf("%d",rec(m));	
}



int rec(int n){
	if(n<2 && n>=0){
		return(n);
	}
	else if(n>=2){
		return((rec(n-1)+rec(n-2))%100);
	}
}
