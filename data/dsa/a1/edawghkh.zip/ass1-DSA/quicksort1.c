#include<stdio.h>
#include<stdlib.h>
int partition(int start,int end,int array[]),l,n,i;
void quicksort(int start,int end,int array[]);
void swap(int *m,int *n);

void main(){
	printf("enter the size of array");
	scanf("%d",&n);
	int array[n];
	printf("enter %d numbers",n);
	for(i=0;i<n;i++){
		scanf("%d",&array[i]);
	}
	quicksort(0,n-1,array);
	for(l=0;l<n;l++){
		printf("%d\n",array[l]);
	}
}


int partition(int start,int end,int array[]){
	int pivotindex=start, r= start+rand()%(end-start+1);
	int pivot = array[r];
	int i;
	swap(&array[r],&array[end]);
	for(i=start;i<end;i++){
		if(array[i] < pivot){
			swap(&array[pivotindex],&array[i]);
			pivotindex++;
		}
	}
	swap(&array[pivotindex],&array[end]);
	return(pivotindex);
}

void quicksort(int start,int end,int array[]){
	if(start<end){
		int pivotindex = partition(start,end,array);
		quicksort(start,pivotindex-1,array);
		quicksort(pivotindex+1,end,array);
	}
}

void swap(int *m,int *n){
	int temp;
	temp = *m;
	*m = *n;
	*n = temp;
}
