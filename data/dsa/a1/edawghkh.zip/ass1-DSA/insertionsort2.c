#include<stdio.h>

int n,i,j,k,l,m,n,o,p,temp;
void swap(int ,int );




void main(){
	printf("enter the size of array");
	scanf("%d",&n);
	int array[n];
	printf("enter %d numbers",n);
	for(i=0;i<n;i++){
		scanf("%d",&array[i]);
	}
	
	for(j=1;j<n;j++){
		k=array[j];
		for(i=j-1;i>=0 && k<array[i];i--)
			array[i+1]=array[i];
			array[i+1]=k;
			
		
	}
		
	for(l=0;l<n;l++){
		printf("%d\n",array[l]);
	}
}
void swap(int m ,int p){
		temp=m;
		m=p;
		p=temp;
	}
