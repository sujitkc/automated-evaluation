 #include<stdio.h>
 int power(int ),m;
 
 void main(){
 	printf("enter the number");
	scanf("%d",&m);
	printf("%d",power(m));
 }
 
 
 int power(int n){
 	int a[n][2][2],i;
 	a[0][0][0]=1;
    a[0][0][1]=1;
    a[0][1][0]=1;
    a[0][1][1]=0;
    for(i=0;i<n-1;i++){
    	a[i+1][0][0]=a[i][0][0]*1+a[i][0][1]*1;
    	a[i+1][0][1]=a[i][0][0]*1+a[i][0][1]*0;
    	a[i+1][1][0]=a[i][1][0]*1+a[i][1][1]*1;
    	a[i+1][1][1]=a[i][1][0]*1+a[i][1][1]*0;
	}
	return a[n-1][1][0];
 }
