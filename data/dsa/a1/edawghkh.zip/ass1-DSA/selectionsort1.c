#include<stdio.h>

int n,i,j,k,l,m,n,o,p,temp;
void swap(int ,int );




void main(){
	printf("enter the size of array");
	scanf("%d",&n);
	int array[n];
	printf("enter %d numbers",n);
	for(i=0;i<n;i++){
		scanf("%d",&array[i]);
	}
	for(j=0;j<n;j++){
		int temp;
			m=j;
		for(i=j+1;i<n;i++){
		  
			if(array[i] < array[m]){
				m = i;
			}
		}
		
			temp=array[j];
			array[j]=array[m];
			array[m]=temp;	
	}
	for(l=0;l<n;l++){
		printf("%d\n",array[l]);
	}
}


 
