#include<stdio.h>
#include<stdlib.h>

void merge(int left[],int s,int k,int e);
int l,n,i,mergesort(int array[],int s,int e);


void main()
{
	printf("enter the size of array");
	scanf("%d",&n);
	int array[n];
	printf("enter %d numbers",n);
	for(i=0;i<n;i++){
		scanf("%d",&array[i]);
	}
	mergesort(array,0,n-1);
	for(l=0;l<n;l++){
		printf("%d",array[l]);
	}

}


int mergesort(int array[],int s,int e){
	//int n = sizeof(array)/sizeof(int);
	//printf("hell=%d\n",sizeof(array));
	//BASE
	int temp;
	if(e<=s+1){
		if(array[s]>array[e]){
			temp=array[s];
			array[s]=array[e];
			array[e]=temp;
		}
	}
	//RECURSIVE
	else{
		int i;
		int mid = (s+e)/2;
		mergesort(array,s,mid);
		mergesort(array,mid+1,e);
		merge(array,s,mid,e);
	}

}

void merge(int array[],int s,int k,int e){
	int i=0,j=0,sol[e-s+1];
	int nl=s,nr=k+1,ns=0;
	while(nl<=k && nr<=e){
		if(array[nl]<array[nr]){
			sol[ns]=array[nl];
			nl++;
			ns++;
		}
		else{
			sol[ns]=array[nr];
			nr++;
			ns++;
		}
	}
	while(nl<=k) sol[ns++]=array[nl++];
	while(nr<=e) sol[ns++]=array[nr++];

	for(i=s;i<=e;i++) array[i]=sol[i];
	}
