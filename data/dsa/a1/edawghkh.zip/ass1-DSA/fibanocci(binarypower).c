 #include<stdio.h>
 #include<math.h>
 int power(int ),m,i,n;
 
 void main(){
	printf("enter the bit size of the binary");
	scanf("%d",&n);
	int array[n];
	printf("enter %d numbers",n);
	for(i=0;i<n;i++){
		scanf("%d",&array[i]);
	}
	int numb=0;
	for(i=0;i<n;i++){
		numb = numb + array[n-1-i]*pow(2,i);	
	}
	printf("%d",power(numb));
 }
 
 
 int power(int n){
 	int a[n][2][2],i;
 	a[0][0][0]=1;
    a[0][0][1]=1;
    a[0][1][0]=1;
    a[0][1][1]=0;
    for(i=0;i<n-1;i++){
    	a[i+1][0][0]=a[i][0][0]*1+a[i][0][1]*1;
    	a[i+1][0][1]=a[i][0][0]*1+a[i][0][1]*0;
    	a[i+1][1][0]=a[i][1][0]*1+a[i][1][1]*1;
    	a[i+1][1][1]=a[i][1][0]*1+a[i][1][1]*0;
	}
	return a[n-1][1][0];
 }
