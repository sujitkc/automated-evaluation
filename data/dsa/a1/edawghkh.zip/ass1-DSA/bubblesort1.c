#include<stdio.h>

int n,i,j,k,l,temp,n,o,p;
void swap(int ,int );




void main(){

	printf("enter the size of array");
	scanf("%d",&n);
	int array[n];
	printf("enter %d numbers",n);
	for(i=0;i<n;i++){
		scanf("%d",&array[i]);
	}
	
	for(j=0;j<n;++j){
		for(k=0;k<n-j-1;++k){  
			if(array[k] > array[k+1]){
				temp = array[k];
				array[k] = array[k+1];
				array[k+1] = temp;
			}
		}
	}
	for(i=0;i<n;i++){
		printf("%d\n",array[i]);
	}
}
void swap(int m ,int p){
		temp=m;
		m=p;
		p=temp;
	}

