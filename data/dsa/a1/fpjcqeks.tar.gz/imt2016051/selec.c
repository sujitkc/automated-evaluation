#include <stdio.h>
#include<stdlib.h>
void Swap(int *a ,int *b){
	int k;
	k=*a;
	*a=*b;
	*b=k;
}
int max(int *x,int k)
{
	int t,i,pos;
	t=x[0];
	pos=0;
	for(i=1;i<=k;i++)
        {
		if(x[i]>t){
			t=x[i];
			pos=i;
		}
	}
	return(pos);
}
void SelectionSort(int *x ,int s){
	int c,d;
	c=s-1;
	while(c>=0){
		d=max(x,c);
		Swap(&x[d],&x[c]);
		c--;
	}
}
int main()
{
	int i,n=25;
	int a[n];
	for(i=n-1;i>=0;i--){
		a[i]=rand()%50;
	}

	SelectionSort(a,n);
	for (int i = 0; i < n; i++)
	{
		printf(" %d,",a[i]);
	}
return 0;
}
