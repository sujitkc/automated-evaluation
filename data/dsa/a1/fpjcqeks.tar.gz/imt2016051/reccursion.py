def fib(n):
	if(n<0):
		print "invaild input"
	else:
		if(n<=1):
			return n
		else:
			return (fib(n-1)+fib(n-2))%100


x=25
print fib(x)

