#include <stdio.h>
#include<stdlib.h>
void Swap(int *a ,int *b){
	int k;
	k=*a;
	*a=*b;
	*b=k;
} 
void Sort(int *a ,int n){
	int i,j;

	for(i=1;i<n;i++){
		j=i-1;
		while( j<i && j>=0){
			if (a[j]>a[j+1]){
				Swap(&a[j+1],&a[j]);
			}
			j--;
		}	
	}
}
int main()
{
	int i,n;
	n=25;
	int a[n];
	for(i=0;i<n;i++)
		a[i]=rand()%50;
	Sort(a,n);
	for (int i = 0; i < n; ++i)
	{
		printf(" %d,",a[i]);
	}
	return 0;
}
