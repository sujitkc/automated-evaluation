#include<stdio.h>
void Swap(int *a ,int *b){
	int k;
	k=*a;
	*a=*b;
	*b=k;
}
void quicksort(int *a,int p,int r)
int q;
if(p<r)
{
	q=partition(a,p,r);
	quicksort(a,p,q-1);
	quicksort(a,q+1,r);
}
void partition(*a,int p,int r){
	int x,i,j;
	x=a[r];
	i=p-1;
	for(j=p;j<r-1;j++)
	{
		if(a[j]<=x)
        	{
        		i=i+1;
			swap(a[i],a[j]);
		}
		else
		{
			swap(a[i+1],a[r]);
		}
	return i+1;
	}
}
int main()
{
	
	int i,n;
	n=25;
	int a[n];
	for(i=0;i<n;i++)
		a[i]=rand()%50;
	quicksort(a,0,n);
	for (int i = 0; i < n; ++i)
	{
		printf(" %d,",a[i]);
	}
	return 0;
}

		
