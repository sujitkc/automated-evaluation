#include <stdio.h>
#include<stdlib.h>
void Swap(int *a ,int *b){
	int k;
	k=*a;
	*a=*b;
	*b=k;
} 
void BubbleSort(int *a ,int n){
	int i,j;
	for (i=0;i<n-1;i++){
		for (j=0;j<n-i-1;j++){
			if (a[j]>a[j+1])
				Swap(&a[j],&a[j+1]);
		}
	}
}
int main()
{
	int i,n;
	n=25;
	int a[n];
	for(i=0;i<n;i++){
		a[i]=rand()%50;}
	BubbleSort(a,n);
	for (int i = 0; i < n; ++i)
	{
		printf(" %d,",a[i]);
	}
	return 0;
}
