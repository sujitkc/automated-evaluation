#include<stdio.h>
#include<stdlib.h>
int fibo(int n){
	if(n==1)
		return 0;
	if(n==2)
		return 1;
	else
		return (fibo(n-1)+fibo(n-2))%100;
}
void main(){
	int p;
	printf("Give any number 'p' : ");
	scanf("%d",&p);
	printf("THe above-given-p th fibonacci number is : %d",fibo(p));
}
