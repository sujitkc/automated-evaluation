#include<stdio.h>
#include<stdlib.h>
void sortingpart(int arr[],int i,int j){
	int pivot,pivotp;
	srand(time(NULL));
	pivotp=i+rand()%(j-i);
	pivot=arr[pivotp];
	int a,b;
	if(pivotp!=0)
		a=0;
	if(pivotp==0)
		a=1;
	b=a;
	while(b<=j){
		if(arr[b]>pivot){
			int temp;
			temp=arr[b];
			arr[b]=arr[a];
			arr[a]=temp;
			if(a+1==pivotp)
				a+=2;
			else
				a++;
		}
		b++;
		if(b==pivotp)
			b++;
	}
	int temp;
	temp=arr[pivotp];
	arr[pivotp]=arr[a];
	arr[a]=temp;
	sortingpart(arr,i,a-1);
	sortingpart(arr,a+1,j);
}
main(){
	int i,j,arr[]={6,5,3,1,8,7,2,4,9},temp;
	int n=9;
	/*
	srand(time(NULL));
	for(i=0;i<n;i++){	
		arr[i]=rand()%n;
	}
	*/
	sortingpart(arr,0,n-1);
	
	for(i=0;i<n;i++){
		printf("%d\n",arr[i]);
	}
	
}
