#include<stdio.h>
#include<stdlib.h>
main(){
	int i,j,arr[10000],temp;
	int n=10000;
	srand(time(NULL));
	for(i=0;i<n;i++){	
		arr[i]=rand()%n;
	}
	for(i=1;i<n;i++){
		j=i-1;
		while(j>=0 && arr[j]>arr[j+1]){
			temp=arr[j+1];
			arr[j+1]=arr[j];
			arr[j]=temp;
			j--;
		}
	}
	/*
	for(i=0;i<n;i++){
		printf("%d\n",arr[i]);
	}
	*/
}
