#include<stdio.h>
#include<stdlib.h>
struct node {
	int value;
	int pos;
	struct node *nxt;
};
struct node starts[10000];
struct node *current;
void addnode(struct node *s,int n,struct node *neww){
	printf("Give a vlaue for the nth node : ");
	scanf("%d",&new.value);
	&new.pos=n;
	if(n==2){
		*s.nxt=*neww;
	}
	*current=*s;
	if(n>2){
		int i=1;
		while(i<n){
			*current=*current.nxt;
		}
		*current.nxt=*neww;
	}
}
void deletenode(struct node *s,int n,struct node neww){
	
}
