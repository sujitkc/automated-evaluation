#include<stdio.h>
#include<stdlib.h>
void main(){
	int i,a=0,b=1,n,c;
	printf("Give the n whose 'th' fibonacci number you want to seek : ");
	scanf("%d",&n);
	for(i=2;i<=n;i++){
		c=(a+b)%100;
		a=b;
		b=c;
	}
	printf("The nth fibonacci number is : %d",c);
}
