#include<stdio.h>
#include<stdlib.h>
void main(){
	int i,n,arr[100000];
	arr[0]=0;
	arr[1]=1;
	printf("Give the 'arrayal' index of the fibonacci number you want : ");
	scanf("%d",&n);
	for(i=2;i<n+1;i++){
		arr[i]=(arr[i-1]+arr[i-2])%100;
	}
	printf("The number is : %d",arr[n]);
}
