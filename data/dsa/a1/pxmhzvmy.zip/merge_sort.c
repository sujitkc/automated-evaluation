#include<stdio.h>
#include<stdlib.h>
void merge(int arr[],int i,int k,int j){
	int l=i;
	int r=k+1;
	int x=0,brr[j+1];
	int y;
	while(l<=k && r<=j){
		if(arr[l]<arr[r])
			brr[x++]=arr[l++];
		else
			brr[x++]=arr[r++];
	}
	while(l<=k)
		brr[x++]=arr[l++];
	while(r<=j)
		brr[x++]=arr[r++];	
	x=0;
	for(y=i;y<=j;y++)
		arr[y]=brr[x++];	
}
void sortingpart(int arr[],int i,int j){
	if(j-i==1){
		if(arr[i]>arr[j]){
			int temp;
			temp=arr[i];
			arr[i]=arr[j];
			arr[j]=temp;
		}
	}
	if(j-i>1){
		sortingpart(arr,i,(i+j)/2);
		sortingpart(arr,(i+j)/2+1,j);
		merge(arr,i,(i+j)/2,j);
	}
}
main(){
	int i,j,arr[10000],temp;
	int n=10000;
	srand(time(NULL));
	for(i=0;i<n;i++){	
		arr[i]=rand()%n;
	}
	sortingpart(arr,0,n-1);
	/*
	for(i=0;i<n;i++){
		printf("%d\n",arr[i]);
	}
	*/
}
