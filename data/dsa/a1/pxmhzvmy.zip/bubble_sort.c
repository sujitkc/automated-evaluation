#include<stdio.h>
#include<stdlib.h>
main(){
	int i,j,arr[10000],temp;
	int n=10000;
	srand(time(NULL));
	for(i=0;i<n;i++){	
		arr[i]=rand()%n;
	}
	for(i=0;i<n;i++){
		for(j=0;j<i-1;j++){
			if(arr[i]<arr[j]){
				temp=arr[j];
				arr[j]=arr[i];
				arr[i]=temp;
			}
		}
	}
	/*
	for(i=0;i<n;i++){
		printf("%d\n",arr[i]);
	}
	*/
}
