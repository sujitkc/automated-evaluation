#include<stdio.h>
#include<stdlib.h>
void matrixmultiply(int arr[2][2],int brr[2][2],int mrr[2][2]){
	mrr[0][0]=arr[0][0]*brr[0][0]+arr[0][1]*brr[1][0];
	mrr[0][1]=arr[0][0]*brr[0][1]+arr[0][1]*brr[1][1];
	mrr[1][0]=arr[1][0]*brr[0][0]+arr[1][1]*brr[1][0];
	mrr[1][1]=arr[1][0]*brr[0][1]+arr[1][1]*brr[1][1];
}
int powery(int arr[2][2],int n,int brr[2][2]){
	int i,j,irr[2][2],mrr[2][2];
	irr[0][0]=1;
	irr[0][1]=0;
	irr[1][0]=0;
	irr[1][1]=1;
	if(n==1){
		matrixmultiply(arr,irr,brr);
	}
	if(n==2){
		matrixmultiply(arr,arr,brr);
	}
	if(n>2 && n%2==0){
		matrixmultiply(arr,arr,mrr);
		powery(mrr,n/2,brr);
	}
	if(n>2 && n%2!=0){
		matrixmultiply(arr,arr,brr);
		powery(brr,n/2,mrr);
		matrixmultiply(arr,mrr,brr);
	}
}
void main(){
	int i,j,n,arr[2][2],brr[2][2];
	arr[0][0]=1;
	arr[0][1]=1;
	arr[1][0]=1;
	arr[1][1]=0;
	printf("Give any n : ");
	scanf("%d",&n);
	powery(arr,n-1,brr);
	if(n>=2)
		printf("That nth fibonacci number is : %d",brr[1][0]);
	if(n==1)
		printf("That nth fibonacci number is : 0");
}
